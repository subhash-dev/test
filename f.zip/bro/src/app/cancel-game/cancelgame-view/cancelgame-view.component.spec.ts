import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelgameViewComponent } from './cancelgame-view.component';

describe('CancelgameViewComponent', () => {
  let component: CancelgameViewComponent;
  let fixture: ComponentFixture<CancelgameViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CancelgameViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelgameViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
