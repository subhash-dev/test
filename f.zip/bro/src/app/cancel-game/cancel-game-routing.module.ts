import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../auth-gaurd/auth-guard.service';
import { CancelGameComponent } from './cancel-game.component';
import { RoleGuard } from '../auth-gaurd/role-guard.service';
import { CancelgameViewComponent } from './cancelgame-view/cancelgame-view.component';

const routes: Routes = [{
  path: "cancelgame",
  canActivate: [AuthGuard],
  component: CancelGameComponent,
  children: [
    {
      path: "view",
      canActivate: [AuthGuard, RoleGuard],
      component: CancelgameViewComponent,
    },
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CancelGameRoutingModule { }
