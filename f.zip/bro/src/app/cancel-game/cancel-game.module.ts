import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CancelGameRoutingModule } from './cancel-game-routing.module';
import { CancelGameComponent } from './cancel-game.component';
import { CancelgameViewComponent } from './cancelgame-view/cancelgame-view.component';
import { DataTablesModule } from 'angular-datatables';
import { FormsModule } from '@angular/forms';
import {ModalModule} from 'ngx-bootstrap';
import { NgbDateParserFormatter, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateMomentParserFormatter } from '../auth-gaurd/date_format';
@NgModule({
  declarations: [CancelGameComponent, CancelgameViewComponent],
  imports: [
    CommonModule,
    CancelGameRoutingModule,
    DataTablesModule,
    FormsModule,
    NgbModule,
    ModalModule.forRoot(),
  ],providers: [
    {
      provide: NgbDateParserFormatter,
      useFactory: () => { return new NgbDateMomentParserFormatter('DD-MM-YYYY') }
    }
  ],
})
export class CancelGameModule { }
