import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelGameComponent } from './cancel-game.component';

describe('CancelGameComponent', () => {
  let component: CancelGameComponent;
  let fixture: ComponentFixture<CancelGameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CancelGameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelGameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
