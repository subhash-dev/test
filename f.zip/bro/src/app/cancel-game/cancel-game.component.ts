import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-game',
  templateUrl: './cancel-game.component.html',
  styleUrls: ['./cancel-game.component.scss']
})
export class CancelGameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
