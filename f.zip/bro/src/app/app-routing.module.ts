import {DashboardComponent} from './dashboard/dashboard.component';
import {LoginComponent} from './login/login.component';
import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {AccessDeniedComponent} from './access-denied/access-denied.component';
import {RoleGuard} from './auth-gaurd/role-guard.service';
import {AuthGuard} from './auth-gaurd/auth-guard.service';
import {GameBlockComponent} from './game-block/game-block.component';
import {CurrancySettingComponent} from './currancy-setting/currancy-setting.component';
import {RestrictionComponent} from './restriction/restriction.component';
import {LiveTvComponent} from './live-tv/live-tv.component';
import {ReactionComponent} from './reaction/reaction.component';
import {RemoveEventComponent} from './remove-event/remove-event.component';
import { from } from 'rxjs';

const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'login', component: LoginComponent},
  {path: 'dashboard', component: DashboardComponent,  canActivate: [AuthGuard,RoleGuard]},
  {path: 'accessdenied', component: AccessDeniedComponent,  canActivate: [AuthGuard,RoleGuard]},
  {path: 'game-lock', component: GameBlockComponent,  canActivate: [AuthGuard,RoleGuard]},
  {path: 'live-tv', component: LiveTvComponent,  canActivate: [AuthGuard,RoleGuard]},
  {path: 'currency-setting', component: CurrancySettingComponent,  canActivate: [AuthGuard,RoleGuard]},
  {path: 'restriction-setting', component: RestrictionComponent,  canActivate: [AuthGuard,RoleGuard]},
  {path: 'reaction', component: ReactionComponent,  canActivate: [AuthGuard,RoleGuard]},
  {path: 'remove/event', component: RemoveEventComponent,  canActivate: [AuthGuard,RoleGuard]}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
