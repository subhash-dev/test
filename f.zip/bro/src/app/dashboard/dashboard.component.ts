import { Component, OnInit } from '@angular/core';
import * as env from '../globals/env';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor() { }
  siteName: any;
  ngOnInit() {
    this.siteName = env.site_name();
  }
}
