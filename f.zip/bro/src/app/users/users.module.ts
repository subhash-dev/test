import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersRoutingModule } from './users-routing.module';
import { UserComponent } from './user.component';
import { UserViewComponent } from './user-view/user-view.component';
import {HttpClientModule} from '@angular/common/http';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ModalModule} from 'ngx-bootstrap';
import {BrowserModule} from '@angular/platform-browser';
import {DemoMaterialModule} from '../../material-module';
import {FormsModule} from '@angular/forms';
import {AngularMultiSelectModule} from 'angular2-multiselect-dropdown';
import { DataTablesModule } from 'angular-datatables';


@NgModule({
  declarations: [UserComponent, UserViewComponent],
  imports: [
    CommonModule,
    UsersRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    FormsModule,
    HttpClientModule,
    ModalModule.forRoot(),
    AngularMultiSelectModule,
    NgbModule,
    DataTablesModule
  ]
})
export class UsersModule { }
