import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {UserComponent} from './user.component';
import {UserViewComponent} from './user-view/user-view.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path: 'user',
  canActivate: [AuthGuard],
  component: UserComponent,
  children: [
    {
      path: 'view',
      canActivate: [AuthGuard, RoleGuard],
      component: UserViewComponent,
    },

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule {
}
