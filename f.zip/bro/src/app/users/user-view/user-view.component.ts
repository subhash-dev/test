import {ModalDirective} from 'ngx-bootstrap';
import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild,ElementRef} from '@angular/core';
import {RoleService} from '../../services/role.service';
import {UserService} from '../../services/user.service';
import {UtilityService} from '../../globals/utilityService';
import {isUndefined} from 'util';
import {Router} from '@angular/router';
import {ToasterConfig} from 'angular2-toaster';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as env from '../../globals/env';
import {NgxSpinnerService} from "ngx-spinner";
var aes256 = require('aes256');
declare let $: any;

class User {
  name: string;
  username:string;
  role:string;
  isActive: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}


@Component({
  selector: 'app-user-view',
  templateUrl: './user-view.component.html',
  styleUrls: ['./user-view.component.scss']
})
export class UserViewComponent implements OnInit {
  @ViewChild('modal', {static: false}) modal: ModalDirective;
  @ViewChild('resetPassModal', {static: false}) resetPassModal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild("addUserForm", {static: false}) formResetValue;
  @ViewChild("conformationForm", {static: false}) resetPasswordForm;
  // @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('focusInput' ,  {static: false}) focusInput: ElementRef;
  @ViewChild('focusText' ,  {static: false}) focusText: ElementRef;
  @ViewChild('focusResetpass' ,  {static: false}) focusResetpass: ElementRef;

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();

  users: User[];
  resData;
  server_url: any = env.server_url();


  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  resetPasswordParams:any;
  constructor(private roleService: RoleService,
              private userService: UserService,
              private chRef: ChangeDetectorRef,
              private utilityService: UtilityService,
              private router: Router,
              private spinner: NgxSpinnerService,
              private http: HttpClient
              ) {
  }
  dataTable: any;
  addUserObject ={
    name:null,
    username:null,
    password:null,
    role:null,
    parent_user_id: this.utilityService.returnLocalStorageData('userId')
  };

  roleFilter = {
    page: 1,
    limit: -1,
    search: null
  };
  roleList = [];
  roleUserList:any;
  selectedRoleItems = [];
  roleSettings = {
    singleSelection: true,
    text: 'Select role',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
  };
  editForm = false;//to show and hide add and update form data in single pop-up
  tempUserId :any;//set user id for reset password
  conformationPassword:any;//set conform password for update data
  tempUserData:any;
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.resetPasswordForm.resetForm();
      // this.getUser();
      this.rerender();
    }
  }
  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if(event.sourceCapabilities) {

    }else {
      this.setFocusToInput();
    }
  }
  ngOnInit() {
    if(isUndefined(this.utilityService.returnAccessRole('USER'))){
      this.router.navigate(['accessdenied']);
    }else{
      this.accessRole = this.utilityService.returnAccessRole('USER');
    }
    this.getRoles();
    this.getUsersDt();
    //this.getUser();
  }

  setFocusToInput() {
    this.focusInput.nativeElement.focus();
    this.focusText.nativeElement.focus();
    this.focusResetpass.nativeElement.focus();
  }

  /**
   * @author kc
   * @date : 03-02-2020;
   */
  getRoles() {
    this.roleService.getAllRoles(this.roleFilter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.roleList = response.data.docs.map(data => {
            return {id: data._id, itemName: data.role_name, modules: data.modules};
        });
    }, error => {
      console.error('get all role error');
    });
  }

    /**
   * @author rk
   * @date : 27-02-2020;
   */

  getUsersDt(){
    this.spinner.show();
    this.rerender();
    const that = this;
    let url = this.server_url + 'user/get-all';
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            dataTablesParameters,
            {}
          ).subscribe(resp => {
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData =JSON.parse(this.resData);
              this.resData = this.resData.data;
              this.spinner.hide();
              console.log(this.resData);
            if(this.resData.docs.length > 0){
              this.users = this.resData.docs;
            }else{
              this.users = null;
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },

      columns: [{ data: '' },{ data: 'name' },{ data: 'username' },{ data: 'role' },{ data: 'updatedAt' },{ data: 'isActive' },{ data: '' }],
      columnDefs: [{orderable: false, targets: [0]}],
    };
  }

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }

  /**
   * @author kc
   * @date : 03-02-2020;
   * Get User Data
   */
  getUser() {
    this.roleService.getAllUserData(this.roleFilter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
		response =JSON.parse(response);
        this.roleUserList = response.data;
        this.chRef.detectChanges();
        const table: any = $('table');
        this.dataTable = table.DataTable({
            // serverSide : true,
            // processing : true,
            // data : this.roleUserList
            // ajax: {
            //   type: "GET",
            //   url: 'http://localhost:5060/digi/api/v1/user?page=1&limit=10',
            //   contentType: 'application/json; charset=utf-8',
            //   data: data => {
            //     console.log(data);
            //     return data = JSON.stringify(data);
            //   }
            // },
        });


        }, error => {
        console.error('get all role error');
        });
  }

  /**
   * @author kc
   * @date : 03-02-2020;
   * role search with name
   */
  onRoleSearch(e) {
    this.roleFilter.search = e.target.value;
    this.getRoles();
  }


  openModel(){
    this.addUserObject ={
      name:null,
      username:null,
      password:null,
      role:null,
      parent_user_id: this.utilityService.returnLocalStorageData('userId')
    };
    this.formResetValue.resetForm();
    this.editForm = false;
    this.modal.show();
  }
  closeModel(data){
    if(data === 'conformation'){
      this.conformationModal.hide();
      // this.getUser();
      this.rerender();
    }else{
      this.modal.hide();
    }

  }

  /**
   * @author kc
   * @date : 03-02-2020;
   * create office admin user
   */
  createNewUser() {
    this.addUserObject.role = this.selectedRoleItems[0]['id'];
    this.addUserObject['userType'] = 'STAFF';
    this.addUserObject['modulesAccessIds'] = this.selectedRoleItems.map(roles =>{
          let modulesIds = roles.modules.map(modulesData =>{
            let data = {
              id : modulesData._id
            };
            return data;
          });
          return modulesIds;
    })[0];
    this.userService.creteUser(this.addUserObject).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
            if(response.status == "true"){
                this.modal.hide();
                //this.getUser();
                this.rerender();
                this.utilityService.popToast('success','Success', 3000 , 'User created successfully.');
            }else{
                //console.log("smake");
                this.utilityService.popToast('error','Error', 3000 , response.message);
            }
    },error =>{
            this.utilityService.popToast('error','Error', 3000 , error.error.message);
            console.error("error in add user", error);
    });
  }

  /**
   * get user by user id
   * @param id
   */
  getUserDetailById(id){
    this.userService.getUserById(id).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
		response =JSON.parse(response);
        this.addUserObject = response.data;
        this.selectedRoleItems = [
          {
            id: this.addUserObject.role._id ,
            itemName: this.addUserObject.role.role_name
          }
        ];
        this.editForm = true;
        this.modal.show();
      },error =>{
        console.error("get user error", error);
      });
  }

  /**
   * update user basic data with user id
   */
  updateUserData(){

    if(this.selectedRoleItems && this.selectedRoleItems[0]['modules']){
      this.addUserObject.role = this.selectedRoleItems[0]['id'];
      this.addUserObject['modulesAccessIds'] = this.selectedRoleItems.map(roles =>{
        let modulesIds = roles.modules.map(modulesData =>{
          let data = {
            id : modulesData._id
          };
          return data;
        });
        return modulesIds;
      })[0];
    }
    this.userService.updateUser(this.addUserObject).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
		response =JSON.parse(response);
        if(response.status === true){
          this.modal.hide();
          this.getUser();
          this.utilityService.popToast('success','Success', 3000 , 'User updated successfully.');
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      },errors =>{
        console.error("error in upadate user");
      });
  }

  /**
   * reset user password
   * @param data
   */
  resetPasswordOpenModal(data){
    this.tempUserId = data;//set user id for reset password
    this.resetPasswordForm.resetForm();
    this.resetPassModal.show();
  }

  /**
   * reset password closed
   */
  closePasswordModel(){
    this.resetPassModal.hide();
  }

  /**
   * reset password api call
   */
  resetPasswordFn(){
    let data = {
      id : this.tempUserId,
      password : this.resetPasswordParams
    };
    this.userService.resetPassword(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
		response =JSON.parse(response);
        if(response.status === true){
          this.resetPassModal.hide();
          this.utilityService.popToast('success','Success', 3000 , response.message);
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      },error =>{
        console.error("error in reset password");
      })
  }

  showConformationModal(data, usr){
    this.tempUserData = usr; /*store data for update user status*/
    this.resetPasswordForm.resetForm();
    this.conformationModal.show();
  }

  updateUserStatus(){
    let key = env.constantKey();
    let token = this.conformationPassword;
    var encrypted = aes256.encrypt(key, token);
    this.tempUserData['token'] = encrypted;
            this.userService.updateUser(this.tempUserData).subscribe(response =>{
                response = this.utilityService.gsk(response.auth);
		        response =JSON.parse(response);
                if(response.status === true){
                  this.conformationModal.hide();
                  this.getUser();
                  this.utilityService.popToast('success','Success', 3000 , 'User updated successfully.');
                }else{
                  this.utilityService.popToast('error','Error', 3000 , response.message);
                }
              }, error =>{
                this.utilityService.popToast('error','Error', 3000 , error.error.message);
              })
        }
}
