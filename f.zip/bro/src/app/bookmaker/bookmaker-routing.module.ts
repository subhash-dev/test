import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {BookmakerComponent} from './bookmaker.component';
import {BookmakerViewComponent} from './bookmaker-view/bookmaker-view.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path: 'bookmaker',
  canActivate: [AuthGuard, RoleGuard],
  component: BookmakerComponent,
  children: [
    {
      path: 'view/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: BookmakerViewComponent,
    },

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BookmakerRoutingModule {
}
