import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookmakerRoutingModule } from './bookmaker-routing.module';
import { BookmakerComponent } from './bookmaker.component';
import {BookmakerViewComponent} from './bookmaker-view/bookmaker-view.component';
import { FormsModule } from '@angular/forms';
import {DemoMaterialModule} from '../../material-module';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {commonDerectivenModule} from '../auth-gaurd/commonDerective.module';
import {ModalModule} from 'ngx-bootstrap';
import {BrowserModule} from '@angular/platform-browser';

@NgModule({
  declarations: [BookmakerComponent, BookmakerViewComponent],
  imports: [
    CommonModule,
    BookmakerRoutingModule,
    FormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    commonDerectivenModule,
    ModalModule.forRoot(),
    HttpClientModule,
  ]
})
export class BookmakerModule { }
