import { ConditionalExpr } from '@angular/compiler';
import { Component, OnInit,HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Console } from 'console';
import { BookmakerService } from 'src/app/services/bookmaker.service';
import { MarketService } from 'src/app/services/market.service';
import {UtilityService} from '../../globals/utilityService';
@Component({
  selector: 'app-bookmaker-view',
  templateUrl: './bookmaker-view.component.html',
  styleUrls: ['./bookmaker-view.component.scss']
})
export class BookmakerViewComponent implements OnInit {

  rateInput:any = 0;
  inputValue:any = 0;
  counterRateL:any = 15;
  counterRateR:any = 15;
  temArray = new Array(15);
  marketId:any;
  marketData:any = [];
  matchName:any;
  runners:any= [];
  variationValue:any = 0;
  variationValues:any = 0;
  selectedVariation = '';
  selectVolume = '';
  lay:any = '';
  back:any = '';
  selectedRunner:any = '';
  bookmakerMode:any;
  backValume:any = 0;
  layValume:any = 0;

  constructor(private route: ActivatedRoute,private bookmakerService: BookmakerService,
              private utilityService: UtilityService,private marketService: MarketService,
              ) { }

  ngOnInit() {
    // this.variationValues =  this.rateInput;
    this.route.params.subscribe(params => {
      this.marketId = params['id'];
      this.bookmakerService.getMarketById(this.marketId).subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne = JSON.parse(resposne);
        console.log("respose----",resposne);
        if(resposne.status == true){
          this.marketData = resposne.data;
          this.matchName = (resposne.data.match.name.substring(0,resposne.data.match.name.indexOf('('))) ?
                            resposne.data.match.name.substring(0,resposne.data.match.name.indexOf('(')) : '';
          this.runners = (resposne.data.runners) ? resposne.data.runners : '';
          this.selectedRunner = resposne.data.runners[0].selectionId;
          this.bookmakerMode = resposne.data.bookmakerMode;
        }
      });

      this.bookmakerService.getBookmakerRate(this.marketId).subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne = JSON.parse(resposne);
        if(resposne.data && resposne.status == true){
            this.inputValue = resposne.data.rate;
            this.rateInput = resposne.data.rate;
            this.counterRateL =  Number(this.inputValue) - 1;
            this.counterRateR = Number(this.inputValue);
            this.selectedVariation = (resposne.data.variation) ? resposne.data.variation :'';
            this.variationValues = Number(this.inputValue) + Number( (resposne.data.variation) ? resposne.data.variation : 0 );
            this.selectedRunner = resposne.data.selectedRunner;
        }
      });

    });

  }

  enterRate(event) {
    this.back = '' ;
    this.lay = '';
    setTimeout(() => {
      event.target.select();
    }, 100);
    this.inputValue = parseFloat(event.target.value) + parseFloat(this.backValume);
    this.counterRateL =  Number(event.target.value) - 1;
    this.counterRateR =  Number(event.target.value);
    this.variationValues = this.variationValue  + Number(event.target.value) + parseFloat(this.layValume);
    this.storeRate();
    if (!this.inputValue) {
      return false;
    }
  }

  buttonVlue(event){
    this.counterRateL =  Number(event.target.value) - 1;
    this.counterRateR =  Number(event.target.value);
    this.rateInput = Number(event.target.value);
    // this.variationValues = this.variationValue  + Number(event.target.value);

  }
  variation(event){
      this.variationValue = Number(event.target.value);
      this.selectedVariation = event.target.value;
  }

  marketStatus(marketStatus){
    this.back = '';
    this.lay = '';
    let data = {};
    if(marketStatus == 'ballstart'){
     data = {
        value : "BALLSTART",
        name : "ballstart",
        id : "MS950763",
      }
    }
    if(marketStatus == 'OPEN'){
       data ={
        name : "OPEN",
        id : "MS940896"
      }
    }
    if(marketStatus == 'suspend'){
       data ={
        value : "SUSPENDED",
        name : "suspend",
        id : "MS950763"
      }
    }
    this.bookmakerService.getMarketStatusUpdate(data,this.marketId).subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne = JSON.parse(resposne);
        if(resposne.status == true){
            data['marketId'] = this.marketId;
            this.updateWhtLblMarket(data);
        }
    });
  }

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    this.back = '';
    this.lay = '';
    var data = {
      value : "BALLSTART",
      name : "ballstart",
      id : "MS950763"
    }
    this.bookmakerService.getMarketStatusUpdate(data,this.marketId).subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne = JSON.parse(resposne);
        if(resposne.status == true){
            data['marketId'] = this.marketId;
            this.updateWhtLblMarket(data);
        }
    });
  }

  /***
   * update in market data in  multiple white label
   * @param data
   */
    updateWhtLblMarket(data) {
        this.utilityService.getAllWhiteLabel().then(response => {
            let x = response.data;
            for (let i = 0; i < x.length; i++) {
                this.bookmakerService.updateWhtLblMarketStatus(data, x[i]).subscribe(response => {
                    // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
                }, error => {

                });
            }
        }).catch(error => {
        });
    }

  selectRunner(value){
    this.selectedRunner = value;
    this.storeRate();
  }

  backStatus(value){
    this.back = value;
    this.lay = '' ;
    this.storeRate();
  }

  layStatus(value){
    this.back = '' ;
    this.lay = value;
    this.storeRate();
  }

  bothStatus(){
    this.back = '' ;
    this.lay = '';
    this.selectedRunner = '';
    this.storeRate();
  }

  storeRate(){
    var arrLen = 0;
    var runnersArr;
    var variationValues ;
    var inputValue;
    var selectedRunner = this.selectedRunner;
    if(this.back){
      inputValue =  (this.inputValue) ? this.inputValue : 0;
      variationValues = "suspend";
    } else if(this.lay) {
      variationValues = (this.variationValues) ? this.variationValues : 0;
      inputValue = "suspend";
    } else {
      variationValues = (this.variationValues) ? this.variationValues : 0;
      inputValue =  (this.inputValue) ? this.inputValue : 0;
    }

    runnersArr = this.runners.map(function (data) {
      arrLen++;
      if(data.selectionId == selectedRunner){
        data.back = (inputValue) ? inputValue : 0;
        data.lay =(variationValues) ? variationValues : 0;
        return data;
      }
      if(selectedRunner == ''){
        data.back = (inputValue) ? inputValue : 0;
        data.lay =(variationValues) ? variationValues : 0;
        return data;
      }
    });
    if(this.runners.length == arrLen && this.inputValue){
        let apiObj = {
            marketId : this.marketId,
            rate : this.inputValue,
            variation :(this.variationValue) ? this.variationValue : 0,
            runners:runnersArr,
            selectedRunner: (this.selectedRunner) ? this.selectedRunner : 'both'
        }
        this.bookmakerService.storeRateData(apiObj).subscribe(response => {
        // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
        }, error => {

        });
    }
  }

    radioChange(event) {
        let data = {
            bookmakerMode: event.target.value
        };
        this.marketService.bookmakerModeUpdate(this.marketId, data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        if (response.status == true) {
            this.utilityService.getAllWhiteLabel().then(response => {
                let x = response.data;
                for (let i = 0; i < x.length; i++) {
                    this.marketService.bookmakerModeUpdateWebHook(this.marketId, data, x[i]).subscribe(checkUserResponse => {
                    });
                }
            }).catch(error => {
                console.error('errro in get white label');
            });
        }
        }, error => {
            console.error('error in priority', error);
        })
    }
  fancyIdDataUpdate(fancyData){
    this.marketService.updateMarket(fancyData).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
      if (response.status == true) {
        this.marketData = response.data
      }
    });
  }

  numSequence(n: number): Array<number> {
    return Array(n);
  }

  valumeChange(backValume,layValume,selectVolume){

    this.backValume = 0;
    this.layValume = 0;
    this.backValume = parseFloat(backValume);
    this.layValume = parseFloat(layValume);
    this.selectVolume = selectVolume;
  }
}
