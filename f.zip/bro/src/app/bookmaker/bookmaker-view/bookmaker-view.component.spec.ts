import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookmakerViewComponent } from './bookmaker-view.component';

describe('BookmakerViewComponent', () => {
  let component: BookmakerViewComponent;
  let fixture: ComponentFixture<BookmakerViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookmakerViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookmakerViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
