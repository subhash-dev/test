import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {EventmasterRoutingModule} from './eventmaster-routing.module';
import {EventmasterComponent} from './eventmaster.component';
import {SportsComponent} from './sports/sports.component';
import {TournamentComponent} from './tournament/tournament.component';
import {MatchesComponent} from './matches/matches.component';
import {FormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DemoMaterialModule} from '../../material-module';
import {HttpClientModule} from '@angular/common/http';
import {SportService} from '../services/sport.service';
import {ModalModule} from 'ngx-bootstrap';
import {AngularMultiSelectModule} from 'angular2-multiselect-dropdown';
import {TournamentService} from '../services/tournament.service';
import {MatchService} from '../services/match.service';
import {MarketComponent} from './market/market.component';
import {NgbDateParserFormatter, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {MarketService} from '../services/market.service';
import {FancyComponent} from './fancy/fancy.component';
import {BookmakerComponent} from './bookmaker/bookmaker.component';
import {commonDerectivenModule} from '../auth-gaurd/commonDerective.module';
import { DataTablesModule } from 'angular-datatables';
import {NgbDateMomentParserFormatter} from "../auth-gaurd/date_format";
import { LineComponent } from './line/line.component';


@NgModule({
  declarations: [EventmasterComponent, BookmakerComponent, SportsComponent, TournamentComponent, MatchesComponent, MarketComponent, FancyComponent, LineComponent
  ],
  imports: [
    CommonModule,
    EventmasterRoutingModule,
    commonDerectivenModule,
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    FormsModule,
    HttpClientModule,
    ModalModule.forRoot(),
    AngularMultiSelectModule,
    NgbModule,
    DataTablesModule
  ],
  providers: [SportService, TournamentService, MatchService, MarketService,
    {
      provide: NgbDateParserFormatter,
      useFactory: () => { return new NgbDateMomentParserFormatter('DD-MM-YYYY') }
    }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EventmasterModule {
}
