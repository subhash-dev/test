import {ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, ViewChild} from '@angular/core';
import {SportService} from '../../services/sport.service';
import {ModalDirective} from 'ngx-bootstrap';
import {UtilityService} from '../../globals/utilityService';
import {Router} from '@angular/router';
import {isUndefined} from 'util';
import {GameSettingService} from '../../services/gameSettingService.service';
import {UserService} from '../../services/user.service';
import {ToasterConfig} from 'angular2-toaster';
import { HttpClient} from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as env from '../../globals/env';
import {NgxSpinnerService} from "ngx-spinner";
var aes256 = require('aes256');
declare let $: any;


class Sport {
  id: number;
  sportname: string;
  isActive: string;
  isManual:string;
  displayOrder:number;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}


@Component({
  selector: 'app-sports',
  templateUrl: './sports.component.html',
  styleUrls: ['./sports.component.scss']
})

export class SportsComponent implements OnInit {
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild('statusChangeModal', {static: false}) statusChangeModal: ModalDirective;
  @ViewChild("addSport", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild(DataTableDirective, {static: false})
  // @ViewChild("focus") nameField: ElementRef;

  @ViewChild('focusInput' ,  {static: false}) focusInput: ElementRef;





  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  sports: Sport[];
  resData;
  server_url: any = env.server_url();

  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });

  accessRole: any;
  tempSportObj: any;
  conformationPassword: any;

  constructor(private sportService: SportService,
              private utilityService: UtilityService,
              private router: Router,
              private gameSettingService: GameSettingService,
              private userService: UserService,
              private chRef: ChangeDetectorRef,
              private spinner: NgxSpinnerService,
              private http: HttpClient) {
  }
  dataTable: any;
  addSportObject = {
    id: null,
    name: null,
    isManual: true,
    isActive: false,
    isView: false,
    isDeleted: false,
    displayOrder: null,
  };
  filter = {
    page: 1,
    limit: 300,
    search: null
  };

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.passwordFormReset.resetForm();
      this.sportsValue.resetForm();
      this.rerender();
    }
  }
  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if(event.sourceCapabilities) {

    }else {
      this.setFocusToInput();
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('SPORT'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('SPORT');
    }
    //this.getSport();
    this.newDatatable();
  }
  setFocusToInput() {

    this.focusInput.nativeElement.focus();
  }
  openModal() {

    this.addSportObject = {
      id: null,
      name: null,
      isManual: true,
      isActive: false,
      isView: false,
      isDeleted: false,
      displayOrder: 9,
    };
    this.modal.show();
  }

  closeModel(data) {
    if(data === 'addModel'){
      this.sportsValue.resetForm();
      this.modal.hide();
    }else{
      this.conformationModal.hide();
      this.statusChangeModal.hide();
      this.rerender();
    }

  }

  newDatatable(){
    this.spinner.show();
    const that = this;
    let url = this.server_url + 'sport/get-all';
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            dataTablesParameters,
            {}
          ).subscribe(resp => {
            this.spinner.hide();
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData = JSON.parse(this.resData)
            this.resData = this.resData.data;
            if(this.resData.docs.length > 0){
              this.sports = this.resData.docs;
              $('.dataTables_empty').css('display', 'none');
            }else {
              $('.dataTables_empty').css('display', 'table-cell');
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },

      columns: [ { data: '' },{ data: 'name' }, { data: 'isActive' }, { data: 'isManual' }, { data: 'isView' }, { data: 'displayOrder' }],
      columnDefs: [ { orderable: false, targets: [0] }]
    };
}


  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }

  /**
   * @author TR
   * @date : 25-02-2020
   * Create White Lable Sports
   */
  createWhitelbSport() {
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.addSportObject.name = this.addSportObject.name.toUpperCase();
        this.sportService.addNewSportwht(this.addSportObject , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author kc
   * @date : 28-01-2020
   * add new sports
   */
  createSport() {
    this.spinner.show();
    this.addSportObject.name = this.addSportObject.name.toUpperCase();
    this.sportService.addNewSport(this.addSportObject).subscribe(resposne => {
    resposne = this.utilityService.gsk(resposne.auth);
    resposne = JSON.parse(resposne)
      this.modal.hide();
      if(resposne.status === true){
        this.rerender();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Sports created successfully.');
        // this.createWhitelbSport();
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }


  updateUserStatus(){
    this.spinner.show();
    let key = env.constantKey();
    let token = this.conformationPassword;
    var encrypted = aes256.encrypt(key, token);
          this.tempSportObj['token'] = encrypted;
          this.sportService.updateSport(this.tempSportObj)
            .subscribe(response =>{
                response = this.utilityService.gsk(response.auth);
                response = JSON.parse(response)
              if(response) {
                this.conformationModal.hide();
                this.spinner.hide();
                // this.updateWhtLblSport(this.tempSportObj);
                this.utilityService.popToast('success', 'Success', 3000, 'Sports updated successfully.');
              }else {
                this.spinner.hide();
                this.utilityService.popToast('error','error', 3000 , response.message );
              }
            }, error =>{
              console.log(error);
              this.spinner.hide();
              this.conformationModal.hide();
              this.utilityService.popToast('error','error', 3000 , error.error.message );
            })
        }

  updateWhtLblSport(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.sportService.updateWhtLblSport(data , x[i])
          .subscribe(response =>{
            // this.utilityService.popToast('success','Success', 1000 , 'White label sport updated successfully.');
          }, error =>{

          });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });

  }
  onchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal.show();


  }
  onchangeWithoutPassword(object){
    this.tempSportObj = object;
    this.statusChangeModal.show();
  }

  /**
   * update display order
   * @param data
   */
  updateDisplayOrder(data) {
    this.spinner.show();
    setTimeout(res => {
      this.sportService.updateSport(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response)
        this.spinner.hide();
        if (response.status === true) {
          this.rerender();
          // this.updateWhtLblSport(data);
        }
      }, error => {
        this.spinner.hide();
        console.error('error in priority', error);
      })
    }, 500)
  }

  updateUserStatusWithoutPassword() {
    this.sportService.updateSport(this.tempSportObj)
      .subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response)
        // this.updateWhtLblSport(this.tempSportObj);
        this.statusChangeModal.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Sports updated successfully.');
      }, error =>{

      })
  }
}



