import { ChangeDetectorRef, Component, HostListener, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { SportService } from '../../services/sport.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatchService } from '../../services/match.service';
import { TournamentService } from '../../services/tournament.service';
import { MarketService } from '../../services/market.service';
import { UtilityService } from '../../globals/utilityService';
import { RoleService } from '../../services/role.service';
import { UserService } from '../../services/user.service';
import { isUndefined } from 'util';
import { GameSettingService } from '../../services/gameSettingService.service';
import { ToasterConfig } from 'angular2-toaster';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as env from '../../globals/env';
import { NgxSpinnerService } from "ngx-spinner";
import { SocketService } from "../../globals/socketService";

declare let $: any;
var aes256 = require('aes256');
class Market {
  id: number;
  match: string;
  market: string;
  marketType: string;
  createdAt: string;
  isActive: string;
  allowBat: string;
  inPlay: string;
  message: string;
  isDisplayRate: string;
  displayOrder: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}


@Component({
  selector: 'app-market',
  templateUrl: './market.component.html',
  styleUrls: ['./market.component.scss']
})
export class MarketComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  @ViewChild('modal', { static: false }) modal: ModalDirective;
  @ViewChild('runnersmodal', { static: false }) runnersmodal: ModalDirective;
  @ViewChild('fancymodal', { static: false }) fancymodal: ModalDirective;
  @ViewChild('suspendModal', { static: false }) suspendModal: ModalDirective;
  @ViewChild('deleteModal', { static: false }) deleteModal: ModalDirective;
  @ViewChild('messageModal', { static: false }) messageModal: ModalDirective;
  @ViewChild('gameLimitModal', { static: false }) gameLimitModal: ModalDirective;
  @ViewChild('liveTvModal', { static: false }) liveTvModal: ModalDirective;
  @ViewChild("addMarketForm", { static: false }) formResetValue;
  @ViewChild("runnersForm", { static: false }) runnersFormResetValue;
  @ViewChild("fancyForm", { static: false }) fancyFormResetValue;
  @ViewChild('conformationModal', { static: false }) conformationModal: ModalDirective;
  @ViewChild('statusChangeModal', { static: false }) statusChangeModal: ModalDirective;
  @ViewChild("conformationForm", { static: false }) passwordFormReset;
  @ViewChild('focusInput', { static: false }) focusInput: ElementRef;
  // @ViewChild('focusonselect' ,  {static: false}) focusonselect: ElementRef;
  // @ViewChild('focusText' ,  {static: false}) focusText: ElementRef;



  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();

  markets: Market[];
  resData;
  tempMarketObj: any;
  settings: any;
  conformationPassword: any;
  server_url: any = env.server_url();


  accessRole: any;
  dropDown = false;

  /* marketName = [
       {name: 'Match Odds', value: 'MATCH_ODDS'},
       {name: 'Fancy' , value: 'FANCY'},
       {name: 'Book maker', value: 'BOOK_MAKER'}
   ]*/
  marketFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  paramId: any;
  getAllMarkets: any;
  fancyConfigObject: any;
  time: any;
  marketTypes: any;

  dataTable: any;
  addMarketObject = {
    marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
    marketType: '',
    marketTypeId: null,
    marketStartTime: localStorage.getItem('date'),
    totalMatched: 0,
    runners: null,
    displayName: null,
    isActive: true,
    message: null,
    match: null,
    tournament: null,
    sport: null,
  };
  fancyId: any;
  fancySettingObject: any;
  fancyNewSettingObject: any;
  marketStatusArray = [
    {
      id: 'MS081893',
      name: 'Open',
      value: 'OPEN'
    },
    {
      id: 'MS180893',
      name: 'Settled',
      value: 'SETTLED'
    },
    {
      id: 'MS930818',
      name: 'Cancelled',
      value: 'CANCELLED'
    },
  ];
  globleSingleFancyObj: any;
  SelecTmatch: any;
  matchSerch: any = '';
  filterMatch = [];
  matchListSerchdata = [];
  constructor(private route: ActivatedRoute,
    private matchService: MatchService,
    private marketService: MarketService,
    private tournamentService: TournamentService,
    private sportService: SportService,
    private utilityService: UtilityService,
    private chRef: ChangeDetectorRef,
    private roleService: RoleService,
    private userService: UserService,
    private gameSettingService: GameSettingService,
    private socketService: SocketService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private http: HttpClient) {
  }

  filter = {
    page: 1,
    limit: -1,
    search: null
  };
  tournamentFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  matchFilter = {
    page: 1,
    limit: 10,
    search: null
  };

  sportList = [];
  selectedSportItems = [];
  sportSettings = {
    singleSelection: true,
    text: 'Select sports',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
  };
  sportId: any;
  tournamentsList = [];
  selectedTournamentsItems = [];
  TournamentsSettings = {
    singleSelection: true,
    text: 'Select tournament',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  tournamentId: any;
  matchList = [];
  selectedMatchItems = [];
  matchSettings = {
    singleSelection: true,
    text: 'Select match',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };

  fancyUserList = [];
  selectedUserItems = [];
  UserSettings = {
    singleSelection: true,
    text: 'Select user',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: false,
  };


  marketList = [];
  selectedMarketItems = [];
  marketSettings = {
    singleSelection: true,
    text: 'Select market',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: false,
  };
  runnes = [{
    selectionId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
    runnerName: null,
    handicap: 1,
    sortPriority: 0,
    metadata: {
      runnerId: (Math.floor(Math.random() * (999999999 - 10000 * 1) * 1000))
    }

  }];
  tempRunners = {
    selectionId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
    runnerName: null,
    handicap: 1,
    sortPriority: 0,
    metadata: {
      runnerId: (Math.floor(Math.random() * (999999999 - 10000 * 1) * 1000))
    }

  };
  fancyArray = [{
    fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
    fancyName: null,
    tempAsiignToName: [],
    assignTo: {
      id: null,
      name: null,
      username: null
    },
    fancySetting: {
      maxStack: null,
      minStack: null,
      maxProfit: null,
      betDelay: null,
      maxStackPerOdds: null,
    },
    fancyConfigurationSetting: {
      ballStart: null,
      rateRange: null,
      rateDiffrence: null
    }
  }];
  tempFancy = {
    fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
    fancyName: null,
    assignTo: {
      id: null,
      name: null,
      username: null
    },
    fancySetting: {
      maxStack: null,
      minStack: null,
      maxProfit: null,
      betDelay: null,
      maxStackPerOdds: null,
    },
    fancyConfigurationSetting: {
      ballStart: null,
      rateRange: null,
      rateDiffrence: null
    }
  };


  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.passwordFormReset.resetForm();
      this.formResetValue.resetForm();
      this.runnersFormResetValue.resetForm();
      this.fancyFormResetValue.resetForm();
      this.rerender();
    }
  }

  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if (event.sourceCapabilities) {

    } else {
      this.setFocusToInput();
    }
  }

  ngOnInit() {
    this.SelecTmatch = '';
    if (isUndefined(this.utilityService.returnAccessRole('MARKET'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('MARKET');
    }
    this.route.params.subscribe(params => {
      this.paramId = params['id'];
    });
    this.marketTypes = this.utilityService.marketType;
    this.marketTypes = this.marketTypes.filter(data => {
      if (data.id !== '5ebc1code68br4bik5b3035' && data.id !== '5ebc1code68br4bik5b0811') {
        return data;
      }
    });
    this.marketList = this.marketTypes.map(data => {
        return { id: data.id, itemName: data.name }
    });
    console.log(this.marketTypes);
    this.getMarketsDt(); //get all market by datatable
    this.getFancyConfig(); //get all fancy Config Setting
    this.getAllSport();//get all sport function call
    //this.getAllMarket();//get all market function call
    this.getAllModules();

    // this.socketService
    //   .changeStatuses()
    //   .subscribe((response) => {
    //     if (response) {
    //       this.rerender();
    //       this.getMarketsDt();
    //     }
    //   });
    this.matchListSerch();
  }

  setFocusToInput() {

    this.focusInput.nativeElement.focus();
    // this.focusonselect.nativeElement.focus();
  }

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  getMarketsDt() {
    let userId = '';
    if (JSON.parse(this.utilityService.returnLocalStorageData('userData')).userType === 'STAFF') {
      userId = (JSON.parse(this.utilityService.returnLocalStorageData('userData')).user_id)
    }
    this.spinner.show();
    const that = this;
    let url = this.server_url + 'market/get-all';
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      // autoWidth: false,
      // scrollX: true,
      // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',
        emptyTable: 'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { matchId: this.paramId, userId: userId, matchName: this.matchSerch }),
            {}
          ).subscribe(resp => {
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData =JSON.parse(this.resData);
            this.resData = this.resData.data;
            this.spinner.hide();
            let uniqueArr = [];
            if (this.resData.docs.length > 0) {
              that.markets = this.resData.docs;
              this.resData.docs.map(data => {
                uniqueArr.push(data.match);
              });
              if (this.filterMatch.length === 0) {
                const map = new Map();
                for (const item of uniqueArr) {
                  if (!map.has(item.id)) {
                    map.set(item.id, true);
                    this.filterMatch.push({
                      id: item.id,
                      name: item.name
                    });
                  }
                }
              }
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },
      columns: [{ data: '' }, { data: 'marketType' }, { data: 'match.name' }, { data: 'marketType' }, { data: 'marketStartTime' }, { data: 'createdAt' }, { data: 'isActive' }, { data: 'isActive' }, { data: 'allowBat' }],
      columnDefs: [{ orderable: false, targets: [0] }]
    };

  }

  /**
   * get all modules list
   */
  getAllModules() {
    this.roleService.getAllModules().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      response.data.docs.map(data => {
        if (data.moduleName === 'FANCY') {
          this.fancyId = data._id;
        }
      });
    }, error => {
      console.error('error in get modules');
    });
  }

  /**
   * @author kc
   * @date : 28-01-2020
   * get all sports
   */
  getAllSport() {
    this.sportService.getAllSport(this.filter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.sportList = response.data.docs.map(data => {
        return { id: data._id, itemName: data.name  + '( ' + data.id + ' )', sportId: data.id };
      });
    }, error => {
      console.error('error in getting all sports', error);
    });
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * sport search with name
   */
  onSportSearch(e) {
    this.filter.search = e.target.value;
    this.getAllSport();
  }

  /**
   * on sport select call relevant tournaments
   * @param e
   */
  onSportSelect(e) {
    this.sportId = e.sportId;
    this.getAllTournament();
  }

  /**
   * @author kc
   * @date : 28-01-2020
   * get all sports
   */
  getAllTournament() {
    this.tournamentService.getAllTournament(this.tournamentFilter, this.sportId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.tournamentsList = response.data.docs.map(data => {
        return { id: data._id, itemName: data.name  + '( ' + data.id + ' )', tournamentId: data.id };
      });
    }, error => {
      console.error('error in getting all sports', error);
    });
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * sport search with name
   */
  onTornamentSearch(e) {
    this.tournamentFilter.search = e.target.value;
    this.getAllTournament();
  }

  /**
   * @author kc
   * @date : 30-01-2019
   * on tournament select relavent match api call
   */
  onTornamentSelect(e) {
    this.tournamentId = e.tournamentId;
    this.getMatches();
  }

  /**
   * @author kc
   * @date : 28-01-2020
   * get all Matches by Tournament id
   */
  getMatches() {
    this.matchService.getAllMatch(this.matchFilter, this.tournamentId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.matchList = response.data.docs.map(data => {
        return { id: data._id, itemName: data.name  + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
      });
    }, error => {
      console.error('get all Matches', error);
    });
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * match search with name
   */
  onMatchSearch(e) {
    this.matchFilter.search = e.target.value;
    this.getMatches();
  }

  /**
   * @author kc
   * @date : 26-03-2020;
   * set market time
   */
  onMatchSelect(e) {
    if (localStorage.getItem('date') === null || localStorage.getItem('date') === 'null') {
      this.addMarketObject.marketStartTime = e.matchTime;
    } else {
      this.addMarketObject.marketStartTime = localStorage.getItem('date');
    }
  }

  /**
   * set market name and id function
   * @param e
   */
  selectmatchType(e) {
    this.addMarketObject.marketType = e.itemName;
    this.addMarketObject.marketTypeId = e.id;
    if (this.addMarketObject.marketTypeId === '5ebc1code68br4bik5b1808') {
      this.getFancyUser();
      this.getFancySetting();
    }
  }

  /**
   * get only fancy user
   */
  getFancyUser() {
    this.userService.fancyUser(this.fancyId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.fancyUserList = response.data.map(data => {
        return { id: data._id, itemName: data.name, userName: data.userName, userType: data.userType }
      });
    }, error => {
      console.error('error in get fancy user');
    });
  }

  /**
   * get fancy global setting and set in main object
   */
  getFancySetting() {
    this.gameSettingService.getAllFancySetting().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);

      this.fancySettingObject = response.data.docs[0];
      this.fancyNewSettingObject = response.data.docs[0];


      this.fancyArray[0].fancySetting.maxStack = this.fancySettingObject.maxStack;
      this.fancyArray[0].fancySetting.minStack = this.fancySettingObject.minStack;
      this.fancyArray[0].fancySetting.maxProfit = this.fancySettingObject.maxProfit;
      this.fancyArray[0].fancySetting.betDelay = this.fancySettingObject.betDelay;
      this.fancyArray[0].fancySetting.maxStackPerOdds = this.fancySettingObject.maxStackPerOdds;

      this.tempFancy.fancySetting.maxStack = this.fancyNewSettingObject.maxStack;
      this.tempFancy.fancySetting.minStack = this.fancyNewSettingObject.minStack;
      this.tempFancy.fancySetting.maxProfit = this.fancyNewSettingObject.maxProfit;
      this.tempFancy.fancySetting.betDelay = this.fancyNewSettingObject.betDelay;
      this.tempFancy.fancySetting.maxStackPerOdds = this.fancyNewSettingObject.maxStackPerOdds;
    }, error => {
      console.error('error in get fancy setting', error);
    })
  }

  /**
   * assign user to fancy
   * @param e
   * @param fancy
   */
  selectAssignTo(e, fancy) {
    this.fancyArray.map(data => {
      if (data.fancyId === fancy.fancyId) {
        data.assignTo.id = e.id;
        data.assignTo.name = e.itemName;
        data.assignTo.username = e.username;
        return data;
      } else {
        return data;
      }
    });
  }



  /**
   * update display order
   * @param data
   */
  updateDisplayOrder(data) {
    this.spinner.show();
    setTimeout(res => {
      this.marketService.updateMarket(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status === true) {
          this.rerender();
          this.spinner.hide();
          // this.updateWhtLblMarket(data);
          //this.getAllMarket()
        }
      }, error => {
        this.spinner.hide();
        console.error('error in priority', error);
      })
    }, 500)

  }

  /**
   * open modal
   */
  openModal() {
    this.formResetValue.resetForm();
    $('#marketType').val('');
    this.addMarketObject = {
      marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
      marketType: '',
      marketTypeId: null,
      marketStartTime: null,
      totalMatched: 0,
      runners: null,
      displayName: null,
      isActive: false,
      message: null,
      match: null,
      tournament: null,
      sport: null
    };
    this.selectedSportItems = [];
    this.selectedTournamentsItems = [];
    this.selectedMatchItems = [];
    this.selectedUserItems = [];
    this.selectedMarketItems = [];
    this.runnes = [{
      selectionId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      runnerName: null,
      handicap: 1,
      sortPriority: 0,
      metadata: {
        runnerId: (Math.floor(Math.random() * (999999999 - 10000 * 1) * 1000))
      }

    }];
    this.tempRunners = {
      selectionId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      runnerName: null,
      handicap: 1,
      sortPriority: 0,
      metadata: {
        runnerId: (Math.floor(Math.random() * (999999999 - 10000 * 1) * 1000))
      }

    };
    this.fancyArray = [{
      fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      fancyName: null,
      tempAsiignToName: [],
      assignTo: {
        id: null,
        name: null,
        username: null
      },
      fancySetting: {
        maxStack: 100,
        minStack: null,
        maxProfit: null,
        betDelay: null,
        maxStackPerOdds: null,
      },
      fancyConfigurationSetting: {
        ballStart: null,
        rateRange: null,
        rateDiffrence: null
      }
    }];
    this.tempFancy = {
      fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      fancyName: null,
      assignTo: {
        id: null,
        name: null,
        username: null
      },
      fancySetting: {
        maxStack: null,
        minStack: null,
        maxProfit: null,
        betDelay: null,
        maxStackPerOdds: null,
      },
      fancyConfigurationSetting: {
        ballStart: null,
        rateRange: null,
        rateDiffrence: null
      }
    };
    this.modal.show();
  }

  /**
   * open modal
   */
  runnersModal() {
    this.runnersFormResetValue.resetForm();
    this.runnersmodal.show();
  }

  /**
   * close modal
   */
  closeModel(data) {
    if (data === 'addMarket') {
      this.formResetValue.resetForm();
      this.modal.hide();
      this.rerender();
    } else if (data === 'suspend') {
      this.suspendModal.hide();
    } else {
      this.conformationModal.hide();
      this.statusChangeModal.hide();
      this.rerender();
    }
  }

  /**
   * close bookmaker modal
   */
  closeRunnerModel() {
    this.runnersFormResetValue.resetForm();
    this.runnersmodal.hide();
  }

  /**
   * close fancy model
   */
  closeFancyModel() {
    this.fancymodal.hide();
    this.fancyFormResetValue.resetForm();
  }

  /**
   * open runners popup
   */
  addRunners() {

    this.modal.hide();//hide market model
    if (this.addMarketObject.marketType === 'Fancy') {
      this.fancymodal.show();
    } else {
      this.runnersModal();//show runner model
    }

  }

  /**
   * @author TR
   * @date 25-02-2020
   * create step 4 for bookmaker (market) for White Lable
   */
  addMarketWhtLbl(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for (let i = 0; i < x.length; i++) {
        this.marketService.addNewMarketWhtLbl(data, x[i]).subscribe(response => {
        });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });

  }

  /**
   * @author TR
   * @date 25-02-2020
   * create step 4 for Fancy (market) for White Lable
   */
  addFancyWhtLbl(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for (let i = 0; i < x.length; i++) {
        this.marketService.addNewFancyMarketWhtLbl(data, x[i]).subscribe(response => {
        });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });
  }

  /**
   * @author kc
   * @date 31-01-2020
   * create step 4 (market)
   */
  cerateBookmakerMarket() {
    this.spinner.show();
    this.gameSettingService.getAllBookmakerSetting().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.addMarketObject['bookmakerSetting'] = response.data.docs[0];
      this.addMarketObject['gameSetting'] = null;
      this.addMarketObject['fancySetting'] = null;
      this.addMarketObject['bookmakerMode'] = 'Auto';
      this.addMarketObject.runners = this.runnes;
      this.addMarketObject['marketStatus'] = {
        id: 'MS081893',
        name: 'OPEN'
      };
      this.addMarketObject.sport = {
        id: this.selectedSportItems[0]['sportId'],
        name: this.selectedSportItems[0]['itemName']
      };
      this.addMarketObject.tournament = {
        id: this.selectedTournamentsItems[0]['tournamentId'],
        name: this.selectedTournamentsItems[0]['itemName']
      };
      this.addMarketObject.match = {
        id: this.selectedMatchItems[0]['matchId'],
        name: this.selectedMatchItems[0]['itemName']
      };
      this.marketService.addNewMarket(this.addMarketObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.runnersmodal.hide();
        this.spinner.hide();
        if (response.status === true) {
          //this.getAllMarket(); // recall all market api for sysnc data
          this.rerender();
          this.utilityService.popToast('success', 'Success', 3000, 'Bookmaker created successfully.');
          // this.addMarketWhtLbl(this.addMarketObject);
        } else {
          this.spinner.hide();
          this.utilityService.popToast('error', 'Error', 3000, response.message);
        }
      }, error => {
        this.spinner.hide();
        console.error('add market error', error);
      });

    }, error => {
      this.spinner.hide();
      console.error('error in get bookmaker setting', error);
    });


  }

  /**
   * create multiple new fancy
   */

  createFancy() {
    this.spinner.show();
    let finalFancyArray = this.fancyArray;
    finalFancyArray.map(data => {
      data['marketId'] = ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100));
      data['marketType'] = this.addMarketObject.marketType;
      data['marketTypeId'] = this.addMarketObject.marketTypeId;
      data['marketStartTime'] = this.addMarketObject.marketStartTime;
      data['totalMatched'] = 0;
      data['gameSetting'] = null;
      data['bookmakerSetting'] = null;
      data['isActive'] = this.addMarketObject.isActive;
      data['fancyConfigurationSetting'] = {
        ballStart: this.fancyConfigObject[0].ballStart,
        rateRange: this.fancyConfigObject[0].rateRange,
        rateDiffrence: this.fancyConfigObject[0].rateDiffrence
      };
      data['marketStatus'] = {
        id: 'MS081893',
        name: 'OPEN'
      };
      data['sport'] = {
        id: this.selectedSportItems[0]['sportId'],
        name: this.selectedSportItems[0]['itemName']
      };
      data['tournament'] = {
        id: this.selectedTournamentsItems[0]['tournamentId'],
        name: this.selectedTournamentsItems[0]['itemName']
      };
      data['match'] = {
        id: this.selectedMatchItems[0]['matchId'],
        name: this.selectedMatchItems[0]['itemName']
      };
      return data;
    });
    this.marketService.addNewFancyMarket(finalFancyArray).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.spinner.hide();
      this.fancymodal.hide();
      if (response.status === true) {
        this.rerender();
        //this.getAllMarket(); // recall all market api for sysnc data
        this.utilityService.popToast('success', 'Success', 3000, 'Fancy created successfully.');
        finalFancyArray.map(data => {
          delete data.fancyConfigurationSetting;
          return data;
        });
        // this.addFancyWhtLbl(finalFancyArray);
      } else {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, response.message);
      }
    }, error => {
      this.spinner.hide();
      console.error('add market error', error);
    });


  }

  /***
   * push new runners object in runners array
   * @param object
   * @param array
   */
  addNewObjectToArray(object, array) {
    array = array || [{}];
    object = typeof object === 'object' ? object || {} : '';
    array.push(object);
    this.tempRunners = {
      selectionId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      runnerName: null,
      handicap: 1,
      sortPriority: 0,
      metadata: {
        runnerId: (Math.floor(Math.random() * (999999999 - 10000 * 1) * 1000))
      }

    };
  }

  /***
   * push new fancy object in runners array
   * @param object
   * @param array
   */
  addNewFancyObjectToArray(object, array) {
    this.tempFancy = {
      fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      fancyName: null,
      assignTo: {
        id: null,
        name: null,
        username: null
      },
      fancySetting: {
        maxStack: this.fancyNewSettingObject.maxStack,
        minStack: this.fancyNewSettingObject.minStack,
        maxProfit: this.fancyNewSettingObject.maxProfit,
        betDelay: this.fancyNewSettingObject.betDelay,
        maxStackPerOdds: this.fancyNewSettingObject.maxStackPerOdds
      },
      fancyConfigurationSetting: {
        ballStart: this.fancyConfigObject[0].ballStart,
        rateRange: this.fancyConfigObject[0].rateRange,
        rateDiffrence: this.fancyConfigObject[0].rateDiffrence
      }
    }
      ;
    console.log('this.tempFancy.fancySetting', this.tempFancy.fancySetting);
    array = array || [{}];
    object = typeof object === 'object' ? object || {} : '';
    array.push(object);

  }


  /**
   * Removes given object from the given array
   * @param object
   * @param array
   */
  removeObjectFromArray(object, array) {
    const index = array.indexOf(object);
    array.splice(index, 1);
  }

  /**
   * open model as per type
   * @param data
   */
  openModels(data, market) {
    this.globleSingleFancyObj = market;
    if (market.marketType === 'Fancy') {
      this.settings = market.fancySetting;
    } else if (market.marketType === 'Bookmaker') {
      this.settings = market.bookmakerSetting;
    } else if (market.marketType === 'Line') {
      this.settings = market.lineSetting;
    } else {
      this.settings = market.gameSetting;
    }

    this.addMarketObject = market;

    if (data === 'suspend') {
      this.suspendModal.show();
    }
    if (data === 'open') {
      this.openMarket();
    }
    if (data === 'delete') {
      this.deleteModal.show();
    }
    if (data === 'message') {
      this.messageModal.show();
    }
    if (data === 'limit') {
      this.gameLimitModal.show();
    }
    if (data === 'liveTv') {
      this.liveTvModal.show();
    }
  }

  /**
   * close model as per type
   * @param data
   */
  closeModels(data) {
    if (data === 'suspend') {
      this.suspendModal.hide();
    }
    if (data === 'delete') {
      this.deleteModal.hide();
    }
    if (data === 'message') {
      this.messageModal.hide();
    }
    if (data === 'limit') {
      this.gameLimitModal.hide();
    }
    if (data === 'liveTv') {
      this.liveTvModal.hide();
    }
  }

  updateUserStatus() {
    this.spinner.show();
          let key = env.constantKey();
          let token = this.conformationPassword;
          var encrypted = aes256.encrypt(key, token);
          this.tempMarketObj['token'] = encrypted;
          this.marketService.updateMarket(this.tempMarketObj)
            .subscribe(response => {
                response = this.utilityService.gsk(response.auth);
                response =JSON.parse(response);
              this.spinner.hide();
              this.conformationModal.hide();
              this.messageModal.hide();
              // this.updateWhtLblMarket(this.tempMarketObj);
              this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
            }, error => {
              this.messageModal.hide();
              this.conformationModal.hide();
              this.spinner.hide();
              this.utilityService.popToast('error', 'Error', 3000, error.error.message);
            })

  }
  // updateWhtLblMarket(data){
  //   this.utilityService.getAllWhiteLabel().then(response =>{
  //     let x = response.data;
  //     /* Hear X is Multiple Whitelable Data*/
  //     for(let i = 0;i < x.length; i++){
  //       this.marketService.updateWhtLblMarket(data ,  x[i]).subscribe(response => {
  //       });
  //     }
  //   }).catch(error =>{
  //     console.error("errro in get white label");
  //   });
  //   // this.marketService.updateWhtLblMarket(data)
  //   //   .subscribe(response =>{
  //   //     // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
  //   //   }, error =>{
  //   //
  //   //   });
  // }

  onchange(object) {
    this.passwordFormReset.resetForm();
    this.conformationModal.show();
    this.tempMarketObj = object;
  }
  onchangeWithoutPassword(object){
    this.tempMarketObj = object;
    this.updateUserStatusWithoutPassword();
  }

  updateMessage() {
    this.tempMarketObj = this.addMarketObject;
    this.updateUserStatus();
  }

  clearMessage() {
    this.addMarketObject.message = '';
  }

  /***
   * update setting data (limits)
   * @param data
   */
  updateSetting(data) {
    this.spinner.show();
    this.tempMarketObj = this.globleSingleFancyObj;

    /*************match odds setting if type is odds************/
    if (this.tempMarketObj.marketTypeId === '5ebc1code68br4bik5b3035') {
      this.tempMarketObj.gameSetting.volume = Number(this.tempMarketObj.gameSetting.volume);
      this.tempMarketObj.gameSetting.minStack = Number(this.tempMarketObj.gameSetting.minStack);
      this.tempMarketObj.gameSetting.maxStack = Number(this.tempMarketObj.gameSetting.maxStack);
      this.tempMarketObj.gameSetting.maxProfit = Number(this.tempMarketObj.gameSetting.maxProfit);
      this.tempMarketObj.gameSetting.maxLoss = Number(this.tempMarketObj.gameSetting.maxLoss);
      this.tempMarketObj.gameSetting.betDelay = Number(this.tempMarketObj.gameSetting.betDelay);
      this.tempMarketObj.gameSetting.minOdds = Number(this.tempMarketObj.gameSetting.minOdds);
      this.tempMarketObj.gameSetting.maxOdds = Number(this.tempMarketObj.gameSetting.maxOdds);
      this.tempMarketObj.gameSetting.preInPlayProfit = Number(this.tempMarketObj.gameSetting.preInPlayProfit);
      this.tempMarketObj.gameSetting.preInPlayStack = Number(this.tempMarketObj.gameSetting.preInPlayStack);
    }


    /*************fancy setting if type is fancy************/
    if (this.tempMarketObj.marketTypeId === '5ebc1code68br4bik5b1808') {
      this.tempMarketObj.fancySetting.minStack = Number(this.tempMarketObj.fancySetting.minStack);
      this.tempMarketObj.fancySetting.maxStack = Number(this.tempMarketObj.fancySetting.maxStack);
      this.tempMarketObj.fancySetting.maxProfit = Number(this.tempMarketObj.fancySetting.maxProfit);
      this.tempMarketObj.fancySetting.betDelay = Number(this.tempMarketObj.fancySetting.betDelay);
      this.tempMarketObj.fancySetting.maxStackPerOdds = Number(this.tempMarketObj.fancySetting.maxStackPerOdds);

    }

    /*************bookmaker setting if type is bookmaker************/
    if (this.tempMarketObj.marketTypeId === '5ebc1code68br4bik5b0810') {
      this.tempMarketObj.bookmakerSetting.minStack = Number(this.tempMarketObj.bookmakerSetting.minStack);
      this.tempMarketObj.bookmakerSetting.maxStack = Number(this.tempMarketObj.bookmakerSetting.maxStack);
      this.tempMarketObj.bookmakerSetting.maxProfit = Number(this.tempMarketObj.bookmakerSetting.maxProfit);
      this.tempMarketObj.bookmakerSetting.betDelay = Number(this.tempMarketObj.bookmakerSetting.betDelay);
      this.tempMarketObj.bookmakerSetting.maxStackPerOdds = Number(this.tempMarketObj.bookmakerSetting.maxStackPerOdds);
    }

    /*************line setting if type is line************/
    if (this.tempMarketObj.marketTypeId === '5ebc1code68br4bik5b0811') {
      this.tempMarketObj.lineSetting.minStack = Number(this.tempMarketObj.lineSetting.minStack);
      this.tempMarketObj.lineSetting.maxStack = Number(this.tempMarketObj.lineSetting.maxStack);
      this.tempMarketObj.lineSetting.maxProfit = Number(this.tempMarketObj.lineSetting.maxProfit);
      this.tempMarketObj.lineSetting.betDelay = Number(this.tempMarketObj.lineSetting.betDelay);
      this.tempMarketObj.lineSetting.maxStackPerOdds = Number(this.tempMarketObj.lineSetting.maxStackPerOdds);
    }


    console.log("this.tempMarketObj", this.tempMarketObj);
    let checkUserObj = {
      id: this.utilityService.returnLocalStorageData('userId'),
      password: this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse => {
        checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
        checkUserResponse =JSON.parse(checkUserResponse);
        if (checkUserResponse.status === true) {
          this.marketService.updateMarketData(this.tempMarketObj)
            .subscribe(response => {
              this.spinner.hide();
              this.gameLimitModal.hide();
               // this.updateWhtLblMarket(this.tempMarketObj);
              this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
            }, error => {

            })
        } else {
          this.spinner.hide();
          this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
        }

      }, error => {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, error.error.message);
      });
  }
  /***
   * update in market data in  multiple white label
   * @param data
   */
  updateWhtLblMarket(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      for (let i = 0; i < x.length; i++) {
        this.marketService.updateWhtLblMarket(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 08-06-2020
   * get fancy configures
   */
  getFancyConfig() {
    this.gameSettingService.getAllfancyConfgSetting().subscribe(responseCong => {
        responseCong = this.utilityService.gsk(responseCong.auth);
        responseCong =JSON.parse(responseCong);
      if (responseCong) {
        this.fancyConfigObject = responseCong.data;
      }
    }, error => {
      console.error('get fancy configure setting successfully', error);
    });
  }

  searchSettleData() {
    console.log(this.SelecTmatch)
    if (this.SelecTmatch) {
      this.matchSerch = this.SelecTmatch;
      this.getMarketsDt();
      this.rerender();
    }
  }
  clear() {
    if (this.SelecTmatch) {
      this.matchSerch = '';
      this.SelecTmatch = '';
      this.getMarketsDt();
      this.rerender();
    }
  }

  updateStatus() {
    this.spinner.show();
    let status = {
      value: "SUSPENDED",
      name: "suspend",
      id: "MS940896"
    };
    this.globleSingleFancyObj.marketStatus = status;
    this.marketService.updateMarket(this.globleSingleFancyObj)
      .subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status == false){
          this.suspendModal.hide();
          this.spinner.hide();
          this.utilityService.popToast('error', 'Error', 3000, 'Market already settled.');
        }else{
          this.suspendModal.hide();
          this.spinner.hide();
           // this.updateWhtLblMarket(this.globleSingleFancyObj);
          this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
        }
      }, error => {

      })
  }

  openMarket(){
    this.spinner.show();
    let status = {
      value: "OPEN",
      name: "open",
      id: "MS081893"
    };
    this.globleSingleFancyObj.marketStatus = status;
    this.marketService.updateMarket(this.globleSingleFancyObj)
      .subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.suspendModal.hide();
        this.spinner.hide();
        // this.updateWhtLblMarket(this.globleSingleFancyObj);
        this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
      }, error => {

      })
  }

  updateUserStatusWithoutPassword() {
    this.marketService.updateMarket(this.tempMarketObj)
      .subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status == false){
          this.messageModal.hide();
          this.statusChangeModal.hide();
          this.utilityService.popToast('error', 'Error', 3000, 'Market already settled.');
        }else{
          this.messageModal.hide();
          // this.updateWhtLblMarket(this.tempMarketObj);
          this.statusChangeModal.hide();
          this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
        }
      }, error => {
      })
  }
   /**
   * get all match list
   */
  matchListSerch() {
    let type = 'All';
    this.marketService.getMatchListSerch(type).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.matchListSerchdata =response.data;
      console.log("this.matchListSerchdata",this.matchListSerchdata);
    }, error => {
      console.error('error');
    });
  }
}
