import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventmaster',
  templateUrl: './eventmaster.component.html',
  styleUrls: ['./eventmaster.component.scss']
})
export class EventmasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
