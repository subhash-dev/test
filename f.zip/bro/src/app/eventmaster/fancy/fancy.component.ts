import { ChangeDetectorRef, Component, HostListener, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { FancyService } from '../../services/fancy.service';
import { MatchService } from '../../services/match.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TournamentService } from '../../services/tournament.service';
import { SportService } from '../../services/sport.service';
import { UtilityService } from '../../globals/utilityService';
import { isUndefined } from 'util';
import { MarketService } from '../../services/market.service';
import { GameSettingService } from '../../services/gameSettingService.service';
import { UserService } from '../../services/user.service';
import { RoleService } from '../../services/role.service';
import { ToasterConfig } from 'angular2-toaster';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as env from '../../globals/env';
import { NgxSpinnerService } from "ngx-spinner";
import { SocketService } from "../../globals/socketService";
import { pickBy, identity } from 'lodash';
import { IfStmt } from '@angular/compiler';
declare let _: any;
var aes256 = require('aes256');
class Fancy {
  id: number;
  type: string;
  marketType: string;
  name: string;
  createdAt: string;
  isActive: string;
  message: string;
  allowBat: string;
  assignTo: string;
  displayOrder: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}


declare let $: any;

@Component({
  selector: 'app-fancy',
  templateUrl: './fancy.component.html',
  styleUrls: ['./fancy.component.scss']
})
export class FancyComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  @ViewChild('modal', { static: false }) modal: ModalDirective;
  @ViewChild('importmodal', { static: false }) importmodal: ModalDirective;
  @ViewChild('fancymodal', { static: false }) fancymodal: ModalDirective;
  @ViewChild('getfancymodal', { static: false }) getfancymodal: ModalDirective;

  @ViewChild('suspendModal', { static: false }) suspendModal: ModalDirective;
  @ViewChild('deleteModal', { static: false }) deleteModal: ModalDirective;
  @ViewChild('messageModal', { static: false }) messageModal: ModalDirective;
  @ViewChild('gameLimitModal', { static: false }) gameLimitModal: ModalDirective;
  @ViewChild('confirmImport', { static: false }) confirmImport: ModalDirective;
  @ViewChild("addFancyForm", { static: false }) formResetValue;
  @ViewChild("importFancyForm", { static: false }) importFancyForm;
  @ViewChild("fancyImportForm", { static: false }) fancyImportForm;
  @ViewChild("fancyForm", { static: false }) fancyFormResetValue;
  @ViewChild("massage", { static: false }) massage;
  @ViewChild("conformationForm", { static: false }) passwordFormReset;
  @ViewChild('conformationModal', { static: false }) conformationModal: ModalDirective;
  @ViewChild('statusChangeModal', { static: false }) statusChangeModal: ModalDirective;
  @ViewChild('focusInput', { static: false }) focusInput: ElementRef;
  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();

  fancys: Fancy[];
  allFancys = [];
  resData;
  server_url: any = env.server_url();

  formValid= true;
  allowbetUpdate: any;
  settings: any;
  accessRole: any;
  Types = 'Open';
  /* fancyName = [
       {name: 'Match Odds', value: 'MATCH_ODDS'},
       {name: 'Fancy' , value: 'FANCY'},
       {name: 'Book maker', value: 'BOOK_MAKER'}
   ]*/
  fancyFilter = {
    page: 1,
    limit: 50,
    search: null,
    userId: null
  };
  getAllFancys: any;
  fancyConfigObject: any;
  time: any;
  fancyTypes: any;
  paramId: any;
  conformationPassword: any;
  tempMarketObj: any;
  matchSerch: any;
  dataTable: any;
  addFancyObject = {
    marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
    marketType: 'Fancy',
    marketTypeId: '5ebc1code68br4bik5b1808',
    marketStartTime: localStorage.getItem('date'),
    totalMatched: 0,
    runners: null,
    displayName: null,
    isActive: false,
    message: null,
    match: null,
    tournament: null,
    sport: null
  };
  fancyTypeId: any;
  fancySettingObject: any;
  fancyNewSettingObject: any;
  SelecTmatch: any;
  endSubmit = false;
  matchData = [];
  importList = [];
  moduleList = [];
  matchListSerchdata =[];
  filterMatch: any;
  importfancySerachValue:any;
  wrongImport : any = "";
  constructor(private route: ActivatedRoute,
    private matchService: MatchService,
    private fancyService: FancyService,
    private tournamentService: TournamentService,
    private sportService: SportService,
    private marketService: MarketService,
    private utilityService: UtilityService,
    private gameSettingService: GameSettingService,
    private chRef: ChangeDetectorRef,
    private userService: UserService,
    private roleService: RoleService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private socketService: SocketService,
    private http: HttpClient) {
  }

  filter = {
    page: 1,
    limit: -1,
    search: null
  };
  tournamentFilter = {
    page: 1,
    limit: 50,
    search: null
  };
  matchFilter = {
    page: 1,
    limit: 100,
    search: null
  };
  sportList = [];
  selectedSportItems = [];
  sportSettings = {
    singleSelection: true,
    text: 'Select sports',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
  };
  sportId: any;
  tournamentsList = [];
  selectedTournamentsItems = [];
  TournamentsSettings = {
    singleSelection: true,
    text: 'Select tournament',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  tournamentId: any;
  matchList = [];
  selectedMatchItems = [];
  selectedActiveMatchItems = [];
  matchSettings = {
    singleSelection: true,
    text: 'Select match',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  fancyUserList = [];
  selectedUserItems = [];
  importfancyArray = [];
  UserSettings = {
    singleSelection: true,
    text: 'Select user',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: false,
  };
  fancyArray = [{
    fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
    fancyName: null,
    tempAsiignToName: [],
    assignTo: {
      id: null,
      name: null,
      username: null
    },
    fancySetting: {
      maxStack: null,
      minStack: null,
      maxProfit: null,
      betDelay: null,
      maxStackPerOdds: null,
    },
    fancyConfigurationSetting: {
      ballStart: null,
      rateRange: null,
      rateDiffrence: null
    }
  }];
  tempFancy = {
    fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
    fancyName: null,
    assignTo: {
      id: null,
      name: null,
      username: null
    },
    fancySetting: {
      maxStack: null,
      minStack: null,
      maxProfit: null,
      betDelay: null,
      maxStackPerOdds: null,
    },
    fancyConfigurationSetting: {
      ballStart: null,
      rateRange: null,
      rateDiffrence: null
    }
  };
  globleSingleFancyObj: any;
  isActive:any;
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.passwordFormReset.resetForm();
      this.formResetValue.resetForm();
      this.fancyFormResetValue.resetForm();
      this.rerender();
    }
  }

  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if (event.sourceCapabilities) {
    } else {
      this.setFocusToInput();
    }
  }

  ngOnInit() {
    this.SelecTmatch = '';
    if (isUndefined(this.utilityService.returnAccessRole('FANCY'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('FANCY');
    }
    this.route.params.subscribe(params => {
      this.paramId = params['id'];
    });
    this.fancyTypes = this.utilityService.marketType;

    this.getFancysDt(); //get all market by datatable
    this.getAllSport();//get all sport function call
    this.getFancySetting();
    this.getFancyConfig();
    this.getAllModule();

    // this.socketService
    //   .changeStatuses()
    //   .subscribe((response) => {
    //     if (response) {
    //       // this.rerender();
    //       this.getFancysDt();
    //     }
    //   });

      this.matchListSerch();
  }

  setFocusToInput() {
    this.focusInput.nativeElement.focus();
  }

  /**focusInput
   * @author rk
   * @date : 28-01-2020
   * reins data table
   */

  render(): void {
    $('.dataTable').dataTable().fnClearTable();
  }

  /**
   * @author rk
   * @date : 28-01-2020
   * get all data from data table wise
   */

  getFancysDt() {
    // this.spinner.show();
    const that = this;
    let url = this.server_url + 'market/get-all';
    let userId = '';

    // console.log(JSON.parse(this.utilityService.returnLocalStorageData('userData')).userType);
    if (JSON.parse(this.utilityService.returnLocalStorageData('userData')).userType === 'STAFF') {
      userId = (JSON.parse(this.utilityService.returnLocalStorageData('userData')).user_id)
    }
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
       // autoWidth: false,
       // scrollX: true,
       // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',
        emptyTable: 'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { id: this.paramId, userId: userId, matchName: this.SelecTmatch }),
            {}
          ).subscribe(resp => {
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData =JSON.parse(this.resData);
            this.resData = this.resData.data;
            this.spinner.hide();
            if (this.resData.docs.length > 0) {
              that.fancys = this.resData.docs;
              let uniqAry = [];
              let i = 0;
              this.resData.docs.map((data, index) => {
                let findId = uniqAry.find(o => o.id == data.match.id);
                if (!findId) {
                  let obj = {
                    id: data.match.id,
                    name: data.match.name
                  };
                  uniqAry.push(obj);
                }
                if (i == index) {
                  this.filterMatch = uniqAry;
                }
                i = i + 1;
              });
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },
      columns: [{ data: ''}, { data: 'fancyName' }, { data: 'match.name' }, { data: 'createdAt' }, { data: 'marketStartTime' }, { data: 'isActive' }, { data: 'isActive' }, { data: 'allowBat' }, { data: 'assignTo' },{ data: 'fancyModeType' }, { data: 'displayOrder' }],
      columnDefs: [{ orderable: false, targets: [0] }],
    };

  }


   /**
   * get all match list
   */
  matchListSerch() {
    let type = 'Fancy';
    this.marketService.getMatchListSerch(type).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.matchListSerchdata = response.data;
        console.log(this.matchListSerchdata)
    }, error => {
      console.error('error');
    });
  }

  /**
   * get all modules list
   */
  getAllModule() {
    this.roleService.getAllModules().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        response.data.docs.map(data => {
            if (data.moduleName === 'FANCY') {
            this.fancyTypeId = data._id;
            }
        });
    }, error => {
      console.error('error in get modules');
    });

  }


  /**
   * get only fancy user
   */
  getFancyUser() {
    this.userService.fancyUser(this.fancyTypeId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.fancyUserList = response.data.map(data => {
            return { id: data._id, itemName: data.name, userName: data.userName, userType: data.userType }
        });
    }, error => {
      console.error('error in get fancy user');
    });
  }

  /**
   * get fancy global setting and set in main object
   */
  getFancySetting() {
    this.gameSettingService.getAllFancySetting().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.fancySettingObject = response.data.docs[0];
        this.fancyNewSettingObject = response.data.docs[0];


        this.fancyArray[0].fancySetting.maxStack = this.fancySettingObject.maxStack;
        this.fancyArray[0].fancySetting.minStack = this.fancySettingObject.minStack;
        this.fancyArray[0].fancySetting.maxProfit = this.fancySettingObject.maxProfit;
        this.fancyArray[0].fancySetting.betDelay = this.fancySettingObject.betDelay;
        this.fancyArray[0].fancySetting.maxStackPerOdds = this.fancySettingObject.maxStackPerOdds;

        this.tempFancy.fancySetting.maxStack = this.fancyNewSettingObject.maxStack;
        this.tempFancy.fancySetting.minStack = this.fancyNewSettingObject.minStack;
        this.tempFancy.fancySetting.maxProfit = this.fancyNewSettingObject.maxProfit;
        this.tempFancy.fancySetting.betDelay = this.fancyNewSettingObject.betDelay;
        this.tempFancy.fancySetting.maxStackPerOdds = this.fancyNewSettingObject.maxStackPerOdds;
    }, error => {
        console.error('error in get fancy setting', error);
    })
  }


  updateDisplayOrder(data) {
    this.spinner.show();
    setTimeout(res => {
      this.marketService.updateMarket(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        if (response.status === true) {
          this.rerender();
          this.spinner.hide();
          // this.updateWhtLblMarket(data);
          // this.getAllFancy();
          this.utilityService.popToast('success', 'Success', 3000, 'Display Order is successfully change.');
        } else {
          this.utilityService.popToast('error', 'Error', 3000, response.message);
        }
      }, error => {
        console.error('error in priority', error);
      })
    }, 500)
  }

  /**
   * open model as per type
   * @param data
   */
  openModels(data, fancyObject) {
    this.massage.resetForm();
    this.globleSingleFancyObj = fancyObject;

    if (fancyObject.marketType === 'Fancy') {
      this.settings = fancyObject.fancySetting;
    } else if (fancyObject.marketType === 'Bookmaker') {
      this.settings = fancyObject.bookmakerSetting;
    } else {
      this.settings = fancyObject.gameSetting;
    }
    this.addFancyObject = fancyObject;
    if (data === 'suspend') {
      this.suspendModal.show();
    }
    if (data === 'delete') {
      this.deleteModal.show();
    }
    if (data === 'message') {
      this.messageModal.show();
    }
    if (data === 'limit') {
      this.gameLimitModal.show();
    }

  }

  /**
   * close model as per type
   * @param data
   */
  closeModels(data) {
    if (data === 'suspend') {
      this.suspendModal.hide();
    }
    if (data === 'delete') {
      this.deleteModal.hide();
    }
    if (data === 'message') {
      this.messageModal.hide();
    }
    if (data === 'limit') {
      this.gameLimitModal.hide();
    }

  }

  /**
   * set fancy name and id function
   * @param e
   */
  selectmatchType(e) {
    this.addFancyObject.marketType = JSON.parse(e.target.value).name;
    this.addFancyObject.marketTypeId = JSON.parse(e.target.value).id;
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020
   * get all sports
   */
  getAllSport() {
    this.sportService.getAllSport(this.filter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.sportList = response.data.docs.map(data => {
            return { id: data._id, itemName: data.name  + '( ' + data.id + ' )', sportId: data.id };
        });
    }, error => {
        console.error('error in getting all sports', error);
    });
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020;
   * sport search with name
   */
  onSportSearch(e) {
    this.filter.search = e.target.value;
    this.getAllSport();
  }

  /**
   * on sport select call relevant tournaments
   * @param e
   */
  onSportSelect(e) {
    this.sportId = e.sportId;
    this.getAllTournament();
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020
   * get all sports
   */
  getAllTournament() {
    this.tournamentService.getAllTournament(this.tournamentFilter, this.sportId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.tournamentsList = response.data.docs.map(data => {
            return { id: data._id, itemName: data.name  + '( ' + data.id + ' )', tournamentId: data.id };
        });
    }, error => {
        console.error('error in getting all sports', error);
    });
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020;
   * sport search with name
   */
  onTornamentSearch(e) {
    this.tournamentFilter.search = e.target.value;
    this.getAllTournament();
  }

  /**
   * @author karan chokshi
   * @date : 30-01-2019
   * on tournament select relavent match api call
   */
  onTornamentSelect(e) {
    this.tournamentId = e.tournamentId;
    this.getMatches();
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020
   * get all Matches by Tournament id
   */
  getMatches() {
    this.matchService.getAllMatch(this.matchFilter, this.tournamentId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.matchList = response.data.docs.map(data => {
          let date = data.openDate.substring(0,
            data.openDate.indexOf('T'));
            return { id: data._id, itemName: data.name + '( ' + date + ' )', matchId: data.id, matchTime: data.openDate };
        });
    }, error => {
        console.error('get all Matches', error);
    });
  }

    /**
   * @author rk
   * @date : 03-11-2020
   * get all Matches by Tournament id
   */
  getMatchesImport() {
    this.matchService.getAllMatchImport().subscribe(response => {
      this.importList = [];
      if(response.status == true){
        let getActiveGame = JSON.parse(response.data);
        for (const [key, value] of Object.entries(getActiveGame)) {
          let gameObj =  { id: value['game_srno'], itemName: value['game_name'] + '( ' + value['game_time'] + ' )',eventid : value['eventid'],gameTime : value['game_time'] };
          this.importList.push(gameObj);
        }
      }else{
        this.importList = [];
      }
      // this.matchList = response.data.docs.map(data => {
      //   return { id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
      // });
    }, error => {
      console.error('get all Matches', error);
    });
  }


  /**
   * @author karan chokshi
   * @date : 28-01-2020;
   * match search with name
   */
  onMatchSearch(e) {
    this.matchFilter.search = e.target.value;
    this.getMatches();
  }

  /**
   * @author kc
   * @date : 26-03-2020;
   * set market time
   */
  onMatchSelect(e) {
    if (localStorage.getItem('date') === null || localStorage.getItem('date') === 'null') {
      this.addFancyObject.marketStartTime = e.matchTime;
    } else {
      this.addFancyObject.marketStartTime = localStorage.getItem('date');
    }
  }

    /**
   * @author kc
   * @date : 26-03-2020;
   * set market time
   */
  onMatchSelectImport(e) {
    this.importList = [];
    this.getMatchesImport();
      this.getAllFancy(e.matchId);//get all fancy function call
    // if (localStorage.getItem('date') === null || localStorage.getItem('date') === 'null') {
    //   this.addFancyObject.marketStartTime = e.matchTime;
    // } else {
    //   this.addFancyObject.marketStartTime = localStorage.getItem('date');
    // }
  }

    /**
   * @author rk
   * @date : 22-12-2020;
   *
   */
  selectedMatch(){
    if(this.selectedActiveMatchItems[0].eventid == this.selectedMatchItems[0]['matchId']){
      this.wrongImport  = "";
    }else{
      this.confirmImport.show();
      this.wrongImport  = "You have selected wrong match";
    }
  }

  closeModelFancyImp(){
    this.confirmImport.hide();
    this.fancyFormResetValue.resetForm();
    this.formResetValue.resetForm();
    // this.fancyImportForm.resetForm();
    this.importmodal.hide();
    this.importfancyArray =[];
    this.selectedActiveMatchItems = [];
    this.wrongImport = "";
  }
  onSubmitgetMarket(){
    this.confirmImport.hide();
    this.Types = 'Open';
    this.getMarket()
  }



  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  /**
   * open modal
   */
  openModal() {
    this.getFancySetting();
    this.fancyFormResetValue.resetForm();
    this.formResetValue.resetForm();
    this.addFancyObject = {
      marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
      marketType: 'Fancy',
      marketTypeId: '5ebc1code68br4bik5b1808',
      marketStartTime: this.addFancyObject.marketStartTime,
      totalMatched: 0,
      runners: null,
      displayName: null,
      isActive: false,
      message: null,
      match: null,
      tournament: null,
      sport: null
    };
    this.selectedSportItems = [];
    this.selectedTournamentsItems = [];
    this.selectedMatchItems = [];
    this.selectedActiveMatchItems = [];
    this.selectedUserItems = [];
    this.time = null;
    this.fancyArray = [{
      fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      fancyName: null,
      tempAsiignToName: [],
      assignTo: {
        id: null,
        name: null,
        username: null
      },
      fancySetting: {
        maxStack: 100,
        minStack: null,
        maxProfit: null,
        betDelay: null,
        maxStackPerOdds: null,
      },
      fancyConfigurationSetting: {
        ballStart: null,
        rateRange: null,
        rateDiffrence: null
      }
    }];
    this.tempFancy = {
      fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      fancyName: null,

      assignTo: {
        id: null,
        name: null,
        username: null
      },
      fancySetting: {
        maxStack: null,
        minStack: null,
        maxProfit: null,
        betDelay: null,
        maxStackPerOdds: null,
      },
      fancyConfigurationSetting: {
        ballStart: null,
        rateRange: null,
        rateDiffrence: null
      }
    };
    this.modal.show();
    this.getFancyUser();
  }


   /**
   * open modal
   */
  openImportModal() {
    this.getFancySetting();
    this.fancyFormResetValue.resetForm();
    this.formResetValue.resetForm();
    this.addFancyObject = {
      marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
      marketType: 'Fancy',
      marketTypeId: '5ebc1code68br4bik5b1808',
      marketStartTime: this.addFancyObject.marketStartTime,
      totalMatched: 0,
      runners: null,
      displayName: null,
      isActive: false,
      message: null,
      match: null,
      tournament: null,
      sport: null
    };
    this.selectedSportItems = [];
    this.selectedTournamentsItems = [];
    this.selectedMatchItems = [];
    this.selectedUserItems = [];
    this.time = null;
    this.fancyArray = [{
      fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      fancyName: null,
      tempAsiignToName: [],
      assignTo: {
        id: null,
        name: null,
        username: null
      },
      fancySetting: {
        maxStack: 100,
        minStack: null,
        maxProfit: null,
        betDelay: null,
        maxStackPerOdds: null,
      },
      fancyConfigurationSetting: {
        ballStart: null,
        rateRange: null,
        rateDiffrence: null
      }
    }];
    this.tempFancy = {
      fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      fancyName: null,

      assignTo: {
        id: null,
        name: null,
        username: null
      },
      fancySetting: {
        maxStack: null,
        minStack: null,
        maxProfit: null,
        betDelay: null,
        maxStackPerOdds: null,
      },
      fancyConfigurationSetting: {
        ballStart: null,
        rateRange: null,
        rateDiffrence: null
      }
    };
    this.importmodal.show();
    this.getFancyUser();
  }

  /**
   * open modal
   */
  openModal1() {
    this.fancymodal.show();
  }

  /**
   * close modal
   */
  closeModel(data) {
    if (data === 'fancy') {
      this.formResetValue.resetForm();
      this.importFancyForm.resetForm();
      this.modal.hide();
      this.importmodal.hide();
      this.rerender();
    } else {
      this.conformationModal.hide();
      this.statusChangeModal.hide();
      this.render();

    }
  }

  /**
   * close modal
   */
  closeFancyModel() {
    this.getfancymodal.hide();
    this.fancymodal.hide();
    this.fancyFormResetValue.resetForm();
    this.formResetValue.resetForm();
    this.importFancyForm.resetForm();
    this.fancyImportForm.resetForm();
    this.importfancyArray =[];

  }

  /**
   * open runners popup
   */
  addRunners() {
    this.modal.hide();
    this.openModal1();
    this.getFancyUser();
  }

  /**
   * open runners popup
   */
  getMarket() {
    this.Types = 'Open';
    if(this.endSubmit) {
      return;
    }
    this.endSubmit = true;
    this.importmodal.hide();
      let selectedId = this.selectedActiveMatchItems[0].id;
      this.matchService.getAllMarketImport(selectedId).subscribe(response => {
      if(response.status == true){
        let getActiveMarket = JSON.parse(response.data);
        for (const [key, value] of Object.entries(getActiveMarket)) {
          if(value['event_type'] == "Regular"){
            let  assignTo = {
              id : this.fancyUserList[0].id,
              itemName : this.fancyUserList[0].itemName,
              username : this.fancyUserList[0].itemName,
              name : this.fancyUserList[0].itemName,
              userType : this.fancyUserList[0].userType
            };
            value['assignTo'] = assignTo;
            value['tempAsiignToName'] = [assignTo];
                this.importfancyArray.push(value);
          }
        }
        let tempArray = [];
        let tempFancy = [];
        tempFancy = this.allFancys;
        let itesf = true;
        if(this.importfancyArray.length > 0){
          if(itesf) {
            _.map(this.importfancyArray, function (e) {
              itesf = false;
              let adminComAry = tempFancy.find(o => o.fancyId === e.srno);
              if (adminComAry) {

              } else {
                tempArray.push(e);
                itesf = true;
              }
            })
          }
        }
        this.importfancyArray = tempArray;
        tempArray = [];
        this.endSubmit = false;
      }else{
        this.endSubmit = false;
        this.importfancyArray = [];
      }
      // this.matchList = response.data.docs.map(data => {
      //   return { id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
      // });
    }, error => {
        this.endSubmit = false;
      console.error('get all Matches', error);
    });
    this.getfancymodal.show();
  }


  /**
   * @author TR
   * @date 25-02-2020
   * create step 4 (fancy)
   */
  createFancyWhtLbl(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for (let i = 0; i < x.length; i++) {
        this.marketService.addNewFancyMarketWhtLbl(data, x[i]).subscribe(response => {
        });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });
  }

  /**
   * @author karan chokshi
   * @date 31-01-2020
   * create step 4 (fancy)
   */
  createFancy() {
    this.spinner.show();
    // console.log("this.fancyConfigObject",this.fancyConfigObject);
    let finalFancyArray = this.fancyArray;
    finalFancyArray.map(data => {
      data['marketId'] = ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100));
      data['marketType'] = this.addFancyObject.marketType;
      data['marketTypeId'] = this.addFancyObject.marketTypeId;
      data['marketStartTime'] = this.addFancyObject.marketStartTime;
      data['fancyMode'] = 'Manual';
      data['fancyModeType'] = 'Manual';
      data['totalMatched'] = 0;
      data['displayOrder'] = 9;
      data['gameSetting'] = null;
      data['fancyConfigurationSetting'] = {
        ballStart: this.fancyConfigObject[0].ballStart,
        rateRange: this.fancyConfigObject[0].rateRange,
        rateDiffrence: this.fancyConfigObject[0].rateDiffrence
      };
      data['marketStatus'] = {
        id: 'MS940896',
        name: 'suspend'
      };
      data['bookmakerSetting'] = null;
      data['isActive'] = this.addFancyObject.isActive;
      data['sport'] = {
        id: this.selectedSportItems[0]['sportId'],
        name: this.selectedSportItems[0]['itemName']
      };
      data['tournament'] = {
        id: this.selectedTournamentsItems[0]['tournamentId'],
        name: this.selectedTournamentsItems[0]['itemName']
      };
      data['match'] = {
        id: this.selectedMatchItems[0]['matchId'],
        name: this.selectedMatchItems[0]['itemName']
      };
      return data;
    });
    this.marketService.addNewFancyMarket(finalFancyArray).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.spinner.hide();
        this.fancymodal.hide();
        if (response.status === true) {
            this.render();
            this.utilityService.popToast('success', 'Success', 3000, 'Fancy created successfully.');
            finalFancyArray.map(data => {
                delete data.fancyConfigurationSetting;
                return data;
            });
        // console.log(finalFancyArray);
        //  this.createFancyWhtLbl(finalFancyArray);
        } else {
            this.spinner.hide();
            this.utilityService.popToast('error', 'Error', 3000, response.message);
        }
        //this.getAllFancy(); // recall all market api for sysnc data
    }, error => {
      console.error('add market error', error);
    });


  }


  /**
   * @author ravi kadia
   * @date 04-11-2020
   * create step 4 (fancy)
   */
  createFancyImport() {
    if(this.endSubmit) {
      return;
    }
    this.endSubmit = true;
    this.spinner.show();
    let finalFancyArrayData = [];
    let finalFancyArray = this.importfancyArray.map(data => {
      if(data.checkBoxValue){
      data['marketId'] = ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100));
      data['fancyId'] = data.srno;
      data['fancyMode'] = 'Auto';
      data['fancyName'] = data.event_name;
      data['marketType'] = this.addFancyObject.marketType;
      data['marketTypeId'] = this.addFancyObject.marketTypeId;
      data['marketStartTime'] = this.selectedMatchItems[0]['matchTime'];
      data['fancySetting'] = this.fancyNewSettingObject;
      data['totalMatched'] = 0;
      data['displayOrder'] = data.display_srno;
      data['gameSetting'] = null;
      data['fancyConfigurationSetting'] = {
        ballStart: this.fancyConfigObject[0].ballStart,
        rateRange: this.fancyConfigObject[0].rateRange,
        rateDiffrence: this.fancyConfigObject[0].rateDiffrence
      };
      data['marketStatus'] = {
        id: 'MS081893',
        name: 'open'
      };
      data['bookmakerSetting'] = null;
      data['isActive'] = this.addFancyObject.isActive;
      data['sport'] = {
        id: this.selectedSportItems[0]['sportId'],
        name: this.selectedSportItems[0]['itemName']
      };
      data['tournament'] = {
        id: this.selectedTournamentsItems[0]['tournamentId'],
        name: this.selectedTournamentsItems[0]['itemName']
      };
      data['match'] = {
        id: this.selectedMatchItems[0]['matchId'],
        name: this.selectedMatchItems[0]['itemName']
      };
      return data;
      }
    });

     finalFancyArrayData = _.without(finalFancyArray, undefined);
    this.marketService.addNewFancyMarket(finalFancyArrayData).subscribe(response => {
      console.log("response++++++++++++++++++++++",response);
      console.log("this.importfancyArray[0]++++++++++++++++++++++",this.importfancyArray[0]);
      response = this.utilityService.gsk(response.auth);
      response =JSON.parse(response);

      this.spinner.hide();
      this.getfancymodal.hide();
      this.fancyFormResetValue.resetForm();
      this.formResetValue.resetForm();
      this.importFancyForm.resetForm();
      this.endSubmit = false;
      if (response.status === true) {
        this.render();
        this.utilityService.popToast('success', 'Success', 3000, 'Fancy created successfully.');
        finalFancyArrayData.map(data => {
          delete data.fancyConfigurationSetting;
          return data;
        });
        console.log(response);
        // this.createFancyWhtLbl(finalFancyArrayData);
        let gameSrNo = this.importfancyArray[0].game_srno;

        this.matchService.getBymatchId(response.data[0].match.id)
        .subscribe(response => {
          response = this.utilityService.gsk(response.auth);
          response =JSON.parse(response);
          if(response.status == true){
            let objectRedis = {
              fancyId : gameSrNo,
              fancyName : response.data.match.name,
              fancyStartTime : response.data.marketStartTime,
              fancymarketId  : response.data.marketId,
            }
            this.gameActiveRedis(objectRedis);
          }
          // this.utilityService.popToast('success', 'Success', 3000, 'Active fancy successfully.');
        }, error => {
        })
        this.importList = [];
        this.importfancyArray = [];
        finalFancyArray = [];
      } else {
        this.endSubmit = false;
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, response.message);
      }
      //this.getAllFancy(); // recall all market api for sysnc data
    }, error => {
      this.endSubmit = false;
      console.error('add market error', error);
    });


  }

  /***
   * push new fancy object in runners array
   * @param object
   * @param array
   */
  addNewFancyObjectToArray(object, array) {
    this.tempFancy = {
      fancyId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
      fancyName: null,
      assignTo: {
        id: null,
        name: null,
        username: null
      },
      fancySetting: {
        maxStack: this.fancyNewSettingObject.maxStack,
        minStack: this.fancyNewSettingObject.minStack,
        maxProfit: this.fancyNewSettingObject.maxProfit,
        betDelay: this.fancyNewSettingObject.betDelay,
        maxStackPerOdds: this.fancyNewSettingObject.maxStackPerOdds
      },
      fancyConfigurationSetting: {
        ballStart: this.fancyConfigObject[0].ballStart,
        rateRange: this.fancyConfigObject[0].rateRange,
        rateDiffrence: this.fancyConfigObject[0].rateDiffrence
      }
    };
    array = array || [{}];
    object = typeof object === 'object' ? object || {} : '';
    array.push(object);

  }


  /**
   * Removes given object from the given array
   * @param object
   * @param array
   */
  removeObjectFromArray(object, array) {
    const index = array.indexOf(object);
    array.splice(index, 1);
  }

  /**
   * assign user to fancy
   * @param e
   * @param fancy
   */
  selectAssignTo(e, fancy) {
    this.fancyArray.map(data => {
      if (data.fancyId === fancy.fancyId) {
        data.assignTo.id = e.id;
        data.assignTo.name = e.itemName;
        data.assignTo.username = e.username;
        return data;
      } else {
        return data;
      }
    });
  }

  selectImportAssignTo(e, fancy){
    this.importfancyArray.map(data => {
      // console.log(data);
      if (data.srno === fancy.srno) {
        data.assignTo.id = e.id;
        data.assignTo.name = e.itemName;
        data.assignTo.username = e.username;
        return data;
      } else {
        return data;
      }
    });
  }


  updateUserStatus() {
    this.spinner.show();
    let key = env.constantKey();
    let token = this.conformationPassword;
    var encrypted = aes256.encrypt(key, token);
    this.tempMarketObj['token'] = encrypted;
    this.marketService.updateMarket(this.tempMarketObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.messageModal.hide();
        this.conformationModal.hide();
        this.spinner.hide();
        // this.updateWhtLblMarket(this.tempMarketObj);
        this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
    }, error => {
        this.messageModal.hide();
        this.conformationModal.hide();
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, error.error.message);
    })
  }


  onchange(object,pageNo) {
    if(pageNo === 'allowBet'){
    this.allowbetUpdate = true;
    }
    this.passwordFormReset.resetForm();
    this.conformationModal.show();
    this.tempMarketObj = object;
  }
  onchangeWithoutPassword(object){
    this.tempMarketObj = object;
    this.updateUserStatusWithoutPassword();
  }

  updateMessage() {
    this.tempMarketObj = this.addFancyObject;
    this.updateUserStatus();
    this.addFancyObject.message = '';
  }

  clearMessage() {
    this.addFancyObject.message = '';
  }

  /***
   * update setting data (limits)
   * @param data
   */
  updateSetting(data) {
    this.spinner.show();
    this.tempMarketObj = this.globleSingleFancyObj;
    this.tempMarketObj.fancySetting.minStack = Number(this.tempMarketObj.fancySetting.minStack);
    this.tempMarketObj.fancySetting.maxStack = Number(this.tempMarketObj.fancySetting.maxStack);
    this.tempMarketObj.fancySetting.maxProfit = Number(this.tempMarketObj.fancySetting.maxProfit);
    this.tempMarketObj.fancySetting.betDelay = Number(this.tempMarketObj.fancySetting.betDelay);
    this.tempMarketObj.fancySetting.maxStackPerOdds = Number(this.tempMarketObj.fancySetting.maxStackPerOdds);

    let checkUserObj = {
      id: this.utilityService.returnLocalStorageData('userId'),
      password: this.conformationPassword
    };

    this.userService.checkUser(checkUserObj).subscribe(checkUserResponse => {
        checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
        checkUserResponse =JSON.parse(checkUserResponse);
        if (checkUserResponse.status === true) {
          this.marketService.updateMarketData(this.tempMarketObj)
            .subscribe(response => {
              this.gameLimitModal.hide();
              this.spinner.hide();
              // this.updateWhtLblMarket(this.tempMarketObj);
              this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
            }, error => {

            })
        } else {
          this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
        }

      }, error => {
        this.utilityService.popToast('error', 'Error', 3000, error.error.message);
      });
  }
  /***
   * update in market data in  multiple white label
   * @param data
   */
  updateWhtLblMarket(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      for (let i = 0; i < x.length; i++) {
        this.marketService.updateWhtLblMarket(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 08-06-2020
   * get fancy configures
   */
  getFancyConfig() {
    this.gameSettingService.getAllfancyConfgSetting().subscribe(responseCong => {
        responseCong = this.utilityService.gsk(responseCong.auth);
        responseCong =JSON.parse(responseCong);
        if (responseCong) {
            this.fancyConfigObject = responseCong.data;
        }
    }, error => {
        console.error('get fancy configure setting successfully', error);
    });
  }

  /**
   * @author TR
   * @date : 08-06-2020
   * get fancy configures
   */
  getAllFancy(e) {
    this.marketService.getAllfancy(e).subscribe(allFancy => {
        allFancy = this.utilityService.gsk(allFancy.auth);
        allFancy =JSON.parse(allFancy);
        if (allFancy) {
            this.allFancys = allFancy.data;
        }
    }, error => {
        console.error('get fancy  successfully', error);
    });
  }

  searchSettleData() {
    if (this.SelecTmatch) {
      this.getFancysDt();
      this.rerender();
    }
  }

  clear() {
    if (this.SelecTmatch) {
      this.matchSerch = '';
      this.SelecTmatch = '';
      this.getFancysDt();
      this.rerender();
    }

  }
  updateStatus() {
    this.spinner.show();
    let status = {
      value: "SUSPENDED",
      name: "suspend",
      id: "MS940896"
    };
    this.globleSingleFancyObj.marketStatus = status;
    this.marketService.updateMarket(this.globleSingleFancyObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.suspendModal.hide();
        this.spinner.hide();
        // this.updateWhtLblMarket(this.globleSingleFancyObj);
        this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
      }, error => {

      })
  }

  gameActiveRedis(id) {
    this.matchService.activeRedisFancyAutoRate(id).subscribe(response => {
        // this.utilityService.popToast('success', 'Success', 3000, 'Active fancy successfully.');
      }, error => {

      })
  }

  updateUserStatusWithoutPassword() {
    this.marketService.updateMarket(this.tempMarketObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status) {
            this.messageModal.hide();
            this.spinner.hide();
            // this.updateWhtLblMarket(this.tempMarketObj);
            this.statusChangeModal.hide();
            this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
        }else {
            this.utilityService.popToast('error', 'Error', 3000, response.message);

        }
    }, error => {

    })
  }



selectAllAccess(e) {
    if (e.target.checked === true) {
        this.moduleList = [];
        this.importfancyArray = this.importfancyArray.map(mDats =>{
            this.moduleList.push(mDats.srno);
            mDats.checkBoxValue = true;
            return mDats;
        })
        // return data;
    } else {
        this.importfancyArray = this.importfancyArray.map(mDats =>{
            mDats.checkBoxValue = false;
            return mDats;
        });
        this.moduleList = [];
        // return data;
    }
}

  /**
   * check module insert or not in array list
   */

  check(e, data) {
    if (e.target.checked === true) {
      this.importfancyArray = this.importfancyArray.map(mDats =>{

        if(mDats.srno === data.srno){

          this.moduleList.push(data.srno);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data.srno);

      this.moduleList = arr2;
      this.importfancyArray = this.importfancyArray.filter(mDats =>{

        if(mDats.srno === data.srno){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }

  multiAssign(e){
    this.formValid = true;
    this.importfancyArray.map(data => {
        let assignObj = {
          id : e.id,
          itemName : e.itemName,
          username : e.itemName,
          name : e.itemName,
          userType : e.userType
        }
        data.tempAsiignToName[0] = assignObj;
        data.assignTo = assignObj;
        return data;
    });
  }
  // selectTypeRes(e){
  //   console.log(e.target.value);
  //   // this.importfancyArray = this.importfancyArray.filter(data => {
  //   //    if(e.target.value === 'Cancel' && data.void_status === 'Y'){
  //   //      return data
  //   //    }
  //   //    if(e.target.value === 'Open' && data.void_status === 'N'){
  //   //      return data
  //   //    }
  //   // });
  // }

  onKeyUp(){

    const x = this.importfancySerachValue.toLowerCase();
    if(x){
      // this.getMarket();
      this.importfancyArray = _.filter(this.importfancyArray, function(item) {
        if (item.event_name.toLowerCase().indexOf(x) !== -1) {
          return item;
        }
      });

    } else {
      this.importfancyArray = [];
      this.getMarket();
    }


    // if (this.importfancyArray && this.importfancyArray.length > 0) {
    //   this.filterData = true;
    // } else {
    //   this.filterData = false;
    // }
  }


}
