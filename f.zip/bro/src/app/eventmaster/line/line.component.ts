import { ChangeDetectorRef, Component, HostListener, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { NgxSpinnerService } from "ngx-spinner";
import * as env from '../../globals/env';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { ModalDirective } from 'ngx-bootstrap';
import { UserService } from '../../services/user.service';
import { MarketService } from '../../services/market.service';
import { UtilityService } from '../../globals/utilityService';
import { RoleService } from '../../services/role.service';
import { isUndefined } from "util";
import { ActivatedRoute, Router } from '@angular/router';
import { GameSettingService } from '../../services/gameSettingService.service';
import { SocketService } from '../../globals/socketService';
declare let $: any;
var aes256 = require('aes256');

class Fancy {
  id: number;
  type: string;
  marketType: string;
  name: string;
  createdAt: string;
  isActive: string;
  message: string;
  allowBat: string;
  assignTo: string;
  displayOrder: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-line',
  templateUrl: './line.component.html',
  styleUrls: ['./line.component.scss']
})
export class LineComponent implements OnInit {
  @ViewChild('suspendModal', { static: false }) suspendModal: ModalDirective;
  @ViewChild('messageModal', { static: false }) messageModal: ModalDirective;
  @ViewChild('gameLimitModal', { static: false }) gameLimitModal: ModalDirective;
  @ViewChild("conformationForm", { static: false }) passwordFormReset;
  @ViewChild('conformationModal', { static: false }) conformationModal: ModalDirective;
  @ViewChild('statusChangeModal', {static: false}) statusChangeModal: ModalDirective;
  @ViewChild('focusInput', { static: false }) focusInput: ElementRef;
  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  line: Fancy[];
  resData;
  fancyTypes: any;
  filterMatch: any;
  fancyTypeId: any;
  accessRole: any;
  paramId: any;
  tempMarketObj: any;
  fancySettingObject: any;
  settings: any;
  message: any;
  fancyNewSettingObject: any;
  globleSingleFancyObj: any;
  conformationPassword: any;
  matchNameVaule: any = '';
  server_url: any = env.server_url();
  SelecTmatch: any;
  matchListSerchdata:[];
  constructor(
    private spinner: NgxSpinnerService,
    private userService: UserService,
    private roleService: RoleService,
    private route: ActivatedRoute,
    private gameSettingService: GameSettingService,
    private router: Router,
    private socketService: SocketService,
    private http: HttpClient,
    private marketService: MarketService,
    private utilityService: UtilityService,
  ) { }

  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if (event.sourceCapabilities) {
    } else {
      this.setFocusToInput();
    }
  }


  ngOnInit() {
    if (isUndefined(this.utilityService.returnAccessRole('LINE'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('LINE');
    }
    this.route.params.subscribe(params => {
      this.paramId = params['id'];
    });
    this.fancyTypes = this.utilityService.marketType;
    this.getMarketLine();
    this.getAllModule();
    this.matchListSerch();

  }
  setFocusToInput() {
    this.focusInput.nativeElement.focus();
  }

  getMarketLine() {
    this.rerender();
    this.spinner.show();
    const that = this;
    let url = this.server_url + 'market/line';
    let userId = '';
    console.log(JSON.parse(this.utilityService.returnLocalStorageData('userData')).userType);
    if (JSON.parse(this.utilityService.returnLocalStorageData('userData')).userType === 'STAFF') {
      userId = (JSON.parse(this.utilityService.returnLocalStorageData('userData')).user_id)
    }
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      // autoWidth: false,
      // scrollX: true,
      // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',
        emptyTable: 'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { id: this.paramId, userId: userId, matchName: this.matchNameVaule }),
            {}
          ).subscribe(resp => {
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData =JSON.parse(this.resData);
            this.resData = this.resData.data;
            this.spinner.hide();
            if (this.resData.docs.length > 0) {
              that.line = this.resData.docs;
            }
            if (this.resData.docs.length > 0) {
              that.line = this.resData.docs;
              console.log(that.line);
              let uniqAry = [];
              let i = 0;
              this.resData.docs.map((data, index) => {
                let findId = uniqAry.find(o => o.id == data.match.id);
                if (!findId) {
                  let obj = {
                    id: data.match.id,
                    name: data.match.name
                  }
                  uniqAry.push(obj);
                }
                if (i == index) {
                  this.filterMatch = uniqAry;
                }
                i = i + 1;
              });
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },
      columns: [{ data: '' }, { data: 'lineName' }, { data: 'match.name' }, { data: 'createdAt' },{ data: 'marketStartTime' }, { data: 'isActive' }, { data: 'isActive' }, { data: 'allowBat' }, { data: 'assignTo' }, { data: 'displayOrder' }],
      columnDefs: [{ orderable: false, targets: [0] }]
    };

  }

  onchange(object) {
    this.passwordFormReset.resetForm();
    this.conformationModal.show();
    this.tempMarketObj = object;
  }

  onchangeWithoutPassword(object){
    this.tempMarketObj = object;
    this.updateUserStatusWithoutPassword();
  }
  /**
   * close modal
   */
  closeModel(data) {
    if (data) {
      this.conformationModal.hide();
    }
    this.statusChangeModal.hide();
    this.getMarketLine();
  }

  /**
   * open model as per type
   * @param data
   */
  openModels(data, fancyObject) {

    this.globleSingleFancyObj = fancyObject;

    if (fancyObject.marketType === 'Line') {
      this.settings = fancyObject.lineSetting;
    }

    if (data === 'suspend') {
      this.suspendModal.show();
    }
    if (data === 'message') {
      this.messageModal.show();
    }
    if (data === 'limit') {
      this.gameLimitModal.show();
    }
    if (data === 'open') {
      this.openMarket();
    }

  }

  /**
   * close model as per type
   * @param data
   */
  closeModels(data) {
    if (data === 'suspend') {
      this.suspendModal.hide();
    }
    if (data === 'message') {
      this.messageModal.hide();
    }
    if (data === 'limit') {
      this.gameLimitModal.hide();
    }

  }

  /***
  * update in market data in  multiple white label
  * @param data
  */
  updateWhtLblMarket(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      for (let i = 0; i < x.length; i++) {
        this.marketService.updateWhtLblMarket(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success', 'Success', 1000, 'white market updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });
  }

  openMarket(){
    this.spinner.show();
    let status = {
      value: "OPEN",
      name: "open",
      id: "MS081893"
    };
    this.globleSingleFancyObj.marketStatus = status;
    this.marketService.updateMarket(this.globleSingleFancyObj).subscribe(response => {
        this.suspendModal.hide();
        this.spinner.hide();
        // this.updateWhtLblMarket(this.globleSingleFancyObj);
        this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
      }, error => {

      })
  }

  updateUserStatus() {
    this.spinner.show();
          let key = env.constantKey();
          let token = this.conformationPassword;
          var encrypted = aes256.encrypt(key, token);
          this.tempMarketObj['token'] = encrypted;
          this.marketService.updateMarket(this.tempMarketObj).subscribe(response => {
              this.messageModal.hide();
              this.conformationModal.hide();
              this.spinner.hide();
              // this.updateWhtLblMarket(this.tempMarketObj);
              this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
            }, error => {
              this.messageModal.hide();
              this.conformationModal.hide();
              this.spinner.hide();
              this.utilityService.popToast('error', 'Error', 3000, error.error.message);
            })
  }

  /**
   * get all modules list
   */
  getAllModule() {
    this.roleService.getAllModules().subscribe(response => {
        this.resData = this.utilityService.gsk(response.auth);
        this.resData =JSON.parse(this.resData);
      this.resData.data.docs.map(data => {
            if (data.moduleName === 'LINE') {
            this.fancyTypeId = data._id;
            }
        });
    }, error => {
        console.error('error in get modules');
    });

  }


  /***
   * update setting data (limits)
   * @param data
   */
  updateSetting(data) {
    this.spinner.show();
    this.tempMarketObj = this.globleSingleFancyObj;
    this.tempMarketObj.lineSetting.minStack = Number(this.settings.minStack);
    this.tempMarketObj.lineSetting.maxStack = Number(this.settings.maxStack);
    this.tempMarketObj.lineSetting.maxProfit = Number(this.settings.maxProfit);
    this.tempMarketObj.lineSetting.betDelay = Number(this.settings.betDelay);
    this.tempMarketObj.lineSetting.maxStackPerOdds = Number(this.settings.maxStackPerOdds);

    let checkUserObj = {
      id: this.utilityService.returnLocalStorageData('userId'),
      password: this.conformationPassword
    };

    this.userService.checkUser(checkUserObj).subscribe(checkUserResponse => {
        checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
        checkUserResponse =JSON.parse(checkUserResponse);
        if (checkUserResponse.status === true) {
          this.marketService.updateMarket(this.tempMarketObj).subscribe(response => {
              this.gameLimitModal.hide();
              this.spinner.hide();
              // this.updateWhtLblMarket(this.tempMarketObj);
              this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
            }, error => {

            })
        } else {
          this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
        }

      }, error => {
        this.utilityService.popToast('error', 'Error', 3000, error.error.message);
      });
  }

  updateMessage() {
    this.globleSingleFancyObj['message'] = this.message;
    this.tempMarketObj = this.globleSingleFancyObj;
    this.updateUserStatus();
  }

  clearMessage() {
    this.message = '';
  }

  updateStatus() {
    this.spinner.show();
    let status = {
      value: "SUSPENDED",
      name: "suspend",
      id: "MS940896"
    };
    var obj = {
      marketId: this.globleSingleFancyObj.marketId,
      status: 'suspend',
      type: "line"
    };
    this.socketService.changeStatus(obj);
    this.globleSingleFancyObj.marketStatus = status;
    this.marketService.updateMarket(this.globleSingleFancyObj).subscribe(response => {
        this.suspendModal.hide();
        this.spinner.hide();
        // this.updateWhtLblMarket(this.globleSingleFancyObj);
        this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
      }, error => {

      })
  }

  searchSettleData() {
    if (this.matchNameVaule) {
         // this.getMarketLine();
        this.rerender();
    }
  }

  clear() {
    if (this.matchNameVaule) {
        this.matchNameVaule = '';
        // this.getMarketLine();
        this.rerender();
    }
  }
  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }

  updateUserStatusWithoutPassword() {
    this.marketService.updateMarket(this.tempMarketObj).subscribe(response => {
        this.messageModal.hide();
        this.spinner.hide();
        this.statusChangeModal.hide();
        this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
      }, error => {
      })
  }

  updateDisplayOrder(data) {
    this.spinner.show();
    setTimeout(res => {
      this.marketService.updateMarket(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status === true) {
            this.rerender();
            this.spinner.hide();
            // this.updateWhtLblMarket(data);
            // this.getAllFancy();
            this.utilityService.popToast('success', 'Success', 3000, 'Display Order is successfully change.');
        } else {
            this.utilityService.popToast('error', 'Error', 3000, response.message);
        }
      }, error => {
            console.error('error in priority', error);
      })
    }, 500)
  }

    /**
   * get all match list
   */
  matchListSerch() {
    let type = 'Line';
    this.marketService.getMatchListSerch(type).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.matchListSerchdata = response.data;
    }, error => {
        console.error('error');
    });
  }
}
