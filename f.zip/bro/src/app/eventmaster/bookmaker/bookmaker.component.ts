import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild,ElementRef} from '@angular/core';
import {UtilityService} from '../../globals/utilityService';
import {SportService} from '../../services/sport.service';
import {MatchService} from '../../services/match.service';
import {TournamentService} from '../../services/tournament.service';
import {ActivatedRoute, Router} from '@angular/router';
import {ModalDirective} from 'ngx-bootstrap';
import {BookmakerService} from '../../services/bookmaker.service';
import {isUndefined} from 'util';
import {MarketService} from '../../services/market.service';
import { RoleService } from '../../services/role.service';
import {GameSettingService} from '../../services/gameSettingService.service';
import {ToasterConfig} from 'angular2-toaster';
import {UserService} from '../../services/user.service';
import {NgxSpinnerService} from "ngx-spinner";
import {SocketService} from "../../globals/socketService";
import { HttpClient, HttpResponse } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import {Subject} from "rxjs";
import * as env from "../../globals/env";
var aes256 = require('aes256');

declare let _: any;
declare let $: any;
class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-bookmaker',
  templateUrl: './bookmaker.component.html',
  styleUrls: ['./bookmaker.component.scss']
})
export class BookmakerComponent implements OnInit {

  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });

  @ViewChild('modal', {static: false}) modal: ModalDirective;
  @ViewChild('importmodal', { static: false }) importmodal: ModalDirective;
  @ViewChild('runnersmodal', {static: false}) runnersmodal: ModalDirective;
  @ViewChild('suspendModal', {static: false}) suspendModal: ModalDirective;
  @ViewChild('deleteModal', {static: false}) deleteModal: ModalDirective;
  @ViewChild('messageModal', {static: false}) messageModal: ModalDirective;
  @ViewChild('gameLimitModal', {static: false}) gameLimitModal: ModalDirective;
  @ViewChild('addBookmakerForm', {static: false}) formResetValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild('statusChangeModal', {static: false}) statusChangeModal: ModalDirective;
  @ViewChild('focusInput' ,  {static: false}) focusInput: ElementRef;
  @ViewChild("importBookmakerForm", { static: false }) importBookmakerForm;
  @ViewChild('getbmmodal', { static: false }) getbmmodal: ModalDirective;
  @ViewChild("matchSettled", { static: false }) matchSettled: ModalDirective;

  @ViewChild(DataTableDirective, {static: false})
  dtElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();
  resData;
  formValid= true;
  filterMatch: any;
  server_url: any = env.server_url();
  selectedTeam: any;
  matchId: any;

  /* bookmakerName = [
       {name: 'Match Odds', value: 'MATCH_ODDS'},
       {name: 'Bookmaker' , value: 'FANCY'},
       {name: 'Book maker', value: 'BOOK_MAKER'}
   ]*/
  bookmakerFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  accessRole: any;
  getAllBookmakers: any;
  time: any;
  bookmakerTypes: any;
  conformationPassword: any;
  tempMarketObj: any;
  paramId: any;
  dataTable: any;
  addBookmakerObject = {
    marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
    marketType: 'Bookmaker',
    marketTypeId: '5ebc1code68br4bik5b0810',
    marketStartTime: this.utilityService.returnLocalStorageData('dateTime'),
    totalMatched: 0,
    runners: null,
    displayName: null,
    isActive: false,
    message: null,
    match: null,
    tournament: null,
    assignTo: {
      id: null,
      name: null,
      username: null
    },
    sport: null
  };
  settledObj = {
    matchId: null,
    team: null
  }
  endSubmit = false;
  importList = [];
  assignTo = [];
  bmUserList = [];
  moduleList = [];
  selectedActiveMatchItems = [];
  importBookmakerArray = [];
  marketRunners = [];
  bmTypeId : any;
  UserSettings = {
    singleSelection: true,
    text: 'Select user',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: false,
  };
  constructor(private route: ActivatedRoute,
              private matchService: MatchService,
              private bookmakerService: BookmakerService,
              private tournamentService: TournamentService,
              private sportService: SportService,
              private marketService: MarketService,
              private utilityService: UtilityService,
              private chRef: ChangeDetectorRef,
              private gameSettingService: GameSettingService,
              private spinner: NgxSpinnerService,
              private userService: UserService,
              private socketService: SocketService,
              private roleService: RoleService,
              private http: HttpClient,
              private router: Router) {
  }

  filter = {
    page: 1,
    limit: -1,
    search: null
  };
  tournamentFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  matchFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  sportList = [];
  settings: any;
  selectedSportItems = [];
  sportSettings = {
    singleSelection: true,
    text: 'Select sports',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
  };
  sportId: any;
  tournamentsList = [];
  selectedTournamentsItems = [];
  TournamentsSettings = {
    singleSelection: true,
    text: 'Select tournament',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  tournamentId: any;
  matchList = [];
  selectedMatchItems = [];
  matchSettings = {
    singleSelection: true,
    text: 'Select match',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  runnes = [{
    selectionId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
    runnerName: null,
    handicap: 1,
    sortPriority: 0,
    metadata: {
      runnerId: (Math.floor(Math.random() * (999999999 - 10000 * 1) * 1000))
    }

  }];
  tempRunners = {
    selectionId: (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000)),
    runnerName: null,
    handicap: 1,
    sortPriority: 0,
    metadata: {
      runnerId: (Math.floor(Math.random() * (999999999 - 10000 * 1) * 1000))
    }

  };
  globleSingleFancyObj: any;
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.passwordFormReset.resetForm();
      this.formResetValue.resetForm();
      this.rerender();
    }
  }
  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if(event.sourceCapabilities) {

    }else {
      this.setFocusToInput();
    }
  }
  ngOnInit() {
    if (isUndefined(this.utilityService.returnAccessRole('BOOKMAKER'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('BOOKMAKER');
    }

    this.route.params.subscribe(params => {
      this.paramId = params['id'];
    });
    this.bookmakerTypes = this.utilityService.marketType;

    this.getAllSport();//get all sport function call
    this.getAllBookmaker();//get all bookmaker function call
    this.getAllModule();
    // this.socketService.changeStatuses().subscribe((response) => {
    //     if(response){
    //       this.rerender();
    //       this.getAllBookmaker();
    //     }
    //   });
  }

  setFocusToInput() {
    this.focusInput.nativeElement.focus();
  }

  /**
   * @author kc
   * @date : 31-01-2020
   * get all bookmaker
   */
  getAllBookmaker() {

    let userId = '';
    if (JSON.parse(this.utilityService.returnLocalStorageData('userData')).userType === 'STAFF') {
      userId = (JSON.parse(this.utilityService.returnLocalStorageData('userData')).user_id)
    }
    let data = {
      filter: this.bookmakerFilter,
      id: this.paramId,
      userId : userId
    };
    //this.spinner.show();
    const that = this;
    let url = this.server_url + 'market/bookmaker';
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      // autoWidth: false,
      // scrollX: true,
      // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters,data),
            {}
          ).subscribe(resp => {
          this.spinner.hide();
          this.resData = resp;
          this.resData = this.utilityService.gsk(this.resData.auth);
          this.resData = JSON.parse(this.resData);
          this.resData = this.resData.data;
          if(this.resData.docs.length > 0){
            that.getAllBookmakers = this.resData.docs;
            let uniqAry = [];
            let i = 0;
            this.resData.docs.map((data, index) => {
              let findId = uniqAry.find(o => o.id == data.match.id);
              if (!findId) {
                let obj = {
                  id: data.match.id,
                  name: data.match.name
                };
                uniqAry.push(obj);
              }
              if (i == index) {
                this.filterMatch = uniqAry;
              }
              i = i + 1;
            });
          }
          this.dtTrigger.next();
          callback({
            recordsTotal: this.resData.total,
            recordsFiltered: this.resData.total,
            data: []
          });
        });
      },
      columns: [{data: 'id'}, {data: 'marketType'}, {data: 'match.name'}, {data: 'createdAt'},{data: 'marketStartTime'}, {data: 'isActive'}, {data: 'isActive'}, {data: 'allowBat'},{data: 'assignTo.name'}, {data: 'displayOrder'},{data: ''}],
      columnDefs: [{orderable: false, targets: [0]}]

    };
    // this.spinner.show();
    // this.bookmakerService.getAllBookmaker(this.bookmakerFilter, this.paramId).subscribe(response => {
    //   this.getAllBookmakers = response.data;
    //   this.spinner.hide();
    //   this.chRef.detectChanges();
    //   const table: any = $('table');
    //   this.dataTable = table.DataTable({
    //     /* serverSide : true,
    //      processing : true*/
    //   });
    // }, error => {
    //   console.error('get error fron all bookmaker');
    // });

  }

  updateDisplayOrder(data) {
    this.spinner.show();
    setTimeout(res => {
      this.marketService.updateMarket(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        if (response.status === true) {
          this.getAllBookmaker();
          this.spinner.hide();
          this.rerender();
          // this.updateWhtLblMarket(data);
          this.utilityService.popToast('success', 'Success', 3000, 'Display Order update  successfully.');
        } else {
          this.utilityService.popToast('error', 'Error', 3000, response.message);
        }
      }, error => {
        console.error('error in priority', error);
      })
    }, 500)

  }

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }

  /**
   * open model as per type
   * @param data
   */
  openModels(data, bookmakerObj) {
    console.log(bookmakerObj)
    this.globleSingleFancyObj = bookmakerObj;
    if (bookmakerObj.marketType === 'Fancy') {
      this.settings = bookmakerObj.fancySetting;
    } else if (bookmakerObj.marketType === 'Bookmaker') {
      this.settings = bookmakerObj.bookmakerSetting;
    } else {
      this.settings = bookmakerObj.gameSetting;
    }
    this.addBookmakerObject = bookmakerObj;
    if (data === 'suspend') {
      this.suspendModal.show();
    }
    if (data === 'delete') {
      this.deleteModal.show();
    }
    if (data === 'message') {
      this.messageModal.show();
    }
    if (data === 'limit') {
      this.gameLimitModal.show();
    }

  }

  /**
   * close model as per type
   * @param data
   */
  closeModels(data) {
    if (data === 'suspend') {
      this.suspendModal.hide();
    }
    if (data === 'delete') {
      this.deleteModal.hide();
    }
    if (data === 'message') {
      this.messageModal.hide();
    }
    if (data === 'limit') {
      this.gameLimitModal.hide();
    }

  }

  /**
   * set bookmaker name and id function
   * @param e
   */
  selectmatchType(e) {
    this.addBookmakerObject.marketType = JSON.parse(e.target.value).name;
    this.addBookmakerObject.marketTypeId = JSON.parse(e.target.value).id;
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020
   * get all sports
   */
  getAllSport() {
    this.sportService.getAllSport(this.filter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.sportList = response.data.docs.map(data => {
            return {id: data._id, itemName: data.name + '( ' + data.id + ' )', sportId: data.id};
        });
    }, error => {
        console.error('error in getting all sports', error);
    });
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020;
   * sport search with name
   */
  onSportSearch(e) {
    this.filter.search = e.target.value;
    this.getAllSport();
  }

  /**
   * on sport select call relevant tournaments
   * @param e
   */
  onSportSelect(e) {
    this.sportId = e.sportId;
    this.getAllTournament();
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020
   * get all sports
   */
  getAllTournament() {
    this.tournamentService.getAllTournament(this.tournamentFilter, this.sportId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.tournamentsList = response.data.docs.map(data => {
            return {id: data._id, itemName: data.name + '( ' + data.id + ' )', tournamentId: data.id};
        });
    }, error => {
      console.error('error in getting all sports', error);
    });
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020;
   * sport search with name
   */
  onTornamentSearch(e) {
    this.tournamentFilter.search = e.target.value;
    this.getAllTournament();
  }

  /**
   * @author karan chokshi
   * @date : 30-01-2019
   * on tournament select relavent match api call
   */
  onTornamentSelect(e) {
    this.tournamentId = e.tournamentId;
    this.getMatches();
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020
   * get all Matches by Tournament id
   */
  getMatches() {
    this.matchService.getAllMatch(this.matchFilter, this.tournamentId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.matchList = response.data.docs.map(data => {
            return {id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate};
        });
    }, error => {
         console.error('get all Matches', error);
    });
  }

  /**
   * @author karan chokshi
   * @date : 28-01-2020;
   * match search with name
   */
  onMatchSearch(e) {
    this.matchFilter.search = e.target.value;
    this.getMatches();
  }


     /**
   * @author kc
   * @date : 26-03-2020;
   * set market time
   */
  onMatchSelectImport(e) {
    this.getMatchesImport();
    this.matchService.getRelatedMarket(e.matchId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        console.log(response)
        if(response.status == true){
            this.marketRunners = response.data.runners;
        }
    });
    // if (localStorage.getItem('date') === null || localStorage.getItem('date') === 'null') {
    //   this.addFancyObject.marketStartTime = e.matchTime;
    // } else {
    //   this.addFancyObject.marketStartTime = localStorage.getItem('date');
    // }
  }


  getMatchesImport() {
    this.matchService.getAllMatchImport().subscribe(response => {
        // response = this.utilityService.gsk(response.auth);
        // response = JSON.parse(response);
        if(response.status == true){
            this.importList = [];
            let getActiveGame = JSON.parse(response.data);
            for (const [key, value] of Object.entries(getActiveGame)) {
            let gameObj =  { id: value['game_srno'], itemName: value['game_name'] + '( ' + value['game_srno'] + ' )',gameData:value};
            this.importList.push(gameObj);
            }
        }else{
            this.importList = [];
        }
      // this.matchList = response.data.docs.map(data => {
      //   return { id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
      // });
    }, error => {
        console.error('get all Matches', error);
    });
  }

  getMarket() {
    if(this.endSubmit) {
      return;
    }
    this.endSubmit = true;
    this.importmodal.hide();
    this.importBookmakerArray = [];
      let selectedId = this.selectedActiveMatchItems[0].id;
      this.matchService.getAllMarketImport(selectedId).subscribe(response => {
      if(response.status == true){
        this.endSubmit = false;
        let getActiveMarket = JSON.parse(response.data);
        for (const [key, value] of Object.entries(getActiveMarket)) {
          if(value['event_type'] == "ODD"){
            let  assignTo = {
              id : this.bmUserList[0].id,
              itemName : this.bmUserList[0].itemName,
              username : this.bmUserList[0].itemName,
              name : this.bmUserList[0].itemName,
              userType : this.bmUserList[0].userType
            };
            value['assignTo'] = assignTo;
            value['tempAsiignToName'] = [assignTo];
                this.importBookmakerArray.push(value);
          }
        }
        let tempArray = [];
        let tempFancy = [];
        //tempFancy = this.fancys;
        if(this.importBookmakerArray.length > 0){
          _.map(this.importBookmakerArray , function (e) {
            let adminComAry = tempFancy.find(o => o.fancyId ===  e.srno);
            if(adminComAry){

            }else{
              tempArray.push(e);
            }
          })
        }
        this.importBookmakerArray = tempArray;
        tempArray = [];
      }else{
        this.endSubmit = false;
        this.importBookmakerArray = [];
      }
      // this.matchList = response.data.docs.map(data => {
      //   return { id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
      // });
    }, error => {
        this.endSubmit = true;
      console.error('get all Matches', error);
    });

    this.getbmmodal.show();
  }


  /**
   * @author kc
   * @date : 26-03-2020;
   * set market time
   */
  onMatchSelect(e) {

    if (this.utilityService.returnLocalStorageData('date') === null || this.utilityService.returnLocalStorageData('date') === 'null') {
      this.addBookmakerObject.marketStartTime = e.matchTime;
    } else {
      this.addBookmakerObject.marketStartTime = this.utilityService.returnLocalStorageData('dateTime');
    }
    console.log("this.addBookmakerObject.marketStartTime", this.addBookmakerObject.marketStartTime);
  }


  /**
   * open modal
   */
  openModal() {
    this.formResetValue.resetForm();
    this.addBookmakerObject = {
      marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
      marketType: 'Bookmaker',
      marketTypeId: '5ebc1code68br4bik5b0810',
      marketStartTime: this.addBookmakerObject.marketStartTime,
      totalMatched: 0,
      runners: null,
      displayName: null,
      isActive: false,
      message: null,
      match: null,
      tournament: null,
      sport: null,
      assignTo: {
        id: null,
        name: null,
        username: null
      }
    };
    this.selectedSportItems = [];
    this.selectedTournamentsItems = [];
    this.selectedMatchItems = [];
    this.time = null;
    this.modal.show();
  }

  /**
   * open modal
   */
  openModal1() {
    this.formResetValue.resetForm();
    this.runnersmodal.show();
  }


   openImportModal() {
     this.getBookMakerSetting();
    this.addBookmakerObject = {
      marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
      marketType: 'Bookmaker',
      marketTypeId: '5ebc1code68br4bik5b0810',
      marketStartTime: this.addBookmakerObject.marketStartTime,
      totalMatched: 0,
      runners: null,
      displayName: null,
      isActive: false,
      message: null,
      match: null,
      tournament: null,
      assignTo: {
        id: null,
        name: null,
        username: null
      },
      sport: null
    };
    this.selectedSportItems = [];
    this.selectedTournamentsItems = [];
    this.selectedMatchItems = [];
    this.time = null;
     this.importmodal.show();
     this.getFancyUser();
   }

  /**
   * close modal
   */
  closeModel(data) {
    if (data !== 'conformation') {
      this.modal.hide();
      this.importBookmakerForm.resetForm();
      this.importmodal.hide();
    } else {
      this.conformationModal.hide();
      this.statusChangeModal.hide();
      this.passwordFormReset.resetForm();
      this.formResetValue.resetForm();
      this.rerender();
    }
  }

    /**
   * close modal
   */
  closeBmModel() {
    this.formResetValue.resetForm();
    this.importBookmakerForm.resetForm();
    this.getbmmodal.hide();
  }


  /**
   * open runners popup
   */
  addRunners() {
    this.modal.hide();
    this.openModal1();
  }

  /**
   * open runners popup
   */
  createBookmakerWhtLbl(data) {
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.marketService.addNewMarketWhtLbl(data ,  x[i]).subscribe(response => {
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author karan chokshi
   * @date 31-01-2020
   * create step 4 (bookmaker)
   */
  cerateBookmaker() {
    this.spinner.show();
        this.gameSettingService.getAllBookmakerSetting().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.addBookmakerObject['bookmakerSetting'] = response.data.docs[0];
        this.addBookmakerObject['gameSetting'] = null;
        this.addBookmakerObject['fancySetting'] = null;
        this.addBookmakerObject.runners = this.runnes;
        this.addBookmakerObject.sport = {
            id: this.selectedSportItems[0]['sportId'],
            name: this.selectedSportItems[0]['itemName']
        };
        this.addBookmakerObject.tournament = {
            id: this.selectedTournamentsItems[0]['tournamentId'],
            name: this.selectedTournamentsItems[0]['itemName']
        };
        this.addBookmakerObject.match = {
            id: this.selectedMatchItems[0]['matchId'],
            name: this.selectedMatchItems[0]['itemName']
        };
        this.addBookmakerObject['marketStatus'] = {
            id: 'MS081893',
            name: 'OPEN'
        };
        console.log('bookmaker object', this.addBookmakerObject)
            this.marketService.addNewMarket(this.addBookmakerObject).subscribe(response => {
                response = this.utilityService.gsk(response.auth);
                response = JSON.parse(response);
                this.modal.hide();
                this.spinner.hide();
                this.getAllBookmaker(); // recall all bookmaker api for sysnc data
                // this.createBookmakerWhtLbl(this.addBookmakerObject); // recall all bookmaker api for sysnc data
            }, error => {
                console.error('add bookmaker error', error);
            });
        });
  }

  /***
   * push new runners object in runners array
   * @param object
   * @param array
   */
  addNewObjectToArray(object, array) {
    array = array || [{}];
    object = typeof object === 'object' ? object || {} : '';
    array.push(object);
    let selectionId = (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000));
    this.tempRunners = {
      selectionId: selectionId,
      runnerName: null,
      handicap: 1,
      sortPriority: 0,
      metadata: {
        runnerId: selectionId
      }

    };
  }

  /**
   * Removes given object from the given array
   * @param object
   * @param array
   */
  removeObjectFromArray(object, array) {
    const index = array.indexOf(object);
    array.splice(index, 1);
  }

  updateUserStatus() {
    this.spinner.show();
    let checkUserObj = {
      id: this.utilityService.returnLocalStorageData('userId'),
      password: this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse => {
        this.conformationModal.hide();
        if (checkUserResponse.status === true) {
          this.marketService.updateMarket(this.tempMarketObj)
            .subscribe(response => {
              this.messageModal.hide();
              this.spinner.hide();
              // this.updateWhtLblMarket(this.tempMarketObj);
              this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
            }, error => {

            })
        } else {
          this.spinner.hide();
          this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
        }

      }, error => {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, error.error.message);
      });

  }

  // updateWhtLblMarket(data) {
  //   this.utilityService.getAllWhiteLabel().then(response =>{
  //     let x = response.data;
  //     for(let i = 0;i < x.length; i++){
  //       this.marketService.updateWhtLblMarket(data, x[i])
  //         .subscribe(response => {
  //           // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
  //         }, error => {
  //
  //         });
  //     }
  //   }).catch(error =>{
  //     console.error("errro in get white label");
  //   });
  // }

  onchange(object) {
    // this.conformationModal.show();
    this.tempMarketObj = object;
    this.updateUserStatusWithoutPassword();
  }
  onchangeWithoutPassword(object){
    this.tempMarketObj = object;
    this.statusChangeModal.show();
  }

  updateMessage() {
    this.updateUserStatus();
    this.tempMarketObj = this.addBookmakerObject;
  }

  clearMessage() {
    this.addBookmakerObject.message = '';
  }

  /***
   * update setting data (limits)
   * @param data
   */
  updateSetting(data) {
    this.spinner.show();
    this.tempMarketObj = this.globleSingleFancyObj;

    this.tempMarketObj.bookmakerSetting.minStack = Number(this.tempMarketObj.bookmakerSetting.minStack);
    this.tempMarketObj.bookmakerSetting.maxStack = Number(this.tempMarketObj.bookmakerSetting.maxStack);
    this.tempMarketObj.bookmakerSetting.maxProfit = Number(this.tempMarketObj.bookmakerSetting.maxProfit);
    this.tempMarketObj.bookmakerSetting.betDelay = Number(this.tempMarketObj.bookmakerSetting.betDelay);
    this.tempMarketObj.bookmakerSetting.maxStackPerOdds = Number(this.tempMarketObj.bookmakerSetting.maxStackPerOdds);

    let checkUserObj = {
      id: this.utilityService.returnLocalStorageData('userId'),
      password: this.conformationPassword
    };

    this.userService.checkUser(checkUserObj).subscribe(checkUserResponse => {
        checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
        checkUserResponse = JSON.parse(checkUserResponse);
            if (checkUserResponse.status === true) {
            this.marketService.updateMarketData(this.tempMarketObj).subscribe(response => {
                response = this.utilityService.gsk(response.auth);
                response = JSON.parse(response);
                this.gameLimitModal.hide();
                this.spinner.hide();
                // this.updateWhtLblMarket(this.tempMarketObj);
                this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
                }, error => {

                })
            } else {
            this.spinner.hide();
            this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
            }

        }, error => {
            this.spinner.hide();
            this.utilityService.popToast('error', 'Error', 3000, error.error.message);
        });
  }
  /***
   * update in market data in  multiple white label
   * @param data
   */
  updateWhtLblMarket(data) {
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      for(let i = 0;i < x.length; i++){
        this.marketService.updateWhtLblMarket(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
          }, error => {

          });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  updateUserStatusWithoutPassword() {
    this.marketService.updateMarket(this.tempMarketObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.messageModal.hide();
        this.spinner.hide();
        // this.updateWhtLblMarket(this.tempMarketObj);
        this.statusChangeModal.hide();
        this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
      }, error => {

      })
  }

   getBookMakerSetting() {
    this.gameSettingService.getAllBookmakerSetting().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.addBookmakerObject['bookmakerSetting'] = response.data.docs[0];
    }, error => {
      console.error('error in get fancy setting', error);
    })
  }

  getFancyUser() {
    this.userService.fancyUser(this.bmTypeId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.bmUserList = response.data.map(data => {
            return { id: data._id, itemName: data.name, userName: data.userName, userType: data.userType }
        });
    }, error => {
        console.error('error in get fancy user');
    });
  }


   /**
   * get all modules list
   */
  getAllModule() {
    this.roleService.getAllModules().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        response.data.docs.map(data => {
            if (data.moduleName === 'BOOKMAKER') {
            this.bmTypeId = data._id;
            }
        });
    }, error => {
      console.error('error in get modules');
    });
  }


  multiAssign(e){
    this.formValid = true;
    this.importBookmakerArray.map(data => {
        let assignObj = {
          id : e.id,
          itemName : e.itemName,
          username : e.itemName,
          name : e.itemName,
          userType : e.userType
        }
        data.tempAsiignToName[0] = assignObj;
        data.assignTo = assignObj;
        return data;
    });
  }

  selectAssignTo(e, fancy) {
    this.importBookmakerArray.map(data => {
      if (data.marketId === fancy.marketId) {
        data.assignTo.id = e.id;
        data.assignTo.name = e.itemName;
        data.assignTo.username = e.username;
        return data;
      } else {
        return data;
      }
    });
  }


  selectAllAccess(e) {
    if (e.target.checked === true) {
      this.moduleList = [];
      this.importBookmakerArray = this.importBookmakerArray.map(mDats =>{
        this.moduleList.push(mDats.srno);
        mDats.checkBoxValue = true;
        return mDats;
      })
      // return data;
    } else {
      this.importBookmakerArray = this.importBookmakerArray.map(mDats =>{

        mDats.checkBoxValue = false;
        return mDats;
      });
      this.moduleList = [];
      // return data;
    }
  }


  check(e, data) {
    if (e.target.checked === true) {
      this.importBookmakerArray = this.importBookmakerArray.map(mDats =>{

        if(mDats.srno === data.srno){

          this.moduleList.push(data.srno);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data.srno);

      this.moduleList = arr2;
      this.importBookmakerArray = this.importBookmakerArray.filter(mDats =>{

        if(mDats.srno === data.srno){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }

  render(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  createBookMakerImport() {
    if(this.endSubmit) {
      return;
    }
    this.endSubmit = true;
    let finalFancyArrayData = [];
    let finalFancyArray = this.importBookmakerArray.map(data => {
      if(data.checkBoxValue){
        let gameData = this.selectedActiveMatchItems[0].gameData;
        let runners = [];
        for (const [index, [key, value]] of Object.entries(Object.entries(gameData))) {
          // console.log(`${index}: ${key} = ${value}`);
          //console.log("value++++++++",value);
          let runnObj = {};
          if(index == "0" || index == "1" || index == "2" ){
            runnObj['selectionId'] = key,
            runnObj['runnerName'] = value
            runnObj['handicap'] = '1',
            runnObj['sortPriority'] = '0',
            runnObj['metadata'] = {
              "runnerId" : key
            }
            if(index == "2"){
              if(_.isNumber(key) == true){
                runners.push(runnObj);
              }
            }else{
              runners.push(runnObj);
            }
          }
        }

        let diff =  _.differenceWith(runners, this.marketRunners, function (o1, o2) {
            return o1['selectionId'] === o2['selectionId']
        });

      runners = (diff.length == 0)?this.marketRunners:runners;
      this.gameSettingService.getAllBookmakerSetting().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
      this.addBookmakerObject['bookmakerSetting'] = response.data.docs[0];
      this.addBookmakerObject['gameSetting'] = null;
      this.addBookmakerObject['fancySetting'] = null;
      this.addBookmakerObject['isActive'] = (this.importBookmakerForm.isActive == true)?true:false;
      this.addBookmakerObject.runners = runners;
      this.addBookmakerObject.sport = {
        id: this.selectedSportItems[0]['sportId'],
        name: this.selectedSportItems[0]['itemName']
      };
      this.addBookmakerObject.tournament = {
        id: this.selectedTournamentsItems[0]['tournamentId'],
        name: this.selectedTournamentsItems[0]['itemName']
      };
      this.addBookmakerObject.match = {
        id: this.selectedMatchItems[0]['matchId'],
        name: this.selectedMatchItems[0]['itemName']
      };
      this.addBookmakerObject['marketStatus'] = {
        id: 'MS081893',
        name: 'OPEN'
      };
      this.addBookmakerObject['bookmakerMode'] = 'Auto';
      this.addBookmakerObject['assignTo'] = data.assignTo;
      this.addBookmakerObject['marketId'] = data['srno'];
      // console.log('bookmaker object', this.addBookmakerObject)
       this.createBmAUto(this.addBookmakerObject);
    });
      }
    })
    this.utilityService.popToast('success', 'Success', 3000, 'Bookmaker Imported  successfully.');
  }


  createBmAUto(addBookmakerObject){
    let marketObj = addBookmakerObject;
     this.marketService.addNewMarket(addBookmakerObject).subscribe(response => {
       response = this.utilityService.gsk(response.auth);
       response = JSON.parse(response);
       if(response.status == true){

        this.formResetValue.resetForm();
        this.importBookmakerForm.resetForm();
        this.getbmmodal.hide();
         this.endSubmit = false;
        let gameSrNo = this.importBookmakerArray[0].game_srno;

        this.matchService.getBymatchId(response.data.match.id)
        .subscribe(response => {
          if(response.status == true){
            let objectRedis = {
              fancyId : gameSrNo,
              fancyName : response.data.match.name,
              fancyStartTime : response.data.marketStartTime,
              fancymarketId  : response.data.marketId,
            }
            this.gameActiveRedis(objectRedis);
          }
          // this.utilityService.popToast('success', 'Success', 3000, 'Active fancy successfully.');
        }, error => {

        })
        // this.createBookmakerWhtLbl(response.data); // recall all bookmaker api for sysnc data
        this.rerender(); // recall all bookmaker api for sysnc data
       }else{

          this.formResetValue.resetForm();
          this.importBookmakerForm.resetForm();
          this.getbmmodal.hide();
         this.endSubmit = false;
          this.rerender(); // recall all bookmaker api for sysnc data
       }
      }, error => {
       this.endSubmit = false;
        console.error('add bookmaker error', error);
      });
  }


  gameActiveRedis(id) {
    this.matchService.activeRedisFancyAutoRate(id).subscribe(response => {
        // this.utilityService.popToast('success', 'Success', 3000, 'Active fancy successfully.');
      }, error => {

      })
  }

  openSettledModal(match) {
    let matchId = match.marketId;
    this.settledObj.matchId = matchId;
    this.settledObj.team = match.runners;
    this.matchSettled.show();
  }

  closeSettledModal() {
    this.matchSettled.hide();
 }


settleBM() {
    if(this.endSubmit) {
        return;
    }
    this.endSubmit = true;
    this.spinner.show();
    let key = env.constantKey();
    let token = this.conformationPassword;
    var encrypted = aes256.encrypt(key, token);
    let resultTeam = this.settledObj.team.find(o => o.selectionId === this.selectedTeam);
    let apiObj = {
        teamId: this.selectedTeam,
        matchId: this.settledObj.matchId,
        matchName: resultTeam.runnerName,
        type:"Bookmaker",
        token: encrypted
    };
    this.matchService.matchBMOffice(apiObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
      this.closeSettledModal();
      this.spinner.hide();
      this.endSubmit = false;
      this.utilityService.popToast('success', 'Success', 3000, response.message);
        // this.utilityService.getAllWhiteLabel().then(response => {
        //     response = this.utilityService.gsk(response.auth);
        //     response = JSON.parse(response);
        //     let x = response.data;
        //     /* Hear X is Multiple Whitelable Data*/
        //     for (let i = 0; i < x.length; i++) {
        //     this.matchService.matchBMSettled(apiObj, x[i]).subscribe(response => {
        //         response = this.utilityService.gsk(response.auth);
        //         response = JSON.parse(response);
        //         this.spinner.hide();
        //         if (response.status == true) {
        //         this.utilityService.popToast('success', 'Success', 3000, response.message);
        //         this.endSubmit = false;
        //         this.getAllBookmaker()
        //         this.closeSettledModal();
        //         } else {
        //         this.closeSettledModal();
        //         this.endSubmit = false;
        //         this.utilityService.popToast('error', 'Error', 3000, response.message);
        //         }
        //     });
        //     }
        // }).catch(error => {
        //     this.closeSettledModal();
        //     this.spinner.hide();
        //     this.endSubmit = false;
        //     this.utilityService.popToast('error','Error', 3000 , error.message);
        // });
    }, error =>{
        this.closeSettledModal();
        this.spinner.hide();
        this.endSubmit = false;
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
    });
}


}
