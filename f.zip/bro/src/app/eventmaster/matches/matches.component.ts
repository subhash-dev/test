import { ChangeDetectorRef, Component, HostListener, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { ActivatedRoute, Router } from '@angular/router';
import { MatchService } from '../../services/match.service';
import { TournamentService } from '../../services/tournament.service';
import { SportService } from '../../services/sport.service';
import { UserService } from '../../services/user.service';
import { UtilityService } from '../../globals/utilityService';
import { isUndefined } from 'util';
import { ToasterConfig } from 'angular2-toaster';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as env from '../../globals/env';
import { NgbTimepickerConfig, NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from "ngx-spinner";
declare let $: any;
declare let _: any;
import { pickBy, identity } from 'lodash';
var aes256 = require('aes256');
class Match {
  id: number;
  name: string;
  tournament: string;
  sports: string;
  openDate: string;
  isManual: string;
  isActive: string;
  inPlay: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-matches',
  templateUrl: './matches.component.html',
  styleUrls: ['./matches.component.scss']
})
export class MatchesComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  @ViewChild(ModalDirective, { static: false }) modal: ModalDirective;
  @ViewChild("addMatchForm", { static: false }) formResetValue;
  @ViewChild("matchTimesForm", { static: false }) matchTimesFormReset;
  @ViewChild('conformationModal', { static: false }) conformationModal: ModalDirective;
  @ViewChild('matchTimeModal', { static: false }) matchTimeModal: ModalDirective;
  @ViewChild('statusChangeModal', { static: false }) statusChangeModal: ModalDirective;
  @ViewChild("conformationForm", { static: false }) passwordFormReset;
  @ViewChild("liveTv", { static: false }) liveTv: ModalDirective;
  @ViewChild('focusInput', { static: false }) focusInput: ElementRef;
  @ViewChild("matchSettled", { static: false }) matchSettled: ModalDirective;

  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();

  matchs: Match[];
  resData;
  server_url: any = env.server_url();
  paramId: any;
  tempMatchObj: any;
  selectedmatchObject: any;
  selectedMatch: any;
  selectedChannel: any;
  channels: any;
  conformationPassword: any;
  dataTable: any;
  time: NgbTimeStruct = { hour: 0, minute: 0, second: 0 };
  accessRole: any;
  selectedTeam: any;
  addMatcheObject = {
    id: (Math.floor(Math.random() * (99999999 - 1000 * 1) * 100)),
    name: null,
    countryCode: null,
    timezone: 'GMT',
    openDate: null,
    isManual: true,
    inPlay: false,
    isActive: false,
    isDeleted: false,
    tournament: null,
    sport: null,
    priority: 0,
  };
  matchId: any;
  settledObj = {
    matchId: null,
    team: null,
    marketType: null
  }
  endSubmit = false;

  unSelectSport: any;
  unSelectTournament: any;
  unSelecTmatch: any;
  matchlistById: any;
  finalData: any;
  constructor(private route: ActivatedRoute,
    private matchService: MatchService,
    private tournamentService: TournamentService,
    private sportService: SportService,
    private chRef: ChangeDetectorRef,
    private utilityService: UtilityService,
    private userService: UserService,
    private spinner: NgxSpinnerService,
    private router: Router,
    config: NgbTimepickerConfig,
    private http: HttpClient) {
    config.seconds = true;
    config.spinners = false;
  }

  matchFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  allMatches: any;
  filter = {
    page: 1,
    limit: -1,
    search: null
  };
  tournamentFilter = {
    page: 1,
    limit: 10,
    search: null
  };

  minPickerDate: any;
  // let month = ('0' + ((new Date().getMonth()) + 1)).slice(-2);
  // let date = ('0' + (new Date().getDate())).slice(-2);
  // minPickerDate: any;


  sportList = [];
  selectedSportItems = [];
  sportSettings = {
    singleSelection: true,
    text: 'Select sports',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
    enableFilterSelectAll: false,
    enableCheckAll: false
  };
  sportId: any;
  tournamentId: any;
  tournamentsList = [];
  selectedTournamentsItems = [];
  TournamentsSettings = {
    singleSelection: true,
    text: 'Select tournament',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
    enableFilterSelectAll: false,
    enableCheckAll: false
  };

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.passwordFormReset.resetForm();
      this.formResetValue.resetForm();
      this.rerender();
    }
  }

  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if (event.sourceCapabilities) {

    } else {
      this.setFocusToInput();
    }
  }

  ngOnInit() {
    this.unSelectSport = '';
    this.unSelectTournament = '';
    this.unSelecTmatch = '';
    if (isUndefined(this.utilityService.returnAccessRole('MATCHES'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('MATCHES');
    }
    this.route.params.subscribe(params => {
      this.paramId = params['id'];
    });
    // this.getMatches();
    this.getMatchsDt();
    this.getAllSport();
    this.getAllChannel();
    let offset = new Date().getTimezoneOffset();
    console.log("*", offset);

    this.minPickerDate = {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate()
    };
  }

  setFocusToInput() {

    this.focusInput.nativeElement.focus();
  }




  /**
   * open modal
   */
  openModal() {
    this.formResetValue.resetForm();
    this.addMatcheObject = {
      id: (Math.floor(Math.random() * (99999999 - 1000 * 1) * 100)),
      name: null,
      countryCode: null,
      timezone: 'GMT',
      openDate: null,
      isManual: true,
      inPlay: false,
      isActive: false,
      isDeleted: false,
      tournament: null,
      sport: null,
      priority: 0,
    };
    this.selectedSportItems = [];
    this.selectedTournamentsItems = [];
    this.time = null

    this.modal.show();
  }


  /**
   * close modal
   */
  closeModel(data) {
    if (data === 'addMatch') {
      this.modal.hide();
    } else {
      this.conformationModal.hide();
      this.statusChangeModal.hide();
      this.rerender();
    }

  }

  /**
   * close matchtime modal
   */
  closematchModal() {
      this.matchTimeModal.hide();
  }

  /**
   * open matchtime modal
   */
  openMatchModal(data) {
      this.selectedmatchObject = data;
      this.matchTimeModal.show();
  }

  updateMatchTime() {
    let convertedTime = {
      hours: null,
      minutes: null,
      seconds: '00'
    };
    let x = this.utilityService.convertTimeAsPerCurrentTimeZoneOffset(this.time);
    convertedTime.hours = x.hours;
    convertedTime.minutes = x.minutes;
    convertedTime.seconds = x.seconds;

    this.addMatcheObject.openDate = (this.addMatcheObject.openDate.year + '-' + this.addMatcheObject.openDate.month + '-' + this.addMatcheObject.openDate.day + ' ' + convertedTime.hours + ':' + convertedTime.minutes + ':' + convertedTime.seconds + '.000Z');

    this.changeMatchTime(this.selectedmatchObject)
  }

  changeMatchTime(data){
   let datas = {
      id: data.id,
      openDate: this.addMatcheObject.openDate
    }
    this.matchService.updateMatchTiming(datas).subscribe(response => {
      if(response){
        this.matchTimeModal.hide();
        this.matchTimesFormReset.resetForm();
      }
    }, error => {
      console.error('error in getting all sports', error);
    });
  }

  /**
   * @author kc
   * @date : 28-01-2020
   * get all sports
   */
  getAllSport() {
    this.sportService.getAllSport(this.filter).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response =JSON.parse(response);
      this.sportList = response.data.docs.map(data => {
        return { id: data._id, itemName: data.name  + '( ' + data.id + ' )', sportId: data.id };
      });
    }, error => {
      console.error('error in getting all sports', error);
    });
  }


  getMatchsDt() {
    // this.spinner.show();
    // this.rerender();
    const that = this;
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      autoWidth: true,
      scrollX: false,
      scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',
        emptyTable: 'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'match/get-all';
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { sportId: this.paramId, data: this.finalData }),
            {}
          ).subscribe(resp => {
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData =JSON.parse(this.resData);
            this.resData = this.resData.data;
            this.spinner.hide();
            if (this.resData.docs.length > 0) {
              that.matchs = this.resData.docs;
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },
      columns: [{ data: '' }, { data: 'name' }, { data: 'tournament.name'  }, { data: 'sport.name' }, { data: 'openDate' }, { data: 'isManual' }, { data: 'isActive' }, { data: 'inPlay' }, { data: 'displayOrder' }, { data: '' }, { data: '' }],
      columnDefs: [{ orderable: false, targets: [0] }]
    };
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * sport search with name
   */
  onSportSearch(e) {
    this.filter.search = e.target.value;
    this.getAllSport();
  }

  onSportSelect(e) {
    this.sportId = e;
    this.tournamentsList = [];
    this.matchlistById=[];
    this.unSelectTournament ='';
    this.unSelecTmatch= '';
    this.getAllTournament();
  }


  /**
   * @author kc
   * @date : 28-01-2020
   * get all sports
   */
  getAllTournament() {
    if(this.sportId){
      this.tournamentService.getAllTournament(this.tournamentFilter,this.sportId.sportId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.tournamentsList = response.data.docs.map(data => {
          return { id: data._id, itemName: data.name  + '( ' + data.id + ' )', tournamnetId: data.id };
        });
      }, error => {
        console.error('error in getting all sports', error);
        this.tournamentsList = [];
      });
    } else {
      this.tournamentsList = [];
    }
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * sport search with name
   */
  onTornamentSearch(e) {
    this.tournamentFilter.search = e.target.value;
    this.getAllTournament();
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * sport search with name
   */
  onTournamentSelect(e) {
    this.tournamentId = e.tournamentId;
  }

  /**
   * @author kc
   * @date : 28-01-2020
   * get all Matches by Tournament id
   */
  getMatches() {
    this.matchService.getAllMatch(this.matchFilter, this.paramId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.allMatches = response.data;
        this.chRef.detectChanges();
        const table: any = $('table');
        this.dataTable = table.DataTable({
            /* serverSide : true,
            processing : true*/
        });
    }, error => {
      console.error('get all Matches', error);
    });
  }

  /**
 * @author rk
 * @date : 28-01-2020
 * reins data table
 */

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  /**
   * @author kc
   * @date : 28-01-2020
   * create match function with sport id
   */
  createWhtlblMatch(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for (let i = 0; i < x.length; i++) {
        this.matchService.addNewWhtLblMatch(data, x[i]).subscribe(response => {
        });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });

  }

  /**
   * @author kc
   * @date : 28-01-2020
   * create match function with sport id
   */
  createMatch() {
    this.spinner.show();
    this.addMatcheObject.tournament = {
      id: this.selectedTournamentsItems[0]['tournamnetId'],
      name: this.selectedTournamentsItems[0]['itemName'],
    };
    this.addMatcheObject.sport = {
      id: this.selectedSportItems[0]['sportId'],
      name: this.selectedSportItems[0]['itemName']
    };
    let convertedTime = {
      hours: null,
      minutes: null,
      seconds: '00'
    };

    let x = this.utilityService.convertTimeAsPerCurrentTimeZoneOffset(this.time);
    convertedTime.hours = x.hours;
    convertedTime.minutes = x.minutes;
    convertedTime.seconds = x.seconds;

    this.addMatcheObject.openDate = (this.addMatcheObject.openDate.year + '-' + this.addMatcheObject.openDate.month + '-' + this.addMatcheObject.openDate.day + ' ' + convertedTime.hours + ':' + convertedTime.minutes + ':' + convertedTime.seconds + '.000Z');
    let key = env.constantKey();
    // var dateTime1 = aes256.encrypt(key, this.addMatcheObject.openDate);
    localStorage.setItem('date', this.addMatcheObject.openDate);
    this.matchService.addNewMatch(this.addMatcheObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.modal.hide();
      this.spinner.hide();
      this.rerender();
      if (response.status === true) {
        //this.getMatches();
        this.utilityService.popToast('success', 'Success', 3000, 'Match created successfully.');
         // this.createWhtlblMatch(this.addMatcheObject);

      } else {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, response.message);
      }

    }, error => {
      this.spinner.hide();
      console.error('error in add new match');
    });
  }

  navigateToMarket(data) {
    this.router.navigate(['/eventmaster/market', data]);
  }


  openLiveTvPopUp(data) {
    this.selectedMatch = data;
    this.liveTv.show();
  }

  closeLiveTvPopUp() {
    this.liveTv.hide();
  }

  openSettledModal(match) {
    let matchId = match.id;
    this.matchService.getMarketByMatchId(matchId).subscribe(marketResponse => {
        marketResponse = this.utilityService.gsk(marketResponse.auth);
        marketResponse =JSON.parse(marketResponse);
        if (marketResponse.status === true) {
          this.settledObj.matchId = matchId;
          this.settledObj.team = marketResponse.data.runners;
          this.settledObj.marketType = marketResponse.data.marketType
        }
      });
    this.matchSettled.show();
  }

  closeSettledModal() {
    this.matchSettled.hide();
  }

  updateUserStatus() {
    this.spinner.show();
          let key = env.constantKey();
          let token = this.conformationPassword;
          var encrypted = aes256.encrypt(key, token);
          this.tempMatchObj['token'] = encrypted;
          this.matchService.updateMatch(this.tempMatchObj).subscribe(response => {
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
              this.spinner.hide();
              this.conformationModal.hide();
              // this.updateWhtLblMatch(this.tempMatchObj);
              this.utilityService.popToast('success', 'Success', 3000, 'Match updated successfully.');
            }, error => {
              this.spinner.hide();
              this.conformationModal.hide();
              this.utilityService.popToast('error', 'Error', 3000, error.error.message);
            })
  }
  updateWhtLblMatch(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for (let i = 0; i < x.length; i++) {
        this.matchService.updateWhtLblMatch(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white Match updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });

  }

  updateWhtLblMatchchannel(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for (let i = 0; i < x.length; i++) {
        this.matchService.updateWhtLblMatchChannel(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white Match updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });

  }

  onchange(object) {
    this.passwordFormReset.resetForm();
    this.conformationModal.show();
    this.tempMatchObj = object;
  }
  onchangeWithoutPassword(object){
    this.tempMatchObj = object;
    this.statusChangeModal.show();
  }

  /**
   * update display order
   * @param data
   */
  updateDisplayOrder(data) {
    this.spinner.show();
    setTimeout(res => {
      this.matchService.updateMatch(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.spinner.hide();
        if (response.status === true) {
          this.rerender();
           // this.updateWhtLblMatch(data);
        }
      }, error => {
        this.spinner.hide();
        console.error('error in priority', error);
      })
    }, 500)

  }
  setDateTest(e) {
    console.log(">>>>", this.addMatcheObject.openDate)
  }

  settleMarket() {
    if(this.endSubmit) {
        return;
    }
    this.endSubmit = true;
    this.spinner.show();
    let key = env.constantKey();
    let token = this.conformationPassword;
    var encrypted = aes256.encrypt(key, token);
    let resultTeam = this.settledObj.team.find(o => o.selectionId === this.selectedTeam);
    let apiObj = {
      teamId: this.selectedTeam,
      matchId: this.settledObj.matchId,
      matchName: resultTeam.runnerName,
      type:this.settledObj.marketType,
      token: encrypted
    };
    this.matchService.matchSettledOffice(apiObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.spinner.hide();
      this.endSubmit = false;
      this.closeSettledModal();
      this.utilityService.popToast('success', 'Success', 3000, "Market settled successfully.");
      // this.utilityService.getAllWhiteLabel().then(response => {
      //   let x = response.data;
      //   /* Hear X is Multiple Whitelable Data*/
      //   for (let i = 0; i < x.length; i++) {
      //     // this.matchService.matchSettled(apiObj, x[i]).subscribe(response => {
      //     //   this.spinner.hide();
      //     //   if (response.status == true) {
      //     //     this.utilityService.popToast('success', 'Success', 3000, response.message);
      //     //     this.endSubmit = false;
      //     //     this.closeSettledModal();
      //     //   } else {
      //     //     this.closeSettledModal();
      //     //     this.endSubmit = false;
      //     //     this.utilityService.popToast('error', 'Error', 3000, response.message);
      //     //   }
      //     // });
      //   }
      // }).catch(error => {
      //   this.closeSettledModal();
      //   this.spinner.hide();
      //   this.endSubmit = false;
      //   this.utilityService.popToast('error','Error', 3000 , error.message);
      // });
    }, error =>{
      this.closeSettledModal();
      this.spinner.hide();
      this.endSubmit = false;
      this.utilityService.popToast('error','Error', 3000 , error.error.message);
    });
  }

  onTornamentSelect(tournamentId) {
    this.matchlistById = [];
    this.tournamentId = tournamentId;
    this.getMatchesby(tournamentId);
  }

  /** subhash
   * get match by  tournamentId
   * 20-7-2020
   */
  getMatchesby(tournamentId) {
    if (tournamentId != '') {
      this.matchService.getAllMatch(this.matchFilter, tournamentId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status == true){
          this.matchlistById = response.data.docs.map(data => {
            return { id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
          });
        } else {
          this.matchlistById = [];
        }
      }, error => {
        console.error('get all Matches', error);
        this.matchlistById = [];
      });
    } else {
      this.matchlistById = [];
    }
  }

  /** subhash
  * get match by  tournamentId
  * 20-7-2020
  */

  searchSettleData() {
    if (this.unSelectSport || this.unSelectTournament || this.unSelecTmatch) {
      this.finalData = '';
      let data = {
        sportId: this.unSelectSport,
        tournamentId: this.tournamentId,
        matchId: this.unSelecTmatch
      };
      this.finalData = pickBy(data, undefined);
      // this.getMatchsDt();
      this.onTornamentSelect(this.tournamentId);
      this.rerender();
    }
  }

  clear() {
    if (this.unSelectSport || this.unSelectTournament || this.unSelecTmatch) {
      this.finalData = '';
      let data = {
        sportId: null,
        tournamentId: null,
        matchId: null,
        marketType: null,
      };
      this.finalData = pickBy(data, undefined);

      this.unSelectSport = '';
      this.unSelectTournament = '';
      this.unSelecTmatch = '';
      this.rerender();
    }

  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Get Channel
   * @method: POST
   */

  getAllChannel() {
    this.spinner.show();
    this.matchService.getAllChannel().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if (response.status === true) {
        this.channels = response.data;
        // this.utilityService.popToast('success','Success', 3000 , 'Channel get successfully.');
        this.spinner.hide();
      } else {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, response.message);
      }
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error', 'Error', 3000, error.message);
    });
  }

  channelUpdate() {
    this.selectedMatch['channelUrl'] = this.selectedChannel;
    this.matchService.updateMatchChennel(this.selectedMatch).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.spinner.hide();
      this.liveTv.hide();
      if (response.status === true) {
        this.updateWhtLblMatchchannel(this.selectedMatch);
      }
    }, error => {
      this.spinner.hide();
      console.error('error in priority', error);
    })
  }

  updateUserStatusWithoutPassword() {
    this.matchService.updateMatch(this.tempMatchObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.spinner.hide();
        // this.updateWhtLblMatch(this.tempMatchObj);
        this.statusChangeModal.hide();
        this.utilityService.popToast('success', 'Success', 3000, 'Match updated successfully.');
    }, error => {
    })
  }


}
