import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {EventmasterComponent} from './eventmaster.component';
import {SportsComponent} from './sports/sports.component';
import {TournamentComponent} from './tournament/tournament.component';
import {MatchesComponent} from './matches/matches.component';
import {MarketComponent} from './market/market.component';
import {FancyComponent} from './fancy/fancy.component';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {BookmakerComponent} from './bookmaker/bookmaker.component';
import { LineComponent } from './line/line.component';

const routes: Routes = [{
  path: 'eventmaster',
  canActivate: [AuthGuard],
  component: EventmasterComponent,
  children: [
    {
      path: 'sports',
      canActivate: [AuthGuard,RoleGuard],
      component: SportsComponent,
    },
    {
      path: 'tournament/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: TournamentComponent,
    },
    {
      path: 'tournament',
      canActivate: [AuthGuard,RoleGuard],
      component: TournamentComponent,
    },
    {
      path: 'matches/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: MatchesComponent,
    },
    {
      path: 'matches',
      canActivate: [AuthGuard,RoleGuard],
      component: MatchesComponent,
    },
    {
      path: 'market/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: MarketComponent,
    },
    {
      path: 'market',
      canActivate: [AuthGuard,RoleGuard],
      component: MarketComponent,
    },
    {
      path: 'fancy/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: FancyComponent,
    },
    {
      path: 'bookmaker/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: BookmakerComponent,
    },
    {
      path: 'line',
      canActivate: [AuthGuard,RoleGuard],
      component: LineComponent,
    },
    {
      path: 'line/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: LineComponent,
    },
  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EventmasterRoutingModule {
}
