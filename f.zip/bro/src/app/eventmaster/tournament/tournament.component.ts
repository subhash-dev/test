import { ChangeDetectorRef, Component, HostListener, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { SportService } from '../../services/sport.service';
import { TournamentService } from '../../services/tournament.service';
import { ActivatedRoute, Router } from '@angular/router';
import { isUndefined } from "util";
import { UtilityService } from '../../globals/utilityService';
import { UserService } from '../../services/user.service';
import { MarketService } from '../../services/market.service';
import { ToasterConfig } from 'angular2-toaster';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as env from '../../globals/env';
import { NgxSpinnerService } from "ngx-spinner";
import { pickBy, identity } from 'lodash';

declare let $: any;

class Tournament {
  id: number;
  name: string;
  sports: string;
  isActive: string;
  isManual: string;
  displayOrder:number;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}


@Component({
  selector: 'app-tournament',
  templateUrl: './tournament.component.html',
  styleUrls: ['./tournament.component.scss']
})
export class TournamentComponent implements OnInit {
  @ViewChild(ModalDirective, { static: false }) modal: ModalDirective;
  @ViewChild('conformationModal', { static: false }) conformationModal: ModalDirective;
  @ViewChild("addTournamentForm", { static: false }) formResetValue;
  @ViewChild("conformationForm", { static: false }) passwordFormReset;
  // @ViewChild('focusInput', { static: false }) focusInput: ElementRef;

  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();

  tournaments: Tournament[];
  resData;
  server_url: any = env.server_url();



  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  paramId: any;
  dataTable: any;
  accessRole: any;
  constructor(private sportService: SportService,
    private tournamentService: TournamentService,
    private route: ActivatedRoute,
    private chRef: ChangeDetectorRef,
    private utilityService: UtilityService,
    private userService: UserService,
    private spinner: NgxSpinnerService,
    private marketService: MarketService,
    private router: Router,
    private http: HttpClient) {
  }

  addTournament = {
    id: (Math.floor(Math.random() * (99999999 - 1000 * 1) * 100)),
    name: null,
    isManual: true,
    isActive: false,
    sport: null,
    isDeleted: false,
  };

  filter = {
    page: 1,
    limit: -1,
    search: null
  };
  sportList = [];
  tempTournamnetObj: any;
  selectedSportItems = [];
  conformationPassword: any;//set conform password for update data
  sportSettings = {
    singleSelection: true,
    text: 'Select sports',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
  };
  allTournaments: any;

  unSelectSport: any;
  unSelectTournament: any;
  SelectSport: any;
  SelectTournament: any;
  finalData: any;
  sportId: any;

  tournamentFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  tournamentsList: any;

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.passwordFormReset.resetForm();
      this.formResetValue.resetForm();
      this.rerender();
    }
  }

  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if (event.sourceCapabilities) {

    } else {
      this.setFocusToInput();
    }
  }
  ngOnInit() {
    this.unSelectSport = '';
    this.unSelectTournament = '';
    if (isUndefined(this.utilityService.returnAccessRole('TOURNAMENTS'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('TOURNAMENTS');
    }
    this.getAllSport();
    this.route.params.subscribe(params => {
      this.paramId = params['id'];
    });

    //this.getTournamnets();
    this.getTournamnetsDt();
  }

  setFocusToInput() {

    // this.focusInput.nativeElement.focus();
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * sport search with name
   */
  onSportSearch(e) {
    this.filter.search = e.target.value;
    this.getAllSport();
  }

  /**
   * open modal
   */
  openModal() {
    this.formResetValue.resetForm();
    this.addTournament = {
      id: (Math.floor(Math.random() * (99999999 - 1000 * 1) * 100)),
      name: null,
      isManual: true,
      isActive: false,
      sport: null,
      isDeleted: false,
    };
    this.modal.show();
  }

  /**
   * close modal
   */
  closeModel(data) {
    if (data === 'addTournament') {
      this.formResetValue.resetForm();
      this.modal.hide();
    } else {
      this.conformationModal.hide();
      this.rerender();
    }

  }


  getTournamnetsDt() {
    // this.spinner.show();
    this.rerender();
    const that = this;
    // let url = this.server_url + 'tournament/get-all';
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      // autoWidth: false,
      // scrollX: true,
      // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [5, 10, 25, 50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',
        emptyTable: 'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'tournament/get-all';
        console.log(url);
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { sportId: this.paramId, data: this.finalData }),
            {}
          ).subscribe(resp => {
            this.spinner.hide();
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData = JSON.parse(this.resData)
            this.resData = this.resData.data;
            if (this.resData.docs.length > 0) {
              that.tournaments = this.resData.docs;
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },
      columns: [{ data: '' }, { data: 'name' }, { data: 'sport.name' }, { data: 'isActive' }, { data: 'isManual' }, { data: ' displayOrder' }],
      columnDefs: [{ orderable: false, targets: [0]}]

    };
  }


  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  /**
   * @author kc
   * @date : 28-01-2020
   * get all sports
   */
  getAllSport() {
    this.sportService.getAllSport(this.filter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.sportList = response.data.docs.map(data => {
            return { id: data._id, itemName: data.name + '( ' + data.id + ' )', sportId: data.id };
        });
    }, error => {
        console.error('error in getting all sports', error);
    });
  }



  /**
   * @author TR
   * @date : 25-02-2020
   * Create tournaments by sport id
   */
  createWhtTournament() {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for (let i = 0; i < x.length; i++) {
        this.addTournament.sport = {
          id: this.selectedSportItems[0]['sportId'],
          name: this.selectedSportItems[0]['itemName']
        };
        this.tournamentService.addNewWhtTournament(this.addTournament, x[i]).subscribe(response => {
        });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });
  }
  /**
   * @author kc
   * @date : 28-01-2020
   * add tournaments
   */
  createTournament() {
    this.spinner.show();
    this.addTournament.sport = {
      id: this.selectedSportItems[0]['sportId'],
      name: this.selectedSportItems[0]['itemName']
    };
    this.tournamentService.addNewTournament(this.addTournament).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.modal.hide();
        this.spinner.hide();
      if (response.status === true) {
        //this.getTournamnets();
        this.rerender();
        this.utilityService.popToast('success', 'Success', 3000, 'Tournament created successfully.');
        // this.createWhtTournament();
      } else {
        this.utilityService.popToast('error', 'Error', 3000, response.message);
      }
    }, error => {
      console.error('add tournamnet error');
    });
  }

  navigateToMatches(data) {
    this.router.navigate(['/eventmaster/matches', data]);
  }

  updateUserStatus() {
    // this.spinner.show();
    // let checkUserObj = {
    //   id: this.utilityService.returnLocalStorageData('userId'),
    //   password: this.conformationPassword
    // };

    // this.userService.checkUser(checkUserObj)
    //   .subscribe(checkUserResponse => {
    //     this.conformationModal.hide();
    //     if (checkUserResponse.status === true) {
          this.tournamentService.updateTournament(this.tempTournamnetObj).subscribe(response => {
                response = this.utilityService.gsk(response.auth);
                response =JSON.parse(response);
                this.spinner.hide();
              // this.updateWhtLblTournament(this.tempTournamnetObj);
                this.conformationModal.hide();
                this.utilityService.popToast('success', 'Success', 3000, 'Tournaments updated successfully.');
            }, error => {

            })
      //   }
      //    else {
      //     this.spinner.hide();
      //     this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
      //   }

      // }, error => {
      //   this.spinner.hide();
      //   this.utilityService.popToast('error', 'Error', 3000, error.error.message);
      // });

  }
  updateWhtLblTournament(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for (let i = 0; i < x.length; i++) {
        this.tournamentService.updateWhtLblTournament(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white Tournament updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });

  }

  onchange(object) {
    this.passwordFormReset.resetForm();
    // this.nameField.nativeElement.focus();
    this.conformationModal.show();
    $("#password3").select();
    this.tempTournamnetObj = object;
  }

  onSportSelect(sportId) {
    // this.sportId = sportId;
    this.getAllTournament(sportId);
  }

  getAllTournament(sportId) {
    if (sportId) {
      this.tournamentService.getAllTournament(this.tournamentFilter, sportId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.tournamentsList = response.data.docs.map(data => {
          return { id: data._id, itemName: data.name + '( ' + data.id + ' )', tournamentId: data.id };
        });
      }, error => {
        console.error('error in getting all sports', error);
      });
    } else {
      this.tournamentsList = [];
    }
  }


  searchSettleData() {
    this.finalData = '';
    if (this.unSelectSport || this.unSelectTournament) {
      let data = {
        sportId: this.unSelectSport,
        tournamentId: this.unSelectTournament
      };
      this.SelectSport = this.unSelectSport;
      this.SelectTournament = this.unSelectTournament;
      this.finalData = pickBy(data, undefined);
      this.sportId = this.unSelectSport;
      this.getTournamnetsDt();
    }
  }

  clear() {
    if (this.unSelectSport || this.unSelectTournament) {
      this.finalData = '';
      let data = {
        sportId: null,
        tournamentId: null,
        matchId: null,
        marketType: null,
      };
      this.finalData = pickBy(data, undefined);

      this.unSelectSport = '';
      this.unSelectTournament = '';
      this.getTournamnetsDt();
      this.onSportSelect(this.unSelectSport);
    }

  }

  /**
   * update display order
   * @param data
   */
  updateDisplayOrder(data) {
    this.spinner.show();
    setTimeout(res => {
      this.tournamentService.updateTournamentDisplay(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.spinner.hide();
        if (response.status === true) {
          this.rerender();
          // this.updateWhtLblSport(data);
        }
      }, error => {
        this.spinner.hide();
        console.error('error in priority', error);
      })
    }, 500)
  }
}
