import {Component, OnInit, ViewChild} from '@angular/core';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import {WhiteLabelSettingService} from '../services/whitelabelsetting.service';
import {UtilityService} from '../globals/utilityService';
import {NgxSpinnerService} from 'ngx-spinner';
import {ModalDirective} from 'ngx-bootstrap';
@Component({
  selector: 'app-restriction',
  templateUrl: './restriction.component.html',
  styleUrls: ['./restriction.component.scss']
})
export class RestrictionComponent implements OnInit {
  @ViewChild('restrictionsModal', {static: false}) restrictionsModal: ModalDirective;
  htmlContent: any;
  whiteLabelFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  whiteLabels: any;
  update = false;
  selectedWhiteLable: any;
  constructor(private whiteLabelSettingService: WhiteLabelSettingService,
              private utilityService: UtilityService,
              private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.getAllWhiteLabel();
  }

  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '0',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Enter text here...',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      {class: 'arial', name: 'Arial'},
      {class: 'times-new-roman', name: 'Times New Roman'},
      {class: 'calibri', name: 'Calibri'},
      {class: 'comic-sans-ms', name: 'Comic Sans MS'}
    ],
    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    uploadWithCredentials: false,
    sanitize: true,
    toolbarPosition: 'top',
    toolbarHiddenButtons: [
      ['bold', 'italic'],
      ['fontSize']
    ]
  };

  /**
   * @author TR
   * @date : 31-07-2020
   * add new restriction
   */

  saveRestriction(){
      this.spinner.show();
      this.whiteLabelSettingService.addNewRestriction(this.htmlContent , this.selectedWhiteLable).subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
			  resposne =JSON.parse(resposne);
        if(resposne.status === true){
          this.spinner.hide();
          // this.restrictionsModal.hide();
          this.utilityService.popToast('success','Success', 3000 , 'Restriction created successfully.');
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , resposne.message);
        }
      }, error => {
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.message);
      });
    }

    /**
   * @author TR
   * @date : 31-07-2020
   * add new restriction
   */

    updateRestriction(){
      this.spinner.show();
      this.whiteLabelSettingService.updateRestriction(this.htmlContent , this.selectedWhiteLable).subscribe(resposne => {
        // resposne = this.utilityService.gsk(resposne.auth);
			//   resposne =JSON.parse(resposne);
        if(resposne.status === true){
          this.spinner.hide();
          // this.restrictionsModal.hide();
          this.utilityService.popToast('success','Success', 3000 , 'Restriction update successfully.');
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , resposne.message);
        }
      }, error => {
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.message);
      });
    }


  closeModel() {
    this.restrictionsModal.hide();
  }
  clearData(){
    this.htmlContent ='';
  }

  addRestrictionModal(data) {
    this.selectedWhiteLable = data;
    console.log(this.selectedWhiteLable)
    this.getwhitelabelRestriction(this.selectedWhiteLable);
    // this.restrictionsModal.show();
  }
  /**
   * @author TR
   * @date : 31-07-2020;
   * get all White Label Setting
   */
  getwhitelabelRestriction(item){
    this.whiteLabelSettingService.getWhiteLabelRes(item)
      .subscribe(response => {

        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
        if(response.data.length > 0){
          this.update = true;
          this.htmlContent = response.data[0].restriction;
        }else {
          this.htmlContent ='';
          this.update = false;
        }
        this.spinner.hide();
      }, error => {
        console.error('error in get all white Restriction');
      })
  }
   /**
   * @author TR
   * @date : 31-07-2020;
   * get all White Label Setting
   */
  getAllWhiteLabel() {
    this.spinner.show();
    this.whiteLabelSettingService.getAllWhiteLabel(this.whiteLabelFilter)
      .subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.whiteLabels = response.data.docs;
        this.spinner.hide();
      }, error => {
        console.error('error in get all white label');
      })
  }
}
