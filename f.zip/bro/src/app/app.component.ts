import {Component, HostListener} from '@angular/core';
import {ActivatedRoute, NavigationStart, Router} from '@angular/router';
import { ToasterConfig } from 'angular2-toaster';
import {UtilityService} from './globals/utilityService';
declare let $: any;
declare let _: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  // @HostListener('window:keyup', ['$event']) handleKeyboardEvent(event: KeyboardEvent) {
  //   if (window) {
  //     window.console.log = function () { };
  //   }
  //   if (event.key === 'f12' || event.key === 'F12') {
  //     localStorage.clear();
  //     sessionStorage.clear();
  //     this.router.navigate(['']);
  //   }
  // }
  // @HostListener('window:keydown', ['$event']) onKeyDown(e) {
  //   if (window) {
  //     window.console.log = function () { };
  //   }
  //   if ((e.shiftKey == true && e.keyCode == 73 && e.ctrlKey == true) || (e.key == 'f12' || e.key == 'F12') ) {
  //     localStorage.clear();
  //     sessionStorage.clear();
  //     this.router.navigate(['']);
  //     return false;
  //   }
  // }
  // @HostListener('contextmenu', ['$event']) onRightClick(event) {
  //   event.preventDefault();
  //   if (window) {
  //     window.console.log = function () { };
  //   }
  //   return false;
  // }

  title = 'bro';
  sidebarHeader = false;
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right',
    limit: 2
  });
  constructor(private router: Router , private route:ActivatedRoute , private utilityService: UtilityService) {
    if(window.console) {
        // window.console.log = function(){};
        // window.console.warn = function(){};
        // window.console.error = function(){};
        // window.console.time = function(){};
        // window.console.timeEnd = function(){};
        // window.console.info = function(){};
        // window.console.trace= function(){};
        // console.clear = function(){};
        // console.clear();
     }

    router.events.forEach((event) => {
      if (event instanceof NavigationStart) {
        if (event['url'] === '/' || event['url'] === '/login') {
          localStorage.clear();
          this.sidebarHeader = false;
        } else {
          this.sidebarHeader = true;
        }

        if (!this.utilityService.returnLocalStorageData('userId')) {
           localStorage.clear();
          this.sidebarHeader = false;
        } else {
          this.sidebarHeader = true;
        }
      }
    });
  }
}
