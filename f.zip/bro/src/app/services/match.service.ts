import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {ConstantService} from '../globals/constant.service';
import {UtilityService} from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class MatchService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();
  redisUrl: any = env.redisApi_url();

  constructor(private http: HttpClient,
              private utilityService: UtilityService,
    private constantService: ConstantService
              ) { }


    /**
     *@author kc
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Match
     */
    getAllMatch(filter, tId): Observable<any> {
        let query = '?page=' + filter.page +   '&limit=' + filter.limit;

        if (!isUndefined(filter.search) && filter.search !== null) {
            query += '&search=' + filter.search;
        }
        if(isUndefined(tId)){
            return this.http.get(this.server_url + 'match' + query)
                .pipe(tap(_ => this.log(`get match successfully`)));
        } else {
            return this.http.get(this.server_url + 'match/' + tId + query)
                .pipe(tap(_ => this.log(`get match successfully`)));
        }
    }

        /**
     *@author rk
     * @date 03-11-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Match import fancy api
     */
    getAllMatchImport(): Observable<any> {
        return this.http.get(this.redisUrl + '/api/v1/user/active-game')
            .pipe(tap(_ => this.log(`get match`)));
  }

  getRelatedMarket(id): Observable<any> {
    return this.http.get(this.server_url + 'market/getBymatchId/' + id)
    .pipe(tap(_ => this.log(`get match`)));
  }

          /**
     *@author rk
     * @date 03-11-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Match import fancy api
     */
    getAllMarketImport(gamesrno): Observable<any> {
      return this.http.get(this.redisUrl + '/api/v1/user/active-market/' + gamesrno)
          .pipe(tap(_ => this.log(`get market`)));
    }

  /***
   * @author TR
   * @date 07-11-2020
   * @param data
   * @returns {Observable<any>}
   * active auto fancy rate
   */
  activeRedisFancyAutoRate(data): Observable<any> {
    return this.http.post(this.redisUrl + '/api/v1/user/add-fancy/',data)
      .pipe(tap(_ => this.log(`Added fancy successfully`)));
  }

  getBymatchId(data): Observable<any> {
    return this.http.get(this.server_url + 'market/getBymatchId/' + data)
      .pipe(tap(_ => this.log(`Added fancy successfully`)));
  }


    /**
     *@author kc
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add new Match
     */
    addNewMatch(data): Observable<any> {
        return this.http.post(this.server_url + 'match' , data)
            .pipe(tap(_ => this.log(`add match successfully`)));
    }

    /**
     *@author kc
     * @date 25-02-2020
     * @param filter
     * @returns {Observable<any>}
     * add new Match for White Lable
     */
    addNewWhtLblMatch(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
      let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
        return this.http.post(webHookUrl + 'match' , data , {headers : headers})
            // .pipe(tap(_ => this.log(`add match successfully`)));
    }

    /**
     *@author kc
     * @date 28-01-2020
     * @param id
     * @returns {Observable<any>}
     * get Match by id
     */
    getMatchById(id): Observable<any> {
        return this.http.get(this.server_url+ 'match/byId' + '/' + id)
            .pipe(tap(_ => this.log(`get match  successfully`)));
    }


    /***
     * @author kc
     * @date 28-01-2020
     * @param data
     * @returns {Observable<any>}
     * update Match
     */
    updateMatch(data): Observable<any> {
        return this.http.put(this.server_url + 'match/' + data._id,data)
            .pipe(tap(_ => this.log(`update match  successfully`)));
    }


    /***
     * @author kc
     * @date 28-01-2020
     * @param data
     * @returns {Observable<any>}
     * update Match
     */
    updateMatchChennel(data): Observable<any> {
        return this.http.put(this.server_url + 'match/chennel/' + data._id,data)
            .pipe(tap(_ => this.log(`update match  successfully`)));
    }

    /***
     * @author kc
     * @date 28-01-2020
     * @param data
     * @returns {Observable<any>}
     * update Match
     */
    updateMatchTiming(data): Observable<any> {
        return this.http.put(this.server_url + 'match/openDate/' + data.id, data)
            .pipe(tap(_ => this.log(`update match  successfully`)));
    }

    /***
     * @author kc
     * @date 28-01-2020
     * @param data
     * @returns {Observable<any>}
     * update Match
     */
    updateWhtLblMatch(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
      let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
      console.log("webHookUrl=====================",webHookUrl + 'match/' + data._id,data , {headers : headers});
      return this.http.put(webHookUrl + 'match/' + data._id,data , {headers : headers})
            .pipe(tap(_ => this.log(`update match  successfully`)));
    }

    /***
     * @author kc
     * @date 28-01-2020
     * @param data
     * @returns {Observable<any>}
     * update Channel
     */
    updateWhtLblMatchChannel(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
      let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
        return this.http.put(webHookUrl + 'match/channel/' + data._id,data , {headers : headers})
            .pipe(tap(_ => this.log(`update channel  successfully`)));
    }


    /**
     *@author rk
     * @date 28-01-2020
     * @param id
     * @returns {Observable<any>}
     * get market by match id
     */

     getMarketByMatchId(id): Observable<any> {
       console.log(id);
      return this.http.get(this.server_url+ 'market' + '/getmarketbymid/' + id)
          .pipe(tap(_ => this.log(`get match  successfully`)));
     }

    /**
     *@author rk
     * @date 28-01-2020
     * @param id
     * @returns {Observable<any>}
     * match settled
     */

    matchSettled(data,headerData): Observable<any> {
      //let finalUrl = env.webHookPreFixUrl()  + this.constantService.nonWebHook + 'market/match-settled';

      let finalUrl = env.webHookPreFixUrl() + headerData.appUrl  + this.constantService.nonWebHook + 'market/match-settled';
      //console.log(finalUrl);
     // let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'apptoken': headerData.app_token});
      return this.http.post(finalUrl, data)
          .pipe(tap(_ => this.log(`handshake is successfully match`)));
    }


     /**
     *@author rk
     * @date 28-01-2020
     * @param id
     * @returns {Observable<any>}
     * match settled
     */

    matchBMSettled(data,headerData): Observable<any> {
      //let finalUrl = env.webHookPreFixUrl()  + this.constantService.nonWebHook + 'market/bm-match-settled';

      let finalUrl = env.webHookPreFixUrl() + headerData.appUrl  + this.constantService.nonWebHook + 'market/bm-match-settled';
      //console.log(finalUrl);

      // let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'apptoken': headerData.app_token});
      return this.http.post(finalUrl, data)
          .pipe(tap(_ => this.log(`handshake is successfully match`)));
    }

    /**
     *@author rk
     * @date 28-01-2020
     * @param id
     * @returns {Observable<any>}
     * match settled
     */

    matchSettledOffice(data): Observable<any> {
      return this.http.post(this.server_url + 'match/settled' , data)
      .pipe(tap(_ => this.log(`Add channel successfully`)));
    }

    /**
     *@author rk
     * @date 28-01-2020
     * @param id
     * @returns {Observable<any>}
     * match settled
     */

    matchBMOffice(data): Observable<any> {
      return this.http.post(this.server_url + 'bookmaker/settled' , data)
      .pipe(tap(_ => this.log(`Add channel successfully`)));
    }

  /**
   *@author TR
   * @date 11-08-2020
   * @param filter
   * @returns {Observable<any>}
   * add new Channel
   */
  addNewChannel(data): Observable<any> {
    return this.http.post(this.server_url + 'match/createChannel' , data)
      .pipe(tap(_ => this.log(`Add channel successfully`)));
  }

  /**
   *@author TR
   * @date 11-08-2020
   * @param filter
   * @returns {Observable<any>}
   * update new Channel
   */
  updateChannel(data): Observable<any> {
    return this.http.put(this.server_url + 'match/updateChannel/'+ data._id , data)
      .pipe(tap(_ => this.log(`Update channel successfully`)));
  }

 /**
   *@author TR
   * @date 11-08-2020
   * @param filter
   * @returns {Observable<any>}
   * delete Channel
   */
 deleteChannel(data): Observable<any> {
    return this.http.post(this.server_url + 'match/deleteChannel' , data)
      .pipe(tap(_ => this.log(`delete channel successfully`)));
  }

  /**
   *@author TR
   * @date 11-08-2020
   * @param filter
   * @returns {Observable<any>}
   * get Channel
   */
  getAllChannel(): Observable<any> {
    return this.http.get(this.server_url + 'match/getAllChannel')
      .pipe(tap(_ => this.log(`Get channel successfully`)));
  }

  log(message) {
    console.log(message);
  }


}
