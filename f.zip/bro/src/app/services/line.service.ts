import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/index';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap } from 'rxjs/internal/operators';
import { isUndefined } from 'util';
import * as env from '../globals/env';
import { ConstantService } from '../globals/constant.service';
import {UtilityService} from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class LineService {
  server_url: any = env.server_url();

  constructor(private http: HttpClient, private utilityService: UtilityService,
    private constantService: ConstantService) { }

  /**
     *@author subhash
    * @date 15-07-2020
    * @returns {Observable<any>}
    * get volume and variation
  **/

  createlineRate(data): Observable<any> {
    console.log('data', data);
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token') });
    return this.http.post(this.server_url + 'line-rate/create', data, { headers: headers })
      .pipe(tap(_ => this.log(`line rate update successfully`)));
  }


  getlineRate(): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token') });
    return this.http.get(this.server_url + 'line-rate/line-rate' ,{ headers: headers })
      .pipe(tap(_ => this.log(`line rate update successfully`)));
  }

  getMarketById(id): Observable<any>{
    return this.http.get(this.server_url + 'line/' + id)
      .pipe(tap(_ => this.log(`get volume`)));
  }


  log(message) {
    console.log(message);
  }
}
