import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {ConstantService} from '../globals/constant.service';
var aes256 = require('aes256');
@Injectable({
  providedIn: 'root'
})
export class WhiteLabelSettingService {
  server_url: any = env.server_url();
  whiteLableUrl : any = env.adminServer_url()
  constructor(private http: HttpClient,
              private constantService: ConstantService
              ) { }


    /**
     *@author kc
     * @date 20-02-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Market
     */
    getAllWhiteLabel(filter): Observable<any> {
        let query = '?page=' + filter.page +   '&limit=' + filter.limit;

        if (!isUndefined(filter.search) && filter.search !== null) {
            query += '&search=' + filter.search;
        }
            return this.http.get(this.server_url + 'whiteLabelSetting/' + query)
                .pipe(tap(_ => this.log(`get whiteLabelSetting successfully`)));
    }

    /**
     *@author kc
     * @date 20-02-2020
     * @param filter
     * @returns {Observable<any>}
     * add new White Label Setting
     */
    addNewWhiteLabelSetting(data): Observable<any> {
        return this.http.post(this.server_url + 'whiteLabelSetting' , data)
            .pipe(tap(_ => this.log(`add whiteLabelSetting successfully`)));
    }

    /**
     *@author TR
     * @date 28-12-2020
     * @param filter
     * @returns {Observable<any>}
     * update White Label Setting
     */
    updateWhiteLabelLayout(data): Observable<any> {
      return this.http.put(this.server_url + 'whiteLabelSetting/layout/' + data._id,data)
        .pipe(tap(_ => this.log(`update layout whiteLabelSetting  successfully`)));
    }

  /**
     *@author kc
     * @date 20-02-2020
     * @param id
     * @returns {Observable<any>}
     * get Market by id
     */
    getWhiteLabelSettingById(id): Observable<any> {
        return this.http.get(this.server_url+ 'whiteLabelSetting' + '/' + id)
            .pipe(tap(_ => this.log(`get whiteLabelSetting  successfully`)));
    }


    /***
     * @author kc
     * @date 20-02-2020
     * @param data
     * @returns {Observable<any>}
     * update Market
     */
    updateWhiteLabelSetting(data): Observable<any> {
        return this.http.put(this.server_url + 'whiteLabelSetting/' + data._id,data)
            .pipe(tap(_ => this.log(`update whiteLabelSetting  successfully`)));
    }


  /**
   * handshke with white label using token
   * @param data
   * @return {Observable<any>}
   */
  handshakeWithWhitelabel(data): Observable<any> {
    return this.http.post(env.webHookPreFixUrl() + data.url + this.constantService.checkHandshakeUrl , data)
      .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }

  /**
   * handshke with white label using token
   * @param data
   * @return {Observable<any>}
   */
  createWhiteLableSettings(data,url ,token): Observable<any> {
  let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': token});
    return this.http.post(env.webHookPreFixUrl() + url + this.constantService.webHookUrl + 'settings', data,{headers : headers
    })
      .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }
  /**
   * handshke with white label using token
   * @param data
   * @return {Observable<any>}
   */
  getWhitelabelSettings(data): Observable<any> {
    let finalUrl;
    if(env.webHookPreFixUrl() === 'http://localhost:7878' ) {
       finalUrl = env.webHookPreFixUrl()  + this.constantService.webHookUrl + 'getallsettings';
    }else if(env.webHookPreFixUrl() === 'https://server.' ){
       finalUrl = env.webHookPreFixUrl() + data.app_url  + this.constantService.webHookUrl + 'getallsettings';
    }
    let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': data.app_token});
    return this.http.get(finalUrl, {headers : headers})
      .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }

  /**
   * handshke with white label using token
   * @param data
   * @return {Observable<any>}
   */
  getCasinoSettings(data): Observable<any> {
    let finalUrl;
    if(env.webHookPreFixUrl() === 'http://localhost:7878' ) {
      finalUrl = env.webHookPreFixUrl() + '/api/v1/gameSetting/casino';
    }else if(env.webHookPreFixUrl() === 'https://server.' ){
      finalUrl = env.webHookPreFixUrl() + data.app_url  + '/api/v1/gameSetting/casino';
    }
    let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': data.app_token});
    return this.http.get(finalUrl, {headers : headers})
      .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }

  /**
   * handshke with white label using token
   * @param data
   * @return {Observable<any>}
   */
  updateCasinoSettings(data , headerData): Observable<any> {
    let finalUrl;
    if(env.webHookPreFixUrl() === 'http://localhost:7878' ) {
      finalUrl = env.webHookPreFixUrl() + '/api/v1/gameSetting/updateGameSetting/casino';
    }else if(env.webHookPreFixUrl() === 'https://server.' ){
      finalUrl = env.webHookPreFixUrl() + headerData.app_url  + '/api/v1/gameSetting/updateGameSetting/casino';
    }

    let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
    return this.http.put(finalUrl,data, {headers : headers})
      .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }

  /**
   *  update setting data in White label Settings
   *  using web hook (game, fancy, bookmaker, user)
   * @param data
   * @return {Observable<any>}
   */
  updateWhitelabelSettingsWithWebHook(data, headerData): Observable<any> {
    //let finalUrl = env.webHookPreFixUrl()  + this.constantService.webHookUrl + 'updateSetting';
    let finalUrl = env.webHookPreFixUrl() + headerData.app_url  + this.constantService.webHookUrl + 'updateSetting';
    console.log(finalUrl)
    let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
    return this.http.put(finalUrl, data,{headers : headers})
      .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }

  /**
   *  update setting data in White label Settings
   *  with market table
   *  using web hook (game, fancy, bookmaker, user)
   * @param data
   * @return {Observable<any>}
   */
  updateWlSettingsWithMarketWebHook(data, headerData): Observable<any> {
    //let finalUrl = env.webHookPreFixUrl()  + this.constantService.webHookUrl + 'updateSetting';
    let finalUrl = env.webHookPreFixUrl() + headerData.app_url  + this.constantService.webHookUrl + 'updateMarketSetting';
    let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
    return this.http.put(finalUrl, data,{headers : headers})
      .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }


  // addNewSport(data,headerData): Observable<any> {
  //   let finalUrl = env.webHookPreFixUrl() + headerData.app_url  + this.constantService.webHookUrl + 'updateMarketSetting';
  //   let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});

  //   return this.http.post(this.whiteLableUrl + 'partnershipcommissions/addSportpc',data)
  //       .pipe(tap(_ => this.log(`update sport`)));
  // }

  addNewSport(data,headerData): Observable<any> {
    if(env.webHookPreFixUrl() === 'https://server.') {
      let finalUrl = env.webHookPreFixUrl() + headerData.app_url  + this.constantService.partnershipUrl  + 'addSportpc';
      let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
      return this.http.post(finalUrl, data,{headers : headers})
        .pipe(tap(_ => this.log(`handshake is successfully match`)));
    }else {
      let finalUrl = env.webHookPreFixUrl()  + this.constantService.nonWebHook + 'partnershipcommissions/addSportpc';
      let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
      return this.http.post(finalUrl, data,{headers : headers})
        .pipe(tap(_ => this.log(`handshake is successfully match`)));
    }
  }

  addNewSportintoOffice(data , id): Observable<any> {
     data['whtlableId'] = id;
    return this.http.post(this.server_url + 'whiteLabelSetting/updateSport',data)
      .pipe(tap(_ => this.log(`add partnership  successfully`)));
  }

  /**
   * @developer:- TR
   *  Add Restriction for Whitelable
   * @param data
   * @return {Observable<any>}
   */
  addNewRestriction(data , headerData): Observable<any> {
    if(env.webHookPreFixUrl() === 'https://server.') {
      let finalUrl = env.webHookPreFixUrl() + headerData.app_url + this.constantService.webHookUrl + 'addRestriction';
      let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
      let items = {
        'restriction': data,
        'id': headerData._id
      };
      return this.http.post(finalUrl, items,{headers : headers})
        .pipe(tap(_ => this.log(`add restriction  successfully`)));
    }else {
      let finalUrl = env.webHookPreFixUrl()  + this.constantService.webHookUrl + 'addRestriction';
      let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
      let items = {
        'restriction': data,
        'id': headerData._id
      };
      return this.http.post(finalUrl, items,{headers : headers})
        .pipe(tap(_ => this.log(`add restriction  successfully`)));
    }
  }

  /**
   * @developer:- TR
   *  Update Restriction for Whitelable
   * @param data
   * @return {Observable<any>}
   */

  updateRestriction(data , headerData): Observable<any> {
    if(env.webHookPreFixUrl() === 'https://server.'){
      let finalUrl = env.webHookPreFixUrl() + headerData.app_url  + this.constantService.webHookUrl  + 'updateRestriction';
      let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
      let items = {
        'restriction': data,
        'id': headerData._id
      };
      return this.http.put(finalUrl, items,{headers : headers})
        .pipe(tap(_ => this.log(`update restriction  successfully`)));
    }else {
      let finalUrl = env.webHookPreFixUrl()  + this.constantService.webHookUrl + 'updateRestriction';
      let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': headerData.app_token});
      let items = {
        'restriction': data,
        'id': headerData._id
      };
      return this.http.put(finalUrl, items,{headers : headers})
        .pipe(tap(_ => this.log(`update restriction  successfully`)));
    }

  }

  /**
   * @developer:- TR
   *  Get Restriction for Whitelable
   * @param data
   * @return {Observable<any>}
   */

  getWhiteLabelRes(data): Observable<any> {
    if(env.webHookPreFixUrl() === 'https://server.'){
      let finalUrl = env.webHookPreFixUrl() + data.app_url  + this.constantService.webHookUrl  + 'getRestriction';
      let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': data.app_token});

      return this.http.post(finalUrl, data,{headers : headers})
        .pipe(tap(_ => this.log(`get restriction  successfully`)));
    }else {
      let finalUrl = env.webHookPreFixUrl()  + this.constantService.webHookUrl + 'getRestriction';
      let headers = new HttpHeaders({'Authorization' : returnLocalStorageData('token'), 'apptoken': data.app_token});

      return this.http.post(finalUrl, data,{headers : headers})
        .pipe(tap(_ => this.log(`get restriction  successfully`)));
    }
  }

  reactionOnwhtlbl(data): Observable<any> {
    return this.http.post(this.server_url + 'whiteLabelSetting/update-reaction', data)
    .pipe(tap(_ => this.log(`add match successfully`)));  }

  log(message) {
    console.log(message);
  }


}

function returnLocalStorageData(pwd){

  let data =  localStorage.getItem(pwd);
  let key = 'bqwOlSSbg9VLtQuMp3mB7OAWQQwrvj6V';
  if(data){
    let decrypt = aes256.decrypt(key, data);
    return decrypt;
  }else {
    return false
  }

}
