import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {UtilityService} from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class SportService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();

  constructor(private http: HttpClient,private utilityService: UtilityService
              ) { }


    /**
     *@author kc
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Sport
     */
    getAllSport(filter): Observable<any> {
        let query = '?page=' + filter.page +   '&limit=' + filter.limit;

        if (!isUndefined(filter.search) && filter.search !== null) {
            query += '&search=' + filter.search;
        }

        return this.http.get(this.server_url + 'sport' + query)
            .pipe(tap(_ => this.log(`get sport successfully`)));
    }

    /**
     *@author kc
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add new role
     */
    addNewSport(data): Observable<any> {
        return this.http.post(this.server_url + 'sport' , data)
            .pipe(tap(_ => this.log(`add rolsporte successfully`)));
    }

    /**
     *@author kc
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add new Sport For White lable
     */
    addNewSportwht(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
      let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
        return this.http.post(webHookUrl + 'sport' , data , {headers : headers})
            // .pipe(tap(_ => this.log(`add sport successfully`)));
    }
  /***
   * @author kc
   * @date 28-01-2020
   * @param data
   * @returns {Observable<any>}
   * update role
   */
  updateWhtLblSport(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});

    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    //console.log(webHookUrl)
    return this.http.put(webHookUrl + 'sport/' + data._id,data , {headers : headers})
      .pipe(tap(_ => this.log(`update Sport  successfully`)));
  }

    /**
     *@author kc
     * @date 28-01-2020
     * @param id
     * @returns {Observable<any>}
     * get role by id
     */
    getSportById(id): Observable<any> {
        return this.http.get(this.server_url+ 'sport' + '/' + id)
            .pipe(tap(_ => this.log(`get Sport  successfully`)));
    }


    /***
     * @author kc
     * @date 28-01-2020
     * @param data
     * @returns {Observable<any>}
     * update role
     */
    updateSport(data): Observable<any> {
        return this.http.put(this.server_url + 'sport/' + data._id,data)
            .pipe(tap(_ => this.log(`update sport  successfully`)));
    }



  log(message) {
    console.log(message);
  }


}
