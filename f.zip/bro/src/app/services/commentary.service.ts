import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/index';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/internal/operators';
import { isUndefined } from 'util';
import * as env from '../globals/env';

@Injectable({
  providedIn: 'root'
})
export class CommentaryService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();

  constructor(private http: HttpClient) { }

  /**
    *@author Subhah
    * @date 10-08-2020
    * @param filter
    * @returns {Observable<any>}
    * get all commentry
    */
  getAllCommentry(): Observable<any> {
    return this.http.get(this.server_url + 'commentary/list')
      .pipe(tap(_ => this.log(`Get commentary successfully`)));
  }

  getAllCommentryIsActive(): Observable<any> {
    return this.http.get(this.server_url + 'commentary/list-all')
      .pipe(tap(_ => this.log(`Get commentary successfully`)));
  }

  /**
    *@author Subhah
    * @date 10-08-2020
    * @param filter
    * @returns {Observable<any>}
    * get all create
    */
  createCommentry(data): Observable<any> {
    return this.http.post(this.server_url + 'commentary/create', data)
      .pipe(tap(_ => this.log(`create commentary successfully`)));
  }

  deleteCommentry(id): Observable<any> {
    return this.http.get(this.server_url + 'commentary/delete/' + id)
      .pipe(tap(_ => this.log(`Delete commentary successfully`)));
  }
  getEditCommentry(id): Observable<any> {
    return this.http.get(this.server_url + 'commentary/edit/' + id)
      .pipe(tap(_ => this.log(`get commentary successfully`)));
  }

  getUpdateCommentry(id,data): Observable<any> {
    return this.http.post(this.server_url + 'commentary/update/'+ id , data)
      .pipe(tap(_ => this.log(`get commentary successfully`)));
  }

  updateStatusCommentry(id,data): Observable<any> {
    console.log('id',id ,'data',data);
    return this.http.post(this.server_url + 'commentary/updateStatus/'+ id , data)
      .pipe(tap(_ => this.log(`Update commentary successfully`)));
  }



  

  log(message) {
    console.log(message);
  }
}
