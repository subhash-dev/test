import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  server_url: any = env.server_url();

  constructor(private http: HttpClient,
              ) { }

  /**
   *@author Ravi Kadia
   * @date 09-01-2020
   * @param filter
   * @returns {Observable<any>}
   * add new user
   */

   loginApi(data): Observable<any> {
    return this.http.post(this.server_url + 'user/login' , data)
      .pipe(tap(_ => this.log(`user login successfully`)));
  }


  /**
   *@author kc
   * @date 09-01-2020
   * @param data
   * @returns {Observable<any>}
   * add new user
   */

  creteUser(data): Observable<any> {
    return this.http.post(this.server_url + 'user' , data)
      .pipe(tap(_ => this.log(`create new user successfully`)));
  }

  /**
   *@author kc
   * @date 09-01-2020
   * @param data
   * @returns {Observable<any>}
   * add new user
   */

  checkUser(data): Observable<any> {
    return this.http.post(this.server_url + 'user/checkUser' , data)
      .pipe(tap(_ => this.log(`check user successfully`)));
  }

  /**
   *@author kc
   * @date 09-01-2020
   * @param data
   * @returns {Observable<any>}
   * add new user
   */

  checkUserLogin(data): Observable<any> {
    return this.http.post(this.server_url + 'user/checkuserlogin' , data)
      .pipe(tap(_ => this.log(`check user successfully`)));
  }

  /**
   * get user by user id
   * @param id
   * @return {Observable<any>}
   */
  getUserById(id): Observable<any>{
    return this.http.get(this.server_url + 'user/' + id)
      .pipe(tap(_ => this.log(`get user by id successfully`)));
  }

  /**
   * update user details
   * @param data
   * @return {Observable<any>}
   */
  updateUser(data): Observable<any>{
    return this.http.put(this.server_url + 'user/' + data._id, data)
      .pipe(tap(_ => this.log(`get user by id successfully`)));
  }

  /**
   * user reset password
   * @param data
   * @return {Observable<any>}
   */
  resetPassword(data): Observable<any>{
    return this.http.put(this.server_url + 'user/resetpassword/' + data.id, data)
      .pipe(tap(_ => this.log(`password updated successfully`)));
  }

  /**
   * get only fancy user
   * @param id
   * @return {Observable<any>}
   */
  fancyUser(id) :Observable<any>{
    return this.http.get(this.server_url + 'user/fancyuser/' + id)
      .pipe(tap(_ => this.log(`fancy user successfully`)));
  }

  logOut() :Observable<any>{
    return this.http.get(this.server_url + 'user/logout')
      .pipe(tap(_ => this.log(`user logout successfully`)));
  }
  log(message) {
    console.log(message);
  }


}
