import { TestBed } from '@angular/core/testing';

import { WhiteLabelWelcomeMassageService } from './white-label-welcome-massage.service';

describe('WhiteLabelWelcomeMassageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WhiteLabelWelcomeMassageService = TestBed.get(WhiteLabelWelcomeMassageService);
    expect(service).toBeTruthy();
  });
});
