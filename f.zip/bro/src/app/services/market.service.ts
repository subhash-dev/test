import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/index';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap } from 'rxjs/internal/operators';
import { isUndefined } from 'util';
import * as env from '../globals/env';
import {UtilityService} from '../globals/utilityService';
import {ConstantService} from '../globals/constant.service';

@Injectable({
  providedIn: 'root'
})
export class MarketService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();

  constructor(private http: HttpClient,
              private utilityService: UtilityService,
    private constantService: ConstantService
  ) { }


  /**
   *@author kc
   * @date 31-01-2020
   * @param filter
   * @returns {Observable<any>}
   * get all Market
   */
  getAllMarket(filter, tId): Observable<any> {
    let query = '?page=' + filter.page + '&limit=' + filter.limit;

    if (!isUndefined(filter.search) && filter.search !== null) {
      query += '&search=' + filter.search;
    }
    if (isUndefined(tId)) {
      return this.http.get(this.server_url + 'market/5ebc1code68br4bik5b3035' + query)
        .pipe(tap(_ => this.log(`get Market successfully`)));
    } else {

      return this.http.get(this.server_url + 'market/' + tId + query)
        .pipe(tap(_ => this.log(`get match successfully`)));
    }
  }

  /**
   *@author kc
   * @date 31-01-2020
   * @param filter
   * @returns {Observable<any>}
   * add new Market
   */
  addNewMarket(data): Observable<any> {
    return this.http.post(this.server_url + 'market', data)
      .pipe(tap(_ => this.log(`add match successfully`)));
  }

  marketSettel(data): Observable<any> {
    return this.http.post(this.server_url + 'market/settled', data)
      .pipe(tap(_ => this.log(`get markect Settel successfully`)));
  }

  /**
   *@author kc
   * @date 25-02-2020
   * @param filter
   * @returns {Observable<any>}
   * add new Market ODDS for White lable
   */
  addNewMarketWhtLbl(data, whtLbl): Observable<any> {

    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken });
    //let webHookUrl = this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/';
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';

    //console.log("te-------------",webHookUrl + 'market', data, { headers: headers });
    return this.http.post(webHookUrl + 'market', data, { headers: headers })
    // .pipe(tap(_ => this.log(`add match successfully`)));
  }
  /**
   *@author kc
   * @date 05-02-2020
   * @param filter
   * @returns {Observable<any>}
   * add new fancy Market
   */
  addNewFancyMarket(data): Observable<any> {
    return this.http.post(this.server_url + 'market/createfancy', data)
      .pipe(tap(_ => this.log(`add match successfully`)));
  }

  /**
   *@author kc
   * @date 25-02-2020
   * @param filter
   * @returns {Observable<any>}
   * add new Market ODDS for White lable
   */
  addNewFancyMarketWhtLbl(data, whtLbl): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken });
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';

    return this.http.post(webHookUrl + 'market/createfancy', data, { headers: headers })
    // .pipe(tap(_ => this.log(`add match successfully`)));
  }


  /**
     *@author kc
     * @date 31-01-2020
     * @param id
     * @returns {Observable<any>}
     * get Market by id
     */
  getMarketById(id): Observable<any> {
    return this.http.get(this.server_url + 'market' + '/' + id)
      .pipe(tap(_ => this.log(`get match  successfully`)));
  }

   /**
     *@author kc
     * @date 31-01-2020
     * @param id
     * @returns {Observable<any>}
     * get Market by id
     */
    getMarketByMatchId(id): Observable<any> {
      return this.http.get(this.server_url + 'market/getmarketbymid/' + '/' + id)
        .pipe(tap(_ => this.log(`get match  successfully`)));
    }

    /**
     *@author kc
     * @date 31-01-2020
     * @param id
     * @returns {Observable<any>}
     * get Market by id
     */
    getAllfancy(id): Observable<any> {
      return this.http.get(this.server_url + 'market/allFancyById/' + id)
        .pipe(tap(_ => this.log(`get match  successfully`)));
    }

  /***
   * @author kc
   * @date 31-01-2020
   * @param data
   * @returns {Observable<any>}
   * update Market
   */
  updateMarket(data): Observable<any> {
    return this.http.put(this.server_url + 'market/flag/' + data._id, data)
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }



  /***
   * @author TR
   * @date 26-08-2020
   * @param data
   * @returns {Observable<any>}
   * Cancel Market
   */
  cancelGameStatus(data): Observable<any> {
    return this.http.put(this.server_url + 'market/cancel/' + data.marketId, data)
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }

    /***
   * @author TR
   * @date 26-08-2020
   * @param data
   * @returns {Observable<any>}
   * Cancel Market
   */
  reopenGameStatus(data): Observable<any> {
    return this.http.put(this.server_url + 'market/reopen/' + data.marketId, data)
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }

  reopenCancelGameStatus(data): Observable<any> {
    return this.http.put(this.server_url + 'market/cancel-reopen/' + data.marketId, data)
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }


  /***
   * @author TR
   * @date 08-08-2020
   * @param data
   * @returns {Observable<any>}
   * update Market Status Comentory
   */
  updateMarketStatus(data): Observable<any> {
    return this.http.put(this.server_url + 'market/commentory/' + data.matchId, data)
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }


  /***
   * @author kc
   * @date 17-04-2020
   * @param data
   * @returns {Observable<any>}
   * update fancy, bookmaker, odd setting with whatever params
   * you can also update any parameter of that object
   */
  updateMarketData(data): Observable<any> {
    return this.http.put(this.server_url + 'market/updateMarketByType/' + data.marketId, data)
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }

  /***
   * @author kc
   * @date 31-01-2020
   * @param data
   * @returns {Observable<any>}
   * update Market in white label(multiple white label)
   */
  updateWhtLblMarket(data, whtLbl): Observable<any> {
    console.log("test------------",data);
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken });
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'market/updateMarketByType/' + data.marketId, data, { headers: headers })
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }

  /***
   * @author TR
   * @date 31-01-2020
   * @param data
   * @returns {Observable<any>}
   * update Market in white label(multiple white label)
   */
  updateWhtLblMarketStatus(data, whtLbl): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken });
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'market/updateMatchByStatus/' + data.matchId, data, { headers: headers })
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }


  /**
   *@author TR
   * @date 01-06-2020
   * @param filter
   * @returns {Observable<any>}
   *get all bet lock
   */

  getAllBetBlock(data, whtLbl): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken });
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    data['appUrl'] = whtLbl.appUrl;
    return this.http.post(webHookUrl + 'lockmatch/getAllLockByUser', data, { headers: headers })
      .pipe(tap(_ => this.log(`get all bet-block successfully`)));
  }

  getAllTransactionsBymatchID(data, whtLbl): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': localStorage.getItem('token')});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'placebet/get-all-viewbet/matchId', data ,{ headers: headers })
      .pipe(tap(_ => this.log(`get all bet-block successfully`)));
  }

  cancelMarket(data, whtLbl): Observable<any> {
  let headers = new HttpHeaders({ 'Authorization': localStorage.getItem('token')});
  let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'placebet/cancel-market', data , { headers: headers })
      .pipe(tap(_ => this.log(`get all bet-block successfully`)));
  }

  reopenMarket(data, whtLbl): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': localStorage.getItem('token')});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
      return this.http.post(webHookUrl + 'placebet/reopen-market', data , { headers: headers })
        .pipe(tap(_ => this.log(`get all bet-block successfully`)));
    }

  cancelGameStatusWhtLbl(data, whtLbl): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': localStorage.getItem('token')});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'market/cancelMarket/'+ data.marketId, data ,{ headers: headers })
      .pipe(tap(_ => this.log(`cancel market successfully`)));
  }


  getMarketBymarketId(marketId): Observable<any> {
    return this.http.get(this.server_url + 'market/marketId/' + marketId)
      .pipe(tap(_ => this.log(`get market successfully`)));
  }

  getMarketStatusChange(data): Observable<any> {
    return this.http.post(this.server_url + 'market/marketStatus-change', data)
      .pipe(tap(_ => this.log(`get market  successfully`)));
  }
  /**
   *@author subhash
   * @date 10-07-2020
   *get all bet lock
   */

  getMarketApi(): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.get(this.server_url + 'marketapi/get', { headers: headers })
      .pipe(tap(_ => this.log(`get marketapi  successfully`)));
  }

  createMarketApi(data): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.post(this.server_url + 'marketapi/create',data, { headers: headers })
      .pipe(tap(_ => this.log(`get all bet-block successfully`)));
  }


  /**
   * get user by user id
   * @param id
   * @return {Observable<any>}
   */
  updateMarketApiById(id,data): Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.put(this.server_url + 'marketapi/update/' + id, data,{ headers: headers })
      .pipe(tap(_ => this.log(`get user by id successfully`)));
  }
  updateMarketApiStatus(id,data): Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.put(this.server_url + 'marketapi/status/' + id, data,{ headers: headers })
      .pipe(tap(_ => this.log(`get user by id successfully`)));
  }

  deleteMarketApiById(id): Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.delete(this.server_url + 'marketapi/delete/' + id,{ headers: headers })
      .pipe(tap(_ => this.log(`get user by id successfully`)));
  }

  /**
   * subhash
   * @return {Observable<any>}
   * 13-7-2020
   */

  lineSettingUpdate(id,data): Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.post(this.server_url + 'market/line-setting/' + id, data, { headers: headers })
      .pipe(tap(_ => this.log(`line Setting Update successfully`)));
  }

  lineConfigurationSettingUpdate(id,data): Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.post(this.server_url + 'market/lineConfigure/' + id, data, { headers: headers })
      .pipe(tap(_ => this.log(`line Configuration Setting Update successfully`)));
  }
  /**
   * subhash
   * @return {Observable<any>}
   * 14-7-2020
   */
  volumeUpdate(id,data): Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.post(this.server_url + 'market/volume/' + id, data, { headers: headers })
      .pipe(tap(_ => this.log(`volume Update successfully`)));
  }

  lineModeUpdate(id,data): Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.post(this.server_url + 'market/line-modeChange/' + id, data, { headers: headers })
      .pipe(tap(_ => this.log(`Line Mode Change successfully`)));
  }

  bookmakerModeUpdate(id,data): Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.post(this.server_url + 'market/bookmaker-modeChange/' + id, data, { headers: headers })
      .pipe(tap(_ => this.log(`bookmaker Mode Change successfully`)));
  }

  bookmakerModeUpdateWebHook(id,data,headerData): Observable<any>{
    //console.log('data',data);
    let finalUrl = env.webHookPreFixUrl() + headerData.appUrl  + this.constantService.nonWebHook + 'market/bookmaker-modeChange/' + id;
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'apptoken': headerData.app_token});
    return this.http.post(finalUrl, data)
        .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }


  fancyModeUpdate(id,data): Observable<any>{
    //console.log('data',data);
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    return this.http.post(this.server_url + 'market/fancy-modeChange/' + id, data, { headers: headers })
      .pipe(tap(_ => this.log(`Line Mode Change successfully`)));
  }


  lineModeUpdateWebHook(id,data,headerData): Observable<any>{
    //console.log('data',data);
    let finalUrl = env.webHookPreFixUrl() + headerData.appUrl  + this.constantService.nonWebHook + 'market/line-modeChange/' + id;
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'apptoken': headerData.app_token});
    return this.http.post(finalUrl, data)
        .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }


  fancyModeUpdateWebHook(id,data,headerData): Observable<any>{
    //console.log('data',data);
    let finalUrl = env.webHookPreFixUrl() + headerData.appUrl  + this.constantService.nonWebHook + 'market/fancy-modeChange/' + id;
    console.log(finalUrl);
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'apptoken': headerData.app_token});
    return this.http.post(finalUrl, data)
        .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }

  getMatchListSerch(type):Observable<any>{
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token')});
    console.log(this.server_url + 'market/getMatch');
      return this.http.get(this.server_url + 'market/getMatch/' + type,{ headers: headers })
      .pipe(tap(_ => this.log(`get match successfully`)));
    }

    removeEvent(data): Observable<any> {
      return this.http.put(this.server_url + 'market/remove/event', data)
      .pipe(tap(_ => this.log(`get Event successfully`)));
    }

  log(message) {
    console.log(message);
  }


}
