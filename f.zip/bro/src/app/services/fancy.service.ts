import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {ConstantService} from '../globals/constant.service';
import {UtilityService} from '../globals/utilityService';


@Injectable({
  providedIn: 'root'
})
export class FancyService {
  server_url: any = env.server_url();

  constructor(private http: HttpClient, private utilityService: UtilityService,
    private constantService: ConstantService) { }


  /**
   *@author kc
   * @date 31-01-2020
   * @param filter
   * @returns {Observable<any>}
   * get all Market
   */
  getAllFancyApi(filter, tId): Observable<any> {
    let query = '?page=' + filter.page + '&limit=' + filter.limit;

    if (!isUndefined(filter.search) && filter.search !== null) {
      query += '&search=' + filter.search;
    }
    if (!isUndefined(filter.userId) && filter.userId !== null) {
      query += '&userId=' + filter.userId;
    }
    if(isUndefined(tId)){
      return this.http.get(this.server_url + 'market' + query)
        .pipe(tap(_ => this.log(`get fancy successfully`)));
    } else {

      return this.http.get(this.server_url + 'market/fancyId/' + tId + query)
        .pipe(tap(_ => this.log(`get fancy successfully`)));
    }
  }

    /**
       *@author Ravi Kadia
      * @date 09-01-2020
      * @param filter
      * @returns {Observable<any>}
      * get volume and variation
    **/

   getVolumeApi(): Observable<any> {
    return this.http.get(this.server_url + 'fancy/get-volume')
      .pipe(tap(_ => this.log(`get volume`)));
  }

  addFancyRate(data): Observable<any> {
    return this.http.post(this.server_url + 'fancy/add-fancy-rate' , data)
      .pipe(tap(_ => this.log(`fancy rate`)));
  }

  getLatestRate(id): Observable<any> {
    return this.http.get(this.server_url + 'fancy/get-latest-rate/' + id)
      .pipe(tap(_ => this.log(`get latest rate`)));
  }

  getMarketById(id): Observable<any>{
    return this.http.get(this.server_url + 'fancy/' + id)
      .pipe(tap(_ => this.log(`get volume`)));
  }

  updateFancyStatus(data): Observable<any> {
    return this.http.post(this.server_url + 'fancy/update-fancy-status' , data)
      .pipe(tap(_ => this.log(`fancy status update`)));
  }


  fancySettled(data,headerData): Observable<any> {
    // let finalUrl = env.webHookPreFixUrl()  + this.constantService.nonWebHook + 'fancy/fancy-settled';

    let finalUrl = env.webHookPreFixUrl() + headerData.appUrl  + this.constantService.nonWebHook + 'fancy/fancy-settled';
    console.log(finalUrl);
    let headers = new HttpHeaders({'Authorization' : localStorage.getItem('token'), 'apptoken': headerData.appToken});
    return this.http.post(finalUrl, data,{headers : headers})
        .pipe(tap(_ => this.log(`handshake is successfully match`)));
  }

  fancySettledOffice(data): Observable<any> {
    return this.http.post(this.server_url + 'fancy/fancySettle' , data)
    .pipe(tap(_ => this.log(`fancy status update`)));
  }

  lineSettledOffice(data): Observable<any> {
    return this.http.post(this.server_url + 'fancy/lineSettle' , data)
    .pipe(tap(_ => this.log(`fancy status update`)));
  }

  /**
   *@author TR
   * @date 08-06-2020
   * @param filter
   * @returns {Observable<any>}
   * Update FancyConfigSetting
   **/

  updateFancyConfgSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'fancy/update-fancy-setting/' + data._id , data)
      .pipe(tap(_ => this.log(`fancy config Setting update`)));
  }

  /**
   *@author TR
   * @date 09-06-2020
   * @param filter
   * @returns {Observable<any>}
   * Update FancySetting
   **/

  updateFancySetting(data): Observable<any> {
    return this.http.put(this.server_url + 'fancy/update-fancy-setting/' + data._id , data)
      .pipe(tap(_ => this.log(`fancy config Setting update`)));
  }

  /**
   *@author subhash
   * @date 08-08-2020
   * @param filter
   * @returns {Observable<any>}
   * Update FancycodeMeter
   **/

  fancycodeMeter(data): Observable<any> {
    return this.http.post(this.server_url + 'fancy/update-fancy-codeMeter', data)
      .pipe(tap(_ => this.log(`fancy config Setting update`)));
  }

  log(message) {
    console.log(message);
  }


}
