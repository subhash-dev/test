import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {ConstantService} from '../globals/constant.service';
import { UtilityService } from '../globals/utilityService';
var aes256 = require('aes256');
@Injectable({
  providedIn: 'root'
})
export class WhiteLabelWelcomeMassageService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();
  constructor(private http: HttpClient,
              private constantService: ConstantService,
              private utilityService: UtilityService
              ) { }


  addWelcomeMassage(massage): Observable<any> {
      return this.http.post(this.server_url + 'white-lable-welcome-massage' , {massage:massage})
          .pipe(tap(_ => this.log(`add white lable welcome massage successfully`)));
  }

  addWelcomeMassageWhiteLable(data , whtLbl): Observable<any> {
    console.log(data.massage)
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    console.log("webHookUrl",webHookUrl);
    return this.http.post(webHookUrl + 'white-lable-welcome-massage', {massage:data.massage})
        .pipe(tap(_ => this.log(`add white lable welcome massage successfully`)));
  }

  welcomeMassage(): Observable<any> {
    return this.http.get(this.server_url + 'white-lable-welcome-massage')
      .pipe(tap(_ => this.log(`White Lable Welcome Massage`)));
  }




  log(message) {
    console.log(message);
  }


}

function returnLocalStorageData(pwd){

  let data =  localStorage.getItem(pwd);
  let key = 'D258K9e3xeaHo4kiFgB76OlcAAMYqC6n';
  if(data){
    let decrypt = aes256.decrypt(key, data);
    return decrypt;
  }else {
    return false
  }

}
