import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {UtilityService} from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class GameSettingService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();
  constructor(private http: HttpClient, private utilityService: UtilityService
              ) { }


    /**
     *@author kc
     * @date 11-02-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Game Setting
     */
    getAllGameSetting(filter): Observable<any> {
        let query = '?page=' + filter.page +   '&limit=' + filter.limit;

        if (!isUndefined(filter.search) && filter.search !== null) {
            query += '&search=' + filter.search;
        }

        return this.http.get(this.server_url + 'gameSetting' + query)
            .pipe(tap(_ => this.log(`get gameSetting successfully`)));
    }

    /**
     *@author TR
     * @date 08-01-2021
     * @param filter
     * @returns {Observable<any>}
     * get all casino Setting
     */
    getAllCasinoSetting(filter): Observable<any> {
        let query = '?page=' + filter.page +   '&limit=' + filter.limit;

        if (!isUndefined(filter.search) && filter.search !== null) {
            query += '&search=' + filter.search;
        }

        return this.http.get(this.server_url + 'gameSetting/casino' + query)
            .pipe(tap(_ => this.log(`get gameSetting successfully`)));
    }

    /**
     *@author kc
     * @date 11-02-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Game Setting
     */
    getAllCupSetting(filter): Observable<any> {
        let query = '?page=' + filter.page +   '&limit=' + filter.limit;

        if (!isUndefined(filter.search) && filter.search !== null) {
            query += '&search=' + filter.search;
        }

        return this.http.get(this.server_url + 'gameSetting/cup' + query)
            .pipe(tap(_ => this.log(`get cupSetting successfully`)));
    }

    /**
     *@author kc
     * @date 11-02-2020
     * @param filter
     * @returns {Observable<any>}
     * add game setting
     */
    addNewGameSetting(data): Observable<any> {
        return this.http.post(this.server_url + 'gameSetting' , data)
            .pipe(tap(_ => this.log(`add gameSetting successfully`)));
    }

    /**
     *@author kc
     * @date 11-02-2020
     * @param filter
     * @returns {Observable<any>}
     * add game setting
     */
    addNewCupSetting(data): Observable<any> {
        return this.http.post(this.server_url + 'gameSetting/cup' , data)
            .pipe(tap(_ => this.log(`add cupSetting successfully`)));
    }

  /**
   *@author kc
   * @date 11-02-2020
   * @param filter
   * @returns {Observable<any>}
   * add game setting
   */
  addNewGameSettingWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'gameSetting' , data , {headers : headers})
      .pipe(tap(_ => this.log(`add gameSetting successfully`)));
  }
  /**
   *@author kc
   * @date 11-02-2020
   * @param filter
   * @returns {Observable<any>}
   * add game setting
   */
  addNewCupSettingWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'gameSetting/cup' , data , {headers : headers})
      .pipe(tap(_ => this.log(`add cupSetting successfully`)));
  }

  /**
   *@author TR
   * @date 10-04-2020
   * @param filter
   * @returns {Observable<any>}
   * add game setting
   */
  addUserSettingWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'userglobalsetting' , data , {headers : headers})
      .pipe(tap(_ => this.log(`add User setting Whitelable successfully`)));
  }



    /**
     *@author kc
     * @date 11-02-2020
     * @param id
     * @returns {Observable<any>}
     * get gameSetting by id
     */
    getGameSettingById(id): Observable<any> {
        return this.http.get(this.server_url+ 'gameSetting' + '/' + id)
            .pipe(tap(_ => this.log(`get gameSetting  successfully`)));
    }

  /**
   *@author kc
   * @date 11-02-2020
   * @param id
   * @returns {Observable<any>}
   * get gameSetting by id
   */
  getGameSettingBySportId(id): Observable<any> {
    return this.http.get(this.server_url+ 'gameSetting' + '/sportId/' + id)
      .pipe(tap(_ => this.log(`get gameSetting  successfully`)));
  }

  /**
   *@author kc
   * @date 11-02-2020
   * @param id
   * @returns {Observable<any>}
   * get gameSetting by id
   */
  getCupSettingBySportId(id): Observable<any> {
    return this.http.get(this.server_url+ 'gameSetting/cup' + '/sportId/' + id)
      .pipe(tap(_ => this.log(`get gameSetting  successfully`)));
  }



    /***
     * @author kc
     * @date 11-02-2020
     * @param data
     * @returns {Observable<any>}
     * update gameSetting
     */
    updateGameSetting(data): Observable<any> {
        return this.http.put(this.server_url + 'gameSetting/' + data._id,data)
            .pipe(tap(_ => this.log(`update gameSetting  successfully`)));
    }

    /***
     * @author kc
     * @date 11-02-2020
     * @param data
     * @returns {Observable<any>}
     * update casinoSetting
     */
    updateCasinoSetting(data): Observable<any> {
        return this.http.put(this.server_url + 'gameSetting/casino/' + data._id,data)
            .pipe(tap(_ => this.log(`update casinoSetting  successfully`)));
    }

    /***
     * @author kc
     * @date 11-02-2020
     * @param data
     * @returns {Observable<any>}
     * update gameSetting
     */
    updateCupSetting(data): Observable<any> {
        return this.http.put(this.server_url + 'gameSetting/cup/' + data._id,data)
            .pipe(tap(_ => this.log(`update cupSetting  successfully`)));
    }



    /***
     * @author RT
     * @date 09-04-2020
     * @param data
     * @returns {Observable<any>}
     * update whitelable gameSetting
     */
    updateGameSettingWhtLbl(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
      let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
      return this.http.put(webHookUrl + 'gameSetting/updateGameSetting',data , {headers : headers})
            .pipe(tap(_ => this.log(`update gameSetting  successfully`)));
    }


  /**
   *@author kc
   * @date 12-02-2020
   * @param filter
   * @returns {Observable<any>}
   * get all fancy Setting
   */
  getAllFancySetting(): Observable<any> {
    let query = '?page=1&limit=-1';

    return this.http.get(this.server_url + 'fancySetting' + query)
      .pipe(tap(_ => this.log(`get fancySetting successfully`)));
  }
  /***
   * @author kc
   * @date 20-02-2020
   * @param data
   * @returns {Observable<any>}
   * add userSetting
   */
  addFancySetting(data): Observable<any> {
    return this.http.post(this.server_url + 'fancySetting', data)
      .pipe(tap(_ => this.log(`add fancySetting  successfully`)));
  }


  /**
   *@author TR
   * @date 10-04-2020
   * @param filter
   * @returns {Observable<any>}
   * add game setting
   */
  addFancySettingWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'webHook/fancySettingAdd' , data , {headers : headers})
      .pipe(tap(_ => this.log(`add User setting Whitelable successfully`)));
  }


  /***
   * @author kc
   * @date 12-02-2020
   * @param data
   * @returns {Observable<any>}
   * update fancySetting
   */
  updateFancySetting(data): Observable<any> {
    return this.http.put(this.server_url + 'fancySetting/' + data._id,data)
      .pipe(tap(_ => this.log(`update fancySetting  successfully`)));
  }

  /***
   * @author kc
   * @date 12-02-2020
   * @param data
   * @returns {Observable<any>}
   * update fancySetting
   */
  updateFancySettingWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updateFancy',data , {headers : headers})
      .pipe(tap(_ => this.log(`update fancySetting  successfully`)));
  }

  /**
   *@author kc
   * @date 12-02-2020
   * @param filter
   * @returns {Observable<any>}
   * get all fancy Setting
   */
  getAllBookmakerSetting(): Observable<any> {
    let query = '?page=1&limit=-1';

    return this.http.get(this.server_url + 'bookmakerSetting' + query)
      .pipe(tap(_ => this.log(`get bookmakerSetting successfully`)));
  }

  /***
   * @author kc
   * @date 20-02-2020
   * @param data
   * @returns {Observable<any>}
   * add userSetting
   */
  addBookMakerSetting(data): Observable<any> {
    return this.http.post(this.server_url + 'bookmakerSetting', data)
      .pipe(tap(_ => this.log(`add bookmakerSetting  successfully`)));
  }

  /**
   *@author TR
   * @date 10-04-2020
   * @param filter
   * @returns {Observable<any>}
   * add game setting
   */
  addBookmakerSettingWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'webHook/bookmakerSettingAdd' , data , {headers : headers})
      .pipe(tap(_ => this.log(`add User setting Whitelable successfully`)));
  }




  /***
   * @author kc
   * @date 12-02-2020
   * @param data
   * @returns {Observable<any>}
   * update bookmakerSetting
   */
  updateBookmakerSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'bookmakerSetting/' + data._id,data)
      .pipe(tap(_ => this.log(`update bookmakerSetting  successfully`)));
  }

  /***
   * @author TR
   * @date 10-04-2020
   * @param data
   * @returns {Observable<any>}
   * update white lable bookmakerSetting
   */
  updateBookmakerSettingWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updateBookmaker',data , {headers : headers})
      .pipe(tap(_ => this.log(`update bookmakerSetting  successfully`)));
  }

  /**
   *@author kc
   * @date 14-02-2020
   * @param filter
   * @returns {Observable<any>}
   * get all user Setting
   */
  getAllUserSetting(): Observable<any> {
    let query = '?page=1&limit=-1';

    return this.http.get(this.server_url + 'userGlobalSetting' + query)
      .pipe(tap(_ => this.log(`get userGlobalSetting successfully`)));
  }

  /***
   * @author kc
   * @date 20-02-2020
   * @param data
   * @returns {Observable<any>}
   * add userSetting
   */
  addUserSetting(data): Observable<any> {
    return this.http.post(this.server_url + 'userGlobalSetting', data)
      .pipe(tap(_ => this.log(`add userGlobalSetting  successfully`)));
  }

  /***
   * @author TR
   * @date 10-04-2020
   * @param data
   * @returns {Observable<any>}
   * add userSetting
   */
  addWhtLblUserSetting(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'userGlobalSetting', data , {headers : headers})
      .pipe(tap(_ => this.log(`add userGlobalSetting  successfully`)));
  }

  /***
   * @author kc
   * @date 17-02-2020
   * @param data
   * @returns {Observable<any>}
   * update userSetting
   */
  updateUserSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'userGlobalSetting/' + data._id,data)
      .pipe(tap(_ => this.log(`update userGlobalSetting  successfully`)));
  }

  /***
   * @author TR
   * @date 10-04-2020
   * @param data
   * @returns {Observable<any>}
   * update White Lable userSetting
   */
  updateWhtLblUserSetting(data): Observable<any> {
    return this.http.put(this.adminServer_url + 'userGlobalSetting/updateUserSetting',data)
      .pipe(tap(_ => this.log(`update userGlobalSetting  successfully`)));
  }


  /***
   * @author kc
   * @date 17-02-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with global setting
   */
   updateAllMarketSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'gameSetting/updateAllMarket', data)
      .pipe(tap(_ => this.log(`update gameSetting  successfully`)));
  }

  /***
   * @author kc
   * @date 17-02-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with global setting
   */
  updateAllCupSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'gameSetting/updateAllMarket/cup', data)
      .pipe(tap(_ => this.log(`update cupSetting  successfully`)));
  }

  /***
   * @author TR
   * @date 14-04-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with global setting
   */
  updateGameSettingToAllWhtLbl(data, whtLbl): Observable<any> {

    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'apptoken': whtLbl.appToken});
    return this.http.put(webHookUrl + 'webHook/updateAllGameSetting/' + data._id,data, {headers : headers})
      .pipe(tap(_ => this.log(`update gameSetting  successfully`)));
  }

  /***
   * @author TR
   * @date 14-04-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with global setting
   */
  updateCupSettingToAllWhtLbl(data, whtLbl): Observable<any> {

    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'apptoken': whtLbl.appToken});
    return this.http.put(webHookUrl + 'webHook/updateAllGameSetting/cup/' + data._id,data, {headers : headers})
      .pipe(tap(_ => this.log(`update cupSetting  successfully`)));
  }

  /***
   * @author kc
   * @date 17-02-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with fancy setting
   */
  updateAllFancySetting(data): Observable<any> {
    return this.http.put(this.server_url + 'fancySetting/updateAllFancySetting', data)
      .pipe(tap(_ => this.log(`update fancySetting  successfully`)));
  }


  /***
   * @author kc
   * @date 24-04-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with fancy setting for whitelable
   */
  updateFancySettingToAllWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updateAllFancySetting/' + data._id, data , {headers : headers})
      .pipe(tap(_ => this.log(`update fancySetting  successfully`)));
  }

  /***
   * @author kc
   * @date 17-02-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with bookmaker setting
   */
  updateAllBookMakerSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'bookmakerSetting/updateAllBookmakerSetting', data)
      .pipe(tap(_ => this.log(`update fancySetting  successfully`)));
  }





  /***
   * @author RT
   * @date 14-04-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with bookmaker setting for Wht Lable
   */
  updateBookmakerSettingToAllWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updateAllBookmakerSetting/' + data._id, data , {headers : headers})
      .pipe(tap(_ => this.log(`update fancySetting  successfully`)));
  }



  /***
   * @author TR
   * @date 08-06-2020
   * @param data
   * @returns {Observable<any>}
   * Get to all fancy Configure setting
   */
  getAllfancyConfgSetting(): Observable<any> {
    return this.http.get(this.server_url + 'fancyConfigure/get')
      .pipe(tap(_ => this.log(`Get fancyConfigSetting  successfully`)));
  }

  /***
   * @author TR
   * @date 20-07-2020
   * @param data
   * @returns {Observable<any>}
   * Get to all line Configure setting
   */
  getAllLineConfgSetting(): Observable<any> {
    return this.http.get(this.server_url + 'lineConfigure/get')
      .pipe(tap(_ => this.log(`Get lineConfigSetting  successfully`)));
  }



  /***
   * @author TR
   * @date 08-06-2020
   * @param data
   * @returns {Observable<any>}
   * Update fancy Configure setting
   */
  updatefancyConfgSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'fancyConfigure/update/' + data._id, data)
      .pipe(tap(_ => this.log(`Update fancyConfigSetting  successfully`)));
  }

  /***
   * @author TR
   * @date 20-07-2020
   * @param data
   * @returns {Observable<any>}
   * Update line Configure setting
   */
  updatelineConfgSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'lineConfigure/update/' + data._id, data)
      .pipe(tap(_ => this.log(`Update lineConfigSetting  successfully`)));
  }


  /***
   * @author TR
   * @date 08-07-2020
   * @param data
   * @returns {Observable<any>}
   * Get to all Line setting
   */
  getAllLineSetting(): Observable<any> {
    return this.http.get(this.server_url + 'lineMarketSetting')
      .pipe(tap(_ => this.log(`Get lineMarket  successfully`)));
  }

  /***
   * @author TR
   * @date 08-07-2020
   * @param data
   * @returns {Observable<any>}
   * add lineMarketSetting
   */
  addLineMarketSetting(data): Observable<any> {
    return this.http.post(this.server_url + 'lineMarketSetting', data)
      .pipe(tap(_ => this.log(`add lineMarketSetting  successfully`)));
  }


  /**
   *@author TR
   * @date 08-07-2020
   * @param filter
   * @returns {Observable<any>}
   * add Line Market setting
   */
  addLineMarketSettingWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'lineMarketSetting' , data , {headers : headers})
      .pipe(tap(_ => this.log(`add User setting Whitelable successfully`)));
  }

  /***
   * @author TR
   * @date 08-07-2020
   * @param data
   * @returns {Observable<any>}
   * update lineMarketSetting
   */
  updateLineMarketSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'lineMarketSetting/' + data._id,data)
      .pipe(tap(_ => this.log(`update lineMarket setting  successfully`)));
  }

  /***
   * @author TR
   * @date 08-07-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with Line setting
   */
  updateAllLineSetting(data): Observable<any> {
    return this.http.put(this.server_url + 'lineMarketSetting/updateAllLineSetting', data)
      .pipe(tap(_ => this.log(`update lineSetting  successfully`)));
  }

  /***
   * @author RT
   * @date 08-07-2020
   * @param data
   * @returns {Observable<any>}
   * update to all market with Line setting for Wht Lable
   */
  updateLineSettingToAllWhtLbl(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'lineMarketSetting/updateAllLineSetting', data , {headers : headers})
      .pipe(tap(_ => this.log(`update lineSetting  successfully`)));
  }

  log(message) {
    console.log(message);
  }
}
