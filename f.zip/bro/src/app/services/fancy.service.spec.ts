import { TestBed } from '@angular/core/testing';

import { FancyService } from './fancy.service';

describe('FancyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FancyService = TestBed.get(FancyService);
    expect(service).toBeTruthy();
  });
});
