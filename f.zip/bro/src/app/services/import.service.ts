import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import * as env from '../globals/env';
import {UserService} from './user.service';
import {Router} from '@angular/router';
import {ConstantService} from '../globals/constant.service';
import {UtilityService} from '../globals/utilityService';


@Injectable({
    providedIn: 'root'
})
export class ImportService {
    import_url: any = env.import_url();
    production: any = env.production_for_import();
    server_url: any = env.server_url();
    adminServer_url: any = env.adminServer_url();
    webHookPreFixUrl: any = env.webHookPreFixUrl();
    private headers = new HttpHeaders(
        {
            'Access-Control-Allow-Origin': '*',
        }
    );

    constructor(private http: HttpClient,
                private userService: UserService,
                private utilityService: UtilityService,
                private router: Router,
                private constantService: ConstantService
                ) {
    }

    /**
     * @author kc
     * @date : 27-01-2019;
     * generate token
     */
    generateToken(): Observable<any> {

        let query = this.production ? this.import_url + '?market_id=1&method=generate_token' : this.import_url + '?market_id=1&method=generate_token&ip=development';
        return this.http.get(query)
            .pipe(tap(_ => this.log(`token generate successfully`)));
    }

    /**
     * @author kc
     * @date : 23-01-2019;
     * import step 1 api calling
     */
    importApiStep1(): Observable<any> {
      /*http://pam555.ml/?market_id=1&method=import_sport&ip=development*/
      let data = {
        id : this.utilityService.returnLocalStorageData('userId')
      };

      let query = this.production ? this.import_url + '?market_id=1&method=import_sport&ip=development' : this.import_url + '?market_id=1&method=import_sport&ip=development';
      //console.log(query);
      return this.http.get(query, { headers:this.headers})
        .pipe(tap(_ => this.log(`step 1 successfully`)));
    }

    /**
     * @author kc
     * @date : 24-01-2019
     * import step 2 api calling
     */
    importApiStep2(id): Observable<any> {

        let query = this.production ? this.import_url + ('?market_id=' + id + '&method=competitions') : (this.import_url + '?market_id=' + id + '&method=competitions&ip=development');
        return this.http.get(query)
            .pipe(tap(_ => this.log(`step 2 successfully`)));
    }


    /**
     * @author kc
     * @date : 24-01-2019
     * import step 3 api calling
     */
    importApiStep3(id): Observable<any> {

        let query = this.production ? this.import_url + ('?market_id=' + id + '&method=competitions_event') : (this.import_url + '?market_id=' + id + '&method=competitions_event&ip=development');
        return this.http.get(query)
            .pipe(tap(_ => this.log(`step 3successfully`)));
    }

    /**
     * @author kc
     * @date : 24-01-2019
     * import step 4 api calling
     */
    importApiStep4(id): Observable<any> {

        let query = this.production ? this.import_url + ('?market_id=' + id + '&method=competitions_event_matchodd') : (this.import_url + '?market_id=' + id + '&method=competitions_event_matchodd&ip=development');
        return this.http.get(query)
            .pipe(tap(_ => this.log(`step 3successfully`)));
    }

    /**
     * @author kc
     * @date : 24-01-2019
     * import step 4 api calling
     */
    importApiStep5(id): Observable<any> {
        let query = this.production ? this.import_url + ('?market_id=' + id + '&method=import_data') : (this.import_url + '?market_id=' + id + '&method=import_data&ip=development');
        return this.http.get(query)
            .pipe(tap(_ => this.log(`step 3successfully`)));
    }


    /**
     *@author kc
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add import external
     */
    addImport(data): Observable<any> {
        return this.http.post(this.server_url + 'import' , data)
            .pipe(tap(_ => this.log(`add import successfully`)));
    }

    /**
     *@author TR
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add import external for White Lable
     */
    addImportWhtLbl(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
     //let webHookUrl = env.webHookPreFixUrl()  + this.constantService.nonWebHook; //for local
      //console.log(webHookUrl);
      let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
      return this.http.post(webHookUrl + 'import' , data , {headers : headers})
            // .pipe(tap(_ => this.log(`add import successfully`)));
    }

    log(message) {
        console.log(message);
    }


}
