import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {UtilityService} from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class BinaryService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();

  constructor(private http: HttpClient, private utilityService: UtilityService
              ) { }


    /**
     *@author TR
     * @date 18-05-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Exchange
     */
    getAllExcahnge(filter): Observable<any> {
        return this.http.post(this.server_url + 'binary/getallexchange', filter)
            .pipe(tap(_ => this.log(`Get instrument successfully`)));
    }

    /**
     *@author TR
     * @date 18-05-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Exchange
     */
    getAllHistory(filter): Observable<any> {
        return this.http.post(this.adminServer_url + 'sharemarket/weeklysettlement/instrumenttransationHistory', filter)
            .pipe(tap(_ => this.log(`Get instrument successfully`)));
    }



    // /**
    //  *@author TR
    //  * @date 18-05-2020
    //  * @param filter
    //  * @returns {Observable<any>}
    //  * get all Exchange
    //  */
    // getAllDefault(filter): Observable<any> {
    //     return this.http.post(this.server_url + 'portfolio/list', filter)
    //         .pipe(tap(_ => this.log(`Get instrument successfully`)));
    // }



    /**
     *@author TR
     * @date 18-05-2020
     * @param filter
     * @returns {Observable<any>}
     * Import instrument
     */
    importInstrument(filter): Observable<any> {
        return this.http.post(this.server_url + 'binary/importInstrument' , filter)
            .pipe(tap(_ => this.log(`Import instrument successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Import instrument for WhiteLable
   */
  importInstrumentwht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'webHook/importInstrument' , data , {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }



    /**
     *@author TR
     * @date 18-05-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Instrument
     */
    getAllInstrument(filter): Observable<any> {
        return this.http.post(this.server_url + 'binary/getinstrument', filter)
            .pipe(tap(_ => this.log(`Get instrument successfully`)));
    }


    /**
     *@author TR
     * @date 16-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add new Exchange
     */
    addNewExchange(data): Observable<any> {
        return this.http.post(this.server_url + 'binary/createexchange' , data)
            .pipe(tap(_ => this.log(`Add exchange successfully`)));
    }



    /**
     *@author TR
     * @date 10-07-2020
     * @param filter
     * @returns {Observable<any>}
     * add new Exchange for WhiteLable
     */
    addNewExchangewht(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
      let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
      return this.http.post(webHookUrl + 'webHook/createexchange' , data , {headers : headers})
      // .pipe(tap(_ => this.log(`add sport successfully`)));
    }

    /**
     *@author TR
     * @date 16-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add new Holiday Day
     */
    addNewHoliday(data): Observable<any> {
        return this.http.post(this.server_url + 'binary/adddays' , data)
            .pipe(tap(_ => this.log(`Add Holiday successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * add new Holiday Day for WhiteLable
   */
  addNewHolidaywht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'webHook/adddays' , data , {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }



    /***
     * @author TR
     * @date 16-05-2020
     * @param data
     * @returns {Observable<any>}
     * update Exchange
     */
    updateExchange(data): Observable<any> {
        return this.http.put(this.server_url + 'binary/updateexchange/'+ data.exchangeName,data)
            .pipe(tap(_ => this.log(`Update exchange  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * update Exchange for WhiteLable
   */
  updateExchangewht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updateexchange/'+ data.exchangeName , data , {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

    /***
     * @author TR
     * @date 16-05-2020
     * @param data
     * @returns {Observable<any>}
     * update Brokerage
     */
    updateBrokerage(data): Observable<any> {
        return this.http.put(this.server_url + 'binary/updatebrokerage',data)
            .pipe(tap(_ => this.log(`Update brokerage  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * update Brokerage for WhiteLable
   */
  updateBrokeragewht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/defaultportfolio/updatebrokerage', data , {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

    /***
     * @author TR
     * @date 18-05-2020
     * @param data
     * @returns {Observable<any>}
     * Delete Exchange
     */
    deleteExchange(data): Observable<any> {
        return this.http.delete(this.server_url + 'binary/exchange/' + data._id)
            .pipe(tap(_ => this.log(`Delete Exchange  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * delete Exchange for WhiteLable
   */
  deleteExchangewht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.delete(webHookUrl + 'webHook/exchange/'+ data._id , {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

    /***
     * @author TR
     * @date 19-05-2020
     * @param data
     * @returns {Observable<any>}
     * Delete LotSize
     */
    deleteLotSize(data): Observable<any> {
        return this.http.delete(this.server_url + 'binary/lotsize/'+ data.exchangeName +'/' + data.name)
            .pipe(tap(_ => this.log(`Delete lotSize  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * delete Lot Size for WhiteLable
   */
  deleteLotSizewht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.delete(webHookUrl + 'webHook/lotsize/'+ data.exchangeName +'/' + data.name , {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }



    /***
     * @author TR
     * @date 20-05-2020
     * @param data
     * @returns {Observable<any>}
     * Update LotSize
     */
    updateLotSize(data): Observable<any> {
        return this.http.put(this.server_url + 'binary/updatelotsizesingle/' + data._id , data)
            .pipe(tap(_ => this.log(`Update lotSize  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update Lot Size for WhiteLable
   */
  updateLotSizewht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updatelotsizesingle/'+ data.name, data ,  {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }


    /***
     * @author TR
     * @date 22-05-2020
     * @param data
     * @returns {Observable<any>}
     * Update ScriptMaster
     */
    updateScriptMaster(data): Observable<any> {
        return this.http.put(this.server_url + 'binary/updatescript/' + data.instrumentToken , data)
            .pipe(tap(_ => this.log(`Update script master  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update Lot Size for WhiteLable
   */
  updateScriptMasterwht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updatescript/'+ data.instrumentToken, data ,  {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }



    /***
     * @author TR
     * @date 22-05-2020
     * @param data
     * @returns {Observable<any>}
     * Delete ScriptMaster
     */
    deleteScriptMaster(data): Observable<any> {
        return this.http.delete(this.server_url + 'binary/script/' + data._id)
            .pipe(tap(_ => this.log(`Update script master  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update Lot Size for WhiteLable
   */
  deleteScriptMasterwht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.delete(webHookUrl + 'webHook/script/'+ data._id,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

    /***
     * @author TR
     * @date 20-05-2020
     * @param data
     * @returns {Observable<any>}
     * Update All LotSize Multiple
     */
    updateAllLotSize(data): Observable<any> {
      if(isNaN(data.lotSize) || data.lotSize === 0) {
        delete data.lotSize
      }
      if(isNaN( data.tradeMargin) || data.tradeMargin === 0){
        delete data.tradeMargin
      }
      if(data.tradeMarginType === "") {
        delete data.tradeMarginType
      }
        return this.http.put(this.server_url + 'binary/updatelotsizeall', data)
            .pipe(tap(_ => this.log(`Update All lotSize  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update Lot Size for WhiteLable
   */
  updateAllLotSizewht(data , whtLbl): Observable<any> {
    if(isNaN(data.lotSize) || data.lotSize === 0) {
      delete data.lotSize
    }
    if(isNaN( data.tradeMargin) || data.tradeMargin === 0){
      delete data.tradeMargin
    }
    if(data.tradeMarginType === "") {
      delete data.tradeMarginType
    }
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updatelotsizeall',data ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

    /***
     * @author TR
     * @date 20-05-2020
     * @param data
     * @returns {Observable<any>}
     * Update All LotSize Multiple
     */
    updateAllBrokerage(data): Observable<any> {
      if(isNaN(data.brokerAgeAmount) || ((data.brokerAgeAmount === 0 || data.brokerAgeAmount === null))) {
        delete data.brokerAgeAmount
      }
      if(isUndefined(data.brokerAgeType) || data.brokerAgeType === "") {
        delete data.brokerAgeType
      }
        return this.http.put(this.server_url + 'binary/updatebrokerage', data)
            .pipe(tap(_ => this.log(`Update All lotSize  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update Brokerage for WhiteLable
   */
  updateAllBrokeragewht(data , whtLbl): Observable<any> {
    if(isNaN(data.brokerAgeAmount) || ((data.brokerAgeAmount === 0 || data.brokerAgeAmount === null))) {
      delete data.brokerAgeAmount
    }
    if(isUndefined(data.brokerAgeType) || data.brokerAgeType === "") {
      delete data.brokerAgeType
    }
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/defaultportfolio/updatebrokerage',data ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

 /***
     * @author TR
     * @date 22-05-2020
     * @param data
     * @returns {Observable<any>}
     * Update All ScriptMaster Multiple
     */
 updateAllScriptMaster(data): Observable<any> {

      if(data.tradeAttribute === "") {
        delete data.tradeAttribute
      }
      if(data.allowTrade === "") {
        delete data.allowTrade
      }
        return this.http.put(this.server_url + 'binary/updatescripts', data)
            .pipe(tap(_ => this.log(`Update All lotSize  successfully`)));
    }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update All Script Master for WhiteLable
   */
  updateAllScriptMasterwht(data , whtLbl): Observable<any> {
    if(data.tradeAttribute === "") {
      delete data.tradeAttribute
    }
    if(data.allowTrade === "") {
      delete data.allowTrade
    }
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updatescripts',data ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

  /***
   * @author TR
   * @date 20-05-2020
   * @param data
   * @returns {Observable<any>}
   * Update LotSize Multiple
   */
  updateLotSizeAll(data): Observable<any> {
    if(isNaN(data.lotSize) || data.lotSize === 0) {
      delete data.lotSize
    }
    if(isNaN( data.tradeMargin ) || data.tradeMargin === 0){
      delete data.tradeMargin
    }
    if(data.tradeMarginType === "") {
      delete data.tradeMarginType
    }
    return this.http.put(this.server_url + 'binary/updatelotsize', data)
      .pipe(tap(_ => this.log(`Update All lotSize  successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update LotSize All for WhiteLable
   */
  updateLotSizeAllwht(data , whtLbl): Observable<any> {
    if(isNaN(data.lotSize) || data.lotSize === 0) {
      delete data.lotSize
    }
    if(isNaN( data.tradeMargin ) || data.tradeMargin === 0){
      delete data.tradeMargin
    }
    if(data.tradeMarginType === "") {
      delete data.tradeMarginType
    }
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updatelotsize',data ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

  /***
   * @author TR
   * @date 26-05-2020
   * @param data
   * @returns {Observable<any>}
   * Update Qty Multiple
   */
  updateQtyAll(data): Observable<any> {
    if(isNaN( data.quantityMax) || data.quantityMax === 0){
      delete data.quantityMax
    }
    if(isNaN( data.quantityBreakup) || data.quantityBreakup === 0){
      delete data.quantityBreakup
    }
    if(isNaN( data.lotsizeMin) || data.lotsizeMin === 0){
      delete data.lotsizeMin
    }
    if(isNaN( data.lotsizeMax) || data.lotsizeMax === 0){
      delete data.lotsizeMax
    }
    if(isNaN( data.lotsizeBreakup) || data.lotsizeBreakup === 0){
      delete data.lotsizeBreakup
    }
    return this.http.put(this.server_url + 'binary/updateinstrumentqty', data)
      .pipe(tap(_ => this.log(`Update Multiple Qty  successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update LotSize All for WhiteLable
   */
  updateQtyAllwht(data , whtLbl): Observable<any> {
    if(isNaN( data.quantityMax) || data.quantityMax === 0){
      delete data.quantityMax
    }
    if(isNaN( data.quantityBreakup) || data.quantityBreakup === 0){
      delete data.quantityBreakup
    }
    if(isNaN( data.lotsizeMin) || data.lotsizeMin === 0){
      delete data.lotsizeMin
    }
    if(isNaN( data.lotsizeMax) || data.lotsizeMax === 0){
      delete data.lotsizeMax
    }
    if(isNaN( data.lotsizeBreakup) || data.lotsizeBreakup === 0){
      delete data.lotsizeBreakup
    }
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updateinstrumentqty',data ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }



  /***
   * @author TR
   * @date 26-05-2020
   * @param data
   * @returns {Observable<any>}
   * Update All LotSize Multiple
   */
  updateAllQty(data): Observable<any> {

    if(isNaN( data.quantityMax) || data.quantityMax === 0){
      delete data.quantityMax
    }
    if(isNaN( data.quantityBreakup) || data.quantityBreakup === 0){
      delete data.quantityBreakup
    }
    if(isNaN( data.lotsizeMin) || data.lotsizeMin === 0){
      delete data.lotsizeMin
    }
    if(isNaN( data.lotsizeMax) || data.lotsizeMax === 0){
      delete data.lotsizeMax
    }
    if(isNaN( data.lotsizeBreakup) || data.lotsizeBreakup === 0){
      delete data.lotsizeBreakup
    }

    return this.http.put(this.server_url + 'binary/updateinstrumentqtyall', data)
      .pipe(tap(_ => this.log(`Update All Qty  successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update updateAllQty for WhiteLable
   */
  updateAllQtywht(data , whtLbl): Observable<any> {
    if(isNaN( data.quantityMax) || data.quantityMax === 0){
      delete data.quantityMax
    }
    if(isNaN( data.quantityBreakup) || data.quantityBreakup === 0){
      delete data.quantityBreakup
    }
    if(isNaN( data.lotsizeMin) || data.lotsizeMin === 0){
      delete data.lotsizeMin
    }
    if(isNaN( data.lotsizeMax) || data.lotsizeMax === 0){
      delete data.lotsizeMax
    }
    if(isNaN( data.lotsizeBreakup) || data.lotsizeBreakup === 0){
      delete data.lotsizeBreakup
    }
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/updateinstrumentqtyall',data ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

  /***
   * @author TR
   * @date 27-05-2020
   * @param data
   * @returns {Observable<any>}
   * Delete portfolio
   */
  deletePortfolio(data): Observable<any> {
    return this.http.delete(this.server_url + 'portfolio/delete/' + data.instrumentId.instrumentToken)
      .pipe(tap(_ => this.log(`Delete portfolio  successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update updateAllQty for WhiteLable
   */
  deletePortfoliowht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.delete(webHookUrl + 'webHook/defaultportfolio/delete/'+ data.instrumentId.instrumentToken ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

  /***
   * @author TR
   * @date 27-05-2020
   * @param data
   * @returns {Observable<any>}
   * Delete all portfolio
   */
  deleteAllPortfolio(): Observable<any> {
    return this.http.delete(this.server_url + 'portfolio/deleteall')
      .pipe(tap(_ => this.log(`Delete all portfolio  successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update deleteAllPortfolio for WhiteLable
   */
  deleteAllPortfoliowht(whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.delete(webHookUrl + 'webHook/defaultportfolio/deleteall' ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

  /***
   * @author TR
   * @date 27-05-2020
   * @param data
   * @returns {Observable<any>}
   * Update portfolio displayOrder
   */
  updateDisplayOrder(data): Observable<any> {
    let item = {
      displayOrder: data.displayOrder
    }
    return this.http.put(this.server_url + 'portfolio/update/' + data.instrumentId.instrumentToken , item)
      .pipe(tap(_ => this.log(`Update portfolio  successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Update updateDisplayOrder for WhiteLable
   */
  updateDisplayOrderwht(data , whtLbl): Observable<any> {
    let item = {
      displayOrder: data.displayOrder
    }
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'webHook/defaultportfolio/update/'+ data.instrumentId.instrumentToken , item ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

  /**
   *@author TR
   * @date 26-05-2020
   * @param filter
   * @returns {Observable<any>}
   * add portfolio
   */
  addDefault(filter): Observable<any> {
    return this.http.post(this.server_url + 'portfolio/create' , filter)
      .pipe(tap(_ => this.log(`create portfolio successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * addDefault for WhiteLable
   */
  addDefaultwht(data , whtLbl): Observable<any> {

    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'webHook/defaultportfolio/create',data ,   {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

  /**
   *@author TR
   * @date 26-05-2020
   * @param filter
   * @returns {Observable<any>}
   * get all intrument for portfolio
   */
  getAllInstDefault(filter , type): Observable<any> {
    return this.http.post(this.server_url + 'binary/getallscript/'+ type, filter)
      .pipe(tap(_ => this.log(`Get instrument successfully`)));
  }



  /**
   *@author TR
   * @date 26-05-2020
   * @param filter
   * @returns {Observable<any>}
   * get all Holiday list
   */
  getAllHolidayList(item): Observable<any> {
    return this.http.get(this.server_url + 'binary/getdays/'+item)
      .pipe(tap(_ => this.log(`Get instrument successfully`)));
  }

  /**
   *@author TR
   * @date 16-06-2020
   * @param filter
   * @returns {Observable<any>}
   * update not settle Script
   */
  settleScript(filter): Observable<any> {
    return this.http.post(this.server_url + 'binary/updatesettleinstrument', filter)
      .pipe(tap(_ => this.log(`update settlement successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * settleScriptwht for WhiteLable
   */
  settleScriptwht(data , whtLbl): Observable<any> {

    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'webhook/updatesettleinstruments' , data , {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }

  /**
   *@author TR
   * @date 16-06-2020
   * @param filter
   * @returns {Observable<any>}
   * weekly update not settle Script
   */
  weeklySettleScript(filter): Observable<any> {

    return this.http.post(this.server_url + 'binary/updateweeklysettleinstrument', filter)
      .pipe(tap(_ => this.log(`update weekly settlement successfully`)));
  }

  /**
   *@author TR
   * @date 10-07-2020
   * @param filter
   * @returns {Observable<any>}
   * weekly update for WhiteLable
   */
  weeklySettleScriptwht(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'webhook/updateweeklysettleinstruments' , data , {headers : headers})
    // .pipe(tap(_ => this.log(`add sport successfully`)));
  }


  log(message) {
    console.log(message);
  }


}
