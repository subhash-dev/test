import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';

@Injectable({
  providedIn: 'root'
})
export class RoleService {
  server_url: any = env.server_url();

  constructor(private http: HttpClient,
              ) { }

    /**
     *@author kc
     * @date 21-01-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Role
     */
    getAllModules(): Observable<any> {
        return this.http.get(this.server_url + 'moduleAccess?page=1&limit=-1')
            .pipe(tap(_ => this.log(`get modules successfully`)));
    }
  /**
   *@author kc
   * @date 07-02-2020
   * @param filter
   * @returns {Observable<any>}
   * add module
   */
  createModule(data): Observable<any> {
    return this.http.post(this.server_url + 'moduleAccess', data)
      .pipe(tap(_ => this.log(`get modules successfully`)));
  }
  /**
   *@author kc
   * @date 21-01-2020
   * @param id
   * @returns {Observable<any>}
   * get role by id
   */
  getModuleById(id): Observable<any> {
    return this.http.get(this.server_url+ 'moduleAccess' + '/' + id)
      .pipe(tap(_ => this.log(`get role  successfully`)));
  }

  /**
   *@author kc
   * @date 07-02-2020
   * @param filter
   * @returns {Observable<any>}
   * add module
   */
  updateModule(data): Observable<any> {
    return this.http.put(this.server_url + 'moduleAccess/' + data._id, data)
      .pipe(tap(_ => this.log(`update modules successfully`)));
  }



  /**
     *@author kc
     * @date 21-01-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Role
     */
    getAllRoles(filter): Observable<any> {
        let query = '?page=' + filter.page +   '&limit=' + filter.limit;

        if (!isUndefined(filter.search) && filter.search !== null) {
            query += '&search=' + filter.search;
        }

        return this.http.get(this.server_url + 'role' + query)
            .pipe(tap(_ => this.log(`get role successfully`)));
    }

  /**
   *@author kc
   * @date 21-01-2020
   * @param filter
   * @returns {Observable<any>}
   * get all User Role Data
   */
  getAllUserData(filter): Observable<any> {
    let query = '?page=' + filter.page +   '&limit=' + filter.limit;

    if (!isUndefined(filter.search) && filter.search !== null) {
      query += '&search=' + filter.search;
    }

    return this.http.get(this.server_url + 'user' + query)
      .pipe(tap(_ => this.log(`get user successfully`)));
  }

    /**
     *@author kc
     * @date 21-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add new role
     */
    addNewRole(data): Observable<any> {
        return this.http.post(this.server_url + 'role' , data)
            .pipe(tap(_ => this.log(`add role successfully`)));
    }

    /**
     *@author kc
     * @date 21-01-2020
     * @param id
     * @returns {Observable<any>}
     * get role by id
     */
    getRoleById(id): Observable<any> {
        return this.http.get(this.server_url+ 'role' + '/' + id)
            .pipe(tap(_ => this.log(`get role  successfully`)));
    }


    /***
     * @author kc
     * @date 21-01-2020
     * @param data
     * @returns {Observable<any>}
     * update role
     */
    updateRole(data): Observable<any> {
        return this.http.put(this.server_url + 'role/' + data._id,data)
            .pipe(tap(_ => this.log(`update role  successfully`)));
    }



  log(message) {
    console.log(message);
  }


}
