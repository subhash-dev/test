import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import { ConstantService } from '../globals/constant.service';
import { UtilityService } from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class BookmakerService {
    server_url: any = env.server_url();
    adminServer_url: any = env.adminServer_url();
    webHookPreFixUrl: any = env.webHookPreFixUrl();

    constructor(private http: HttpClient,
                private utilityService: UtilityService,
                private constantService: ConstantService
              ) { }


  /**
   *@author kc
   * @date 31-01-2020
   * @param filter
   * @returns {Observable<any>}
   * get all BookMaker
   */
  getAllBookmaker(filter, tId): Observable<any> {
    let query = '?page=' + filter.page +   '&limit=' + filter.limit;

    if (!isUndefined(filter.search) && filter.search !== null) {
      query += '&search=' + filter.search;
    }
    if(isUndefined(tId)){
      return this.http.get(this.server_url + 'market' + query)
        .pipe(tap(_ => this.log(`get Bookmaker successfully`)));
    } else {
      return this.http.get(this.server_url + 'market/bookmaker/' + tId + query)
        .pipe(tap(_ => this.log(`get Bookmaker successfully`)));
    }
  }

  // /**
  //  *@author kc
  //  * @date 31-01-2020
  //  * @param filter
  //  * @returns {Observable<any>}
  //  * add new Market
  //  */
  // addNewFancy(data): Observable<any> {
  //   return this.http.post(this.server_url + 'market' , data)
  //     .pipe(tap(_ => this.log(`add fancy successfully`)));
  // }
  //
  // /**
  //  *@author kc
  //  * @date 31-01-2020
  //  * @param id
  //  * @returns {Observable<any>}
  //  * get Market by id
  //  */
  // getFancyById(id): Observable<any> {
  //   return this.http.get(this.server_url + 'market' + '/' + id)
  //     .pipe(tap(_ => this.log(`get fancy  successfully`)));
  // }
  //
  //
  // /***
  //  * @author kc
  //  * @date 31-01-2020
  //  * @param data
  //  * @returns {Observable<any>}
  //  * update Market
  //  */
  // updateFancy(data): Observable<any> {
  //   return this.http.put(this.server_url + 'market/' + data._id,data)
  //     .pipe(tap(_ => this.log(`update fancy  successfully`)));
  // }


  //  * @author subhash
  //  * @date 3-011-2020
  //  * @param data
  //  * @returns {Observable<any>}
  //  * get Market
  //  */
  getMarketById(marketId): Observable<any> {
    return this.http.get(this.server_url + 'market/bookmaker/' + marketId)
      .pipe(tap(_ => this.log(`update market bookmaker successfully`)));
  }

  getBookmakerRate(marketId): Observable<any> {
    return this.http.get(this.server_url + 'bookmaker/bookmaker-latest-rate/' + marketId)
      .pipe(tap(_ => this.log(`get bookmaker latest rate successfully`)));
  }


  getMarketStatusUpdate(data,marketId): Observable<any> {
    console.log(this.server_url + 'market/marketstatus/update/' + marketId,data);
    return this.http.put(this.server_url + 'market/marketstatus/update/' + marketId,data)
      .pipe(tap(_ => this.log(`update marketstatus successfully`)));
  }

  updateWhtLblMarketStatus(data, whtLbl): Observable<any> {
    let headers = new HttpHeaders({ 'Authorization': this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken });
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'market/marketstatus/update/' + data.marketId, data, { headers: headers })
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }

  storeRateData(data): Observable<any> {
    console.log(this.server_url + 'bookmaker/add-bookmaker-rate',data);
    return this.http.post(this.server_url + 'bookmaker/add-bookmaker-rate',data)
      .pipe(tap(_ => this.log(`update Market  successfully`)));
  }

  log(message) {
    console.log(message);
  }


}
