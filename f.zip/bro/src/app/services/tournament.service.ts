import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {UtilityService} from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class TournamentService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();

  constructor(private http: HttpClient,private utilityService: UtilityService
              ) { }


    /**
     *@author kc
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Sport
     */
    getAllTournament(filter, sId): Observable<any> {
        let query = '?page=' + filter.page +   '&limit=' + filter.limit;

        if (!isUndefined(filter.search) && filter.search !== null) {
            query += '&search=' + filter.search;
        }
        if(isUndefined(sId)){
            return this.http.get(this.server_url + 'tournament' + query)
                .pipe(tap(_ => this.log(`get tournament successfully`)));
        } else {
        return this.http.get(this.server_url + 'tournament/'+ sId  + query)
            .pipe(tap(_ => this.log(`get tournament successfully`)));
        }
    }

    /**
     *@author kc
     * @date 28-01-2020
     * @param filter
     * @returns {Observable<any>}
     * add new role
     */
    addNewTournament(data): Observable<any> {
        return this.http.post(this.server_url + 'tournament' , data)
            .pipe(tap(_ => this.log(`add tournament successfully`)));
    }


    /**
     *@author kc
     * @date 25-02-2020
     * @param filter
     * @returns {Observable<any>}
     * add Tournament for white lable
     */
    addNewWhtTournament(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
      let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
        return this.http.post(webHookUrl + 'tournament' , data , {headers : headers})
            // .pipe(tap(_ => this.log(`add tournament successfully`)));
    }

    /**
     *@author kc
     * @date 28-01-2020
     * @param id
     * @returns {Observable<any>}
     * get role by id
     */
    getTournamentById(id): Observable<any> {
        return this.http.get(this.server_url+ 'tournament' + '/' + id)
            .pipe(tap(_ => this.log(`get tournament  successfully`)));
    }


    /***
     * @author kc
     * @date 28-01-2020
     * @param data
     * @returns {Observable<any>}
     * update role
     */
    updateTournament(data): Observable<any> {
        return this.http.put(this.server_url + 'tournament/' + data._id,data)
            .pipe(tap(_ => this.log(`update tournament  successfully`)));
    }

    /***
     * @author TR
     * @date 28-01-2020
     * @param data
     * @returns {Observable<any>}
     * update Display order
     */
    updateTournamentDisplay(data): Observable<any> {
        return this.http.put(this.server_url + 'tournament/displayOrder/' + data._id,data)
            .pipe(tap(_ => this.log(`update tournament  successfully`)));
    }

  /***
   * @author kc
   * @date 28-01-2020
   * @param data
   * @returns {Observable<any>}
   * update role
   */
  updateWhtLblTournament(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.put(webHookUrl + 'tournament/' + data._id,data , {headers : headers})
      .pipe(tap(_ => this.log(`update tournament  successfully`)));
  }


  log(message) {
    console.log(message);
  }


}
