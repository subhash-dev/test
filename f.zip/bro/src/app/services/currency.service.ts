import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {UtilityService} from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class CurrencyService {
  server_url: any = env.server_url();
  adminServer_url: any = env.adminServer_url();
  webHookPreFixUrl: any = env.webHookPreFixUrl();

  constructor(private http: HttpClient, private utilityService: UtilityService
              ) { }


  /**
   * @author TR
   * @date : 05-06-2020
   * Get All Currency
   */
    getAllCurrency(): Observable<any> {
        return this.http.get(this.server_url + 'currency')
            .pipe(tap(_ => this.log(`get currency successfully`)));
    }

  /**
   * @author TR
   * @date : 05-06-2020
   * Add new Currency
   */
    addNewCurrency(data): Observable<any> {
        return this.http.post(this.server_url + 'currency' , data)
            .pipe(tap(_ => this.log(`add currency successfully`)));
    }

  /**
   * @author TR
   * @date : 05-06-2020
   * Add currency for All whitelable and all user
   */
    addNewCurrencywht(data , whtLbl): Observable<any> {
      let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';
    return this.http.post(webHookUrl + 'currency' , data , {headers : headers})
            // .pipe(tap(_ => this.log(`add sport successfully`)));
    }

  /**
   * @author TR
   * @date : 05-06-2020
   * update currency for All whitelable and all user
   */
  updateWhtLblCurrency(data , whtLbl): Observable<any> {
    let headers = new HttpHeaders({'Authorization' : this.utilityService.returnLocalStorageData('token'), 'appToken': whtLbl.appToken});
    let webHookUrl = (this.webHookPreFixUrl === 'https://server.') ? this.webHookPreFixUrl + whtLbl.appUrl + '/api/v1/' : this.webHookPreFixUrl + '/api/v1/';

    return this.http.put(webHookUrl + 'currency/updateAllUser',data , {headers : headers})
      .pipe(tap(_ => this.log(`Update currency  successfully`)));
  }


  /**
   * @author TR
   * @date : 05-06-2020
   * Update currency
   */
    updateCurrency(data): Observable<any> {
        return this.http.put(this.server_url + 'currency/' + data.userId._id,data)
            .pipe(tap(_ => this.log(`update currency  successfully`)));
    }



  log(message) {
    console.log(message);
  }


}
