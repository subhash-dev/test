import {BrowserModule} from '@angular/platform-browser';
import {NgModule, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {CommonModule} from '@angular/common';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {LoginComponent} from './login/login.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {SidebarComponent} from './sidebar/sidebar.component';
import {HeaderComponent} from './header/header.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DemoMaterialModule} from 'src/material-module';
import {NgxSpinnerModule} from 'ngx-spinner';
import {FormsModule} from '@angular/forms';
import {UtilityService} from './globals/utilityService';
import {SocketService} from './globals/socketService';
import { SocketServiceRedis } from './globals/socketServiceRedis';
import {ImportModule} from './import/import.module';
import {FancyModule} from './fancy/fancy.module';
import {UsersModule} from './users/users.module';
import {EventModule} from './event/event.module';
import {BookmakerModule} from './bookmaker/bookmaker.module';
import {RoleModule} from './role/role.module';
import {OpenGameModule} from './open-game/open-game.module';
import {ReopenGameModule} from './reopen-game/reopen-game.module';
import {CommentaryModule} from './commentary/commentary.module';
import {EventmasterModule} from './eventmaster/eventmaster.module';
import {CommonService} from './services/common.service';
import {ToasterModule} from 'angular2-toaster';
import {AuthGuard} from './auth-gaurd/auth-guard.service';
import {RoleGuard} from './auth-gaurd/role-guard.service';
import {DefaultRequestOptions} from './auth-gaurd/default-request-options.provider';
import {UserService} from './services/user.service';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import {GlobalSettingModule} from './global-setting/global-setting.module';
import {commonDerectivenModule} from './auth-gaurd/commonDerective.module';
import { DataTablesModule } from 'angular-datatables';
import {BbMarketModule} from "./bb-market/bb-market.module";
import { GameBlockComponent } from './game-block/game-block.component';
import { CurrancySettingComponent } from './currancy-setting/currancy-setting.component';
import { ReportsModule } from './reports/reports.module';
import { CancelGameModule } from './cancel-game/cancel-game.module';
import { LineModule } from './line/line.module';
import { ApisettingModule } from './apisetting/apisetting.module';
import { RestrictionComponent } from './restriction/restriction.component';
import {AngularEditorModule} from '@kolkov/angular-editor';
import { ModalModule } from "ngx-bootstrap";
import { LiveTvComponent } from './live-tv/live-tv.component';
import { UserIdleModule } from 'angular-user-idle';
import { WhitelabelWelcomeMassageModule } from './whitelabel-welcome-massage/whitelabel-welcome-massage.module';
import { ReactionComponent } from './reaction/reaction.component';
import { RemoveEventComponent } from './remove-event/remove-event.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    SidebarComponent,
    HeaderComponent,
    AccessDeniedComponent,
    GameBlockComponent,
    CurrancySettingComponent,
    RestrictionComponent,
    LiveTvComponent,
    ReactionComponent,
    RemoveEventComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    NgxSpinnerModule,
    FormsModule,
    HttpClientModule,
    ImportModule,
    FancyModule,
    UsersModule,
    CommonModule,
    EventModule,
    BookmakerModule,
    RoleModule,
    OpenGameModule,
    ReopenGameModule,
    CommentaryModule,
    EventmasterModule,
    ToasterModule.forRoot(),
    ModalModule.forRoot(),
    GlobalSettingModule,
    commonDerectivenModule,
    DataTablesModule,
    BbMarketModule,
    ReportsModule,
    CancelGameModule,
    LineModule,
    ApisettingModule,
    AngularEditorModule,
    WhitelabelWelcomeMassageModule,
    UserIdleModule.forRoot({idle: 10000, timeout: 10, ping: 10})
    ],
  providers: [
    UtilityService,
    UserService,
    CommonService,
    SocketService,
    SocketServiceRedis,
    AuthGuard,
    RoleGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: DefaultRequestOptions,
      multi: true
    },
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {
}
