import {Component, OnInit,ViewChild} from '@angular/core';
import * as env from '../globals/env';
import {UtilityService} from '../globals/utilityService';
import {UserService} from '../services/user.service';
import {Route, Router} from '@angular/router';
import {RoleService} from '../services/role.service';
import {NgxSpinnerService} from "ngx-spinner";
var aes256 = require('aes256');

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  @ViewChild("loginForm", { static: false }) loginForm;
  logo: any = env.PROJECT_LOGO_URL;
  loginResponse: any;
  loginObject = {
    userName: null,
    password: null,
    deviceId : "fromwebdeviceId123",
    fcmToken : "fromwebfcmtoken123",
    channel : "WEB"
  };
  showPassword = false;
  password_usr:any;

  constructor(private utilityService: UtilityService,
              private userService: UserService,
              private spinner: NgxSpinnerService,
              private router: Router) {

  }


  ngOnInit() {

  }

  /*
    Developer: Ravi
    Date: 09-jan-2020
    title: Login method from backend
    Use: This function is use login from backend
*/

  Login() {
    let key = env.constantKey();
    let token = this.password_usr;
    let user = this.loginObject.userName;
    var encrypted = aes256.encrypt(key, token);
    this.loginObject.password = encrypted;
      let hostName = this.utilityService.getHostname();
      this.userService.loginApi(this.loginObject).subscribe(resposne =>{
        resposne = this.utilityService.gsk(resposne.auth);
        resposne = JSON.parse(resposne);
        if(resposne.status === true){
          this.utilityService.popToast('success','Success', 1000 , 'Login successfully.');
           var descryptJson = aes256.decrypt(key, resposne.data);
         let resposne1 = JSON.parse(descryptJson);
          let userData = JSON.stringify(resposne1);
          let userId = resposne1.user_id;
          let token = resposne.token;
          let role = JSON.stringify(resposne1.role.role_name);
          let ip = resposne1.ipAddress;
          let dateTime = resposne1.dateTime;
          var userData1 = aes256.encrypt(key, userData);
          var userId1 = aes256.encrypt(key, userId);
          var role1 = aes256.encrypt(key, role);
          var ip1 = aes256.encrypt(key, ip);
          var dateTime1 = aes256.encrypt(key, dateTime);
          localStorage.setItem('userData', userData1);
          localStorage.setItem('userId', userId1);
          localStorage.setItem('token', token);
          localStorage.setItem('role', role1);
          localStorage.setItem('ip', ip1);
          localStorage.setItem('dateTime', dateTime1);
          sessionStorage.setItem('userId', userId1);


          this.router.navigate(['/dashboard']);
        }else{
          this.utilityService.popToast('error','Error', 1000 , resposne.message);
        }
      }, error =>{
        let input = document.getElementById('userName');
        input.focus();
        this.loginObject.password = '';
        this.loginForm.resetForm();
        this.utilityService.popToast('error','Error', 1000 , error.error.message);
      });
  }
  showPass(){
    this.showPassword = (this.showPassword === true) ?  false : true;
  }
}
