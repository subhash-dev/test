import { ChangeDetectorRef, Component, OnInit, ViewChild ,Inject,LOCALE_ID } from '@angular/core';
import { SportService } from '../../services/sport.service';
import { MatchService } from '../../services/match.service';
import { TournamentService } from '../../services/tournament.service';
import { MarketService } from '../../services/market.service';
import { UtilityService } from '../../globals/utilityService';
import { ToasterConfig } from 'angular2-toaster';
import { DataTableDirective } from 'angular-datatables';
import { DataTablesModule } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as moment from "moment";
import { HttpClient } from '@angular/common/http';
import { NgbTimepickerConfig, NgbTimeStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import * as env from '../../globals/env';
declare let $: any;
import { pickBy, identity } from 'lodash';
import { CommonService } from 'src/app/services/common.service';
import { formatDate } from '@angular/common';
import {ModalDirective} from 'ngx-bootstrap';
var aes256 = require('aes256');


class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
@Component({
  selector: 'app-market-pl',
  templateUrl: './market-pl.component.html',
  styleUrls: ['./market-pl.component.scss']
})
export class MarketPlComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  @ViewChild(DataTableDirective, { static: false })
  @ViewChild('reOpen', { static: false }) reOpen: ModalDirective;

  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();
  resData: any;
  allSport: any;
  allTournament: any;
  allMatch: any;
  sportSelect: any;
  tournamentSelect: any;
  marketType: any;
  matchDate:any;
  matchDateEnd:any;
  finalData: any;
  matchSelect: any;
  server_url: any = env.server_url();
  unSelectSport: any;
  unSelectTournament: any;
  unSelecTmatch: any;
  unSelecMarket: any;
  getMatchesId: any;
  whiteLabelAll: any;
  selectWhiteLabel:any;
  tranPlsByMtachid:any;
  marketTypeSelect:any;
  selectMtachDate:any;
  selectMtachDateStart:any;
  fancyId:any;
  marketId:any;
  lineId:any;
  jsonData:any = [];
  conformationPassword: any;
  endSubmit = false;
  marketDetail : any;

  constructor(private sportService: SportService,
    private matchService: MatchService,
    private tournamentService: TournamentService,
    private marketService: MarketService,
    private http: HttpClient,
    private router: Router,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private commonService :CommonService,
    private utilityService: UtilityService,
    config: NgbTimepickerConfig,
    @Inject(LOCALE_ID) private locale: string
  ) { }

  filter = {
    page: 1,
    limit: -1,
    search: null
  };
  tournamentFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  matchFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  sportList = [];
  sportId: any;

  tournamentsList = [];
  selectedTournamentsItems = [];
  TournamentsSettings = {
    singleSelection: true,
    text: 'Select tournament',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  tournamentId: any;
  matchList = [];
  selectedMatchItems = [];
  matchSettings = {
    singleSelection: true,
    text: 'Select match',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  matchID: any;
  marketFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  paramId: any;
  getAllMarkets: any;
  fancyConfigObject: any;
  minPickerDate: any;
  // time: any;
  time: NgbTimeStruct = { hour: 0, minute: 0, second: 0 };
  marketTypes: any;
  ngOnInit() {
    this.getAllSportList();
    this.marketSettel();
    this.setvalue();
    this.getAllWhiteLabel();

    this.minPickerDate = {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate()
    };
    let data = {
      matchDate:moment().format("YYYY-MM-DD"),
      matchDateEnd:moment().format("YYYY-MM-DD")
    };
    this.finalData = pickBy(data, undefined);
  }

  /**
   * @author TR
   * @date 23-06-2020
   * GetAll settled market list
   * @param data
   */
  dataTable: any;
  addMarketObject = {
    marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
    marketType: '',
    marketTypeId: null,
    marketStartTime: this.utilityService.returnLocalStorageData('dateTime'),
    totalMatched: 0,
    runners: null,
    displayName: null,
    isActive: true,
    message: null,
    match: null,
    tournament: null,
    sport: null,
  };

  getAllSportList() {
    this.sportService.getAllSport(this.filter).subscribe(getSportAll => {
        getSportAll = this.utilityService.gsk(getSportAll.auth);
        getSportAll =JSON.parse(getSportAll);
        this.allSport = getSportAll.data.docs.map(data => {
            return { id: data._id, itemName: data.name + '( ' + data.id + ' )', sportId: data.id };
        });
    });
  }

  onSportSelect(sportId) {
    this.unSelectTournament = '';
    this.tournamentId = '';
    this.unSelecTmatch = '';
    this.matchID = '';
    this.matchList = [];
    this.sportId = sportId;
    this.marketType = null;
    this.getAllTournament(sportId);
  }

  getAllTournament(sportId) {
    if(sportId){
        this.matchList = [];
        this.tournamentService.getAllTournament(this.tournamentFilter, sportId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.tournamentsList = response.data.docs.map(data => {
            return { id: data._id, itemName: data.name + '( ' + data.id + ' )', tournamentId: data.id };
        });
    }, error => {
      console.error('error in getting all sports', error);
    });
  }else {
    this.tournamentsList = [];
  }
  }


  onTornamentSelect(tournamentId) {
    this.tournamentId = tournamentId;
    this.unSelecTmatch = '';
    this.matchID = '';
    this.matchList = [];
    this.marketType = null;
    this.getMatches(tournamentId);
  }


  getMatches(tournamentId) {
    if(tournamentId){
        this.matchService.getAllMatch(this.matchFilter, tournamentId).subscribe(response => {
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
            this.matchList = response.data.docs.map(data => {
                return { id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
            });
        }, error => {
            console.error('get all Matches', error);
            this.matchList = [];
        });
    }else{
        this.matchList = [];
    }
  }

  onMatchesSelect(matchid) {
    this.marketType = null;
    this.matchID = matchid;
  }

  marketSettel() {
    this.spinner.show();
    this.rerender();
    const that = this;
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      // autoWidth: false,
      // scrollX: true,
      // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',

        emptyTable: 'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'market/report';
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { data: this.finalData ,marketStatusID:'MS180893'}),
            {}
          ).subscribe(resp => {
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData =JSON.parse(this.resData);
            this.resData = this.resData.data;
            this.spinner.hide();
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },

      // columns: [{ data: '' }, { data: 'createdAt' }, { data: 'sport' }, { data: 'tournament' }, { data: 'match' }, { data: 'marketType' }, { data: '' }, { data: '' }, { data: '' }],
      columnDefs: [{ orderable: false, targets: [0], searchable: true }]
    };
  }

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  onMarketSelect(marketTypes) {
    this.marketType = marketTypes;
  }
  selectMtachDateStarts(e) {
    this.matchDate = e.target.value;
  }
  selectMtachDateEnd(e) {
    this.matchDateEnd = e.target.value;
  }


  searchSettleData() {
    this.finalData = '';

    let data = {
      sportId: this.sportId,
      tournamentId: this.tournamentId,
      matchId: this.matchID,
      marketType: this.marketType,
      matchDate:this.matchDate,
      matchDateEnd:(this.matchDateEnd) ? this.matchDateEnd:moment().format("YYYY-MM-DD")
    };
    this.finalData = pickBy(data, undefined);
    this.marketSettel();
  }
  clear() {
    this.finalData = '';
    let data = {
      sportId: null,
      tournamentId: null,
      matchId: null,
      marketType: null,
      matchDate:moment().format("YYYY-MM-DD"),
      matchDateEnd:moment().format("YYYY-MM-DD")
    };
    this.finalData = pickBy(data, undefined);
    this.marketSettel();
    this.unSelectSport = '';
    this.unSelectTournament = '';
    this.unSelecTmatch = '';
    this.unSelecMarket = '';
    this.tournamentsList = [];
    this.matchList = [];
    this.selectMtachDate='';
    this.selectMtachDateStart='';

  }
  setvalue() {
    this.unSelectSport = '';
    this.unSelectTournament = '';
    this.unSelecTmatch = '';
    this.unSelecMarket = '';
  }

  // for viewbet
  getmatchId(obj) {
    this.tranPlsByMtachid = null;
    this.getMatchesId = null;
    this.selectWhiteLabel = null;
    this.fancyId = null;
    this.marketTypeSelect = null;
    this.marketId = null;
    this.lineId = null

    if(obj.marketType === 'Fancy') {
      this.getMatchesId = obj.match.id;
      this.selectWhiteLabel = '';
      this.fancyId = obj.fancyId;
      this.marketTypeSelect = obj.marketType;
    }
    if(obj.marketType === 'Match Odds') {
      this.getMatchesId = obj.match.id;
      this.marketId = obj.marketId;
      this.selectWhiteLabel = '';
      this.marketTypeSelect = obj.marketType;
    }
    if(obj.marketType === 'Line') {
      this.getMatchesId = obj.match.id;
      this.selectWhiteLabel = '';
      this.lineId = obj.lineId;
      this.marketTypeSelect = obj.marketType;
    }
    if(obj.marketType === 'Winner') {
      this.getMatchesId = obj.match.id;
      this.marketId = obj.marketId;
      this.selectWhiteLabel = '';
      this.marketTypeSelect = obj.marketType;
    }
    if(obj.marketType === 'Bookmaker') {
      this.getMatchesId = obj.match.id;
      this.marketId = obj.marketId;
      this.selectWhiteLabel = '';
      this.marketTypeSelect = obj.marketType;
    }
  }

  getAllWhiteLabel() {
    this.utilityService.getAllWhiteLabel().then(response => {
      this.whiteLabelAll = response.data.map(data => {
        return { data: data.appDomainName, appUrl: data.appUrl };
      });
    }).catch(error => {
      console.error("errro in get white label");
    });
  }

  whiteLabelSelection() {
    console.log(this.selectWhiteLabel);
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      for(let i = 0;i < x.length; i++){

        if(x[i].appUrl === this.selectWhiteLabel){
          let obj = {
            matchId: this.getMatchesId,
            status: 'open',
            fancyId: this.fancyId,
            marketId :this.marketId,
            lineId:this.lineId,
            marketTypeSelect:this.marketTypeSelect
          }
          this.marketService.getAllTransactionsBymatchID(obj, x[i]).subscribe(response => {
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
            this.tranPlsByMtachid = response.data;
              }, error => {
                this.spinner.hide();
                console.error('error', error);
              })
        }
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  modelclose() {
    let id = '';
    // this.getmatchId(id);
    this.selectWhiteLabel = '';
    this.whiteLabelSelection();
  }

  download() {
    this.jsonData =[];
    let count = 0;

    if(this.tranPlsByMtachid){

    let dataTemps = this.tranPlsByMtachid.map(transaction => {
      let dataArr ={
        USERNAME:transaction.userId.userName,
        MASTER:transaction.userId.parentId.userName,
        RUNNER:(transaction.gameType == 'market') ? transaction.team[0].runnerName:
                transaction.gameType == 'line'? transaction.gameDetail[0].lineName :
                transaction.gameType == 'fancy' ? transaction.gameDetail[0].fancyName + "/" + transaction.volume:
                transaction.gameType == 'Bookmaker' ? 'Bookmaker':'',
        BETTYPE:transaction.runner_type,
        RATE: transaction.odds,
        AMOUNT: transaction.rate,
        'P/L AMOUNT': (transaction.transction_result === 'Loss')?(transaction.lay < 0 )? transaction.lay  : transaction.back:
        transaction.transction_result === 'Win'?(transaction.lay > 0 )? transaction.lay : transaction.back:'-',
        'WIN/LOSS': (transaction.transction_result) ? transaction.transction_result : '-' ,
        MARKET: transaction.gameType,
        MATCH: transaction.gameDetail[0].match.name.substring(0, transaction.gameDetail[0].match.name.indexOf('(')),
        'PLACED TIME': formatDate(transaction.placeTime,'dd-MM-yyyy h:mm:ss',this.locale),
        'MATCHED TIME': formatDate(transaction.betTime,'dd-MM-yyyy h:mm:ss',this.locale),
        'IP': (transaction.ip) ? transaction.ip:''
      }
      count++;
      this.jsonData.push(dataArr);
    });
    let headerKey = ['USERNAME','MASTER','RUNNER','BETTYPE','RATE', 'AMOUNT','P/L AMOUNT','WIN/LOSS' ,'MARKET', 'MATCH','PLACED TIME' ,'MATCHED TIME','IP'];
    let csvName = 'Bet History Report';
    if(this.tranPlsByMtachid.length == count) {
      this.commonService.downloadFile(this.jsonData, headerKey,csvName);
    }
    }

  }
  //this model is used to open model of reopen market
  openReopenMarketModal(data){
    this.marketDetail = data;
    this.reOpen.show();
  }


  closeReopenModal(){
    this.conformationPassword = '';
    this.reOpen.hide();
  }

  reOpenSubmit(matchData){
    if(this.endSubmit) {
        return;
    }
    this.endSubmit = true;

    let key = env.constantKey();
        let token = this.conformationPassword;
        var encrypted = aes256.encrypt(key, token);
        let obj = {
          marketType : (matchData.marketType=="Match Odds")?"market":(matchData.marketType).toLowerCase(),
          marketId: (matchData.marketType == "Fancy")?matchData.fancyId:matchData.marketId,
          token : encrypted
        };
        this.reOpenGameOffice(obj);
        this.reOpen.hide();
    }

    reOpenGameOffice(data){
      let status = {
        id : "MS940896",
        value: 'SUSPEND',
        name : "suspend",
      };
    data['status'] = status;
    let whtLblData = data;
      this.marketService.reopenGameStatus(whtLblData).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
          this.endSubmit = false;
          delete whtLblData.token;
          if(response){
            this.marketSettel();
            this.spinner.hide();
            this.utilityService.popToast('success', 'Success', 3000, "Game reopen successfully.");
            this.closeReopenModal();
            // this.whiteLabelAll.map(data =>{
            //     this.marketService.reopenMarket(whtLblData, data).subscribe(response => {
            //       this.spinner.hide();
            //       this.utilityService.popToast('success', 'Success', 3000, "Game reopen successfully.");
            //       this.closeReopenModal();
            //     }, error => {
            //       this.spinner.hide();
            //       this.closeReopenModal();
            //       this.utilityService.popToast('success', 'Success', 3000, "Game reopen successfully.");
            //     })
            // })
          }
          this.spinner.hide();

          // this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
        }, error => {
          this.endSubmit = false;
          this.spinner.hide();
          this.closeReopenModal();
           this.utilityService.popToast('error', 'Error', 3000, error.error.message);
        })
    }

}
