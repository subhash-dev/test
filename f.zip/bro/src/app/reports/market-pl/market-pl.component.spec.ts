import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketPlComponent } from './market-pl.component';

describe('MarketPlComponent', () => {
  let component: MarketPlComponent;
  let fixture: ComponentFixture<MarketPlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketPlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketPlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
