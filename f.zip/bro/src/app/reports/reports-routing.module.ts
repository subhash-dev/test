import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MarketPlComponent } from './market-pl/market-pl.component';
import { ReportsComponent } from './reports.component';
import { AuthGuard } from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path:'reports',
  component: ReportsComponent,
  children:[
    {
      path: 'settled',
      canActivate: [AuthGuard],
      component: MarketPlComponent,
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
