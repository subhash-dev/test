import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';
import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './reports.component';
import { MarketPlComponent } from './market-pl/market-pl.component';
import { DataTablesModule } from 'angular-datatables';
import {NgbDateParserFormatter, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {NgbDateMomentParserFormatter} from "../auth-gaurd/date_format";
import {ModalModule} from 'ngx-bootstrap';

@NgModule({
  declarations: [ReportsComponent, MarketPlComponent],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    DataTablesModule,
    FormsModule,
    NgbModule,
    ModalModule.forRoot(),

  ], 
  providers: [
    {
      provide: NgbDateParserFormatter,
      useFactory: () => { return new NgbDateMomentParserFormatter('DD-MM-YYYY') }
    }
  ],
})
export class ReportsModule { }
