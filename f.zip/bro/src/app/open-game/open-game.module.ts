import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OpenGameRoutingModule } from './open-game-routing.module';
import { OpenGameComponent } from './open-game.component';
import { OpengameViewComponent } from './opengame-view/opengame-view.component';
import { ReportsRoutingModule } from '../reports/reports-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { FormsModule } from '@angular/forms';
import {ModalModule} from 'ngx-bootstrap';
@NgModule({
  declarations: [OpenGameComponent, OpengameViewComponent],
  imports: [
    CommonModule,
    OpenGameRoutingModule,
    CommonModule,
    ReportsRoutingModule,
    DataTablesModule,
    ModalModule.forRoot(),
    FormsModule
  ]
})
export class OpenGameModule { }
