import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpengameViewComponent } from './opengame-view.component';

describe('OpengameViewComponent', () => {
  let component: OpengameViewComponent;
  let fixture: ComponentFixture<OpengameViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpengameViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpengameViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
