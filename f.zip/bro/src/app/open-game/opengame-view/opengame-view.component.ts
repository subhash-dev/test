import { ChangeDetectorRef, Component, OnInit, ViewChild ,Inject,LOCALE_ID } from '@angular/core';
import { MarketService } from '../../services/market.service';
import { SportService } from '../../services/sport.service';
import { MatchService } from '../../services/match.service';
import { TournamentService } from '../../services/tournament.service';
import { UtilityService } from '../../globals/utilityService';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import * as env from '../../globals/env';
declare let $: any;
var aes256 = require('aes256');
import { pickBy, identity } from 'lodash';
import {ModalDirective} from 'ngx-bootstrap';
import { Observable } from 'rxjs';
import { UserService } from '../../services/user.service';
import { CommonService } from 'src/app/services/common.service';
import { formatDate } from '@angular/common';
import { FancyService } from 'src/app/services/fancy.service';


class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-opengame-view',
  templateUrl: './opengame-view.component.html',
  styleUrls: ['./opengame-view.component.scss']
})
export class OpengameViewComponent implements OnInit {
  @ViewChild('matchSettled', { static: false }) matchSettled: ModalDirective;
  @ViewChild('gameEnd', { static: false }) gameEnd: ModalDirective;
  @ViewChild('gameEndLine', { static: false }) gameEndLine: ModalDirective;
  @ViewChild(DataTableDirective, { static: false })
  @ViewChild('cancleGame', { static: false }) cancleGame: ModalDirective;
  @ViewChild("conformationForm", { static: false }) passwordFormReset;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();
  resData: any;
  allSport: any;
  allTournament: any;
  allMatch: any;
  sportSelect: any;
  tournamentSelect: any;
  marketType: any;
  finalData: any;
  matchSelect: any;
  server_url: any = env.server_url();
  unSelectSport: any;
  unSelectTournament: any;
  unSelecTmatch: any;
  unSelecMarket: any;
  whiteLabelAll: any;
  getMatchesId: any;
  selectWhiteLabel: any;
  whtLbl: any;
  tranPlsByMtachid: any;
  marketTypeSelect:any;
  conformationPassword: any;
  marketDetail : any;
  fancyId:any;
  marketId:any;
  lineId:any;
  jsonData:any = [];
  endSubmit = false;
  lineMarket: any;

  constructor(private sportService: SportService,
    private matchService: MatchService,
    private userService : UserService,
    private tournamentService: TournamentService,
    private marketService: MarketService,
    private http: HttpClient,
    private fancyService: FancyService,
    private router: Router,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private commonService :CommonService,
    private utilityService: UtilityService,
    @Inject(LOCALE_ID) private locale: string
  ) { }

  filter = {
    page: 1,
    limit: -1,
    search: null
  };
  tournamentFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  matchFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  sportList = [];
  sportId: any;

  tournamentsList = [];
  selectedTournamentsItems = [];
  TournamentsSettings = {
    singleSelection: true,
    text: 'Select tournament',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  tournamentId: any;
  matchList = [];
  selectedMatchItems = [];
  matchSettings = {
    singleSelection: true,
    text: 'Select match',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  matchID: any;
  matchId: any;
  marketFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  paramId: any;
  getAllMarkets: any;
  fancyConfigObject: any;
  time: any;
  marketTypes: any;

  settledObj = {
    matchId: null,
    team: null,
    matchName: null,
  }
  selectedTeam: any;
  endGameObject = {
    result: null,
    password: null
  };
  fancyDetail: any;

  ngOnInit() {
    this.getAllSportList();
    this.getMarketOpen();
    this.setvalue();
    let data = {};
    this.getAllWhiteLabel();
  }

  dataTable: any;
  addMarketObject = {
    marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
    marketType: '',
    marketTypeId: null,
    marketStartTime: this.utilityService.returnLocalStorageData('dateTime'),
    totalMatched: 0,
    runners: null,
    displayName: null,
    isActive: true,
    message: null,
    match: null,
    tournament: null,
    sport: null,
  };

  getAllSportList() {
    this.sportService.getAllSport(this.filter).subscribe(getSportAll => {
        getSportAll = this.utilityService.gsk(getSportAll.auth);
        getSportAll = JSON.parse(getSportAll);
        this.allSport = getSportAll.data.docs.map(data => {
            return { id: data._id, itemName: data.name + '( ' + data.id + ' )', sportId: data.id };
        });
    });
  }

  sportSelection(sportSelect) {
    this.unSelectTournament = '';
    this.unSelecTmatch = '';
    this.matchList = [];
    this.marketType = null;
    this.unSelecMarket = '';
    this.sportId = sportSelect;
    this.getAllTournament(sportSelect);
  }

  getAllTournament(sportSelect) {
    if (sportSelect) {
      this.matchList = [];
      this.tournamentService.getAllTournament(this.tournamentFilter, sportSelect).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        this.tournamentsList = response.data.docs.map(data => {
          return { id: data._id, itemName: data.name + '( ' + data.id + ' )', tournamentId: data.id };
        });
      }, error => {
        console.error('error in getting all sports', error);
      });
    } else {
      this.tournamentsList = [];
    }
  }


  onTornamentSelect(tournamentSelect) {
    this.marketType = null;
    this.unSelecMarket = '';
    this.unSelecTmatch = '';
    this.matchList = [];
    this.getMatches(tournamentSelect);
  }


  getMatches(tournamentSelect) {
    if (tournamentSelect) {
        this.matchService.getAllMatch(this.matchFilter, tournamentSelect).subscribe(response => {
            response = this.utilityService.gsk(response.auth);
            response = JSON.parse(response);
            this.matchList = response.data.docs.map(data => {
            return { id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
            });
        }, error => {
            console.error('Not data', error);
            this.matchList = [];
        });
    } else {
        this.matchList = [];
    }

  }

  onMatchesSelect() {
    this.marketType = null;
    this.unSelecMarket = '';
    this.matchID = this.matchSelect;
  }

  getMarketOpen() {
    this.spinner.show();
    this.rerender();
    const that = this;
    let url = this.server_url + 'market/report';
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      // autoWidth: false,
      // scrollX: true,
      // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      // order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',

        emptyTable: 'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { data: this.finalData,types:'open', marketStatusID: ['MS930818','MS180893'] }),
            {}
          ).subscribe(resp => {
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData = JSON.parse(this.resData);
            this.resData = this.resData.data;
            this.spinner.hide();
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },

      columns: [{ data: '' }, { data: 'marketStartTime' }, { data: 'match' }, { data: 'marketType' },{ data: '' }, { data: '' }],
      columnDefs: [{ orderable: false, targets: [0]}]
    };
  }

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  onMarketSelect(marketTypes) {
    this.marketType = marketTypes;
  }

  searchSettleData() {
    this.finalData = '';
    let data = {
      sportId: this.unSelectSport,
      tournamentId: this.unSelectTournament,
      matchId: this.unSelecTmatch,
      marketType: this.marketType,
    };
    this.finalData = pickBy(data, undefined);
    this.getMarketOpen();
  }
  clear() {
    this.finalData = '';
    let data = {
      sportId: null,
      tournamentId: null,
      matchId: null,
      marketType: null,
    };
    this.finalData = pickBy(data, undefined);
    this.getMarketOpen();
    this.unSelectSport = '';
    this.unSelectTournament = '';
    this.unSelecTmatch = '';
    this.unSelecMarket = '';
    this.tournamentsList = [];
    this.matchList = [];

  }
  setvalue() {
    this.unSelectSport = '';
    this.unSelectTournament = '';
    this.unSelecTmatch = '';
    this.unSelecMarket = '';
  }


  /***
   * update in market data in  multiple white label
   * @param data
   */
  getAllWhiteLabel() {
    this.utilityService.getAllWhiteLabel().then(response => {
      console.log(response)
        // response = this.utilityService.gsk(response.auth);
        // response = JSON.parse(response);
        this.whiteLabelAll = response.data.map(data => {
            return { data: data.appDomainName, appUrl: data.appUrl , checked: false };
        });
    }).catch(error => {
        console.error("errro in get white label");
    });
  }

  getmatchId(obj) {
    console.log(obj);
    this.tranPlsByMtachid = null;
    this.getMatchesId = null;
    this.selectWhiteLabel = null;
    this.fancyId = null;
    this.marketTypeSelect = null;
    this.marketId = null;
    this.lineId = null

    if(obj.marketType === 'Fancy') {
      this.getMatchesId = obj.match.id;
      this.selectWhiteLabel = '';
      this.fancyId = obj.fancyId;
      this.marketTypeSelect = obj.marketType;
    }
    if(obj.marketType === 'Match Odds') {
      this.getMatchesId = obj.match.id;
      this.marketId = obj.marketId;
      this.selectWhiteLabel = '';
      this.marketTypeSelect = obj.marketType;
    }
    if(obj.marketType === 'Line') {
      this.getMatchesId = obj.match.id;
      this.selectWhiteLabel = '';
      this.lineId = obj.lineId;
      this.marketTypeSelect = obj.marketType;
    }
    if(obj.marketType === 'Winner') {
      this.getMatchesId = obj.match.id;
      this.marketId = obj.marketId;
      this.selectWhiteLabel = '';
      this.marketTypeSelect = obj.marketType;
    }
    if(obj.marketType === 'Bookmaker') {
      this.getMatchesId = obj.match.id;
      this.marketId = obj.marketId;
      this.selectWhiteLabel = '';
      this.marketTypeSelect = obj.marketType;
    }
  }

  whiteLabelSelection(selectWhiteLabel) {
    if (selectWhiteLabel) {
        this.utilityService.getAllWhiteLabel().then(response => {
        // response = this.utilityService.gsk(response.auth);
        // response = JSON.parse(response);
        let x = response.data;
        for (let i = 0; i < x.length; i++) {
            if (x[i].appUrl === this.selectWhiteLabel) {
            let obj = {
                matchId: this.getMatchesId,
                status: 'open',
                fancyId: this.fancyId,
                marketId :this.marketId,
                lineId:this.lineId,
                marketTypeSelect:this.marketTypeSelect
            }

            this.marketService.getAllTransactionsBymatchID(obj, x[i]).subscribe(response => {
                response = this.utilityService.gsk(response.auth);
                response = JSON.parse(response);
                this.tranPlsByMtachid = response.data;
            }, error => {
                this.spinner.hide();
                console.error('error', error);
            })
            }
        }
        }).catch(error => {
        console.error("errro in get white label");
        });
    } else {
        this.tranPlsByMtachid = '';
    }
  }

  modelclose() {
    let id = '';
    // this.getmatchId();
    this.whiteLabelSelection(this.selectWhiteLabel = '');
  }


  /*
    Developer: Rk
    Date: 25-08/2020
    title: Open cancle market modal
    Use: This function end game result declare
  */
  openCancleMarketModal(data) {
    this.marketDetail = data;
    this.cancleGame.show();
  }
  closeCancleModal(){
    this.whiteLabelAll.map(data => {
      data.checked = false;
    })
    this.conformationPassword = '';
    this.cancleGame.hide();
  }
  cancleGameSubmit(matchData){
        if(this.endSubmit) {
            return;
        }
        this.endSubmit = true;
        this.spinner.show();
        let key = env.constantKey();
        let token = this.conformationPassword;
        var encrypted = aes256.encrypt(key, token);
        let obj = {
          marketType : (matchData.marketType=="Match Odds")?"market":(matchData.marketType).toLowerCase(),
          marketId: (matchData.marketType == "Fancy")?matchData.fancyId:matchData.marketId,
          marketName : (matchData.marketType == "Fancy")?matchData.fancyName:(matchData.marketType == "Line") ? matchData.lineName : matchData.match.name,
          token : encrypted
        };
        this.cancelGameOffice(obj);
        this.cancleGame.hide();
    }

  cancelGameOffice(data){
      let status = {
        id: 'MS930818',
        name: 'Cancelled',
        value: 'CANCELLED'
      };
    data['status'] = status;
    let whtLblData = data;
        this.marketService.cancelGameStatus(whtLblData).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
            if(response){
            this.getMarketOpen();
            this.endSubmit = false;
            delete whtLblData.token;
            this.spinner.hide();
            this.closeCancleModal();
            this.utilityService.popToast('success', 'Success', 3000, "Game cancelled");
            // this.whiteLabelAll.map(data =>{
            //     this.marketService.cancelMarket(whtLblData, data).subscribe(response => {
            //       this.spinner.hide();
            //       this.utilityService.popToast('success', 'Success', 3000, "Game cancelled");
            //       this.closeCancleModal();
            //     }, error => {
            //       this.spinner.hide();
            //       this.closeCancleModal();
            //       this.utilityService.popToast('success', 'Success', 3000, "Game cancelled");
            //       this.closeCancleModal();
            //     })
            // })
            }
            this.spinner.hide();

            // this.utilityService.popToast('success', 'Success', 3000, 'Market updated successfully.');
        }, error => {
            this.endSubmit = false;
            this.spinner.hide();
            this.closeCancleModal();
            this.utilityService.popToast('error', 'Error', 3000, error.error.message);
        })
    }

    download() {
        this.jsonData =[];
        let count = 0;

        if(this.tranPlsByMtachid){
            let dataTemps = this.tranPlsByMtachid.map(transaction => {
            let dataArr ={
                USERNAME:transaction.userId.userName,
                MASTER:transaction.userId.parentId.userName,
                RUNNER:(transaction.gameType == 'market') ? transaction.team[0].runnerName:
                        transaction.gameType == 'line'? transaction.gameDetail[0].lineName :
                        transaction.gameType == 'fancy' ? transaction.gameDetail[0].fancyName + "/" + transaction.volume:
                        transaction.gameType == 'Bookmaker' ? 'Bookmaker':'',
                'BETT YPE':transaction.runner_type,
                RATE: transaction.odds,
                AMOUNT: transaction.rate,
                MARKET: transaction.gameType,
                MATCH: transaction.gameDetail[0].match.name.substring(0, transaction.gameDetail[0].match.name.indexOf('(')),
                'PLACED TIME': formatDate(transaction.placeTime,'dd-MM-yyyy h:mm:ss',this.locale),
                'MATCHED TIME': formatDate(transaction.betTime,'dd-MM-yyyy h:mm:ss',this.locale),
                'IP': (transaction.ip) ? transaction.ip:''
            }
            count++;
            this.jsonData.push(dataArr);
        });
            let headerKey = ['USERNAME','MASTER','RUNNER','BET TYPE','RATE', 'AMOUNT', 'MARKET', 'MATCH','PLACED TIME' ,'MATCHED TIME','IP'];
            let csvName = 'Bet History Report';
            if(this.tranPlsByMtachid.length == count) {
                this.commonService.downloadFile(this.jsonData, headerKey,csvName);
            }
        }

    }
    openModal(item){
      console.log(item);
      if(item.marketType == 'Bookmaker' || item.marketType == 'Winner'|| item.marketType == 'Match Odds'){
        let matchId = item.match.id;
        this.matchService.getMarketByMatchId(matchId).subscribe(marketResponse => {
            marketResponse = this.utilityService.gsk(marketResponse.auth);
            marketResponse = JSON.parse(marketResponse);
            if (marketResponse.status === true) {
              this.settledObj.matchId = matchId;
              this.settledObj.team = marketResponse.data.runners;
              this.settledObj.matchName = marketResponse.data.match.name;

            }
          });
        this.matchSettled.show();
      }
      if(item.marketType == 'Fancy'){
          this.fancyDetail = item;
          this.gameEnd.show()
      }
      if(item.marketType == 'Line'){
        this.lineMarket = item;
        this.gameEndLine.show()
      }
    }
    closeModal(){
      this.gameEnd.hide();
      this.matchSettled.hide();
      this.gameEndLine.hide();
    }

    settleMarket() {
      if(this.endSubmit) {
          return;
      }
      this.endSubmit = true;
      this.spinner.show();
      let key = env.constantKey();
      let token = this.conformationPassword;
      var encrypted = aes256.encrypt(key, token);
      let resultTeam = this.settledObj.team.find(o => o.selectionId === this.selectedTeam);
      let apiObj = {
        teamId: this.selectedTeam,
        matchId: this.settledObj.matchId,
        matchName: resultTeam.runnerName,
        type:"Match Odds",
        token: encrypted
      };
      this.matchService.matchSettledOffice(apiObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        // this.utilityService.getAllWhiteLabel().then(response => {
        //   let x = response.data;
        //   /* Hear X is Multiple Whitelable Data*/
        //   for (let i = 0; i < x.length; i++) {
        //     this.matchService.matchSettled(apiObj, x[i]).subscribe(response => {
        //       this.spinner.hide();
        //       if (response.status == true) {
        //         this.utilityService.popToast('success', 'Success', 3000, response.message);
        //         this.endSubmit = false;
        //         this.closeModal();
        //         this.getMarketOpen();
        //       } else {
        //         this.closeModal();
        //         this.getMarketOpen();
        //         this.endSubmit = false;
        //         this.utilityService.popToast('error', 'Error', 3000, response.message);
        //       }
        //     });
        //   }
        // }).catch(error => {
        //   this.closeModal();
        //   this.getMarketOpen();
        //   this.spinner.hide();
        //   this.endSubmit = false;
        //   this.utilityService.popToast('error','Error', 3000 , error.message);
        // });
        this.utilityService.popToast('success', 'Success', 3000, 'market settled');
            this.closeModal();
            this.getMarketOpen();
            this.spinner.hide();
            this.endSubmit = false;
      }, error =>{
        this.closeModal();
        this.getMarketOpen();
        this.spinner.hide();
        this.endSubmit = false;
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });
    }

    addEndGame(fancyId) {
      if(this.endSubmit) {
          return;
      }
      this.endSubmit = true;
      let key = env.constantKey();
      let token = this.endGameObject.password;
      var encrypted = aes256.encrypt(key, token);
      let marketObj = {
        market_uniq_id: fancyId,
        type: "fancy",
        result: this.endGameObject.result,
        token: encrypted
      };
      //settled fancy from office
      this.fancyService.fancySettledOffice(marketObj).subscribe(checkUserResponse => {
            checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
            checkUserResponse = JSON.parse(checkUserResponse);
            if(checkUserResponse.status == true){

                delete marketObj.token;
                // this.utilityService.getAllWhiteLabel().then(response => {
                //   let x = response.data;
                //   let totalWht = x.length;
                //   /* Hear X is Multiple Whitelable Data*/
                //   for (let i = 0; i < totalWht; i++) {
                //     this.fancyService.fancySettled(marketObj,x[i])
                //     .subscribe(checkUserResponse => {
                //       this.closeModal();
                //       this.getMarketOpen();
                //       this.utilityService.popToast('success', 'Success', 3000, "Fancy Settled.");
                //     });
                //   }
                // }).catch(error =>{
                //   console.error("errro in get white label");
                // });
                this.closeModal();
                this.getMarketOpen();
            }else if(checkUserResponse.status == 'False'){
                this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
                this.endSubmit = false;
            }else{
                this.closeModal();
                this.utilityService.popToast('error','Error', 3000 , "Fancy already settled.");
            }
        }, error =>{
          this.endSubmit = false;
          this.utilityService.popToast('error','Error', 3000 , error.error.message);
        })

    }

    addEndGameLine(marketId){
        if(this.endSubmit) {
            return;
        }
        this.endSubmit = true;
        let key = env.constantKey();
        let token = this.endGameObject.password;
        var encrypted = aes256.encrypt(key, token);
        let marketObj = {
            market_uniq_id: marketId,
            type: 'line',
            result: this.endGameObject.result,
            token: encrypted
        }
        this.fancyService.lineSettledOffice(marketObj).subscribe(checkUserResponse => {
            checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
            checkUserResponse = JSON.parse(checkUserResponse);
            if(checkUserResponse.status == true){
                delete marketObj.token;
                // this.utilityService.getAllWhiteLabel().then(response => {

                //   let x = response.data;
                //   /* Hear X is Multiple Whitelable Data*/
                //   for (let i = 0; i < x.length; i++) {
                //     this.fancyService.fancySettled(marketObj, x[i])
                //       .subscribe(checkUserResponse => {
                //         this.closeModal();

                //         this.utilityService.popToast('success', 'Success', 3000, 'Line market Settled.');
                //       });
                //   }
                // }).catch(error => {
                //   console.error('errro in get white label');
                // });
                this.closeModal();
            }else{
                this.closeModal();
                this.utilityService.popToast('error','Error', 3000 , "Line already settled.");
            }
        }, error =>{
            this.endSubmit = false;
            this.utilityService.popToast('error','Error', 3000 , error.error.message);
        });
    }
  }

