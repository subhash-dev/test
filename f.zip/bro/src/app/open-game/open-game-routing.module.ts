import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {OpengameViewComponent} from './opengame-view/opengame-view.component';
import {OpenGameComponent} from './open-game.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path: 'opengame',
  canActivate: [AuthGuard],
  component: OpenGameComponent,
  children: [
    {
      path: 'view',
      canActivate: [AuthGuard, RoleGuard],
      component: OpengameViewComponent,
    },

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OpenGameRoutingModule {
}
