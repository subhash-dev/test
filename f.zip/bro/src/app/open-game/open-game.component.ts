import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-game',
  templateUrl: './open-game.component.html',
  styleUrls: ['./open-game.component.scss']
})
export class OpenGameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
