import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ReopengameViewComponent} from './reopengame-view/reopengame-view.component';
import {ReopenGameComponent} from './reopen-game.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path: 'reopengame',
  canActivate: [AuthGuard],
  component: ReopenGameComponent,
  children: [
    {
      path: 'view',
      canActivate: [AuthGuard, RoleGuard],
      component: ReopengameViewComponent,
    },

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReopenGameRoutingModule {
}
