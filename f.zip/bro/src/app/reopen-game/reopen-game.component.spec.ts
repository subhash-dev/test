import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReopenGameComponent } from './reopen-game.component';

describe('ReopenGameComponent', () => {
  let component: ReopenGameComponent;
  let fixture: ComponentFixture<ReopenGameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReopenGameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReopenGameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
