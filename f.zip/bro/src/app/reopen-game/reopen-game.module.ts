import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReopenGameRoutingModule } from './reopen-game-routing.module';
import { ReopenGameComponent } from './reopen-game.component';
import { ReopengameViewComponent } from './reopengame-view/reopengame-view.component';
import { ReportsRoutingModule } from '../reports/reports-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [ReopenGameComponent, ReopengameViewComponent],
  imports: [
    CommonModule,
    ReopenGameRoutingModule,
    CommonModule,
    ReportsRoutingModule,
    DataTablesModule,
    FormsModule
  ]
})
export class ReopenGameModule { }
