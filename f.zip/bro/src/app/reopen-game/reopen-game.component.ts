import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reopen-game',
  templateUrl: './reopen-game.component.html',
  styleUrls: ['./reopen-game.component.scss']
})
export class ReopenGameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
