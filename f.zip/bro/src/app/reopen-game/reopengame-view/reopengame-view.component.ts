import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MarketService } from '../../services/market.service';
import {SportService} from '../../services/sport.service';
import {MatchService} from '../../services/match.service';
import {TournamentService} from '../../services/tournament.service';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import * as env from '../../globals/env';
declare let $: any;
import { pickBy, identity } from 'lodash';
import {UtilityService} from '../../globals/utilityService';

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-reopengame-view',
  templateUrl: './reopengame-view.component.html',
  styleUrls: ['./reopengame-view.component.scss']
})
export class ReopengameViewComponent implements OnInit {
  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};

  dtTrigger = new Subject();
  resData: any;
  allSport: any;
  allTournament: any;
  allMatch: any;
  sportSelect: any;
  tournamentSelect: any;
  marketType: any;
  finalData: any;
  matchSelect: any;
  server_url: any = env.server_url();
  unSelectSport: any;
  unSelectTournament: any;
  unSelecTmatch: any;
  unSelecMarket: any;
  constructor(private sportService: SportService,
    private matchService: MatchService,
    private tournamentService: TournamentService,
    private marketService: MarketService,
    private http: HttpClient,
    private router: Router,
    private utilityService: UtilityService,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService
  ) { }

  filter = {
    page: 1,
    limit: -1,
    search: null
  };
  tournamentFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  matchFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  sportList = [];
  sportId: any;

  tournamentsList = [];
  selectedTournamentsItems = [];
  TournamentsSettings = {
    singleSelection: true,
    text: 'Select tournament',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  tournamentId: any;
  matchList = [];
  selectedMatchItems = [];
  matchSettings = {
    singleSelection: true,
    text: 'Select match',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: true,
  };
  matchID: any;
  marketFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  paramId: any;
  getAllMarkets: any;
  fancyConfigObject: any;
  time: any;
  marketTypes: any;

  ngOnInit() {
    this.getAllSportList();
    this.getMarketReopen();
    this.setvalue();
  }

  /**
   * @author TR
   * @date 23-06-2020
   * GetAll settled market list
   * @param data
   */
  dataTable: any;
  addMarketObject = {
    marketId: ('1.' + Math.floor(Math.random() * (888888888 - 10000 * 1) * 100)),
    marketType: '',
    marketTypeId: null,
    marketStartTime: this.utilityService.returnLocalStorageData('dateTime'),
    totalMatched: 0,
    runners: null,
    displayName: null,
    isActive: true,
    message: null,
    match: null,
    tournament: null,
    sport: null,
  };

  getAllSportList() {
    this.sportService.getAllSport(this.filter).subscribe(getSportAll => {
      this.allSport = getSportAll.data.docs.map(data => {
        return { id: data._id, itemName: data.name + '( ' + data.id + ' )', sportId: data.id };
      });
    });
  }

  sportSelection() {
    this.sportId = this.sportSelect;
    this.getAllTournament();
  }

  getAllTournament() {
    this.tournamentService.getAllTournament(this.tournamentFilter, this.sportId).subscribe(response => {

      this.tournamentsList = response.data.docs.map(data => {
        return { id: data._id, itemName: data.name + '( ' + data.id + ' )', tournamentId: data.id };
      });
    }, error => {
      console.error('error in getting all sports', error);
    });
  }


  onTornamentSelect() {
    this.tournamentId = this.tournamentSelect;
    this.getMatches();
  }


  getMatches() {
    this.matchService.getAllMatch(this.matchFilter, this.tournamentId).subscribe(response => {
      this.matchList = response.data.docs.map(data => {
        return { id: data._id, itemName: data.name + '( ' + data.id + ' )', matchId: data.id, matchTime: data.openDate };
      });
    }, error => {
      console.error('get all Matches', error);
    });
  }

  onMatchesSelect() {
    this.matchID = this.matchSelect;
  }

  getMarketReopen() {
    this.spinner.show();
    this.rerender();
    const that = this;
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      // autoWidth: false,
      // scrollX: true,
      // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      lengthMenu: [5, 10, 25, 50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',

        emptyTable: 'No record found',
        paginate: {
          first: 'first', last: 'last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'market/open';
        console.log("this.url",url);

        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { data: this.finalData }),
            {}
          ).subscribe(resp => {
            this.resData = resp.data;
            console.log("this.resData",this.resData);
            this.spinner.hide();
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },

      // columns: [{ data: '' }, { data: 'createdAt' }, { data: 'sport' }, { data: 'tournament' }, { data: 'match' }, { data: 'marketType' }, { data: '' }, { data: '' }, { data: '' }],
      columnDefs: [{ orderable: false, targets: [0], searchable: true }]
    };
  }

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  onMarketSelect() {
    this.marketType = this.marketTypes;
  }

  searchSettleData(){
    this.finalData = '';
    let data = {
      sportId: this.sportSelect,
      tournamentId: this.tournamentSelect,
      matchId: this.matchSelect,
      marketType: this.marketType,
    };
    this.finalData = pickBy(data, undefined);
    this.getMarketReopen();
  }
  clear() {
    this.finalData = '';
    let data = {
      sportId: null,
      tournamentId: null,
      matchId: null,
      marketType: null,
    };
    this.finalData = pickBy(data, undefined);
    this.getMarketReopen();
    this.unSelectSport = '';
    this.unSelectTournament = '';
    this.unSelecTmatch = '';
    this.unSelecMarket = '';

  }
  setvalue() {
    this.unSelectSport = '';
    this.unSelectTournament = '';
    this.unSelecTmatch = '';
    this.unSelecMarket = '';
  }

}
