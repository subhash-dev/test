import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReopengameViewComponent } from './reopengame-view.component';

describe('ReopengameViewComponent', () => {
  let component: ReopengameViewComponent;
  let fixture: ComponentFixture<ReopengameViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReopengameViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReopengameViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
