import {ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from 'ngx-bootstrap';
import {NgxSpinnerService} from 'ngx-spinner';
import * as env from '../globals/env';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '../globals/utilityService';
import {UserService} from '../services/user.service';
import {BinaryService} from '../services/binary.service';
import {ToasterConfig} from 'angular2-toaster';
import {MatchService} from '../services/match.service';


@Component({
  selector: 'app-live-tv',
  templateUrl: './live-tv.component.html',
  styleUrls: ['./live-tv.component.scss']
})
export class LiveTvComponent implements OnInit {
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('deleteModal', {static: false}) 'deleteModal': ModalDirective;
  @ViewChild("addChannel", {static: false}) addChannelReset;
  channels;
  deleteObject;
  server_url: any = env.server_url();
  addChannelObject = {
    _id: null,
    channelName: null,
    channelUrl: null
  };
  edit = false;


  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });


  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private matchService: MatchService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private http: HttpClient) {
  }


  ngOnInit() : void {
    // if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
    //   this.router.navigate(['accessdenied']);
    // } else {
    //   this.accessRole = this.utilityService.returnAccessRole('binary');
    // }
    // this.newDatatable();
    //
    this.getAllChannel();
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Open Modal Operation
   */

  openModal(data , item) {
    this.addChannelReset.resetForm();
    if(data === 'add'){
      this.addChannelObject.channelName = '';
      this.addChannelObject.channelUrl = '';
      this.edit = false;
      this.modal.show();
    }else if(data === 'delete'){
    this.deleteObject = item;
    this.deleteModal.show();
    }else if(data === 'edit'){
    this.deleteObject = item;
      this.addChannelObject = {
        channelName:item.channelName,
        channelUrl: item.channelUrl,
        _id: item._id
      };
      this.edit = true;
      this.modal.show();
    }
  }


  /**
   * @author TR
   * @date : 15-05-2020
   * Close Modal Operation
   */

  closeModel(data) {
    if(data === 'delete') {
      this.deleteModal.hide();
  } else {
      this.modal.hide();
    }
}



  /**
   * @author TR
   * @date : 15-05-2020
   * Get Channel
   * @method: POST
   */

  getAllChannel() {
    this.spinner.show();
    this.matchService.getAllChannel().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response =JSON.parse(response);
      if(response.status){
        this.spinner.hide();
        this.channels = response.data;
        // this.utilityService.popToast('success','Success', 3000 , 'Channel get successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }


  /**
   * @author TR
   * @date : 15-05-2020
   * Create Exchange
   * @method: POST
   */

  createChannel() {
    if(this.addChannelObject.channelName && this.addChannelObject.channelName.length && this.addChannelObject.channelUrl  ) {
      this.addChannelObject._id = null;
      this.spinner.show();
      this.matchService.addNewChannel(this.addChannelObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        console.log(response)
          if (response.status === true) {
            this.modal.hide();
            this.getAllChannel();
            this.spinner.hide();
            this.utilityService.popToast('success', 'Success', 3000, 'Channel created successfully.');
          } else {
            this.spinner.hide();
            this.utilityService.popToast('error', 'Error', 3000, response.message);
          }
          //$('#addModel').modal('hide');
        }, error => {
          this.spinner.hide();
          this.utilityService.popToast('error', 'Error', 3000, error.message);
        });
    }
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Update Channel
   * @method: POST
   */

  updateChannel() {
    console.log("this.addChannelObject",this.addChannelObject);
    if(this.addChannelObject.channelName != null && this.addChannelObject.channelUrl != null  ) {
      this.spinner.show();
      this.matchService.updateChannel(this.addChannelObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status === true) {
          this.modal.hide();
          this.getAllChannel();
          this.spinner.hide();
          this.utilityService.popToast('success', 'Success', 3000, 'Channel update successfully.');
        } else {
          this.spinner.hide();
          this.utilityService.popToast('error', 'Error', 3000, response.message);
        }
        //$('#addModel').modal('hide');
      }, error => {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, error.message);
      });
    }
  }

  /**
   * @author TR
   * @date : 18-05-2020
   * Delete Channel
   * @method: POST
   */

  deleteChannel() {
    this.spinner.show();
    this.matchService.deleteChannel(this.deleteObject).subscribe(resposne => {
      resposne = this.utilityService.gsk(resposne.auth);
      resposne =JSON.parse(resposne);
      this.deleteModal.hide();
      if(resposne.status === true){
        this.getAllChannel();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'channel deleted successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  redirectUrl(data){
    window.open(data.channelUrl, "_blank");
  }
}
