import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {ToasterConfig} from 'angular2-toaster';
import {UtilityService} from '../globals/utilityService';
import {UserService} from '../services/user.service';
import {GameSettingService} from '../services/gameSettingService.service';
import {NgxSpinnerService} from 'ngx-spinner';
import {Router} from '@angular/router';
import {CurrencyService} from '../services/currency.service';

@Component({
  selector: 'app-currancy-setting',
  templateUrl: './currancy-setting.component.html',
  styleUrls: ['./currancy-setting.component.scss']
})
export class CurrancySettingComponent implements OnInit {

  constructor(private currencyService: CurrencyService,
              private utilityService: UtilityService,
              private router: Router,
              private gameSettingService: GameSettingService,
              private userService: UserService,
              private chRef: ChangeDetectorRef,
              private spinner: NgxSpinnerService) { }
   buttonObject = [{
      name:'',
     value:'',
     isActive: true
  },
     {
       name:'',
       value:'',
       isActive: true
     },
     {
       name:'',
       value:'',
       isActive: true
     },
     {
       name:'',
       value:'',
       isActive: true
     },
     {
       name:'',
       value:'',
       isActive: true
     },
     {
       name:'',
       value:'',
       isActive: true
     },
     {
       name:'',
       value:'',
       isActive: true
     },
     {
       name:'',
       value:'',
       isActive: true
     },
     {
       name:'',
       value:'',
       isActive: true
     },
     {
       name:'',
       value:'',
       isActive: true
     }
   ];
  currencyAll: any;
  responseButton: any;

  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  ngOnInit() {
    this.getAllCurrency();
  }


  /**
   * @author TR
   * @date : 04-06-2020
   * add new Currency
   */
  getAllCurrency(){
  this.currencyService.getAllCurrency().subscribe(response => {
    response = this.utilityService.gsk(response.auth);
		response =JSON.parse(response);
    this.currencyAll = response.data;
    this.responseButton = this.currencyAll[0].buttons;
    console.log(this.responseButton)

  });
  }
   /**
   * @author TR
   * @date : 04-06-2020
   * add new Currency
   */
  createCurrency() {
    this.spinner.show();
    let data = {
        buttons: this.buttonObject,
        userId: this.utilityService.returnLocalStorageData('userId')
    };
    this.currencyService.addNewCurrency(data).subscribe(resposne => {
      resposne = this.utilityService.gsk(resposne.auth);
			resposne =JSON.parse(resposne);
      if(resposne.status === true){
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Currency created successfully.');
        this.createWhitelbCurrency(data);
        this.getAllCurrency();
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /**
   * @author TR
   * @date : 05-06-2020
   * update  Currency
   */
  updateCurrency() {
    let data = {
      _id: this.currencyAll[0]._id,
      buttons: this.currencyAll[0].buttons,
      userId: this.currencyAll[0].userId
    };
    this.spinner.show();
    this.currencyService.updateCurrency(data).subscribe(resposne => {
      resposne = this.utilityService.gsk(resposne.auth);
			resposne =JSON.parse(resposne);
      if(resposne.status === true){
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Currency updated successfully.');
        this.updateWhtLblCurrency(data);
        this.getAllCurrency();
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /**
   * @author TR
   * @date : 05-06-2020
   * add new Currency all whitelable
   */
  createWhitelbCurrency(item) {
    this.utilityService.getAllWhiteLabel().then(response =>{
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.currencyService.addNewCurrencywht(item , x[i]).subscribe(resposne => {
          response = this.utilityService.gsk(response.auth);
			    response =JSON.parse(response);
          if(resposne.status === true){
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }


  /**
   * @author TR
   * @date : 05-06-2020
   * add new Currency all whitelable
   */
  updateWhtLblCurrency(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      // response = this.utilityService.gsk(response.auth);
			// response =JSON.parse(response);
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.currencyService.updateWhtLblCurrency(data , x[i])
          .subscribe(response =>{
            // this.utilityService.popToast('success','Success', 1000 , 'White label sport updated successfully.');
          }, error =>{

          });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });

  }
}
