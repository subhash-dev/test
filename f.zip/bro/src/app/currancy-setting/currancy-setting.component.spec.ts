import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrancySettingComponent } from './currancy-setting.component';

describe('CurrancySettingComponent', () => {
  let component: CurrancySettingComponent;
  let fixture: ComponentFixture<CurrancySettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrancySettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrancySettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
