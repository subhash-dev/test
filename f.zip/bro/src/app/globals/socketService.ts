import { Component, OnInit, Inject, Injectable } from '@angular/core';
import {DOCUMENT} from '@angular/common';
import {Router} from '@angular/router';
import {Location} from '@angular/common';
import * as io from 'socket.io-client';
import { Observable} from 'rxjs';
import * as env from '../globals/env';
declare var $ : any;
@Injectable()

export class SocketService{
  private url = env.socket_url();
  private socket;

  constructor(@Inject(DOCUMENT) private document: any,
              private router: Router,
              private location: Location
              ) {
                this.socket = io(this.url,{
                  autoConnect: true,
                  reconnection: true,
                  reconnectionDelay: 1000,
                  reconnectionDelayMax: 5000,
                  reconnectionAttempts: Infinity,
                  transports: ['websocket', 'polling', 'flashsocket']});
                this.socket.emit('join-room', 'room1');
  }

   //Join room function
   joinRoom(roomId){
     console.log(roomId);
    this.socket.emit('join-room', roomId);
  }

  disconnect(){
    this.socket.disconnect(0);
  }
  connect(){
    this.socket.connect(0);
  }

  rateBroadcast(id,apiObj,type){
    this.socket.emit('api-obj', {"data":apiObj,"id":id,"type":type});
  }

  changeMode(id,apiObj){
    this.socket.emit('change-mode', {"data":apiObj,"id":id});
  }

  changeStatus(status){
    this.socket.emit('change-status', status);
  }
  // public changeStatuses = () => {
  //   return Observable.create((observer) => {
  //     this.socket.on('change-status', (message) => {
  //       observer.next(message);
  //     });
  //   });
  // };

//   public getRate = () => {
//     return Observable.create((observer) => {
//         this.socket.on('api-obj', (message) => {
//             //console.log("server");
//             //console.log(message);
//             observer.next(message);
//         });
//     });
// }


public oddsRate = () => {
  return Observable.create((observer) => {
      this.socket.on('odds-rate', (message) => {
        console.log(message);
          observer.next(message);
      });
  });
}

sendCounter(fancyId){
  this.socket.emit('send-counter', fancyId);
}

public getTimer = () => {
  return Observable.create((observer) => {
      this.socket.on('send-counter', (message) => {
          observer.next(message);
      });
  });
}

public logoutBySuperAdmin = () => {
  return Observable.create((observer) => {
      this.socket.on('logoutSuperAdmin', (message) => {
          observer.next(message);
      });
  });
}


}
