'use strict';

/*
    Developer: Ravi
    Date: 09-jan-2020
    title: Validation rule for sign up form
    Use: This function is use for set global validation rules
*/
export const GlobalRegex = {
};

