import {Injectable} from '@angular/core';

@Injectable()
export class ConstantService {

  checkHandshakeUrl = '/api/v1/basicsettings/apptoken';
  webHookUrl = '/api/v1/webHook/';
  nonWebHook = '/api/v1/';
  partnershipUrl = '/api/v1/partnershipcommissions/';
  constructor() {
/*    this.inquiry = this.baseURL + '/aakash-ceramic/api/v1/inquiry';*/
  }

}
