import { Component, OnInit, Inject, Injectable } from '@angular/core';
import {DOCUMENT} from '@angular/common';
import {Router} from '@angular/router';
import {Location} from '@angular/common';
import * as io from 'socket.io-client';
import { Observable} from 'rxjs';
import * as env from './env';


declare var $ : any;
@Injectable()

export class SocketServiceRedis{
  // private url =  env.client_socket_redis();
  private url =  'http://51.159.19.115:4848';


  private socket;

  constructor(@Inject(DOCUMENT) private document: any,
              private router: Router,
              private location: Location
              ) {
                this.socket = io('https://sslbhav.rdsconn.com',{
                  autoConnect: true,
                  reconnection: true,
                  reconnectionDelay: 1000,
                  reconnectionDelayMax: 5000,
                  reconnectionAttempts: Infinity,
                    transports: ['websocket','flashsocket','htmlfile','xhr-polling','jsonp-polling','polling']
                  }
                );
                //this.socket.emit('join-room', 'room2');
            }

  //Join room function
  joinRoom(roomId){
    this.socket.emit('join-room', roomId);
  }

  disconnect(){
    this.socket.disconnect(0);
  }

  connect(){
    this.socket.connect(0);      
  }

  //this function use for getting bet from socket emit event
  public oddsRate = () => {
    return Observable.create((observer) => {
      this.socket.on('odds-rate', (message) => {
        observer.next(message);
      });
    });
  }


  public fancyRate = () => {
    return Observable.create((observer) => {
      this.socket.on('fancy-auto-rate', (message) => {
        observer.next(message);
      });
    });
  }

}
