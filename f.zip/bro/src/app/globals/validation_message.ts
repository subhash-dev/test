'use strict';


/*
    Developer: Ravi
    Date: 09-jan-2020
    title: Login messages
    Use: This function is use for set global validation messages
*/

export const loginMessages = {

  password: "Enter transaction password"
};
