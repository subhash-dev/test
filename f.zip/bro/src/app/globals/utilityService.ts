import {Component, OnInit, Inject, Injectable} from '@angular/core';
import {DOCUMENT} from '@angular/common';
import {Router} from '@angular/router';
import {Location} from '@angular/common';
import {Toast, ToasterConfig, ToasterService} from 'angular2-toaster';
import {WhiteLabelSettingService} from '../services/whitelabelsetting.service';
import { UserService } from '../services/user.service';
declare var $: any;
var aes256 = require('aes256');
import * as env from './env';
var aes256 = require('aes256');
@Injectable()

export class UtilityService {

  private toasterService: ToasterService;
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right',
    limit:2
  });
  roles:any;
  whiteLabelFilter = {
    page: 1,
    limit: -1,
    search: null
  };
  constructor(@Inject(DOCUMENT) private document: any,
              private router: Router,
              toasterService : ToasterService,
              private userService: UserService,
              private whiteLabelSettingService: WhiteLabelSettingService,
              private location: Location) {
    this.toasterService = toasterService;
  }

  marketType = [
    /* to be check later*/
    {
      id: '5ebc1code68br4bik5b3035',
      name: 'Match Odds'
    },
    {
      id: '5ebc1code68br4bik5b1808',
      name: 'Fancy'
    },
    {
      id: '5ebc1code68br4bik5b0810',
      name: 'Bookmaker'
    },
    {
      id: '5ebc1code68br4bik5b0811',
      name: 'Line'
    },
    {
      id: '5ebc1code68br4bik5b0814',
      name: 'Cup'
    }

  ];

  feturesArrayList= [
    {
      id:1,
      name: 'Allow Bet',
      value: 'ALLOWBET',
    },
    {
      id:2,
      name: 'Apply Commission',
      value: 'APPLYCOMMISION'
    },
    {
      id:3,
      name: 'Limit',
      value: 'LIMIT'
    },
    {
      id:4,
      name: 'Message',
      value: 'MESSAGE'
    },
    {
      id:5,
      name: 'Suspended',
      value: 'SUSPENDED'
    },
    {
      id:6,
      name: 'Enter Rate',
      value: 'ENTERRATE'
    },
    {
      id:7,
      name: 'Commentary',
      value: 'COMMENTARY'
    },
    {
      id:8,
      name: 'Result',
      value: 'RESULT'
    }
  ];

  marketStatusArray = [
    {
      id: 'MS081893',
      name: 'Open',
      value: 'OPEN'
    },
    {
      id: 'MS180893',
      name: 'Settled',
      value: 'SETTLED'
    },
    {
      id: 'MS930818',
      name: 'Cancelled',
      value: 'Cancelled'
    },
    {
      id: 'MS940896',
      name: 'suspend',
      value: 'SUSPENDED'
    },
    {
      id: 'MS950763',
      name: 'ballstart',
      value: 'BALLSTART'
    },
    {
      id: 'MS960523',
      name: 'active',
      value: 'ACTIVE'
    },
  ];

  /**
   *get user module list from local storage
   * @return {any}
   */
  getRoleAccess() {
    this.roles = JSON.parse(returnLocalStorageData('userData')).role.modules;
    return this.roles;
  }

  returnAccessRole(module){
    this.roles = JSON.parse(returnLocalStorageData('userData')).role.modules;
    let accessRole = this.roles.filter(data =>{
      if(data.moduleName === module){
        return data;
      }
    })[0];
    return accessRole;
  }

  returnLocalStorageData(pwd){
    let key = env.constantKey();
      let data =  localStorage.getItem(pwd);
      if(data){
        let decrypt = aes256.decrypt(key, data);
        return decrypt;
      }else{
        return false;
      }




  }

  returnSessionStorageData(pwd){
    let key = env.constantKey();
    let data =  sessionStorage.getItem(pwd);
    if(data){
      let decrypt = aes256.decrypt(key, data);
      return decrypt;
    }else{
      return false;
    }
  }



  getHostname() {
    return (this.document.location.hostname == 'localhost') ? document.location.port : this.document.location.hostname;
  }

  popToast(type,title ,timeout, body ) {
    const toast: Toast = {
      type: type,
      title: title,
      timeout: timeout,
      body: body
    };
    this.toasterService.pop(toast);
  }

  /***
   * @author TR
   * @date 25-06-2020
   * @param data
   * @return {{hours: number; minutes: number}}
   * convert date to according to GMT time zone
   */
   ConvertUTCTimeToLocalTime(res)
  {
    var convertdLocalTime = new Date(res);
    var hourOffset = convertdLocalTime.getTimezoneOffset() / 60;

    convertdLocalTime.setHours( convertdLocalTime.getHours() + hourOffset );
   return convertdLocalTime

  }

  /***
   * @author kc
   * @date 10-04-2020
   * @param data
   * @return {{hours: number; minutes: number}}
   * convert date to according to current time zone
   */
  convertTimeAsPerCurrentTimeZoneOffset(data){

    let offset = new Date().getTimezoneOffset();

    let tempMin;
    let finalTime;
    if(data.hour > 12){
      tempMin = ((data.hour - 12) * 60);
      finalTime = ((tempMin + offset ) / 60);
      finalTime = (((12 + finalTime) * 60 ) === 0) ?  ((12 + finalTime) * 60 ) : (((12 + finalTime) * 60 ) + data.minute);
      finalTime = (finalTime / 60)
    }else{
      tempMin = ((data.hour) * 60);
      finalTime = ((tempMin + offset ) / 60);
      finalTime = (((finalTime) * 60 ) === 0) ?  ((finalTime) * 60 ) : (((finalTime) * 60 ) + data.minute);
      finalTime = (finalTime / 60)
    }

    let n = (finalTime * 60);
    let num = n;
    let hours = (num / 60);
    let rhours = Math.floor(hours);
    let minutes = (hours - rhours) * 60;
    let rminutes = Math.round(minutes);


    //console.log("rhours", rhours);
    //console.log("rminutes", rminutes);

    let finalHourMinSecObject ={
      hours : Math.abs(rhours),
      minutes : Math.abs(rminutes) ,
      seconds : data.second
    };
    return finalHourMinSecObject;

  }




  /**
   * @author kc
   * @date : 27-02-2020;
   * get all White Label Setting
   */
    getAllWhiteLabel(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.whiteLabelSettingService.getAllWhiteLabel(this.whiteLabelFilter)
        .subscribe(response => {
          response = this.gsk(response.auth);
          response = JSON.parse(response);
          if (response.status === true) {

            let whtData = response.data.docs;
            whtData = whtData.map(data =>{
              if(data.isActive === true){
                let x = {
                  appUrl : data.app_url,
                  appDomainName : data.app_domainName,
                  appToken : data.app_token,
                  isActive : data.isActive,
                  isDeleted : data.isDeleted,
                };
                return x;
              }

            });

            resolve({data: whtData});
          } else {
            resolve({data: []});
          }
        }, error => {
          resolve({success: true});
        })
    });
  }


  gsk(auth){
    var firstTF = auth.substring(0, 25);
    firstTF = firstTF.substr(firstTF.length - 20);
    firstTF = this.reverseString(firstTF);
    let lastTF = auth.substring(25);
    let data = aes256.decrypt(firstTF,lastTF);
    return data;
  }

  reverseString(str){
    var splitString = str.split(""); // var splitString = "hello".split("");
    var reverseArray = splitString.reverse();
    var joinArray = reverseArray.join("");
    return joinArray;
  }

}

function returnLocalStorageData(pwd){
  let key = env.constantKey();
    let data =  localStorage.getItem(pwd);
    if(data){
    let decrypt = aes256.decrypt(key, data);
    return decrypt;
    }else {
      return false
    }

}
