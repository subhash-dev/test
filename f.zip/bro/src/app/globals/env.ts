'use strict';
import {isDevMode} from '@angular/core';


// server config
//call json user-service api url
export function server_url() {
  if(isDevMode()) {
    // return 'https://socket.myfancy.ml/api/v1/';
    return 'https://localhost:3030/api/v1/';
  }else {
       return 'http://localhost:2021/api/v1/';
      //  return 'https://socket.titanexch9.com/api/v1/';
  }
}

// server config
//this is for server white-label call (webhook point url)
export function adminServer_url() {
  if(isDevMode()) {
    // return 'https://server.myfancy.ml/api/v1/';
    return 'https://localhost:7878/api/v1/';
  }else {
    return 'http://localhost:2020/api/v1/';
    // return 'https://server.titanexch9.com/api/v1/';
  }
}
/*this is for calling socket api and socket connection call*/
export function socket_url() {
  if(isDevMode()) {
    // return 'https://socket.myfancy.xyz';
    return 'ws://localhost:3030';
  }else {
    // return 'https://socket.titanexch9.com';
    // return 'ws://173.249.31.102:2220'
    //return 'ws://35.176.244.62:2021';
   return 'ws://localhost:2021';
  }
}


export function redisApi_url() {
    return 'https://sslbhav.rdsconn.com';
}

export function site_name() {
  return 'Titan-Exchange9'
}

//webHook Pre-Fix Url
//base url use in service file for calling web-hook api
export function webHookPreFixUrl() {
    return 'https://server.';
   // return 'https://localhost:2021';
  // return 'https://';
}
export function constantKey() {
  return 'bqwOlSSbg9VLtQuMp3mB7OAWQQwrvj6V';
}

//import server ip
export function import_url() {
    return 'https://games555.ml';
}
//production
export function production_for_import() {
    return false;
}

export const OTP_SECONDS = 5;


// project config
export const PROJECT_NAME = 'Titanexch9';
export const PROJECT_LOGO_URL = 'assets/images/digi_logo.png';
export const PROJECT_LOGO_SMALL_URL = 'assets/images/digi_logo.png';

// set static variables
export const STATIC_PROFILE_IMAGE = 'assets/images/defaultprofile.png';

export const validationRules = {
  comapnyNameMax: 100
};

export const serviceHeader = {
  'Content-Type': 'application/json; charset=utf-8',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE',
  'Access-Control-Allow-Headers': '*'
};

