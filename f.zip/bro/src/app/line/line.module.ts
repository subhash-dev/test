import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LineRoutingModule } from './line-routing.module';
import { LineViewComponent } from './line-view/line-view.component';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DemoMaterialModule } from 'src/material-module';
import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { LineComponent } from './line.component';
import {commonDerectivenModule} from '../auth-gaurd/commonDerective.module';

@NgModule({
  declarations: [LineComponent,LineViewComponent],
  imports: [
    CommonModule,
    LineRoutingModule,
    CommonModule,
    commonDerectivenModule,
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    FormsModule,
    ModalModule.forRoot(),
    HttpClientModule,
  ]
})
export class LineModule { }
