import {Component, OnInit, HostListener, ElementRef, ViewChild} from '@angular/core';
import {MarketService} from '../../services/market.service';
import {ActivatedRoute, Router,} from '@angular/router';
import {UtilityService} from '../../globals/utilityService';
import {ModalDirective} from 'ngx-bootstrap';
import {LineService} from '../../services/line.service';
import {UserService} from '../../services/user.service';
import {FancyService} from './../../services/fancy.service';
import {SocketService} from '../../globals/socketService';
import {ToasterConfig} from 'angular2-toaster';
import {CommonService} from './../../services/common.service';
import * as env from '../../globals/env';
import {SocketServiceRedis} from '../../globals/socketServiceRedis';

var aes256 = require('aes256');

@Component({
  selector: 'app-line-view',
  templateUrl: './line-view.component.html',
  styleUrls: ['./line-view.component.scss']
})


export class LineViewComponent implements OnInit {
  @ViewChild('lineConfigure', {static: false}) lineConfigure: ModalDirective;
  @ViewChild('lineSetting', {static: false}) lineSetting: ModalDirective;
  @ViewChild('endGameForm', {static: false}) formResetValue;
  @ViewChild('gameEnd', {static: false}) gameEnd: ModalDirective;


  lineId: any;
  lineMarket: any;
  lineConfgSettings: any;
  ballStatus: any;
  getMarketId: any;
  marketStatusChange: any;
  lineSettingData: any;
  lineConfigureData: any;
  Volume;
  multipler;
  lineMode: any;
  rateInput;
  noSecond;
  yesSecond;
  noSecondVol;
  yesSecondVol;

  noFirst;
  noFirstVol;
  noThird;
  noThirdVol;
  yesFirst;
  yesFirstVol;
  yesThird;
  yesThirdVol;

  no2: any;
  no2Vol: any;
  yes2: any;
  yes2Vol: any;
  preVal;
  preValSec;
  preVol1;
  preVol2;
  fancyRateAry;
  inputVal;
  lastObj = {};
  marketIdDec;
  lastrate_of_line: any;
  lastrate_max: any;
  lastrate_min: any;
  lineRate: number;
  rateRange;
  rateDiffrence;
  endSubmit = false;
  settel:any = 'false';
  endGameObject = {
    result: null,
    password: null
  };

  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right'
  });

  Toast = {
    type: '',
    title: '',
    timeout: 0,
    body: ''
  };


  constructor(private userService: UserService,
              private commonService: CommonService,
              private marketService: MarketService,
              private socketService: SocketService,
              private socketServiceRedis: SocketServiceRedis,
              private utilityService: UtilityService,
              private lineService: LineService,
              private route: ActivatedRoute,
              private fancyService: FancyService,) {
  }

  ngOnInit() {
    this.settel = 'false';
    this.route.params.subscribe(params => {
      this.getMarketId = params['id'];
      this.socketServiceRedis.joinRoom(this.getMarketId);
    })
    this.getmarketByID(this.getMarketId);


    this.socketServiceRedis.oddsRate().subscribe((response) => {
        let marketId = response.marketId;
        let marketIdDec = response.marketId.toString().replace('.', '');
        let runners;
          if(response.numberOfRunners){
            runners = response.numberOfRunners;
          }else{
            runners = response.runners.length;
          }
        for (let i = 0; i < runners; i++) {
          if (this.lineMode == 'Auto') {
            const linerobj = this.lineMarket.find(o => o.marketId == marketId);
            if (linerobj) {
              let lineMultipler = 0;
              if (linerobj.lineSetting) {
                  lineMultipler = linerobj.lineSetting.MultiplierVolume;
              }
              // In live market rate is reverse
              const availableBack = response.runners[i].ex.availableToBack;
              this.noSecond = (availableBack[0]) ? String(Math.round(availableBack[0].price)) : '';
              this.noSecondVol = (availableBack[0]) ? String(Math.round(availableBack[0].size * lineMultipler)) : '';
              const availableLay = response.runners[i].ex.availableToLay;
              this.yesSecond = (availableLay[0]) ? String(Math.round(availableLay[0].price)) : '';
              this.yesSecondVol = (availableLay[0]) ? String(Math.round(availableLay[0].size * lineMultipler)) : '';
            }
          }
        }
      });

  }


  getlineRateLastRecord() {
    if (this.lineMode == 'Manual') {
      this.lineService.getlineRate().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status == true) {
          this.lastrate_of_line = parseInt(response.data.no2);
          this.rateInput = response.data.master_code_id;
          this.noSecond = parseInt(response.data.no2);
          this.noSecondVol = parseInt(response.data.no2Vol);
          this.yesSecond = parseInt(response.data.yes2);
          this.yesSecondVol = parseInt(response.data.yes2Vol);
          this.inputVal = response.data.master_code_id;
        }
      }, error => {
        console.error('error in priority', error);
      })
    }
  }

  getmarketByID(marketId) {
    this.marketService.getMarketBymarketId(marketId).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status == true) {
            this.lineMarket = response.data.docs;
            this.lineSettingData = response.data.docs[0].lineSetting;
            this.lineConfigureData = response.data.docs[0].lineConfigurationSetting;
            this.rateRange = (response.data.docs[0].lineConfigurationSetting) ? response.data.docs[0].lineConfigurationSetting.rateRange : 15;
            this.rateDiffrence = (response.data.docs[0].lineConfigurationSetting) ? response.data.docs[0].lineConfigurationSetting.rateDiffrence : 1;
            this.Volume = response.data.docs[0].lineSetting.volume;
            this.multipler = (response.data.docs[0].lineSetting.MultiplierVolume) ? response.data.docs[0].lineSetting.MultiplierVolume : 0;
            this.lineMode = response.data.docs[0].lineMode;
            if (this.lineMode == null || this.lineMode == '') {
            this.lineMode = 'Auto';
            }else {
            this.ballStatus = this.lineMarket[0].marketStatus.name === 'ballStart' ? 'Ball Start' :  this.lineMarket[0].marketStatus.name === 'Open' ? 'Live' : 'Suspended' ;
            }

            this.getlineRateLastRecord();
        }
    }, error => {
      console.error('error in priority', error);
    })
  }

  actionBtnClick(action) {
    if (action == 'ballstart') {
      this.ballStatus = 'Ball Start';
      this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = '';
    } else if (action == 'suspend') {
      this.ballStatus = 'Suspended';
      // this.noFirst = this.noFirstVol =  this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol =  this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol =  this.yesThird = this.yesThirdVol= "";
    } else {
      this.ballStatus = 'Open';
       this.rateCalculator(this.inputVal);
    }

    let data = {
      marketStatus: this.ballStatus,
      marketId: this.getMarketId
    }

    var obj = {
      marketId: this.getMarketId,
      status: action,
      type: 'line'
    }
    this.socketService.changeStatus(obj);

    this.marketService.getMarketStatusChange(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status == true) {
            this.marketStatusChange = response.data;
            //this.updateWhtLblMarket(data);
        }
    }, error => {
      console.error('error in priority', error);
    })

  }

  /***
   * update in market data in  multiple white label
   * @param data
   */
  updateWhtLblMarket(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      for (let i = 0; i < x.length; i++) {
        this.marketService.updateWhtLblMarket(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error('errro in get white label');
    });
  }

  /*
     Developer: RK
     Date: 23-02/2020
     title: Open end game modal
     Use: This function end game result declare
   */
  openModal() {
    this.formResetValue.resetForm();
    this.endGameObject = {
      result: null,
      password: null
    };
    this.gameEnd.show();
  }


  openLineConfgModal() {
    this.lineConfigure.show();
  }

  closeLineConfgModal() {
    this.lineConfigure.hide();
  }

  openLineSettngModal() {
    this.lineSetting.show();
  }

  closelineSettngModal() {
    this.lineSetting.hide();
  }

  lineConfigureUpdate() {
    this.marketService.lineConfigurationSettingUpdate(this.getMarketId, this.lineConfigureData).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status == true) {
            this.marketStatusChange = response.data;
            this.rateRange = (response.data.lineConfigurationSetting) ? Number(response.data.lineConfigurationSetting.rateRange) : 15;
            this.rateDiffrence = (response.data.lineConfigurationSetting) ? Number(response.data.lineConfigurationSetting.rateDiffrence) : 1;
            // this.updateWhtLblMarket(this.marketStatusChange);
            this.utilityService.popToast('success', 'Success', 3000, 'Line Configure updated successfully.');
            this.closeLineConfgModal();
        }
    }, error => {
      console.error('error in priority', error);
    })
  }


  lineSettingUpdate() {
    this.lineSettingData.MultiplierVolume =  Number(this.lineSettingData.MultiplierVolume);
    this.marketService.lineSettingUpdate(this.getMarketId, this.lineSettingData).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status == true) {
            this.marketStatusChange = response.data;
            this.multipler = (response.data.lineSetting.MultiplierVolume) ? response.data.lineSetting.MultiplierVolume : 100;
            this.updateWhtLblMarket(this.marketStatusChange);
            this.utilityService.popToast('success', 'Success', 3000, 'Line setting updated successfully.');
            this.closelineSettngModal();
        }
    }, error => {
      console.error('error in priority', error);
    })
  }

  VolumeSave() {
    let data = {
      volume: this.Volume
    }
    this.marketService.volumeUpdate(this.getMarketId, data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if (response.status == true) {
        this.getmarketByID(this.getMarketId);
        this.utilityService.popToast('success', 'Success', 3000, 'Volume updated successfully.');
      }
    }, error => {
      console.error('error in priority', error);
    })

  }

  radioChange(event) {
    let data = {
      lineMode: event.target.value
    };
    this.marketService.lineModeUpdate(this.getMarketId, data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if (response.status == true) {
        this.socketService.changeMode(this.getMarketId, response);
        this.getmarketByID(this.getMarketId);

        this.utilityService.getAllWhiteLabel().then(response => {
          let x = response.data;
          /* Hear X is Multiple Whitelable Data*/
          for (let i = 0; i < x.length; i++) {
            this.marketService.lineModeUpdateWebHook(this.getMarketId, data, x[i]).subscribe(checkUserResponse => {
                if (event.target.value == 'Manual') {
                  this.getlineRateLastRecord();
                }
              });
          }


        }).catch(error => {
          console.error('errro in get white label');
        });
      }
    }, error => {
      console.error('error in priority', error);
    })
  }

  /*
   Developer: RK
   Date: 23-02/2020
   title: modal Submit
   Use: This function end game result declare
 */
  addEndGame(marketId) {
    if(this.endSubmit) {
      return;
    }
    this.endSubmit = true;
    let key = env.constantKey();
    let token = this.endGameObject.password;
    var encrypted = aes256.encrypt(key, token);
    let marketObj = {
      market_uniq_id: marketId,
      type: 'line',
      result: this.endGameObject.result,
      token: encrypted
    }
    console.log(marketObj);
    this.fancyService.lineSettledOffice(marketObj).subscribe(checkUserResponse => {
        checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
        checkUserResponse =JSON.parse(checkUserResponse);
        if(checkUserResponse.status == true){
          this.settel = 'true';
          this.closeModal();
          // this.utilityService.getAllWhiteLabel().then(response => {
          //
          //   let x = response.data;
          //   /* Hear X is Multiple Whitelable Data*/
          //   for (let i = 0; i < x.length; i++) {
           //    this.fancyService.fancySettled(marketObj, x[i])
          //       .subscribe(checkUserResponse => {
          //         console.log("-------------------checkUserResponse",checkUserResponse);
          //         this.settel = 'true';
          //         this.closeModal();
          //
          //         this.utilityService.popToast('success', 'Success', 3000, 'Line market Settled.');
          //       });
          //   }
          // }).catch(error => {
          //   console.error('errro in get white label');
          // });
        }else{
          this.closeModal();
          this.settel = 'true';
          this.utilityService.popToast('error','Error', 3000 , "Line already settled.");
        }
      }, error =>{
        this.endSubmit = false;
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });
  }

  /*
       Developer: RK
       Date: 23-02/2020
       title: Open end game modal
       Use: This function end game result declare
     */
  closeModal() {
    this.gameEnd.hide();
  }

  enterRate(event) {
    setTimeout(() => {
      event.target.select();
    }, 100);
    var inputValue = event.target.value;
    if (!inputValue) {
      return false;
    }
    this.rateCalculator(inputValue);
  }


  rateCalculator(inputValue) {

    //duplicate word not allowed and only alphanumeric, plus, minus, dot, star, slash, backslash are allowed
    var numberRegExp = /^[0-9]+$/;
    var restrictRegexp = /^[a-zA-Z0-9\+\-\.\*\/\\]+$/;
    var regexp_plus_minus = /^((\+)|(\-))([a-z0-9.*/\\])?$/;
    var regexp = /^\d{1,}((\+)|(\-)?)([*\\]?)((\+[*\\])|(\-[*\\]))?$/;
    var backSlashReg = /^\d{1,}((\/)|(\,)?)([0-9\\]?)(([0-9\\]))?$/;

    this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = '';

    var minRangeVal = parseInt(this.preVal) - this.rateRange;
    minRangeVal = minRangeVal >= 0 ? minRangeVal : 0;
    var maxRangeVal = parseInt(this.preVal) + this.rateRange;

    if (regexp.test(inputValue) || backSlashReg.test(inputValue)) {
      //Find last character
      var lastChar = inputValue.charAt(inputValue.length - 1);

      if ((inputValue == '0') || inputValue === '+' || inputValue === '-' || (inputValue.trim() == '') || (lastChar == '+') || (lastChar == '-')) {
        console.log('first');
        this.invalidRate();  //Calling invalid function
        return false;
      }
      console.log(regexp_plus_minus.test(inputValue));

      var numVal = parseInt(inputValue.match(/(\d+)/g)); //extract number from string
      var charVal = inputValue.replace(numVal, '');

      if (charVal.split('-').length > 2 || charVal.split('+').length > 2 || ((charVal.charAt(0) == '+' || charVal.charAt(0) == '-') && (charVal.charAt(1) == '-' || charVal.charAt(1) == '+'))) {
        this.invalidRate();  //Calling invalid function
        return false;
      }

      //out of range error msg
      if (this.preVal && (numVal < minRangeVal || numVal > maxRangeVal)) {
        this.invalidRate();  //Calling invalid function
        return false;
      }

      console.log(this.multipler);
      console.log(this.Volume);
      console.log('inputValue', inputValue);

      var charSign = charVal.charAt(0);

      if (charSign == '/') { //Condition for sign is / for e.g. 55/4
        this.noSecond = numVal;
        this.noSecondVol = parseInt(this.Volume) * parseInt(this.multipler);
        this.yesSecond = parseInt(inputValue) + parseInt(lastChar);
        this.yesSecondVol = parseInt(this.Volume) * parseInt(this.multipler);
        this.preVal = numVal;
        this.preValSec = parseInt(inputValue) + parseInt(lastChar);
        this.preVol1 = parseInt(this.Volume) * parseInt(this.multipler);
        this.preVol2 = parseInt(this.Volume) * parseInt(this.multipler);
        this.inputVal = inputValue;
        this.storeFancyRate(inputValue)
      } else {
        //This code is execute when input having number only for e.g 55 OR 75
        this.noSecond = inputValue;
        this.noSecondVol = parseInt(this.Volume) * parseInt(this.multipler);
        this.yesSecond = parseInt(inputValue) + parseInt(this.rateDiffrence);
        this.yesSecondVol = parseInt(this.Volume) * parseInt(this.multipler);
        this.preVal = inputValue;
        this.preValSec = parseInt(inputValue) + parseInt(this.rateDiffrence);
        this.preVol1 = parseInt(this.Volume) * parseInt(this.multipler);
        this.preVol2 = parseInt(this.Volume) * parseInt(this.multipler);
        this.inputVal = inputValue;
        this.storeFancyRate(inputValue)
      }

    } else {
      console.log('thierd');
      this.invalidRate();  //Calling invalid function
      return false;
    }
  }


  invalidRate() {
    this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = '';
    this.rateInput = '';
    this.Toast.title = 'Error';
    this.Toast.type = 'error';
    this.Toast.body = 'Invalid input';
    this.commonService.popToast(this.Toast);
  }


  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    this.ballStatus = 'Ball Start';
    let data = {
      marketStatus: this.ballStatus,
      marketId: this.getMarketId
    }
    var obj = {
      marketId: this.getMarketId,
      status: 'ballstart',
      type: 'line'
    }
    this.socketService.changeStatus(obj);

    this.marketService.getMarketStatusChange(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status == true) {
            this.marketStatusChange = response.data;
            this.updateWhtLblMarket(this.marketStatusChange);
        }
    }, error => {
        console.error('error in priority', error);
    })
  }


  storeFancyRate(masterCode) {
    // console.log("this.fancyId-------------------",this.fancyId);
    this.ballStatus = 'Live';
    let type = 'line';
    let statusValue = this.utilityService.marketStatusArray.filter(obj => obj.name === 'active');
    let apiObj = {
      master_code_id: masterCode,
      id: this.getMarketId,
      no1: this.noFirst,
      no1Vol: this.noFirstVol,
      no2: this.noSecond,
      no2Vol: this.noSecondVol,
      no3: this.noThird,
      no3Vol: this.noThirdVol,
      yes1: this.yesFirst,
      yes1Vol: this.yesFirstVol,
      yes2: this.yesSecond,
      yes2Vol: this.yesSecondVol,
      yes3: this.yesThird,
      yes3Vol: this.yesThirdVol,
      limit: 0,
      statusValue: statusValue
    }
    this.lastObj = apiObj;
    this.socketService.rateBroadcast(this.getMarketId, apiObj, type);

    this.lineService.createlineRate(apiObj).subscribe(resposne => {
      console.log(resposne);
    });
    //this.actionBtnClick('Open');
  }
}
