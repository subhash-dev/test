import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LineViewComponent } from './line-view/line-view.component';
import { AuthGuard } from '../auth-gaurd/auth-guard.service';
import { RoleGuard } from '../auth-gaurd/role-guard.service';
import { LineComponent } from './line.component';

const routes: Routes = [{
  path: 'line',
  canActivate: [AuthGuard, RoleGuard],
  component: LineComponent,
  children: [
    {
      path: 'view/:id',
      canActivate: [AuthGuard, RoleGuard],
      component: LineViewComponent,
    },

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LineRoutingModule { }
