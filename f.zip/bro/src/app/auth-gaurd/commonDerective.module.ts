// Modules
import {NgModule} from '@angular/core';
import {OnlynumberDirective} from './onlyNumber';
import {EllipsisPipe} from './ellipsis.pipe';
import {DisableRightClickDirective} from './right -click';
import {OnlyCharDirective} from "./onlyCharacter";
import {OnlyDigitDirective} from "./onlyDigit";
import {OnlyNumCharDirective} from "./NumAndChar";
import {AutofocusDirective} from "./autofocus.directive";
@NgModule({
  declarations:[
    OnlynumberDirective,
    EllipsisPipe,
    DisableRightClickDirective,
    OnlyCharDirective,
    OnlyDigitDirective,
    OnlyNumCharDirective,
    AutofocusDirective
  ],
  exports:[
    OnlynumberDirective,
    EllipsisPipe,
    DisableRightClickDirective,
    OnlyCharDirective,
    OnlyDigitDirective,
    OnlyNumCharDirective,
    AutofocusDirective
  ]
})
export class commonDerectivenModule{}
