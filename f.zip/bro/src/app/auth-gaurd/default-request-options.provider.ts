import {Injectable} from '@angular/core';
import {isUndefined} from "util";
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {Observable} from "rxjs/index";
import {Router} from '@angular/router';
import {tap} from 'rxjs/internal/operators';
import {UtilityService} from '../globals/utilityService';

@Injectable()
export class DefaultRequestOptions implements HttpInterceptor {
  constructor(private router: Router, private utilityService: UtilityService) {}
  intercept(options: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if(options.url && options.url.startsWith("https://maps.googleapis.com/")){
      return next.handle(options);
    }
   /* if(options.url && options.url.startsWith("http://pam555.ml")){
      options.headers.set('Authorization', '');
      const clone = options.clone({ setHeaders: {'Authorization': '' } });
      return next.handle(clone);
    }
*/

    // if(options.url && options.url.startsWith("http://game555.ml")){
    if(options.url && options.url.startsWith("https://games555.ml")){
      return next.handle(options);
    }

    if (options && options.headers) {
      if(options.headers.get('Content-Type') !== null){
        return next.handle(options);
      }
      if(options.headers.get('Content-Type') === ''){
        options.headers.set('Content-Type', 'application/json');
      }
      if(!isUndefined(localStorage.getItem('token')) && localStorage.getItem('token') !== null){

        options.headers.set('Authorization', localStorage.getItem('token'));
        const clone = options.clone({ setHeaders: { 'Authorization': `${localStorage.getItem('token')}` } });
        return next.handle(clone).pipe( tap(() => {},
          (err: any) => {
            if (err instanceof HttpErrorResponse) {
              if (err.status !== 401) {
                return;
              }else{
                this.router.navigate(['/login']);
              }
            }
          }));
      }

    } else {
      if(!isUndefined(localStorage.getItem('token')) && localStorage.getItem('token') !== null){
          console.log('hello');
        options.headers.set('Authorization', localStorage.getItem('token'));
        const clone = options.clone({ setHeaders: { 'Authorization': `${localStorage.getItem('token')}` } });
        return next.handle(clone);
      }
    }

    return next.handle(options);
  }
}
