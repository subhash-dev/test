import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap";
import {DataTableDirective} from "angular-datatables";
import {Subject} from "rxjs";
import * as env from "../../globals/env";
import {ToasterConfig} from "angular2-toaster";
import {UtilityService} from "../../globals/utilityService";
import {Router} from "@angular/router";
import {BinaryService} from "../../services/binary.service";
import {UserService} from "../../services/user.service";
import {NgxSpinnerService} from "ngx-spinner";
import {HttpClient} from "@angular/common/http";
import {isUndefined} from "util";
declare let $: any;
declare let _: any;

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
@Component({
  selector: 'app-script-qty-setting',
  templateUrl: './script-qty-setting.component.html',
  styleUrls: ['./script-qty-setting.component.scss']
})
export class ScriptQtySettingComponent implements OnInit {

  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild("addExchange", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild(DataTableDirective, {static: false})
    // @ViewChild("focus") nameField: ElementRef;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  exchange: any;
  resData;
  server_url: any = env.server_url();



  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  tempSportObj: any;
  conformationPassword: any;
  moduleList = [];
  scriptName = [];
  getAllExchng: any;
  checkBoxValue:any;
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private binaryService: BinaryService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private http: HttpClient) {
  }
  dataTable: any;
  addExchangeObject = {
    _id: null,
    exchangeName: null,
    name: null,
    lotSize: null,
    quantityMax: null,
    lotsizeMax: null,
    quantityBreakup: null,
    lotsizeBreakup: null,
    updatedAt: null
  };
  filter = {
    page: 1,
    limit: 300,
    search: null
  };
  selectedValue = "MCX";
  exchangeType = "";
  qtyMax: any;
  breakupQty: any;
  lotMax: any;
  breakupLot: any;
  startRange: any;
  endRange: any;

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.passwordFormReset.resetForm();
      this.sportsValue.resetForm();
      this.rerender();
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    //this.getSport();
    this.getAllExcahnge();
    this.newDatatable();
  }


  openModal(item) {
    this.addExchangeObject = {
      _id: null,
      exchangeName: null,
      name: null,
      lotSize: null,
      quantityMax: null,
      lotsizeMax: null,
      quantityBreakup: null,
      lotsizeBreakup: null,
      updatedAt: null
    };
    this.modal.show();
  }

  closeModel(data) {
    if(data === 'addModel'){
      this.sportsValue.resetForm();
      this.modal.hide();
    }else{
      this.conformationModal.hide();
      this.rerender();
    }

  }

  getAllExcahnge(){
    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": "",
        "regex": false
      }
    };
    this.binaryService.getAllExcahnge(data).subscribe(response => {
      this.getAllExchng = response.data.docs;
      this.selectedValue = this.getAllExchng[0].exchangeName;
      this.exchangeType = this.getAllExchng[0].exchangeName;
      this.newDatatable();
    }, error => {
      console.error('error in get users settings');
    });
  }

  newDatatable(){
    this.spinner.show();
    const that = this;
    this.rerender();
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[1, 'asc']],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },

      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'binary/getallscriptqtysetting/' + this.selectedValue;
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters,{parameterType:this.selectedValue}),
            {}
          ).subscribe(resp => {
          this.spinner.hide();
          this.resData = resp.data;

          if(this.resData !== "" && this.resData.docs.length > 0){
            this.exchange = this.resData.docs;

          }else {
            this.resData = {
              total:0,
              page:0,
              pages:0
            }
          }
          this.dtTrigger.next();
          callback({
            recordsTotal: this.resData.total,
            recordsFiltered: this.resData.total,
            data: []
          });
        });
      },

      columns: [ { data: '' },{ data: 'name' }, { data: 'lotSize' }, { data: 'quantityMax' }, { data: 'lotsizeMax' }, { data: 'quantityBreakup' },{ data: 'lotsizeBreakup' }, { data: 'updatedAt' }],
      columnDefs: [ { orderable: false, targets: [0] } ]
    };
  }


  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }




  updateUserStatus(){
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal.hide();
        if(checkUserResponse.status === true){
          this.binaryService.updateExchange(this.tempSportObj)
            .subscribe(response =>{
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'Lot size updated successfully.');
            }, error =>{

            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }

      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });

  }

  /**
   * @author TR
   * @date : 18-05-2020
   * Create Exchange
   * @method: POST
   */

  deleteLotSize() {
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal.hide();
        if(checkUserResponse.status === true){
          this.binaryService.deleteLotSize(this.tempSportObj)
            .subscribe(response =>{
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'LotSize deleted successfully.');
            }, error =>{

            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }
      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });
  }


  selectAllAccess(e) {
    if (e.target.checked === true) {

      this.moduleList = [];
      this.scriptName = [];
      this.exchange = this.exchange.map(mDats =>{
        this.moduleList.push(mDats._id);
        this.scriptName.push(mDats.name);
        mDats.checkBoxValue = true;
        return mDats;
      })
      // return data;
    } else {
      this.exchange = this.exchange.map(mDats =>{

        mDats.checkBoxValue = false;
        return mDats;
      });
      this.moduleList = [];
      this.scriptName = [];
      // return data;
    }
  }

  /**
   * check module insert or not in array list
   */

  check(e, data) {
    if (e.target.checked === true) {
      this.exchange = this.exchange.map(mDats =>{

        if(mDats._id === data._id){

          this.moduleList.push(data._id);
          this.scriptName.push(data.name);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data._id);
      let arr3 = _.without(this.scriptName, data.name);

      this.moduleList = arr2;
      this.scriptName = arr3;
      this.exchange = this.exchange.filter(mDats =>{

        if(mDats._id === data._id){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }
  onSelectionChange(e){
    this.selectedValue = e;
    this.newDatatable();
  }


  /**
   * check module insert or not in array list
   */

  filterApply(){
    this.exchange = this.exchange.map(data => {
      if(_.includes(this.moduleList, data._id)){

        // if(!isUndefined(this.lotSizes) && this.lotSizes !== "" ) {
        //
        //   if(data.lotsizeMin < Number(this.lotSizes)){
        //     data.lotsizeMin = Number(this.lotSizes);
        //   }
        //
        // }

        if(!isUndefined(this.qtyMax) && this.qtyMax !== "" ) {
          data.lotsizeResponse.quantityMax = Number(this.qtyMax);
        }

        if(!isUndefined(this.breakupQty) && this.breakupQty !== "" ) {
          data.lotsizeResponse.quantityBreakup = Number(this.breakupQty);
        }

        if(!isUndefined(this.lotMax) && this.lotMax !== "" ) {
          data.lotsizeResponse.lotsizeMax = Number(this.lotMax);
        }

        if(!isUndefined(this.breakupLot) && this.breakupLot !== "" ) {
          data.lotsizeResponse.lotsizeBreakup = Number(this.breakupLot);
        }

      }else {
        if((data.lotSize >= Number(this.startRange)) && (data.lotSize <= Number(this.endRange))){
          this.moduleList.push(data._id);
          this.scriptName.push(data.name);
          data.checkBoxValue = true;

        if(!isUndefined(this.qtyMax) && this.qtyMax !== "" ) {
          data.lotsizeResponse.quantityMax = Number(this.qtyMax);
        }

        if(!isUndefined(this.breakupQty) && this.breakupQty !== "" ) {
          data.lotsizeResponse.quantityBreakup = Number(this.breakupQty);
        }

        if(!isUndefined(this.lotMax) && this.lotMax !== "" ) {
          data.lotsizeResponse.lotsizeMax = Number(this.lotMax);
        }

        if(!isUndefined(this.breakupLot) && this.breakupLot !== "" ) {
          data.lotsizeResponse.lotsizeBreakup = Number(this.breakupLot);
        }
        }
      }
      return data;
    });
    if(this.moduleList.length === 0){
      this.utilityService.popToast('error','Error', 3000 , 'Please select any one');
    }
  }


  /**
   * @author TR
   * @date : 22-05-2020
   * Update All Multiple
   */
  updateAllData() {
    this.spinner.show();
    let dataUpdateAll = {
      name: this.scriptName.toString(),
      quantityMax: Number(this.qtyMax),
      quantityBreakup: Number(this.breakupQty),
      // lotSize: Number(this.lotSize),
      lotsizeMax: Number(this.lotMax),
      lotsizeBreakup: Number(this.breakupLot)
    };
    this.qtyMax = '';
    this.breakupQty = '';
    this.startRange = '';
    this.endRange = '';
    this.lotMax = '';
    this.breakupLot = '';
    this.binaryService.updateAllQty(dataUpdateAll).subscribe(resposne => {
      if(resposne.status === true){
        dataUpdateAll['name'] = this.scriptName.toString()
         this.updateAllDataWhtLbl(dataUpdateAll);
        this.moduleList = [];
        this.scriptName = [];
        this.newDatatable();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'LotSize all update multiple successfully.');
      }else{
        this.spinner.hide();
        this.newDatatable();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.newDatatable();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /**
   * @author TR
   * @date : 22-05-2020
   * Update Multiple
   */
  updateMultiple() {
    this.spinner.show();
    let dataUpdateAll = {
      name: this.scriptName.toString(),
      quantityMax: Number(this.qtyMax),
      quantityBreakup: Number(this.breakupQty),
      lotsizeMax: Number(this.lotMax),
      lotsizeBreakup: Number(this.breakupLot)
    };
    this.qtyMax = '';
    this.breakupQty = '';
    this.startRange = '';
    this.endRange = '';
    this.lotMax = '';
    this.breakupLot = '';
    this.binaryService.updateQtyAll(dataUpdateAll).subscribe(resposne => {
      if(resposne.status === true){
        dataUpdateAll['name'] = this.scriptName.toString()
         this.updateMultipleWhtLbl(dataUpdateAll);
        this.moduleList = [];
        this.newDatatable();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'LotSize update multiple successfully.');
      }else{
        this.spinner.hide();
        this.newDatatable();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.newDatatable();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * updateScript for Whitelable
   * @method: POST
   */

  updateAllDataWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateAllQtywht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * updateScript for Whitelable
   * @method: POST
   */

  updateMultipleWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateQtyAllwht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }
}
