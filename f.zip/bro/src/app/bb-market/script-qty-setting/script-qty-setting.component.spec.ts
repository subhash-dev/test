import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScriptQtySettingComponent } from './script-qty-setting.component';

describe('ScriptQtySettingComponent', () => {
  let component: ScriptQtySettingComponent;
  let fixture: ComponentFixture<ScriptQtySettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScriptQtySettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScriptQtySettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
