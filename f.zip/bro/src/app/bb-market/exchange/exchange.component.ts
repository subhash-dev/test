import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild,ElementRef} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap";
import {DataTableDirective} from "angular-datatables";
import {Subject} from "rxjs";
import * as env from "../../globals/env";
import {ToasterConfig} from "angular2-toaster";
import {UtilityService} from "../../globals/utilityService";
import {Router} from "@angular/router";
import {NgxSpinnerService} from "ngx-spinner";
import {HttpClient} from "@angular/common/http";
import {isUndefined} from "util";
import {BinaryService} from "../../services/binary.service";
import {UserService} from "../../services/user.service";

declare let $: any;


class Exchange {
  _id: number;
  exchangeName: string;
  tradeAttribute: string;
  brokerAgeType: string;
  brokerAgeAmount: string;
  highlowTradeLimit: string;
  oddLimitRate: string;
  autoLotSize: string;
  isActive: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
@Component({
  selector: 'app-exchange',
  templateUrl: './exchange.component.html',
  styleUrls: ['./exchange.component.scss']
})
export class ExchangeComponent implements OnInit {

  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild('conformationModal1', {static: false}) conformationModal1: ModalDirective;
  @ViewChild('modalTime', {static: false}) modalTime: ModalDirective;
  @ViewChild("addExchange", {static: false}) addExchangeReset;
  @ViewChild("addHoliday", {static: false}) addHolidayReset;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild(DataTableDirective, {static: false})
  @ViewChild('focusInput' ,  {static: false}) focusInput: ElementRef;
  @ViewChild('focusText' ,  {static: false}) focusText: ElementRef;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  exchange: Exchange[];
  resData;
  server_url: any = env.server_url();



  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  tempSportObj: any;
  conformationPassword: any;

  constructor(
              private utilityService: UtilityService,
              private router: Router,
              private binaryService: BinaryService,
              private userService: UserService,
              private chRef: ChangeDetectorRef,
              private spinner: NgxSpinnerService,
              private http: HttpClient) {
  }
  dataTable: any;
  minPickerDate: any;
  minPickerDate1: any;
  minTime: any;
  addExchangeObject = {
    _id: null,
    exchangeName: null,
    tradeAttribute: null,
    brokerAgeType: null,
    brokerAgeAmount: null,
    highlowTradeLimit: false,
    oddLimitRate: false,
    autoLotSize: false,
    isActive: false
  };
  addHolidayObj = {
    exchange: null,
    startDate: null,
    endDate: null,
    startTime1: null,
    endTime1: null,
    startTime2: null,
    endTime2: null,
    isHoliday: false
  };
  edit = false;
  add = false;
  filter = {
    page: 1,
    limit: 300,
    search: null
  };

  /**
   * @author TR
   * @date : 15-05-2020
   * keychange  to call hostListener function Like, Escape button
   */

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.passwordFormReset.resetForm();
      this.addExchangeReset.resetForm();
      this.rerender();
    }
  }
  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if(event.sourceCapabilities) {

    }else {
      this.setFocusToInput();
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    this.newDatatable();

    this.minPickerDate = {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate()
    };


  }

  setDateTest(e){
    console.log(this.addHolidayObj.startDate.day);
    console.log(new Date().getDate());
    this.minPickerDate1 = {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: this.addHolidayObj.startDate.day
    };
  }
  setFocusToInput() {
    this.focusInput.nativeElement.focus();
    this.focusText.nativeElement.focus();
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Open Modal Operation
   */

  openModal(data , item) {
    if(data === 'edit'){
      this.add = false;
      this.edit = true;
      this.addExchangeObject = {
        _id: item._id,
        exchangeName: item.exchangeName,
        tradeAttribute: item.tradeAttribute,
        highlowTradeLimit: item.highlowTradeLimit,
        brokerAgeAmount: item.brokerAgeAmount,
        brokerAgeType: item.brokerAgeType,
        oddLimitRate: item.oddLimitRate,
        autoLotSize: item.autoLotSize,
        isActive: item.isActive
      };
    }else{
      this.add = true;
      this.edit = false;
      this.addExchangeReset.resetForm();
      this.addExchangeObject = {
        _id: null,
        exchangeName: null,
        tradeAttribute: 'FULLY',
        brokerAgeType: 'TURNOVER',
        brokerAgeAmount: null,
        highlowTradeLimit: false,
        oddLimitRate: false,
        autoLotSize: false,
        isActive: false
      };
    }

    this.modal.show();
  }

  /**
   * @author TR
   * @date : 24-06-2020
   * Open Time Modal Operation
   */

    openTimeModal(data , item){
    if(data === 'editHoliday'){
      this.add = false;
      this.edit = true;
      this.addHolidayObj = {
        exchange: item.exchangeName,
        startDate: null,
        endDate: null,
        startTime1: null,
        endTime1: null,
        startTime2: null,
        endTime2: null,
        isHoliday: false
      };
    }else{
      this.add = true;
      this.edit = false;
      this.addHolidayReset.resetForm();
      this.addHolidayObj = {
        exchange: this.exchange[0].exchangeName,
        startDate: null,
        endDate: null,
        startTime1: null,
        endTime1: null,
        startTime2: null,
        endTime2: null,
        isHoliday: false
      };
    }
      this.modalTime.show();
    }

  openCalender(item){
    this.router.navigate([ 'bbmarket/holiday-list' , { exchange: item.exchangeName } ])
  }

   /**
   * @author TR
   * @date : 15-05-2020
   * Close Modal Operation
   */

  closeModel(data) {
     if (data === 'exchangeModel') {
       this.addExchangeReset.resetForm();
       this.modal.hide();
     } else {
       this.conformationModal.hide();
       this.conformationModal1.hide();
       this.rerender();
     }
   }

     /**
   * @author TR
   * @date : 15-05-2020
   * Close Modal Operation
   */

  closeTimeModel() {
      this.addHolidayReset.resetForm();
      this.modalTime.hide();

  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Get Cxhange function for data table
   * @param : _id
   * @method : POST
   */

  newDatatable(){
       this.spinner.show();
      const that = this;
      let url = this.server_url + 'binary/getallexchange';

      this.dtOptions = {
        pagingType: 'full_numbers',
        pageLength: 50,   // -- trying to set to 5 records only
        paging: true,
        serverSide: true,
        // autoWidth: true,
        // scrollX: true,
        // scrollCollapse:true,
        processing: true,
        responsive: true,
        lengthChange: true,
        order: [[1, 'asc']],
        lengthMenu: [5, 10, 25, 50, 75, 100,200],
        language: {
          lengthMenu: '_MENU_',
          zeroRecords:    '',
          emptyTable:     'No record found',
          paginate: {
            first: 'First', last: 'Last',
            next: '<i class="fa fa-chevron-circle-right">',
            previous: '<i class="fa fa-chevron-circle-left">'
          }
        },

        ajax: (dataTablesParameters: any, callback) => {
          that.http
            .post<DataTablesResponse>(
              url,
              dataTablesParameters,
              {}
            ).subscribe(resp => {
            this.spinner.hide();
            this.resData = resp.data;

            if(this.resData !== "" && this.resData.docs.length > 0){
              this.exchange = this.resData.docs;
            }else {
              this.resData = {
                total:0,
                page:0,
                pages:0
              }
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
        },

        columns: [ { data: '' },{ data: 'exchangeName' }, { data: 'tradeAttribute' },{ data: 'brokerAgeType' }, { data: 'brokerAgeAmount' }, { data: 'highlowTradeLimit' }, { data: 'oddLimitRate' }, { data: 'isActive' }, { data: 'updatedAt' }, { data: 'Action' }],
        columnDefs: [{ orderable: false, targets: [0], searchable: true }]
      };
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * This is refresh Datatable function
   */

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }





  /**
   * @author TR
   * @date : 15-05-2020
   * Create Exchange
   * @method: POST
   */

  createExchange() {
     this.spinner.show();
    this.addExchangeObject.exchangeName = this.addExchangeObject.exchangeName.toUpperCase();
    this.binaryService.addNewExchange(this.addExchangeObject).subscribe(resposne => {
      this.modal.hide();
      if(resposne.status === true){
        this.rerender();
        delete this.addExchangeObject._id;
        this.addNewExchangeWhtLbl(this.addExchangeObject);
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Exchange created successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /**
   * @author TR
   * @date : 24-06-2020
   * Create Holiday
   * @method: POST
   */

  createHoliday() {
     this.spinner.show();
    this.addHolidayObj.exchange = this.addHolidayObj.exchange.toUpperCase();
     if(this.addHolidayObj.startTime1 !== null){
    this.addHolidayObj.startTime1 = (this.addHolidayObj.endDate.year + '-' + this.addHolidayObj.endDate.month + '-' + this.addHolidayObj.endDate.day + ' ' + this.addHolidayObj.startTime1.hour + ':' + this.addHolidayObj.startTime1.minute + ':' + this.addHolidayObj.startTime1.second +'.000Z');
     }else {
       delete this.addHolidayObj.startTime1;
     }
    if(this.addHolidayObj.startTime2 !== null) {
      this.addHolidayObj.startTime2 = (this.addHolidayObj.endDate.year + '-' + this.addHolidayObj.endDate.month + '-' + this.addHolidayObj.endDate.day + ' ' + this.addHolidayObj.startTime2.hour + ':' + this.addHolidayObj.startTime2.minute + ':' + this.addHolidayObj.startTime2.second + '.000Z');
    }else {
       delete this.addHolidayObj.startTime2;
    }
      if(this.addHolidayObj.endTime1 !== null) {
        this.addHolidayObj.endTime1 = (this.addHolidayObj.endDate.year + '-' + this.addHolidayObj.endDate.month + '-' + this.addHolidayObj.endDate.day + ' ' + this.addHolidayObj.endTime1.hour + ':' + this.addHolidayObj.endTime1.minute + ':' + this.addHolidayObj.endTime1.second + '.000Z');
      }else {
        delete this.addHolidayObj.endTime1;
      }
        if(this.addHolidayObj.endTime2 !== null) {
          this.addHolidayObj.endTime2 = (this.addHolidayObj.endDate.year + '-' + this.addHolidayObj.endDate.month + '-' + this.addHolidayObj.endDate.day + ' ' + this.addHolidayObj.endTime2.hour + ':' + this.addHolidayObj.endTime2.minute + ':' + this.addHolidayObj.endTime2.second + '.000Z');
        }else {
          delete this.addHolidayObj.endTime2;
        }
    this.addHolidayObj.startDate = (this.addHolidayObj.startDate.year + '-' + this.addHolidayObj.startDate.month + '-' + this.addHolidayObj.startDate.day + ' ' + '00' + ':' + '00' + ':' + '01' +'.000Z');
    this.addHolidayObj.endDate = (this.addHolidayObj.endDate.year + '-' + this.addHolidayObj.endDate.month + '-' + this.addHolidayObj.endDate.day + ' ' + '23' + ':' + '59' + ':' + '59' +'.000Z');
    console.log(this.addHolidayObj);
    this.binaryService.addNewHoliday(this.addHolidayObj).subscribe(resposne => {
      this.modalTime.hide();
      if(resposne.status === true){
        this.rerender();
         this.createHolidayWhtLbl(this.addHolidayObj);
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Holiday created successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }


  /**
   * @author TR
   * @date : 15-05-2020
   * Update Exchange and after Check User Function
   * @method: PUT and POST
   */

  updateUserStatus(){
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal.hide();
        if(checkUserResponse.status === true){
          let data = {
            exchangeName: this.tempSportObj.exchangeName,
            isActive: this.tempSportObj.isActive,
            _id: this.tempSportObj._id,
            highlowTradeLimit: this.tempSportObj.highlowTradeLimit,
            oddLimitRate: this.tempSportObj.oddLimitRate
          };
          this.binaryService.updateExchange(data)
            .subscribe(response =>{
              delete data._id
               this.updateExchangeWhtLbl(data)
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'Exchange updated successfully.');
            }, error =>{

            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }

      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });

  }

  /**
   * @author TR
   * @date : 15-05-2020
   * parameter change function on listing to update value
   */

  onchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal.show();


  }

  /**
   * @author TR
   * @date : 18-05-2020
   * parameter change function on listing to update value
   */

  onSelectionChange(object){
    // this.tempSportObj = object;
    // this.passwordFormReset.resetForm();
    // this.conformationModal1.show();


  }

  /**
   * @author TR
   * @date : 18-05-2020
   * parameter change function on listing to update value
   */

  onDeleteExchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal1.show();


  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Update Exchange  Function
   * @method: PUT
   */

  updateExchange(){
    this.spinner.show();
    this.addExchangeObject.brokerAgeAmount = Number(this.addExchangeObject.brokerAgeAmount);
    this.binaryService.updateExchange(this.addExchangeObject)
      .subscribe(response =>{
        delete this.addExchangeObject._id;
         this.updateExchangeWhtLbl(this.addExchangeObject);
        this.modal.hide();
        this.rerender();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Exchange updated successfully.');
      }, error =>{

      })
  }

  /**
   * @author TR
   * @date : 18-05-2020
   * Create Exchange
   * @method: POST
   */

  deleteExchange() {
     this.spinner.show();
    this.binaryService.deleteExchange(this.tempSportObj).subscribe(resposne => {
      this.modal.hide();
      if(resposne.status === true){
        this.rerender();
        // this.deleteExchangeWhtLbl(this.tempSportObj);
        this.spinner.hide();
        this.conformationModal1.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Exchange created successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * Create Exchange for Whitelable
   * @method: POST
   */

  addNewExchangeWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.addNewExchangewht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * Create Holiday Whtlable
   * @method: POST
   */
  createHolidayWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.addNewHolidaywht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * Upodate Exchange Whtlable
   * @method: POST
   */
  updateExchangeWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateExchangewht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * Delete Exchange Whtlable
   * @method: POST
   */
  deleteExchangeWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.deleteExchangewht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

}
