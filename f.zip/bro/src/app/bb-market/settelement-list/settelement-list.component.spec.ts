import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SettelementListComponent } from './settelement-list.component';

describe('SettelementListComponent', () => {
  let component: SettelementListComponent;
  let fixture: ComponentFixture<SettelementListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SettelementListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SettelementListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
