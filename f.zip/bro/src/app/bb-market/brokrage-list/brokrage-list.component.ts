import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {Subject} from "rxjs/index";
import {Router} from "@angular/router";
import {DataTableDirective} from "angular-datatables";
import {UserService} from "../../services/user.service";
import {ModalDirective} from "ngx-bootstrap";
import {NgxSpinnerService} from "ngx-spinner";
import {HttpClient} from "@angular/common/http";
import * as env from "../../globals/env";
import {UtilityService} from "../../globals/utilityService";
import {isUndefined} from "util";
import {ToasterConfig} from "angular2-toaster";
import {BinaryService} from "../../services/binary.service";
declare let $: any;
declare let _: any;

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
@Component({
  selector: 'app-brokrage-list',
  templateUrl: './brokrage-list.component.html',
  styleUrls: ['./brokrage-list.component.scss']
})
export class BrokrageListComponent implements OnInit {

  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild('conformationModal1', {static: false}) conformationModal1: ModalDirective;
  @ViewChild("addExchange", {static: false}) addExchangeReset;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild("brokerageForm", {static: false}) brokerageForm;
  @ViewChild(DataTableDirective, {static: false})
    // @ViewChild("focus") nameField: ElementRef;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  exchange: any;
  resData;
  server_url: any = env.server_url();



  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  brokerageAmounts: any;
  brokerageTypes: any;
  tempSportObj: any;
  instrumentName: any;
  conformationPassword: any;

  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private binaryService: BinaryService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private http: HttpClient) {
  }
  dataTable: any;
  addExchangeObject = {
    id: null,
    exchangeName: null,
    name: null,
    brokerAgeType: null,
    brokerAgeAmount: null,
    tradeMargin: null
  };
  edit = false;
  add = false;
  filter = {
    page: 1,
    limit: 300,
    search: null
  };
  exchangeType = 'MCX';
  selectedValue = 'MCX';
  getAllExchng : any;
  selectedBrokerageTypes = 'TURNOVER';
  moduleList = [];
  checkBoxValue:any;
  /**
   * @author TR
   * @date : 15-05-2020
   * keychange  to call hostListener function Like, Escape button
   */

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.passwordFormReset.resetForm();
      this.addExchangeReset.resetForm();
      this.brokerageForm.resetForm();
      this.rerender();
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    this.getAllExcahnge();
    this.newDatatable();

  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Open Modal Operation
   */

  openModal(data , item) {
    if(data === 'edit'){
      console.log(item);
      this.add = false;
      this.edit = true;
      this.addExchangeObject = {
        id: item._id,
        exchangeName: item.exchangeName,
        name: item.name,
        brokerAgeType: item.brokerageresponse.brokerAgeType,
        brokerAgeAmount: item.brokerageresponse.brokerAgeAmount,
        tradeMargin: item.tradeMargin
      };
    }else{
      this.add = true;
      this.edit = false;
      this.addExchangeReset.resetForm();
      this.addExchangeObject = {
        id: null,
        exchangeName: null,
        name: null,
        brokerAgeType: null,
        brokerAgeAmount: null,
        tradeMargin: null
      };
    }

    this.modal.show();
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Close Modal Operation
   */

  closeModel(data) {
    if(data === 'exchangeModel'){
      this.addExchangeReset.resetForm();
      this.modal.hide();
    }else{
      this.conformationModal.hide();
      this.conformationModal1.hide();
      this.rerender();
    }

  }

  getAllExcahnge(){
    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": "",
        "regex": false
      }
    };
    this.binaryService.getAllExcahnge(data).subscribe(response => {
      this.getAllExchng = response.data.docs;
      this.selectedValue = this.getAllExchng[0].exchangeName;
      this.exchangeType = this.getAllExchng[0].exchangeName;
      this.newDatatable();
      this.spinner.hide();
    }, error => {
      console.error('error in get users settings');
    });
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Get Cxhange function for data table
   * @param : _id
   * @method : POST
   */

  newDatatable(){
    this.spinner.show();
    const that = this;
    this.rerender();
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[1, 'asc']],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },

      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'binary/getallbrokeragesetting/' + this.selectedValue;
        that.http
          .post<DataTablesResponse>(
            url,
            dataTablesParameters,
            {}
          ).subscribe(resp => {
          this.spinner.hide();
          this.resData = resp.data;

          if(this.resData !== "" && this.resData.docs.length > 0){
            this.exchange = this.resData.docs;
          }else {
            this.resData = {
              total:0,
              page:0,
              pages:0
            }
          }
          this.dtTrigger.next();
          callback({
            recordsTotal: this.resData.total,
            recordsFiltered: this.resData.total,
            data: []
          });
        });
      },

      columns: [ { data: '' },{ data: 'exchangeName' },{ data: 'name' },  { data: 'lotSize' }, { data: 'brokerAgeType' }, { data: 'brokerAgeAmount' }, { data: 'updatedAt' }, { data: '' }],
      columnDefs: [ { orderable: false, targets: [0] } ]
    };
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * This is refresh Datatable function
   */

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  /**
   * @author TR
   * @date : 15-05-2020
   * Create Exchange
   * @method: POST
   */

  createExchange() {
    this.spinner.show();
    this.addExchangeObject.exchangeName = this.addExchangeObject.exchangeName.toUpperCase();
    this.binaryService.addNewExchange(this.addExchangeObject).subscribe(resposne => {
      this.modal.hide();
      if(resposne.status === true){
        this.rerender();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Exchange created successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Update Exchange and after Check User Function
   * @method: PUT and POST
   */

  updateUserStatus(){
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal.hide();
        if(checkUserResponse.status === true){
          this.binaryService.updateExchange(this.tempSportObj)
            .subscribe(response =>{
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'Exchange updated successfully.');
            }, error =>{

            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }

      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });

  }

  selectAllAccess(e) {
    if (e.target.checked === true) {

      this.moduleList = [];
      this.exchange = this.exchange.map(mDats =>{
        this.moduleList.push(mDats.name);
        mDats.checkBoxValue = true;
        return mDats;
      })
      // return data;
    } else {
      this.exchange = this.exchange.map(mDats =>{

        mDats.checkBoxValue = false;
        return mDats;
      });
      this.moduleList = [];
      // return data;
    }
  }

  /**
   * check module insert or not in array list
   */

  check(e, data) {
    if (e.target.checked === true) {
      this.exchange = this.exchange.map(mDats =>{

        if(mDats.name === data.name){

          this.moduleList.push(data.name);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data.name);

      this.moduleList = arr2;
      this.exchange = this.exchange.filter(mDats =>{

        if(mDats.name === data.name){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * parameter change function on listing to update value
   */

  onchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal.show();


  }

  /**
   * @author TR
   * @date : 18-05-2020
   * parameter change function on listing to update value
   */

  onDeleteExchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal1.show();


  }
  onSelectionChange(e){
    this.selectedValue = e;
    console.log(this.selectedValue)
    this.newDatatable();
  }

  onChangeTrade(e){
    this.selectedBrokerageTypes = e;
  }

  /**
   * check module insert or not in array list
   */

  filterApply(){
    this.exchange = this.exchange.map(data => {
      if(_.includes(this.moduleList, data.name)){

        if(!isUndefined(this.brokerageAmounts) && this.brokerageAmounts !== "" ) {
          data.brokerageresponse.brokerAgeAmount = Number(this.brokerageAmounts);
        }

        if(!isUndefined(this.brokerageTypes) && this.brokerageTypes !== ""){
          data.brokerageresponse.brokerAgeType = this.brokerageTypes;
        }
      }
      return data;
    });
    if(this.moduleList.length === 0){
      this.utilityService.popToast('error','Error', 3000 , 'Please select any one');
    }
  }

  /**
   * @author TR
   * @date : 15-05-2020
   * Update Brokerage  Function
   * @method: PUT
   */

  updateBrokerage(){
    this.spinner.show();
    this.addExchangeObject.brokerAgeAmount = Number(this.addExchangeObject.brokerAgeAmount);
    this.instrumentName = this.addExchangeObject.name;
    delete this.addExchangeObject.tradeMargin;
    this.binaryService.updateBrokerage(this.addExchangeObject)
      .subscribe(response =>{
        delete this.addExchangeObject.id;
        this.addExchangeObject['name'] = this.instrumentName;
         this.updateBrokerageWhtLbl(this.addExchangeObject);
        this.modal.hide();
        this.rerender();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Brokerage updated successfully.');
      }, error =>{

      })
  }


  /**
   * @author TR
   * @date : 22-05-2020
   * Update All Multiple
   */
  updateAllData() {
    this.spinner.show();
    let dataUpdateAll = {
      name: this.moduleList.toString(),
      brokerAgeAmount: Number(this.brokerageAmounts),
      brokerAgeType: this.brokerageTypes,
      exchangeName: this.selectedValue
    };
    this.brokerageTypes = '';
    this.brokerageAmounts = '';
    this.binaryService.updateAllBrokerage(dataUpdateAll).subscribe(resposne => {
      this.moduleList = [];
      if(resposne.status === true){
         this.updateAllDataWhtLbl(dataUpdateAll);
        this.brokerageForm.resetForm();
        this.newDatatable();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Brokerage all update successfully.');
      }else{
        this.spinner.hide();
        this.newDatatable();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.newDatatable();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * Update Brokerage for Whitelable
   * @method: POST
   */

  updateBrokerageWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateBrokeragewht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * Update Brokerage for Whitelable
   * @method: POST
   */

  updateAllDataWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateAllBrokeragewht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

}
