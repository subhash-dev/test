import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokrageListComponent } from './brokrage-list.component';

describe('BrokrageListComponent', () => {
  let component: BrokrageListComponent;
  let fixture: ComponentFixture<BrokrageListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrokrageListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokrageListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
