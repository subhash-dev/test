import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LotSizeMasterComponent } from './lot-size-master.component';

describe('LotSizeMasterComponent', () => {
  let component: LotSizeMasterComponent;
  let fixture: ComponentFixture<LotSizeMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LotSizeMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LotSizeMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
