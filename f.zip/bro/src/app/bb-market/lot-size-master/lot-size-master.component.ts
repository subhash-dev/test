import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap";
import {DataTableDirective} from "angular-datatables";
import {Subject} from "rxjs";
import * as env from "../../globals/env";
import {ToasterConfig} from "angular2-toaster";
import {UtilityService} from "../../globals/utilityService";
import {Router} from "@angular/router";
import {BinaryService} from "../../services/binary.service";
import {UserService} from "../../services/user.service";
import {NgxSpinnerService} from "ngx-spinner";
import {HttpClient} from "@angular/common/http";
import {isUndefined} from "util";
declare let $: any;
declare let _: any;

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
@Component({
  selector: 'app-lot-size-master',
  templateUrl: './lot-size-master.component.html',
  styleUrls: ['./lot-size-master.component.scss']
})
export class LotSizeMasterComponent implements OnInit {

  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild("addExchange", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild(DataTableDirective, {static: false})
    // @ViewChild("focus") nameField: ElementRef;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  exchange: any;
  dataUpdateAll: any;
  resData;
  server_url: any = env.server_url();



  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  tempSportObj: any;
  conformationPassword: any;
  moduleList = [];
  scriptName = [];
  getAllExchng: any;
  checkBoxValue:any;
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private binaryService: BinaryService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private http: HttpClient) {
  }
  dataTable: any;
  addExchangeObject = {
    _id: null,
    exchangeName: null,
    name: null,
  lotSize: null,
    tradeMargin: null,
    tradeMarginType: null,
  updatedAt: null
  };
  filter = {
    page: 1,
    limit: 300,
    search: null
  };
  selectedValue = "MCX";
  selectedTradeTyp = "AMOUNT";
  exchangeType = "";
  tradeMarginTypes = '';
  lotSizes: any;
  tradeMargins: any;

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.passwordFormReset.resetForm();
      this.sportsValue.resetForm();
      this.rerender();
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    //this.getSport();
    this.getAllExcahnge();
    this.newDatatable();
  }


  openModal(item) {
    this.addExchangeObject = {
      _id: item._id,
      exchangeName: item.exchangeName,
      name: item.name,
      lotSize: item.lotSize,
      tradeMargin: item.tradeMargin,
      tradeMarginType: item.tradeMarginType,
      updatedAt: item.updatedAt
    };
    this.modal.show();
  }

  closeModel(data) {
    if(data === 'addModel'){
      this.sportsValue.resetForm();
      this.modal.hide();
    }else{
      this.conformationModal.hide();
      this.rerender();
    }

  }

  getAllExcahnge(){
    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": "",
        "regex": false
      }
    };
    this.binaryService.getAllExcahnge(data).subscribe(response => {
      this.getAllExchng = response.data.docs;
      this.selectedValue = this.getAllExchng[0].exchangeName;
      this.exchangeType = this.getAllExchng[0].exchangeName;
      this.newDatatable();
      this.spinner.hide();
    }, error => {
      console.error('error in get users settings');
    });
  }

  newDatatable(){
    this.spinner.show();
    const that = this;
    this.rerender();
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[1, 'asc']],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },

      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'binary/getlotsize/' + this.selectedValue;
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters,{parameterType:this.selectedValue}),
            {}
          ).subscribe(resp => {
          this.spinner.hide();
          this.resData = resp.data;

          if(this.resData !== "" && this.resData.docs.length > 0){
            this.exchange = this.resData.docs;
          }else {
            this.resData = {
              total:0,
              page:0,
              pages:0
            }
          }
          this.dtTrigger.next();
          callback({
            recordsTotal: this.resData.total,
            recordsFiltered: this.resData.total,
            data: []
          });
        });
      },

      columns: [ { data: '' },{ data: 'exchangeName' }, { data: 'name' }, { data: 'lotSize' }, { data: 'tradeMargin' }, { data: 'tradeMarginType' }, { data: 'updatedAt' }, { data: 'Action' }],
      columnDefs: [ { orderable: false, targets: [0] } ]
    };
  }


  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  /**
   * @author TR
   * @date : 19-05-2020
   * Update single
   */
  updateLotSize() {
     this.spinner.show();
    this.addExchangeObject.exchangeName = this.addExchangeObject.exchangeName.toUpperCase();
    console.log(this.addExchangeObject)
    this.binaryService.updateLotSize(this.addExchangeObject).subscribe(resposne => {
      this.modal.hide();
      delete this.addExchangeObject._id;
       this.updateLotSizeWhtLbl(this.addExchangeObject);
      let newUrl = this.server_url + 'binary/getlotsize/' + this.selectedValue;
      this.newDatatable();
      if(resposne.status === true){
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'LotSize update successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }


  updateUserStatus(){
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal.hide();
        if(checkUserResponse.status === true){
          this.binaryService.updateExchange(this.tempSportObj)
            .subscribe(response =>{
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'Lot size updated successfully.');
            }, error =>{

            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }

      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });

  }
  /**
   * @author TR
   * @date : 18-05-2020
   * parameter change function on listing to update value
   */

  onDeleteExchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal.show();


  }
  /**
   * @author TR
   * @date : 18-05-2020
   * Create Exchange
   * @method: POST
   */

  deleteLotSize() {
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal.hide();
        if(checkUserResponse.status === true){
          this.binaryService.deleteLotSize(this.tempSportObj)
            .subscribe(response =>{
               this.deleteLotSizeWhtLbl(this.tempSportObj);
              this.rerender();
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'LotSize deleted successfully.');
            }, error =>{
            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }
      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });
  }


  selectAllAccess(e) {
    if (e.target.checked === true) {

      this.moduleList = [];
      this.scriptName = [];
      this.exchange = this.exchange.map(mDats =>{
        this.moduleList.push(mDats._id);
        this.scriptName.push(mDats.name);
        mDats.checkBoxValue = true;
        return mDats;
      })
      // return data;
    } else {
      this.exchange = this.exchange.map(mDats =>{

        mDats.checkBoxValue = false;
        return mDats;
      });
      this.moduleList = [];
      this.scriptName = [];
      // return data;
    }
  }

  /**
   * check module insert or not in array list
   */

  check(e, data) {
    if (e.target.checked === true) {
      this.exchange = this.exchange.map(mDats =>{

        if(mDats._id === data._id){

          this.moduleList.push(data._id);
          this.scriptName.push(data.name);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data._id);
      let arr3 = _.without(this.scriptName, data.name);

      this.moduleList = arr2;
      this.scriptName = arr3;
      this.exchange = this.exchange.filter(mDats =>{

        if(mDats._id === data._id){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }
  onSelectionChange(e){
    this.selectedValue = e;
    this.newDatatable();
  }

  onChangeTrade(e){
    this.selectedTradeTyp = e;
  }

  /**
   * check module insert or not in array list
   */

  filterApply(){
    console.log("this.lotSizes",this.lotSizes)
    console.log("this.tradeMarginTypes",this.tradeMarginTypes)
    console.log("this.tradeMargins",this.tradeMargins)
    this.exchange = this.exchange.map(data => {
      if(_.includes(this.moduleList, data._id)){
      if(_.includes(this.scriptName, data.name)){


      if(!isUndefined(this.lotSizes) && this.lotSizes !== "") {
          data.lotSize = Number(this.lotSizes);
      }
      if(!isUndefined(this.tradeMargins) && this.tradeMargins !== "" ){
        data.tradeMargin = Number(this.tradeMargins);
      }

      if(this.tradeMarginTypes !== ""){
        data.tradeMarginType = this.tradeMarginTypes;
      }
      }
      }
      return data;
    });
    if(this.moduleList.length === 0){
      this.utilityService.popToast('error','Error', 3000 , 'Please select any one');
    }

  }

  // updateAllMastersMul(){
  //   this.addExchangeObject.exchangeName = this.addExchangeObject.exchangeName.toUpperCase();
  //   this.binaryService.updateAllLotSize(this.addExchangeObject).subscribe(resposne => {
  //     if(resposne.status === true){
  //       this.newDatatable();
  //       this.spinner.hide();
  //       this.utilityService.popToast('success','Success', 3000 , 'LotSize all update multiple successfully.');
  //     }else{
  //       this.spinner.hide();
  //       this.newDatatable();
  //       this.utilityService.popToast('error','Error', 3000 , resposne.message);
  //     }
  //     //$('#addModel').modal('hide');
  //   }, error => {
  //     this.spinner.hide();
  //     this.newDatatable();
  //     this.utilityService.popToast('error','Error', 3000 , error.message);
  //   });
  // }

  /**
   * @author TR
   * @date : 22-05-2020
   * Update All Multiple
   */
  updateAllData(data) {
     this.spinner.show();
     if(data === 'all'){
       this.dataUpdateAll = {
      exchangeName: this.selectedValue,
      lotSizeName: this.scriptName.toString(),
      lotSize: Number(this.lotSizes),
      tradeMargin: Number(this.tradeMargins),
      tradeMarginType: this.tradeMarginTypes
    };
    this.tradeMarginTypes = '';
    this.tradeMargins = '';
    this.lotSizes = '';
     } else {

       this.dataUpdateAll = {
         exchangeName: data.exchangeName,
         lotSizeName: data.name,
         lotSize: Number(data.lotSize),
         tradeMargin: Number(data.tradeMargin),
         tradeMarginType: data.tradeMarginType
       };
     }
    this.binaryService.updateAllLotSize(this.dataUpdateAll).subscribe(resposne => {
      if(resposne.status === true){
        this.modal.hide();
        this.dataUpdateAll['lotSizeName'] = this.scriptName.toString()
        if(this.dataUpdateAll.lotSizeName === ''){
          this.dataUpdateAll['lotSizeName'] = data.name
        }
         this.updateAllDataWhtLbl(this.dataUpdateAll);
        this.moduleList = [];
        this.scriptName = [];
        this.newDatatable();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'LotSize all update multiple successfully.');
      }else{
        this.spinner.hide();
        this.newDatatable();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.newDatatable();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /**
   * @author TR
   * @date : 22-05-2020
   * Update Multiple
   */
  updateMultiple() {
     this.spinner.show();
    let dataUpdateAll = {
      exchangeName: this.selectedValue,
      lotSizeName: this.scriptName.toString(),
      lotSize: Number(this.lotSizes),
      tradeMargin: Number(this.tradeMargins),
      tradeMarginType: this.tradeMarginTypes
    };
    this.tradeMarginTypes = '';
    this.tradeMargins = '';
    this.lotSizes = '';
    this.binaryService.updateLotSizeAll(dataUpdateAll).subscribe(resposne => {
      if(resposne.status === true){
        dataUpdateAll['lotSizeName'] = this.scriptName.toString()
         this.updateMultipleWhtLbl(dataUpdateAll);
        this.moduleList = [];
        this.scriptName = [];
        this.newDatatable();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'LotSize update multiple successfully.');
      }else{
        this.spinner.hide();
        this.newDatatable();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.newDatatable();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * UpdateLotSize for Whitelable
   * @method: POST
   */

  updateLotSizeWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateLotSizewht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * deleteLotSize for Whitelable
   * @method: POST
   */

  deleteLotSizeWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.deleteLotSizewht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * deleteLotSize for Whitelable
   * @method: POST
   */

  updateAllDataWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateAllLotSizewht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * deleteLotSize for Whitelable
   * @method: POST
   */

  updateMultipleWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateLotSizeAllwht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }
}
