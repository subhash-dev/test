import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractSettleHistoryComponent } from './contract-settle-history.component';

describe('ContractSettleHistoryComponent', () => {
  let component: ContractSettleHistoryComponent;
  let fixture: ComponentFixture<ContractSettleHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContractSettleHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractSettleHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
