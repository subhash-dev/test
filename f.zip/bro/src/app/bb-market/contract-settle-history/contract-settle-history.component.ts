import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {BinaryService} from '../../services/binary.service';
import {UserService} from '../../services/user.service';
import {isUndefined} from "util";
import {DataTableDirective} from 'angular-datatables';
import {ModalDirective} from 'ngx-bootstrap';
import {HttpClient} from '@angular/common/http';
import {Subject} from 'rxjs';
import {UtilityService} from '../../globals/utilityService';
import {Router} from '@angular/router';
import * as env from '../../globals/env';
import {ToasterConfig} from 'angular2-toaster';
import * as moment from 'moment';
import {NgxSpinnerService} from 'ngx-spinner';
declare let $:any;
var _ = require('lodash');

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-contract-settle-history',
  templateUrl: './contract-settle-history.component.html',
  styleUrls: ['./contract-settle-history.component.scss']
})
export class ContractSettleHistoryComponent implements OnInit {

  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild("addExchange", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild('history', { static: false }) history: ModalDirective;
  @ViewChild(DataTableDirective, {static: false})
    // @ViewChild("focus") nameField: ElementRef;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  searchVal: any;
  exchange: any;
  getAllHistoryData: any;
  filterDataObjects: any;
  filterData: any;
  resData;
  getAllExchng;
  server_url: any = env.adminServer_url();
  selectedValue = 'ALL';
  whitelableList = [];
  selectedSettleItem = '';

  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  conformationPassword: any;

  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private binaryService: BinaryService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private http: HttpClient,
    private spinner: NgxSpinnerService) {
  }
  dataTable: any;
  addExchangeObject = {
    id: null,
    exchangeName: null,
    name: null,
    instrument_token: null,
    expiry: null,
    lot_size: null,
    last_price: null
  };
  filter = {
    page: 1,
    limit: 300,
    search: null,
    exchangeName: null,
    from: null,
    to: null,
  };
  fromDate: any;
  toDate: any;
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    this.getAllExcahnge();
    this.newDatatable();
    this.settleRateWhtLbl();
  }

  onSelectionChange(e){
    this.selectedValue = e;
    this.newDatatable();
  }
  onSelectionSettle(e){
    this.selectedSettleItem = e;
    if(this.server_url === 'http://localhost:7878/api/v1/'){

    }else{
      let data = 'http://'+this.selectedSettleItem +'/api/v1/';
      this.server_url = data;
    }
    // this.newDatatable();
  }


  /**
   * @author TR
   * @date : 16-06-2020
   * @method POST
   * get all exchange
   */

  getAllExcahnge(){

    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": "",
        "regex": false
      },
      "exchange": this.selectedValue
    };

    // console.log(data);
    this.binaryService.getAllExcahnge(data).subscribe(response => {
      this.getAllExchng = response.data.docs;

      this.newDatatable();
      this.spinner.hide();
    }, error => {
      console.error('error in get exchange');
    });
  }

  /**
   * @author TR
   * @date : 16-06-2020
   * @method POST
   * not weekly settle instrument listing
   */

  newDatatable(){
    this.spinner.show();
    const that = this;
    this.rerender();
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[1, 'asc']],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },

      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'sharemarket/weeklysettlement/transationHistory';
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters,{exchangeName:this.selectedValue, startDate:this.filter.from, endDate:this.filter.to , weeklyContractSettle:true}),
            {}
          ).subscribe(resp => {
          this.spinner.hide();
          this.resData = resp.data;

          if(this.resData !== "" && this.resData.docs.length > 0){
            this.exchange = this.resData.docs;
          }else {
            this.resData = {
              total:0,
              page:0,
              pages:0
            }
          }
          this.dtTrigger.next();
          callback({
            recordsTotal: this.resData.total,
            recordsFiltered: this.resData.total,
            data: []
          });
        });
      },

      columns: [ { data: '' },{ data: 'exchangeName' }, { data: 'name' }, { data: 'expiry' }, { data: 'createdAt' }, { data: 'settlementDate' }, { data: 'Action' }],
      columnDefs: [{ orderable: false, targets: [6] } ]
    };
  }


  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  // /**
  //  * @author TR
  //  * @date : 16-06-2020
  //  * @method PUT
  //  * update weekly settlement
  //  */
  // settleRate(ite , type) {
  //   this.spinner.show();
  //   let item = [];
  //   item.push(ite);
  //   let data;
  //   if(type === 'weekly') {
  //     data = {
  //       method:"FIXPRICE",
  //       preData:item,
  //     };
  //   }else {
  //     data = {
  //       method:"BUYSELL",
  //       preData:item,
  //     };
  //   }
  //
  //
  //   this.binaryService.weeklySettleScript(data).subscribe(resposne => {
  //     if(resposne.status === true){
  //       this.settleRateWhtLbl(data);
  //       this.spinner.hide();
  //       this.utilityService.popToast('success','Success', 3000 , 'weekly settlement successfully.');
  //       this.newDatatable();
  //     }else{
  //       this.spinner.hide();
  //       this.utilityService.popToast('error','Error', 3000 , resposne.message);
  //     }
  //     //$('#addModel').modal('hide');
  //   }, error => {
  //     this.spinner.hide();
  //     this.utilityService.popToast('error','Error', 3000 , error.message);
  //   });
  // }
  //
  // /**
  //  * @author TR
  //  * @date : 16-06-2020
  //  * @method PUT
  //  * update weekly settlement
  //  */
  // updateAllSettle(ite , type) {
  //   this.spinner.show();
  //   let data;
  //   if(type === 'weekly') {
  //     data = {
  //       method:"FIXPRICE",
  //       preData:ite,
  //     };
  //   }else {
  //     data = {
  //       method:"BUYSELL",
  //       preData:ite,
  //     };
  //   }
  //
  //
  //   this.binaryService.weeklySettleScript(data).subscribe(resposne => {
  //     if(resposne.status === true){
  //       this.settleRateWhtLbl(data);
  //       this.spinner.hide();
  //       this.utilityService.popToast('success','Success', 3000 , 'weekly settlement successfully.');
  //       this.newDatatable();
  //     }else{
  //       this.spinner.hide();
  //       this.utilityService.popToast('error','Error', 3000 , resposne.message);
  //     }
  //     //$('#addModel').modal('hide');
  //   }, error => {
  //     this.spinner.hide();
  //     this.utilityService.popToast('error','Error', 3000 , error.message);
  //   });
  // }

  /**
   * @author TR
   * @date : 16-06-2020
   * update search filter
   */
  searchFilterData() {
    // console.log(this.fromDate , this.toDate)
    if (this.fromDate !== null && !isUndefined(this.fromDate)) {
      this.filter.from = this.fromDate.year + '-' + this.fromDate.month + '-' + this.fromDate.day;
    }
    if(this.toDate !== null && !isUndefined(this.toDate)) {
      this.filter.to = + this.toDate.year + '-' + this.toDate.month + '-' + this.toDate.day;
    }
    this.newDatatable()
  }

  /**
   * @author TR
   * @date : 16-06-2020
   * update clear search filter
   */

  clearFilter(){
    this.filter.from = null;
    this.filter.to = null;
    this.fromDate = '';
    this.toDate = '';
    this.newDatatable()
  }

  /**
   * @author TR
   * @date : 16-06-2020
   * update clear date
   */

  clearDate(e){
    // console.log("e.target.value", e);
    if(e.target.value === ''){
      this.newDatatable()
    }

  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * updateScript for Whitelable
   * @method: POST
   */

  settleRateWhtLbl(){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      this.whitelableList = response.data;
      this.selectedSettleItem = this.whitelableList[0].app_domainName;
      /* Hear X is Multiple Whitelable Data*/
      // for(let i = 0;i < x.length; i++){
      //   this.binaryService.weeklySettleScriptwht(data , x[i]).subscribe(resposne => {
      //     if(resposne.status === true){
      //       // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
      //     }
      //   });
      // }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }
  viewHistory(data){
    this.history.show();
    let items = {
      instrumentToken: data.instrumentToken,
      userId:"ALL"
    };
    this.binaryService.getAllHistory(items).subscribe(response => {
      this.getAllHistoryData = response.data;

      this.newDatatable();
      this.spinner.hide();
    }, error => {
      console.error('error in get exchange');
    });
  }

  modelclose(){
    this.history.hide();
  }

  /**
   * @author TR
   * @date : 12-06-2020
   * Local Search Functionality
   */

  mySearch(){
    const x = this.searchVal.toLowerCase();
    this.filterDataObjects = _.map(this.getAllHistoryData[0].transationData, function(item) {
      if (item.userName.toLowerCase().indexOf(x) !== -1) {
        return item;
      }
    });
    if (this.filterDataObjects && this.filterDataObjects.length > 0) {
      this.filterData = true;
    } else {
      this.filterData = false;
    }
  }



}
