import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {BinaryService} from '../../services/binary.service';
import {UserService} from '../../services/user.service';
import {isUndefined} from "util";
import {DataTableDirective} from 'angular-datatables';
import {ModalDirective} from 'ngx-bootstrap';
import {HttpClient} from '@angular/common/http';
import {Subject} from 'rxjs';
import {UtilityService} from '../../globals/utilityService';
import {Router} from '@angular/router';
import * as env from '../../globals/env';
import {ToasterConfig} from 'angular2-toaster';
import * as moment from 'moment';
import {NgxSpinnerService} from 'ngx-spinner';
declare let $:any;
var _ = require('lodash');

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-weekly-settle-list',
  templateUrl: './weekly-settle-list.component.html',
  styleUrls: ['./weekly-settle-list.component.scss']
})
export class WeeklySettleListComponent implements OnInit {


  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild("addExchange", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild(DataTableDirective, {static: false})
    // @ViewChild("focus") nameField: ElementRef;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  exchange: any;
  resData;
  getAllExchng;
  server_url: any = env.server_url();
  selectedValue = 'ALL';
  selectedSettleItem = 'weekly';
  fileReaded:any;
  settleRateAllCsv:any;

  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  conformationPassword: any;

  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private binaryService: BinaryService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private http: HttpClient,
    private spinner: NgxSpinnerService) {
  }
  dataTable: any;
  addExchangeObject = {
    id: null,
    exchangeName: null,
    name: null,
    instrument_token: null,
    expiry: null,
    lot_size: null,
    last_price: null
  };
  filter = {
    page: 1,
    limit: 300,
    search: null,
    exchangeName: null,
    from: null,
    to: null,
  };
  fromDate: any;
  toDate: any;
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    this.getAllExcahnge();
    this.newDatatable();
  }

  onSelectionChange(e){
    this.selectedValue = e;
    this.newDatatable();
  }
  onSelectionSettle(e){
    this.selectedSettleItem = e;
    console.log(this.selectedSettleItem)
    this.newDatatable();
  }


  /**
   * @author TR
   * @date : 16-06-2020
   * @method POST
   * get all exchange
   */

  getAllExcahnge(){

    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": "",
        "regex": false
      },
      "exchange": this.selectedValue
    };

    // console.log(data);
    this.binaryService.getAllExcahnge(data).subscribe(response => {
      this.getAllExchng = response.data.docs;

      this.newDatatable();
      this.spinner.hide();
    }, error => {
      console.error('error in get exchange');
    });
  }

  /**
   * @author TR
   * @date : 16-06-2020
   * @method POST
   * not weekly settle instrument listing
   */

  newDatatable(){
    this.spinner.show();
    const that = this;
    this.rerender();
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[1, 'asc']],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },

      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'binary/getnotsettleinstrument';
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters,{exchange:this.selectedValue, startDate:this.filter.from, endDate:this.filter.to , weeklyContractSettle:true}),
            {}
          ).subscribe(resp => {
          this.spinner.hide();
          this.resData = resp.data;

          if(this.resData !== "" && this.resData.docs.length > 0){
            this.exchange = this.resData.docs;
          }else {
            this.resData = {
              total:0,
              page:0,
              pages:0
            }
          }
          this.dtTrigger.next();
          callback({
            recordsTotal: this.resData.total,
            recordsFiltered: this.resData.total,
            data: []
          });
        });
      },

      columns: [ { data: '' },{ data: 'exchangeName' }, { data: 'name' }, { data: 'expiry' }, { data: 'updatedAt' }, { data: '' }, { data: 'Action' }],
      columnDefs: [{ orderable: false, targets: [6] } ]
    };
  }


  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  /**
   * @author TR
   * @date : 16-06-2020
   * @method PUT
   * update weekly settlement
   */
  settleRate(ite , type) {
    this.spinner.show();
    let item = [];
    item.push(ite);
    let data;
    if(type === 'weekly') {
      data = {
        method:"FIXPRICE",
        preData:item,
      };
    }else {
      data = {
        method:"BUYSELL",
        preData:item,
      };
    }


    this.binaryService.weeklySettleScript(data).subscribe(resposne => {
      if(resposne.status === true){
         this.settleRateWhtLbl(data);
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'weekly settlement successfully.');
        this.newDatatable();
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /**
   * @author TR
   * @date : 16-06-2020
   * @method PUT
   * update weekly settlement
   */
  updateAllSettle(ite , type) {
    this.spinner.show();
    let data;
    if(type === 'weekly') {
      data = {
        method:"FIXPRICE",
        preData:ite,
      };
    }else {
      data = {
        method:"BUYSELL",
        preData:ite,
      };
    }


    this.binaryService.weeklySettleScript(data).subscribe(resposne => {
      if(resposne.status === true){
        this.settleRateWhtLbl(data);
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'weekly settlement successfully.');
        this.newDatatable();
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /**
   * @author TR
   * @date : 16-06-2020
   * update search filter
   */
  searchFilterData() {
    // console.log(this.fromDate , this.toDate)
    if (this.fromDate !== null && !isUndefined(this.fromDate)) {
      this.filter.from = this.fromDate.month + '-' + this.fromDate.day + '-' + this.fromDate.year + ' ' + '00' + ':' + '00' + ':' + '01' +'.000Z';
    }
    if(this.toDate !== null && !isUndefined(this.toDate)) {
      this.filter.to = this.toDate.month + '-' + this.toDate.day + '-' + this.toDate.year + ' ' + '23' + ':' + '59' + ':' + '59' +'.000Z';
    }
    this.newDatatable()
  }

  /**
   * @author TR
   * @date : 16-06-2020
   * update clear search filter
   */

  clearFilter(){
    this.filter.from = null;
    this.filter.to = null;
    this.fromDate = '';
    this.toDate = '';
    this.newDatatable()
  }

  /**
   * @author TR
   * @date : 16-06-2020
   * update clear date
   */

  clearDate(e){
    // console.log("e.target.value", e);
    if(e.target.value === ''){
      this.newDatatable()
    }

  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * updateScript for Whitelable
   * @method: POST
   */

  settleRateWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.weeklySettleScriptwht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 29-10-2020
   * import csv
   * @method: csv reader
   */
  importScript(){
    document.getElementById('csv').click();
  }

  csv2Array(fileInput: any){
//read file from input
    this.fileReaded = fileInput.target.files[0];

    let reader: FileReader = new FileReader();
    reader.readAsText(this.fileReaded);

    reader.onload = (e) => {
      const csv: string = reader.result as string;

      let allTextLines = csv.split(/\r|\n|\r/);
      let headers = allTextLines[0].split(',');
      let lines = [];

      for (let i = 0; i < allTextLines.length; i++) {
        // split content based on comma
        let data = allTextLines[i].split(',');
        if (data.length === headers.length) {
          let tarr = [];
          let object;
          for (let j = 0; j < headers.length; j++) {
            tarr.push(data[j]);
            object = {
              item1 : data[0],
              item2 : data[1],
              item3 : data[2]
            };
          }
          let ite = object;

          lines.push(ite);
        }
      }
      // all rows in the csv file
      this.settleRateAllCsv = lines;
      if(this.exchange){
       _.map(this.exchange , function (e) {
         let adminComAry = lines.find(o => o.item1 ===  e.name && o.item2 ===  e.expiry);
         if(adminComAry){
           e['settlePrice'] = adminComAry.item3;
         }
       })
      }
    }
  }
}


