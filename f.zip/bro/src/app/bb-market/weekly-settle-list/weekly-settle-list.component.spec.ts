import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeeklySettleListComponent } from './weekly-settle-list.component';

describe('WeeklySettleListComponent', () => {
  let component: WeeklySettleListComponent;
  let fixture: ComponentFixture<WeeklySettleListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeeklySettleListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeeklySettleListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
