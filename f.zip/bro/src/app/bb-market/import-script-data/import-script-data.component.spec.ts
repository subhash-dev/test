import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportScriptDataComponent } from './import-script-data.component';

describe('ImportScriptDataComponent', () => {
  let component: ImportScriptDataComponent;
  let fixture: ComponentFixture<ImportScriptDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportScriptDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportScriptDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
