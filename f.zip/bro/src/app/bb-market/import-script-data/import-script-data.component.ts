import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap";
import * as env from "../../globals/env";
import {UtilityService} from "../../globals/utilityService";
import {Router} from "@angular/router";
import {BinaryService} from "../../services/binary.service";
import {UserService} from "../../services/user.service";
import {NgxSpinnerService} from "ngx-spinner";
import {ToasterConfig} from "angular2-toaster";
import {isUndefined} from "util";
declare let $: any;
declare let _: any;


@Component({
  selector: 'app-import-script-data',
  templateUrl: './import-script-data.component.html',
  styleUrls: ['./import-script-data.component.scss']
})
export class ImportScriptDataComponent implements OnInit {
  selectedValue = '';
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild("addExchange", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;


  exchange: any;
  resData;
  getAllExchng;
  server_url: any = env.server_url();

  selectAllData = false;


  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  conformationPassword: any;
  moduleList = [];
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private binaryService: BinaryService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService) {
  }
  dataTable: any;
  addExchangeObject = {
    id: null,
    exchangeName: null,
    name: null,
    instrument_token: null,
    expiry: null,
    lot_size: null,
    last_price: null
  };
  filter = {
    page: 1,
    limit: 300,
    search: null,
    exchangeName: null,
    from: null,
    to: null,
  };
  fromDate: any;
  toDate: any;
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    this.getAllExcahnge();
  }

  onSelectionChange(e){
    this.selectedValue = e;
    this.moduleList = [];
    this.newDatatable();
  }


  getAllExcahnge(){
    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": "",
        "regex": false
      }
    };
    this.binaryService.getAllExcahnge(data).subscribe(response => {
      this.getAllExchng = response.data.docs;
      this.spinner.hide();
    }, error => {
      console.error('error in get users settings');
    });
  }

  newDatatable(){
    this.spinner.show()
    this.filter.exchangeName = this.selectedValue;
    if(this.filter.from === null){
      delete this.filter.from
    }
    if(this.filter.to === null){
      delete this.filter.to
    }
    this.binaryService.getAllInstrument(this.filter).subscribe(response => {
      this.resData = response;
      this.spinner.hide();
      this.exchange = this.resData.data;
      if(this.resData.data.length > 0){
        this.exchange = this.resData.data;

        this.exchange = this.exchange.map(mData =>{

          mData.checkBoxValue = false;

          return mData;

        })

      }
    }, error => {
      console.error('error in get users settings');
    });
  }


  /**
   * @author kc
   * @date : 28-01-2020
   * add new sports
   */
  importData() {
    this.spinner.show();
    let data = {
      exchangeName: this.selectedValue,
      instruments:  this.moduleList.toString()
    };
    this.binaryService.importInstrument(data).subscribe(resposne => {
      if(resposne.status === true){
        this.spinner.hide();
         this.importDataWhtLbl(data);
        this.utilityService.popToast('success','Success', 3000 , 'Import instrument successfully.');
        this.moduleList = [];
        this.selectAllData = false;
        this.newDatatable();

      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }


  selectAllAccess(e) {
    if (e.target.checked === true) {

      this.moduleList = [];
      this.exchange = this.exchange.map(mDats =>{
        this.moduleList.push(mDats.instrument_token);
        mDats.checkBoxValue = true;
        return mDats;
      })


      // this.addRoleObject.modules.push(data);
      // return data;
    } else {
      this.exchange = this.exchange.map(mDats =>{

        mDats.checkBoxValue = false;
        return mDats;
      });
      this.moduleList = [];
      // return data;
    }
  }

  /**
   * check module insert or not in array list
   */

  check(e, data) {
    if (e.target.checked === true) {
      this.exchange = this.exchange.map(mDats =>{

        if(mDats.instrument_token === data.instrument_token){

          this.moduleList.push(data.instrument_token);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data.instrument_token);

    this.moduleList = arr2;
      this.exchange = this.exchange.filter(mDats =>{

        if(mDats.instrument_token === data.instrument_token){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }

  searchFilterData(){

    this.filter.from = (this.fromDate.day + '-' + this.fromDate.month + '-' + this.fromDate.year);
      this.filter.to = (this.toDate.day + '-' + this.toDate.month + '-' + this.toDate.year);

    console.log(this.filter)
     this.newDatatable()
  }
  clearFilter(){
    this.filter.from = null;
    this.filter.to = null;
    this.fromDate = '';
    this.toDate = '';
    this.newDatatable()
  }
  clearDate(e){
    console.log("e.target.value", e);
    if(e.target.value === ''){
      this.newDatatable()
    }

  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * Import Instrument for Whitelable
   * @method: POST
   */

  importDataWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.importInstrumentwht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

}
