import {Component, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap";
import {CalendarEvent,
  CalendarEventAction,
  CalendarEventTimesChangedEvent,
  CalendarView} from 'angular-calendar';
import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours,
} from 'date-fns';
import { Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {isUndefined} from "util";
import {BinaryService} from '../../services/binary.service';
import {UtilityService} from '../../globals/utilityService';
import {ActivatedRoute, Router} from '@angular/router';
import {NgxSpinnerService} from 'ngx-spinner';
const colors: any = {
  red: {
    primary: '#ad2121',
    secondary: '#FAE3E3',
  },
  blue: {
    primary: '#1e90ff',
    secondary: '#D1E8FF',
  },
  yellow: {
    primary: '#e3bc08',
    secondary: '#FDF1BA',
  },
};
@Component({
  selector: 'app-holiday-list',
  templateUrl: './holiday-list.component.html',
  styleUrls: ['./holiday-list.component.scss']
})
export class HolidayListComponent implements OnInit {

  @ViewChild('modalContent', { static: true }) modalContent: TemplateRef<any>;
  @ViewChild('editHoliday', {static: false}) editHoliday: ModalDirective;
  view: CalendarView = CalendarView.Month;

  CalendarView = CalendarView;

  viewDate: Date = new Date();

  refresh: Subject<any> = new Subject();

  activeDayIsOpen: boolean = true;
  sub: any;
  exchangeName: any;
  selectedDate: any;
  isHoliday = true;
  holidayList: any;
  today: any;
  holidayListCreate: any = [];

  constructor(private modal: NgbModal , private router: Router , private route: ActivatedRoute, private spinner: NgxSpinnerService , private binaryService: BinaryService , private utilityService: UtilityService) {}

  ngOnInit() : void {
    this.sub=this.route.paramMap.subscribe(params => {
      this.exchangeName = params.get('exchange');

    });
    this.getAllHolidayList(this.exchangeName);
    this.today = startOfDay(new Date());

  }
  actions: CalendarEventAction[] = [
    {
      label: ' is Holiday:  <i class="fas fa-fw fa-pencil-alt"></i>',
      a11yLabel: '<mat-slide-toggle name="SportHideShow" class="example-margin sport_focus"> </mat-slide-toggle>',
      onClick: ({ event }: { event: CalendarEvent }): void => {
        this.editHoliday.show();
        this.selectedDate = event.start;
        // let date = this.utilityService.ConvertUTCTimeToLocalTime(event.start);
        // console.log(date.getTimezoneOffset())
      },
    }

  ];
  getAllHolidayList(item){
     this.spinner.show();
    this.binaryService.getAllHolidayList(item)
      .subscribe(response =>{
        this.holidayList = response.data;
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Get all holiday successfully.');
        if(this.holidayList !== ""){
         this.holidayList.map(res => {
           console.log("res data",res)
           let date = this.utilityService.ConvertUTCTimeToLocalTime(res.Date);
           console.log(date);
           // if(this.today <= date){
          let item = {
            start : subDays(startOfDay(date), 0) ,
            title:  res.isHoliday ?  res.Day + ' is a Holiday' : res.tradeTimeStart2 ? res.Day + " <h1 class='title-time'>" + "<span>"+' Start :- &nbsp;'+ "</span>"+ res.tradeTimeStart1.split('T').pop().split('.')[0] + "<span>"+' To &nbsp;'+ "</span>"+ res.tradeTimeEnd1.split('T').pop().split('.')[0] + "</h1> <h1 class='title-time'>" + "<span>"+'  Start :- &nbsp;'+ "</span>"+ res.tradeTimeStart2.split('T').pop().split('.')[0] + "<span>"+' To &nbsp;'+ "</span>"+ res.tradeTimeEnd2.split('T').pop().split('.')[0] + "</h1>" : res.Day + " <h1 class='title-time'>" + "<span>"+' Start :- &nbsp;'+ "</span>"+ res.tradeTimeStart1.split('T').pop().split('.')[0] + "<span>"+' To &nbsp;'+ "</span>"+ res.tradeTimeEnd1.split('T').pop().split('.')[0] + "</h1>",
            color: res.isHoliday ? colors.red : colors.yellow,
            allDay: true,
            actions: this.actions,
            resizable: {
              beforeStart: true,
              afterEnd: true,
            },
            draggable: true,
          };
          this.holidayListCreate.push(item);
           // }
        });
        }

      }, error =>{

      })
  }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
      this.viewDate = date;
    }
  }



  events: CalendarEvent[] = this.holidayListCreate;

  eventTimesChanged({
                      event,
                      newStart,
                      newEnd,
                    }: CalendarEventTimesChangedEvent): void {
    this.events = this.events.map((iEvent) => {
      if (iEvent === event) {
        return {
          ...event,
          start: newStart,
          end: newEnd,
        };
      }
      return iEvent;
    });
    // this.handleEvent('Dropped or resized', event);
  }
  setView(view: CalendarView) {
    this.view = view;
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }


  // handleEvent(action: string, event: CalendarEvent): void {
  //   this.modalData = { event, action };
  //   this.modal.open(this.modalContent, { size: 'lg' });
  // }

  // addEvent(): void {
  //   this.events = [
  //     ...this.events,
  //     {
  //       title: 'New event',
  //       start: startOfDay(new Date()),
  //       end: endOfDay(new Date()),
  //       color: colors.red,
  //       draggable: true,
  //       resizable: {
  //         beforeStart: true,
  //         afterEnd: true,
  //       },
  //     },
  //   ];
  // }

  // deleteEvent(eventToDelete: CalendarEvent) {
  //   this.events = this.events.filter((event) => event !== eventToDelete);
  // }

  closeModel(){
    this.editHoliday.hide();
  }
  updateHoliday(){
    var isoDate = new Date(this.selectedDate.getTime() - this.selectedDate.getTimezoneOffset() * 60000).toISOString();
    var isoDateEnd = new Date(this.selectedDate.getTime() - this.selectedDate.getTimezoneOffset() * 119999).toISOString();
    let data = {
      exchange: this.exchangeName,
      isHoliday: this.isHoliday,
      startDate: isoDate,
      endDate: isoDateEnd
    };
    this.createHoliday(data)
  }

  createHoliday(data) {
    this.spinner.show();
    console.log(data)
    data.exchange = data.exchange.toUpperCase();
    this.binaryService.addNewHoliday(data).subscribe(resposne => {
      this.editHoliday.hide();
      if(resposne.status === true){
         this.createHolidayWhtLbl(data);
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Holiday Update successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * Create Holiday for Whitelable
   * @method: POST
   */

  createHolidayWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.addNewHolidaywht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }
}

