import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BbMarketComponent } from './bb-market.component';

describe('BbMarketComponent', () => {
  let component: BbMarketComponent;
  let fixture: ComponentFixture<BbMarketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BbMarketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BbMarketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
