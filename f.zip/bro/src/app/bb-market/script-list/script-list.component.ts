import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap";
import {DataTableDirective} from "angular-datatables";
import {Subject} from "rxjs";
import * as env from "../../globals/env";
import {ToasterConfig} from "angular2-toaster";
import {UtilityService} from "../../globals/utilityService";
import {Router} from "@angular/router";
import {BinaryService} from "../../services/binary.service";
import {UserService} from "../../services/user.service";
import {NgxSpinnerService} from "ngx-spinner";
import {HttpClient} from "@angular/common/http";
import {isUndefined} from "util";
declare let $: any;
declare let _: any;

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
@Component({
  selector: 'app-script-list',
  templateUrl: './script-list.component.html',
  styleUrls: ['./script-list.component.scss']
})
export class ScriptListComponent implements OnInit {

  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal1', {static: false}) conformationModal1: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild("addExchange", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild(DataTableDirective, {static: false})
    // @ViewChild("focus") nameField: ElementRef;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  exchange: any;
  resData;
  server_url: any = env.server_url();



  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  tempSportObj: any;
  conformationPassword: any;
  selectAllData = false;
  moduleList = [];
  lotSize: any;
  getAllExchng: any;
  exchangeType = 'MCX';
  selectedValue = 'MCX';
  allowTrades = '';
  tradeAttributes = '';
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private binaryService: BinaryService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private http: HttpClient) {
  }
  dataTable: any;
  addExchangeObject = {
    _id: null,
    exchangeName: null,
    name: null,
    expiry: null,
    tradingsymbol: null,
    instrumentToken: null,
    lotSize: null,
    tradeMargin: null,
    lastPrice: null,
    tradeAttribute: null,
    brokerAgeAmount: null,
    brokerAgeType: null,
    tradeMarginType: null,
    allowTrade: null,
    tickSize: null,
    quantityBreakup: null,
    lotsizeMin: null,
    lotsizeMax: null,
    lotsizeBreakup: null,
    quantityMax: null,
    quantityMin: null,
  };
  filter = {
    page: 1,
    limit: 300,
    search: null
  };

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.passwordFormReset.resetForm();
      this.sportsValue.resetForm();
      this.rerender();
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    //this.getSport();
    this.newDatatable();
    this.getAllExcahnge();
  }


  openModal(data) {
    this.addExchangeObject = {
      _id: data._id,
      exchangeName: data.exchangeName,
      name: data.name,
      instrumentToken: data.instrumentToken,
      expiry: data.expiry,
      tradingsymbol: data.tradingsymbol,
      brokerAgeAmount: data.brokerAgeAmount,
      brokerAgeType: data.brokerAgeType,
      lotSize: data.lotSize,
      tradeMargin: data.tradeMargin,
      lastPrice: data.lastPrice,
      tradeAttribute: data.tradeAttribute,
      allowTrade: data.allowTrade.toString(),
      tradeMarginType: data.tradeMarginType,
      tickSize: data.tickSize,
      quantityMin: data.quantityMin,
      quantityMax: data.quantityMax,
      quantityBreakup: data.quantityBreakup,
      lotsizeMin: data.lotsizeMin,
      lotsizeMax: data.lotsizeMax,
      lotsizeBreakup: data.lotsizeBreakup
    };
    this.modal.show();
  }

  closeModel(data) {
    if(data === 'addModel'){
      this.sportsValue.resetForm();
      this.modal.hide();
    }else if(data === 'updateScript'){
      this.conformationModal1.hide();
      this.rerender();
    }else {
      this.conformationModal.hide();
      this.rerender();
    }

  }

  getAllExcahnge(){
    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": "",
        "regex": false
      }
    };
    this.binaryService.getAllExcahnge(data).subscribe(response => {
      this.getAllExchng = response.data.docs;
      this.selectedValue = this.getAllExchng[0].exchangeName;
      this.exchangeType = this.getAllExchng[0].exchangeName;
      this.newDatatable();
      this.spinner.hide();
    }, error => {
      console.error('error in get users settings');
    });
  }

  newDatatable(){
    this.rerender();
    // this.spinner.show();
    const that = this;

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[1, 'asc']],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },

      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'binary/getallscript/' + this.selectedValue;
        that.http
          .post<DataTablesResponse>(
            url,
            dataTablesParameters,
            {}
          ).subscribe(resp => {
          this.spinner.hide();
          this.resData = resp.data;

          if(this.resData !== "" && this.resData.docs.length > 0){
            this.exchange = this.resData.docs;
          }else {
            this.resData = {
              total:0,
              page:0,
              pages:0
            }
          }
          this.dtTrigger.next();
          callback({
            recordsTotal: this.resData.total,
            recordsFiltered: this.resData.total,
            data: []
          });
        });
      },

      columns: [ { data: '' },{ data: 'exchangeName' }, { data: 'name' },{ data: 'expiry' }, { data: 'lotSize' }, { data: 'tradeMargin' }, { data: 'tradeAttribute' }, { data: 'allowTrade' }, { data: 'Action' }],
      columnDefs: [ { orderable: false, targets: [0] } ]
    };
  }


  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }


  /**
   * @author TR
   * @date : 19-05-2020
   * Update single
   */
  updateScript() {
    // this.spinner.show();
    this.addExchangeObject.exchangeName = this.addExchangeObject.exchangeName.toUpperCase();
    this.addExchangeObject.brokerAgeAmount = Number(this.addExchangeObject.brokerAgeAmount);
    this.binaryService.updateScriptMaster(this.addExchangeObject).subscribe(resposne => {
      this.modal.hide();
      delete this.addExchangeObject._id
      this.updateScriptWhtLbl(this.addExchangeObject)
      this.newDatatable();
      if(resposne.status === true){
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'LotSize update successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }


  updateScriptMaster(){
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal1.hide();
        if(checkUserResponse.status === true){
          this.binaryService.updateScriptMaster(this.tempSportObj)
            .subscribe(response =>{
              // this.updateScriptWhtLbl(this.tempSportObj);
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'Script master updated successfully.');
            }, error =>{

            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }

      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });

  }
  /**
   * @author TR
   * @date : 18-05-2020
   * parameter change function on listing to update value
   */

  onDeleteExchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal.show();


  }
  /**
   * @author TR
   * @date : 18-05-2020
   * Create Exchange
   * @method: POST
   */

  deleteScriptMaster() {
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal.hide();
        if(checkUserResponse.status === true){
          this.binaryService.deleteScriptMaster(this.tempSportObj)
            .subscribe(response =>{
              // this.deleteScriptMasterWhtLbl(this.tempSportObj);
              this.rerender();
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'Scrip master deleted successfully.');
            }, error =>{

            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }
      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });
  }


  selectAllAccess(e) {
    if (e.target.checked === true) {

      this.moduleList = [];
      this.exchange = this.exchange.map(mDats =>{
        this.moduleList.push(mDats.instrumentToken);
        mDats.checkBoxValue = true;
        return mDats;
      })
      // return data;
    } else {
      this.exchange = this.exchange.map(mDats =>{

        mDats.checkBoxValue = false;
        return mDats;
      });
      this.moduleList = [];
      // return data;
    }
  }

  /**
   * check module insert or not in array list
   */

  check(e, data) {
    if (e.target.checked === true) {
      this.exchange = this.exchange.map(mDats =>{

        if(mDats.instrumentToken === data.instrumentToken){

          this.moduleList.push(data.instrumentToken);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data.instrumentToken);

      this.moduleList = arr2;
      this.exchange = this.exchange.filter(mDats =>{

        if(mDats.instrumentToken === data.instrumentToken){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }
  onSelectionChange(e){
    this.selectedValue = e;
    this.newDatatable();
  }

  /**
   * check module insert or not in array list
   */

  filterApply(){
    this.exchange = this.exchange.map(data => {
      if(_.includes(this.moduleList, data.instrumentToken)){
        if(this.tradeAttributes !== ""){
          data.tradeAttribute = this.tradeAttributes;
        }
        if(this.allowTrades !== ""){
          data.allowTrade = this.allowTrades;
        }
      }
      return data;
    });
    if(this.moduleList.length === 0){
      this.utilityService.popToast('error','Error', 3000 , 'Please select any one');
    }
  }

  /**
   * @author TR
   * @date : 22-05-2020
   * Update All Multiple
   */
  updateAllData() {
    this.spinner.show();
    let dataUpdateAll = {
      instruments: this.moduleList.toString(),
      tradeAttribute: this.tradeAttributes,
      allowTrade: this.allowTrades
    };
    this.allowTrades = '';
    this.tradeAttributes = '';
    this.binaryService.updateAllScriptMaster(dataUpdateAll).subscribe(resposne => {
      if(resposne.status === true){
         this.updateAllDataWhtLbl(dataUpdateAll);
        this.moduleList = [];
        this.newDatatable();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Script master all update multiple successfully.');
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }


  onchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal1.show();
  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * updateScript for Whitelable
   * @method: POST
   */

  updateScriptWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateScriptMasterwht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * updateScript for Whitelable
   * @method: POST
   */

  deleteScriptMasterWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.deleteScriptMasterwht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * updateAllData for Whitelable
   * @method: POST
   */

  updateAllDataWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateAllScriptMasterwht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }
}
