import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeeklySettleHistoryComponent } from './weekly-settle-history.component';

describe('WeeklySettleHistoryComponent', () => {
  let component: WeeklySettleHistoryComponent;
  let fixture: ComponentFixture<WeeklySettleHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeeklySettleHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeeklySettleHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
