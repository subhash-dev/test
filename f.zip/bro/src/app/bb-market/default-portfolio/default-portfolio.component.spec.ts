import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultPortfolioComponent } from './default-portfolio.component';

describe('DefaultPortfolioComponent', () => {
  let component: DefaultPortfolioComponent;
  let fixture: ComponentFixture<DefaultPortfolioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefaultPortfolioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultPortfolioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
