import {ChangeDetectorRef, Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap";
import {DataTableDirective} from "angular-datatables";
import {Subject} from "rxjs";
import * as env from "../../globals/env";
import {ToasterConfig} from "angular2-toaster";
import {UtilityService} from "../../globals/utilityService";
import {Router} from "@angular/router";
import {BinaryService} from "../../services/binary.service";
import {UserService} from "../../services/user.service";
import {NgxSpinnerService} from "ngx-spinner";
import {HttpClient} from "@angular/common/http";
import {isUndefined} from "util";
declare let $: any;
declare let _: any;

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
@Component({
  selector: 'app-default-portfolio',
  templateUrl: './default-portfolio.component.html',
  styleUrls: ['./default-portfolio.component.scss']
})
export class DefaultPortfolioComponent implements OnInit {

  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal1', {static: false}) conformationModal1: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild("addExchange", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild(DataTableDirective, {static: false})
    // @ViewChild("focus") nameField: ElementRef;


  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  exchange: any;
  resData;
  addDefaultData:any;
  resDataModal;
  server_url: any = env.server_url();



  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  accessRole: any;
  tempSportObj: any;
  conformationPassword: any;
  selectAllData = false;
  moduleList = [];
  lotSize: any;
  getAllExchng: any;
  searchVal: '';
  exchangeType = 'MCX';
  selectedValue = 'MCX';
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private binaryService: BinaryService,
    private userService: UserService,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private http: HttpClient) {
  }
  filter = {
    page: 1,
    limit: 300,
    search: null
  };

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.key === 'Escape'){
      this.passwordFormReset.resetForm();
      this.sportsValue.resetForm();
      this.defaultRender();
    }
  }
  ngOnInit() : void {
    if (isUndefined(this.utilityService.returnAccessRole('binary'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('binary');
    }
    this.defaultList();
    this.getAllExcahnge();
  }


  openModal() {
    this.instrumentList();
    this.modal.show();
  }

  closeModel(data) {
    if(data === 'addModel'){
      this.modal.hide();
    }else if(data === 'updateScript'){
      this.conformationModal1.hide();
      this.defaultRender();
    }else {
      this.conformationModal.hide();
      this.defaultRender();
    }

  }

  getAllExcahnge(){
    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": "",
        "regex": false
      }
    };
    this.binaryService.getAllExcahnge(data).subscribe(response => {
      this.getAllExchng = response.data.docs;
      this.selectedValue = this.getAllExchng[0].exchangeName;
      this.exchangeType = this.getAllExchng[0].exchangeName;
      this.defaultList();
      this.spinner.hide();
    }, error => {
      console.error('error in get users settings');
    });
  }

  defaultList(){
    this.defaultRender();
     this.spinner.show();
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[1, 'asc']],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },

      ajax: (dataTablesParameters: any, callback) => {
        let url = this.server_url + 'portfolio/list';
        this.http
          .post<DataTablesResponse>(
            url,
            dataTablesParameters,
            {}
          ).subscribe(resp => {
          this.spinner.hide();
          this.resData = resp.data;

          if(this.resData !== "" && this.resData.docs.length > 0){
            this.exchange = this.resData.docs;
          }else {
            this.resData = {
              total:0,
              page:0,
              pages:0
            }
          }
          this.dtTrigger.next();
          callback({
            recordsTotal: this.resData.total,
            recordsFiltered: this.resData.total,
            data: []
          });
        });
      },

       columns: [ { data: '' }, { data: 'displayOrder' },{ data: 'exchangeName' },{ data: 'name' },{ data: 'expiry' },{ data: 'tradingsymbol' },{ data: 'lotSize' },{ data: 'action' }],
       columnDefs: [ { orderable: false, targets: [0] } ]
    };
  }

  instrumentList() {

    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        },
        {
          "data": "exchangeName",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 1000,
      "search": {
        "value": this.searchVal,
        "regex": false
      }
    };
    this.binaryService.getAllInstDefault(data, this.selectedValue).subscribe(response => {
      this.addDefaultData = response.data.docs;
      this.spinner.hide();
    }, error => {
      console.error('error in get default');
      // this.spinner.show();
      // this.dtOptions= {
      //   pagingType: 'full_numbers',
      //   pageLength: 25,   // -- trying to set to 5 records only
      //   paging: true,
      //   serverSide: true,
      //   // autoWidth: true,
      //   // scrollX: true,
      //   // scrollCollapse:true,
      //   processing: true,
      //   responsive: true,
      //   lengthChange: true,
      //   lengthMenu: [5, 10, 25, 50, 75, 100,200],
      //   language: {
      //     lengthMenu: '_MENU_',
      //     zeroRecords:    '',
      //     emptyTable:     'No record found',
      //     paginate: {
      //       first: 'first', last: 'last',
      //       next: '<i class="fa fa-chevron-circle-right">',
      //       previous: '<i class="fa fa-chevron-circle-left">'
      //     }
      //   },
      //
      //   ajax: (dataTablesParameters: any, callback) => {
      //     let url = this.server_url + 'binary/getlotsize/' + this.selectedValue;
      //     console.log(url)
      //     this.http
      //       .post<DataTablesResponse>(
      //         url,
      //         dataTablesParameters,
      //         {}
      //       ).subscribe(resp => {
      //       this.spinner.hide();
      //       this.resDataModal = resp.data;
      //
      //       if(this.resDataModal !== "" && this.resDataModal.docs.length > 0){
      //         this.addDefaultData = this.resDataModal.docs;
      //       }else {
      //         this.resDataModal = {
      //           total:0,
      //           page:0,
      //           pages:0
      //         }
      //       }
      //       this.dtTrigger.next();
      //       callback({
      //         recordsTotal: this.resDataModal.total,
      //         recordsFiltered: this.resDataModal.total,
      //         data: []
      //       });
      //     });
      //   },
      //
      //    // columns: [ { data: '' }, { data: 'name' },{ data: 'expiry' }]
      // };
    });
  }

  defaultRender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }



  /**
   * @author TR
   * @date : 18-05-2020
   * parameter change function on listing to update value
   */

  onDeleteExchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal.show();


  }

  /**
   * @author TR
   * @date : 18-05-2020
   * parameter change function on listing to update value
   */

  onSelectionChange(e){
    this.selectedValue = e;
    this.instrumentList();
  }
  /**
   * @author TR
   * @date : 26-05-2020
   * delete portfolio
   * @method: POST
   */

  deleteScriptMaster() {
    this.spinner.show();
    let checkUserObj = {
      id : this.utilityService.returnLocalStorageData('userId'),
      password : this.conformationPassword
    };

    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse =>{
        this.conformationModal.hide();
        if(checkUserResponse.status === true){
           this.binaryService.deletePortfolio(this.tempSportObj)
            .subscribe(response =>{
              if(response){
              this.defaultRender();
               this.deletePortfolioWhtLbl(this.tempSportObj);
              }
              this.spinner.hide();
              this.utilityService.popToast('success','Success', 3000 , 'Portfolio deleted successfully.');
            }, error =>{

            })
        }else{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , checkUserResponse.message);
        }
      }, error =>{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , error.error.message);
      });
  }


  selectAllAccess(e) {
    if (e.target.checked === true) {

      this.moduleList = [];
      this.addDefaultData = this.addDefaultData.map(mDats =>{
        this.moduleList.push(mDats.instrumentToken);
        mDats.checkBoxValue = true;
        return mDats;
      })
      // return data;
    } else {
      this.addDefaultData = this.addDefaultData.map(mDats =>{

        mDats.checkBoxValue = false;
        return mDats;
      });
      this.moduleList = [];
      // return data;
    }
  }

  /**
   * check module insert or not in array list
   */

  check(e, data) {
    if (e.target.checked === true) {
      this.addDefaultData = this.addDefaultData.map(mDats =>{
        if(mDats.instrumentToken === data.instrumentToken){

          this.moduleList.push(data.instrumentToken);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data.instrumentToken);

      this.moduleList = arr2;
      this.addDefaultData = this.addDefaultData.filter(mDats =>{

        if(mDats.instrumentToken === data.instrumentToken){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }

  onchange(object){
    this.tempSportObj = object;
    this.passwordFormReset.resetForm();
    this.conformationModal1.show();
  }
  mySearch(){
    this.instrumentList();
  }

  /**
   * @author TR
   * @date : 26-05-2020
   * add portfolio
   * @method: POST
   */
  addDefault(){
    let data = {
      exchangeName: this.selectedValue,
      instruments: this.moduleList.toString()
    };
    this.binaryService.addDefault(data).subscribe(response => {
        this.modal.hide();
        this.defaultRender();
        this.moduleList = [];
        this.addDefaultWhtLbl(data);
        this.utilityService.popToast('success','Success', 3000 , 'Add Default successfully.');
      this.spinner.hide();
    }, error => {
        this.utilityService.popToast('error','Error', 3000 , error);
  }
    )}

  /**
   * @author TR
   * @date : 27-05-2020
   * delete all portfolio
   * @method: DELETE
   */
  deleteAllModal(){
    this.binaryService.deleteAllPortfolio().subscribe(response =>{
        this.defaultRender();
         this.deleteAllModalWhtLbl();
        this.spinner.hide();
        this.utilityService.popToast('success','Success', 3000 , 'Portfolio all deleted successfully.');
      }, error =>{

      })
  }
  /**
   * @author TR
   * @date : 27-05-2020
   * update portfolio
   * @method: PUT
   */
  displayOrderUpdt(data){
    this.binaryService.updateDisplayOrder(data).subscribe(response =>{
      if(response){
        delete data._id;
         this.displayOrderUpdtWhtLbl(data);
      this.spinner.hide();
      this.defaultRender();
      // this.utilityService.popToast('success','Success', 3000 , 'Portfolio updated successfully.');
      }
    }, error =>{

    })
  }

  /// Whitelable Hook *****************************************************************///

  /**
   * @author TR
   * @date : 10-07-2020
   * Delete Portfolio for Whitelable
   * @method: POST
   */

  deletePortfolioWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.deletePortfoliowht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * Add Portfolio for Whitelable
   * @method: POST
   */

  addDefaultWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.addDefaultwht(data , x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }


  /**
   * @author TR
   * @date : 10-07-2020
   * Delete Portfolio for Whitelable
   * @method: POST
   */

  deleteAllModalWhtLbl(){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.deleteAllPortfoliowht(x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /**
   * @author TR
   * @date : 10-07-2020
   * display Order Portfolio for Whitelable
   * @method: POST
   */

  displayOrderUpdtWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.binaryService.updateDisplayOrderwht(data,x[i]).subscribe(resposne => {
          if(resposne.status === true){
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }
}
