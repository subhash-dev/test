import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';

import { BbMarketRoutingModule } from './bb-market-routing.module';
import { BbMarketComponent } from './bb-market.component';
import { ExchangeComponent } from './exchange/exchange.component';
import {commonDerectivenModule} from "../auth-gaurd/commonDerective.module";
import {BrowserModule} from "@angular/platform-browser";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {DemoMaterialModule} from "../../material-module";
import {FormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";
import {ModalModule} from "ngx-bootstrap";
import {AngularMultiSelectModule} from "angular2-multiselect-dropdown";
import {NgbDateParserFormatter, NgbModule} from "@ng-bootstrap/ng-bootstrap";
import {DataTablesModule} from "angular-datatables";
import {SportService} from "../services/sport.service";
import {BinaryService} from "../services/binary.service";
 import { LotSizeMasterComponent } from './lot-size-master/lot-size-master.component';
 import { ImportScriptDataComponent } from './import-script-data/import-script-data.component';
 import { ScriptListComponent } from './script-list/script-list.component';
import { ScriptQtySettingComponent } from './script-qty-setting/script-qty-setting.component';
import { DefaultPortfolioComponent } from './default-portfolio/default-portfolio.component';
import {NgbDateMomentParserFormatter} from "../auth-gaurd/date_format";
import { BrokrageListComponent } from './brokrage-list/brokrage-list.component';
import { SettelementListComponent } from './settelement-list/settelement-list.component';
import { WeeklySettleListComponent } from './weekly-settle-list/weekly-settle-list.component';
import { HolidayListComponent } from './holiday-list/holiday-list.component';
import {CalendarModule, DateAdapter} from 'angular-calendar';
import {adapterFactory} from 'angular-calendar/date-adapters/date-fns';
import { WeeklySettleHistoryComponent } from './weekly-settle-history/weekly-settle-history.component';
import { ContractSettleHistoryComponent } from './contract-settle-history/contract-settle-history.component';
// import {FlatpickrModule} from 'angularx-flatpickr';

@NgModule({
  declarations: [BbMarketComponent, ExchangeComponent,
       LotSizeMasterComponent,
    ScriptListComponent ,
     ImportScriptDataComponent,
     ScriptQtySettingComponent,
     DefaultPortfolioComponent,
     BrokrageListComponent,
     SettelementListComponent,
     WeeklySettleListComponent,
     HolidayListComponent,
     WeeklySettleHistoryComponent,
     ContractSettleHistoryComponent
  ],
  imports: [
    CommonModule,
    BbMarketRoutingModule,
    commonDerectivenModule,
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    FormsModule,
    HttpClientModule,
    ModalModule.forRoot(),
    AngularMultiSelectModule,
    NgbModule,
    DataTablesModule,
    // FlatpickrModule.forRoot(),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
  ],
  providers: [SportService, BinaryService,
    {
      provide: NgbDateParserFormatter,
      useFactory: () => { return new NgbDateMomentParserFormatter('DD-MM-YYYY') }
    }
  ],

  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class BbMarketModule { }
