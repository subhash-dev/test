import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bb-market',
  templateUrl: './bb-market.component.html',
  styleUrls: ['./bb-market.component.scss']
})
export class BbMarketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
