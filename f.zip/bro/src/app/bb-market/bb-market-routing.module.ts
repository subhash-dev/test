import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AuthGuard} from "../auth-gaurd/auth-guard.service";
import {RoleGuard} from "../auth-gaurd/role-guard.service";
import {BbMarketComponent} from "./bb-market.component";
import {ExchangeComponent} from "./exchange/exchange.component";
 import {LotSizeMasterComponent} from "./lot-size-master/lot-size-master.component";
 import {ImportScriptDataComponent} from "./import-script-data/import-script-data.component";
import {ScriptListComponent} from "./script-list/script-list.component";
import {ScriptQtySettingComponent} from "./script-qty-setting/script-qty-setting.component";
import {DefaultPortfolioComponent} from "./default-portfolio/default-portfolio.component";
import {BrokrageListComponent} from './brokrage-list/brokrage-list.component';
import {SettelementListComponent} from './settelement-list/settelement-list.component';
import {WeeklySettleListComponent} from './weekly-settle-list/weekly-settle-list.component';
import {HolidayListComponent} from './holiday-list/holiday-list.component';
import {WeeklySettleHistoryComponent} from './weekly-settle-history/weekly-settle-history.component';
import {ContractSettleHistoryComponent} from './contract-settle-history/contract-settle-history.component';

const routes: Routes = [{
  path: 'bbmarket',
  canActivate: [AuthGuard],
  component: BbMarketComponent,
  children: [
    {
      path: 'exchange',
      canActivate: [AuthGuard,RoleGuard],
      component: ExchangeComponent,
    }
    ,
    {
      path: 'lot-size-master',
      canActivate: [AuthGuard,RoleGuard],
      component: LotSizeMasterComponent,
     }
    ,
    {
      path: 'import-script-data',
      canActivate: [AuthGuard,RoleGuard],
      component: ImportScriptDataComponent,
    }
    ,
    {
      path: 'script-list',
      canActivate: [AuthGuard,RoleGuard],
      component: ScriptListComponent,
    },
    {
      path: 'brokrage-list',
      canActivate: [AuthGuard,RoleGuard],
      component: BrokrageListComponent,
    },
    {
      path: 'script-qty-setting',
      canActivate: [AuthGuard,RoleGuard],
      component: ScriptQtySettingComponent,
    },
    {
      path: 'default-portfolio',
      canActivate: [AuthGuard,RoleGuard],
      component: DefaultPortfolioComponent,
    },
    {
      path: 'contract-list',
      canActivate: [AuthGuard,RoleGuard],
      component: SettelementListComponent,
    },
    {
      path: 'weekly-list',
      canActivate: [AuthGuard,RoleGuard],
      component: WeeklySettleListComponent,
    },
    {
      path: 'holiday-list',
      canActivate: [AuthGuard,RoleGuard],
      component: HolidayListComponent,
    },
    {
      path: 'weekly-history',
      canActivate: [AuthGuard,RoleGuard],
      component: WeeklySettleHistoryComponent,
    },
    {
      path: 'contract-history',
      canActivate: [AuthGuard,RoleGuard],
      component: ContractSettleHistoryComponent,
    }
  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class BbMarketRoutingModule { }
