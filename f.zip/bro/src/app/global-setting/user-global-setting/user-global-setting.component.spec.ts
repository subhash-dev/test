import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserGlobalSettingComponent } from './user-global-setting.component';

describe('UserGlobalSettingComponent', () => {
  let component: UserGlobalSettingComponent;
  let fixture: ComponentFixture<UserGlobalSettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserGlobalSettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserGlobalSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
