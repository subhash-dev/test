import {Component, OnInit, ViewChild} from '@angular/core';
import {GameSettingService} from '../../services/gameSettingService.service';
import {ModalDirective} from 'ngx-bootstrap';
import {SportService} from '../../services/sport.service';
import {isUndefined} from "util";
import {UtilityService} from '../../globals/utilityService';
import {Router} from '@angular/router';
import {NgxSpinnerService} from "ngx-spinner";

@Component({
  selector: 'app-user-global-setting',
  templateUrl: './user-global-setting.component.html',
  styleUrls: ['./user-global-setting.component.scss']
})
export class UserGlobalSettingComponent implements OnInit {
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild("addTournamentForm", {static: false}) formResetValue;
  constructor(private gameSettingService: GameSettingService,
              private sportService : SportService,
              private utilityService : UtilityService,
              private spinner: NgxSpinnerService,
              private router : Router

  ) { }
  userSettings:any;
  sportList = [];
  selectedSportItems = [];
  sportSettings = {
    singleSelection: true,
    text: 'Select Sport',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
  };
  sportFilter = {
    page: 1,
    limit: -1,
    search: null
  };
  accessRole:any;
  ngOnInit() {
    if (isUndefined(this.utilityService.returnAccessRole('USERSETTING'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('USERSETTING');
    }
    this.getUserSetting();
    this.getAllSport();

  }

  /***
   * get all user settings
   */
  getUserSetting(){
    this.spinner.show()
    this.gameSettingService.getAllUserSetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.userSettings = response.data;
        this.spinner.hide()
    }, error =>{
         console.error("error in get game setting", error);
    })
  }

  /**
   * open modal
   */
  openModal() {
    this.modal.show();
  }
  /**
   * open modal
   */
  closeModal() {
    this.formResetValue.resetForm();
    this.modal.hide();
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * sport search with name
   */
  onSportSearch(e) {
    this.sportFilter.search = e.target.value;
    this.getAllSport();
  }

  /**
   * @author kc
   * @date : 17-02-2020
   * get all sports
   */
  getAllSport() {

    this.sportService.getAllSport(this.sportFilter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.sportList = response.data.docs.map(data => {
        return {id: data.id, itemName: data.name + '( ' + data.id + ' )', sportId: data.id};
      });
      // this.sportList.push({
      //     id: '5ebc1code68br4bik5b1808',
      //     itemName: 'Fancy'
      //   },
      //   {
      //     id: '5ebc1code68br4bik5b0810',
      //     itemName: 'Bookmaker'
      //   })
    }, error => {
      console.error('error in getting all sports', error);
    });
  }

  addUserSettings(){
    let finalUserObject = {
      sport: {
        id: this.selectedSportItems[0]['id'],
        name: this.selectedSportItems[0]['itemName']
      },
      minStack: 0,
      maxStack: 0,
      maxProfit: 0,
      maxLoss: 0,
      betDelay: 0,
      minOdds: 0,
      maxOdds: 0,
      preInPlayProfit: 0,
      preInPlayStack: 0
    };
    this.gameSettingService.addUserSetting(finalUserObject).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if(response.status === true){
        // this.addWhtLblUserSetting(finalUserObject);
        this.getUserSetting();
        this.modal.hide();
        if (response.status === true) {
          this.utilityService.popToast('success','Success', 3000 , 'User setting created successfully');
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }else{
        this.modal.hide();
      }
    }, error =>{
      console.error("error in add user setting", error);
    })
  }

  /***
   * update white lable user settings
   */
  addWhtLblUserSetting(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){
        this.gameSettingService.addWhtLblUserSetting(data ,  x[i]).subscribe(response => {
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /***
   * update user settings
   */
  updateUserSettings(data){
    data.minStack = data.minStack === "null" ? JSON.parse("null") : data.minStack;
    data.maxProfit = data.maxProfit === "null" ? JSON.parse("null") : data.maxProfit;
    data.maxLoss = data.maxLoss === "null" ? JSON.parse("null") : data.maxLoss;
    data.betDelay = data.betDelay === "null" ? JSON.parse("null") : data.betDelay;
    data.minOdds = data.minOdds === "null" ? JSON.parse("null") : data.minOdds;
    data.maxOdds = data.maxOdds === "null" ? JSON.parse("null") : data.maxOdds;
    data.preInPlayProfit = data.preInPlayProfit === "null" ? JSON.parse("null") : data.preInPlayProfit;
    data.preInPlayStack = data.preInPlayStack === "null" ? JSON.parse("null") : data.preInPlayStack;

    this.gameSettingService.updateUserSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
     if(response.status === true){
       // this.updateWhtLblUserSettings(data);
       this.getUserSetting();
       this.utilityService.popToast('success','Success', 3000 , 'User setting updated successfully');
     }else{
       this.utilityService.popToast('error','Error', 3000 , response.message);
     }
    }, error =>{
      console.error("error in get game setting", error);
    })
  }

  // /***
  //  * update white lable user settings
  //  */
  // updateWhtLblUserSettings(data){
  //   data.minStack = data.minStack === "null" ? JSON.parse("null") : data.minStack;
  //   data.maxProfit = data.maxProfit === "null" ? JSON.parse("null") : data.maxProfit;
  //   data.maxLoss = data.maxLoss === "null" ? JSON.parse("null") : data.maxLoss;
  //   data.betDelay = data.betDelay === "null" ? JSON.parse("null") : data.betDelay;
  //   data.minOdds = data.minOdds === "null" ? JSON.parse("null") : data.minOdds;
  //   data.maxOdds = data.maxOdds === "null" ? JSON.parse("null") : data.maxOdds;
  //   data.preInPlayProfit = data.preInPlayProfit === "null" ? JSON.parse("null") : data.preInPlayProfit;
  //   data.preInPlayStack = data.preInPlayStack === "null" ? JSON.parse("null") : data.preInPlayStack;
  //
  //   this.gameSettingService.updateWhtLblUserSetting(data).subscribe(response =>{
  //    if(response.status === true){
  //
  //      // this.utilityService.popToast('success','Success', 3000 , 'User setting updated successfully');
  //    }else{
  //      this.utilityService.popToast('error','Error', 3000 , response.message);
  //    }
  //   }, error =>{
  //     console.error("error in get game setting", error);
  //   })
  // }


}
