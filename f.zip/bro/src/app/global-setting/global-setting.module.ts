import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { GlobalSettingComponent } from './global-setting.component';
import { GameSettingComponent } from './game-setting/game-setting.component';
import {GlobalSettingRoutingModule} from './global-setting-routing.module';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {AngularMultiSelectModule} from 'angular2-multiselect-dropdown';
import {DemoMaterialModule} from '../../material-module';
import {commonDerectivenModule} from '../auth-gaurd/commonDerective.module';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {ModalModule} from 'ngx-bootstrap';
import { UserGlobalSettingComponent } from './user-global-setting/user-global-setting.component';
import {GameSettingService} from '../services/gameSettingService.service';
import { WhiteLabelSettingComponent } from './white-label-setting/white-label-setting.component';
import {WhiteLabelSettingService} from '../services/whitelabelsetting.service';
import {MatSelectModule} from '@angular/material';
import {ConstantService} from '../globals/constant.service';
import { WhiteLabelAddComponent } from './white-label-add/white-label-add.component';

@NgModule({
  declarations: [GlobalSettingComponent, GameSettingComponent, UserGlobalSettingComponent, WhiteLabelSettingComponent, WhiteLabelAddComponent],
  imports: [
    CommonModule,
    GlobalSettingRoutingModule,
    commonDerectivenModule,
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    FormsModule,
    HttpClientModule,
    ModalModule.forRoot(),
    AngularMultiSelectModule,
    NgbModule,
    MatSelectModule
  ],
  schemas : [CUSTOM_ELEMENTS_SCHEMA],
  providers : [GameSettingService, WhiteLabelSettingService, ConstantService]
})
export class GlobalSettingModule { }
