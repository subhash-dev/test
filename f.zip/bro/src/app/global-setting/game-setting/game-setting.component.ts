import {Component, OnInit, ViewChild} from '@angular/core';
import {GameSettingService} from '../../services/gameSettingService.service';
import {isUndefined} from "util";
import {UtilityService} from '../../globals/utilityService';
import {Router} from '@angular/router';
import {SportService} from '../../services/sport.service';
import {ModalDirective} from 'ngx-bootstrap';
import {ToasterConfig} from 'angular2-toaster';
import {NgxSpinnerService} from "ngx-spinner";

@Component({
  selector: 'app-game-setting',
  templateUrl: './game-setting.component.html',
  styleUrls: ['./game-setting.component.scss']
})
export class GameSettingComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild("addTournamentForm", {static: false}) formResetValue;
  accessRole  :any;
  constructor(private gameSettingService : GameSettingService,
              private utilityService: UtilityService,
              private spinner: NgxSpinnerService,
              private router: Router,
              private sportService : SportService

  ) { }

  filter={
    page : 1,
    limit : 10,
    search : null
  };
  sportFilter = {
    page: 1,
    limit: -1,
    search: null
  };
  cupSettings : any;
  gameSettings : any;
  casinoSettings : any;
  fancySettingData : any;
  bookmakerSettingData : any;
  fancyConfgSettings : any;
  lineConfgSettings : any;
  LineSettingData : any;
  sportList = [];
  selectedSportItems = [];
  sportSettings = {
    singleSelection: true,
    text: 'Select Sport',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
  };
  addUserDataSetting = false;
  ngOnInit() {
    if(isUndefined(this.utilityService.returnAccessRole('GAMESETTING'))){
      this.router.navigate(['accessdenied']);
    }else{
      this.accessRole = this.utilityService.returnAccessRole('GAMESETTING');
    }
    this.getAllSport();
    this.getGameSetting();
    this.getCasinoSetting();
    this.getCupSetting();
    this.getFancySetting();
    this.getBookmakerSetting();
    this.getFancyConfigSetting();
    this.getLineConfigSetting();
    this.lineMarketSettings();
  }

  /**
   * open modal
   */
  openModal() {
    this.modal.show();
  }
  /**
   * open modal
   */
  closeModal() {
    this.formResetValue.resetForm();
    this.modal.hide();
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * sport search with name
   */
  onSportSearch(e) {
    this.filter.search = e.target.value;
    this.getAllSport();
  }

  /**
   * @author kc
   * @date : 17-02-2020
   * get all sports
   */
  getAllSport() {

    this.sportService.getAllSport(this.sportFilter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
		response =JSON.parse(response);
        this.sportList = response.data.docs.map(data => {
            return {id: data.id, itemName: data.name + '( ' + data.id + ' )', sportId: data.id};
        });
        this.sportList.push({
            id: '5ebc1code68br4bik5b1808',
            itemName: 'Fancy'
        },{
            id: '5ebc1code68br4bik5b0810',
            itemName: 'Bookmaker'
        },{
            id: '5ebc1code68br4bik5b0811',
            itemName: 'Line'
        },{
             id: '5ebc1code68br4bik5b0814',
            itemName: 'Cup'
        })
    }, error => {
      console.error('error in getting all sports', error);
    });
  }

  /**
   * create new game setting
   * in office panel
   */
  createGameSetting(){
    if(this.selectedSportItems[0]['id'] === '5ebc1code68br4bik5b1808'){
      let finalFancy = {
        id:'5ebc1code68br4bik5b1808',
        minStack:0,
        maxStack: 0,
        maxProfit: 0,
        maxLoss: 0,
        betDelay: 0,
        maxStackPerOdds: 0
      };

      this.gameSettingService.addFancySetting(finalFancy).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
		response =JSON.parse(response);
        this.modal.hide();
        if(response.status === true){

          let finalUserObject = {
            sport: {
              id: this.selectedSportItems[0]['id'],
              name: this.selectedSportItems[0]['itemName']
            },
            minStack: 0,
            maxStack: 0,
            maxProfit: 0,
            maxLoss: 0,
            betDelay: 0,
            preInPlayProfit: 0,
            preInPlayStack: 0
          };
        this.gameSettingService.addUserSetting(finalUserObject).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
            if (response.status === true) {
                // this.addUserSettingWhtLbl(finalUserObject);
                this.utilityService.popToast('success','Success', 3000 , 'User setting created successfully');
            }else{
                this.utilityService.popToast('error','Error', 3000 , response.message);
            }
        }, error =>{
            this.utilityService.popToast('error','Error', 3000 , error.message);
            console.error("error in add user setting", error);
        });



          // this.addFancySettingWhtLbl(finalFancy);
            this.utilityService.popToast('success','Success', 3000 , 'Fancy setting created successfully');
            this.getFancySetting();

        }else{
            this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }, error =>{
            console.error("error in add user setting", error);
      })
    }
    else if(this.selectedSportItems[0]['id'] === '5ebc1code68br4bik5b0810'){
      let finalBookmaker = {
        id:'5ebc1code68br4bik5b0810',
        minStack:0,
        maxStack: 0,
        maxProfit: 0,
        maxLoss: 0,
        betDelay: 0,
        maxStackPerOdds: 0
      };

    this.gameSettingService.addBookMakerSetting(finalBookmaker).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.modal.hide();
        if(response.status === true){
          let finalUserObject = {
            sport: {
              id: this.selectedSportItems[0]['id'],
              name: this.selectedSportItems[0]['itemName']
            },
            minStack: 0,
            maxStack: 0,
            maxProfit: 0,
            minOdds: 0,
            maxOdds: 0,
            maxLoss: 0,
            betDelay: 0,
            preInPlayProfit: 0,
            preInPlayStack: 0
          };
          this.gameSettingService.addUserSetting(finalUserObject).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
            if (response.status === true) {
              // this.addUserSettingWhtLbl(finalUserObject);
              this.utilityService.popToast('success','Success', 3000 , 'User setting created successfully');
            }else{
              this.utilityService.popToast('error','Error', 3000 , response.message);
            }
          }, error =>{
            this.utilityService.popToast('error','Error', 3000 , error.message);
            console.error("error in add user setting", error);
          });



          this.getBookmakerSetting();
          // this.addBookmakerSettingWhtLbl(finalBookmaker);
          this.utilityService.popToast('success','Success', 3000 , 'Bookmaker setting created successfully');
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }, error =>{
        this.utilityService.popToast('error','Error', 3000 , error.message);
        console.error("error in add user setting", error);
      })

    }
    else if(this.selectedSportItems[0]['id'] === '5ebc1code68br4bik5b0811'){
      let finalLineMarket = {
        id:'5ebc1code68br4bik5b0811',
        minStack:0,
        maxStack: 0,
        maxProfit: 0,
        maxLoss: 0,
        betDelay: 0,
        maxStackPerOdds: 0,
        volume: 0,
        MultiplierVolume: 0
      };

      this.gameSettingService.addLineMarketSetting(finalLineMarket).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.modal.hide();
        if(response.status === true){
          let finalUserObject = {
            sport: {
              id: this.selectedSportItems[0]['id'],
              name: this.selectedSportItems[0]['itemName']
            },
            minStack: 0,
            maxStack: 0,
            maxProfit: 0,
            minOdds: 0,
            maxOdds: 0,
            maxLoss: 0,
            betDelay: 0,
            preInPlayProfit: 0,
            preInPlayStack: 0
          };
          this.gameSettingService.addUserSetting(finalUserObject).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
            if (response.status === true) {
              // this.addUserSettingWhtLbl(finalUserObject);
              this.utilityService.popToast('success','Success', 3000 , 'User setting created successfully');
            }else{
              this.utilityService.popToast('error','Error', 3000 , response.message);
            }
          }, error =>{
            this.utilityService.popToast('error','Error', 3000 , error.message);
            console.error("error in add user setting", error);
          });



          this.lineMarketSettings();
           // this.addLineMarketSettingWhtLbl(finalLineMarket);
          this.utilityService.popToast('success','Success', 3000 , 'Line market setting created successfully');
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }, error =>{
        this.utilityService.popToast('error','Error', 3000 , error.message);
        console.error("error in add user setting", error);
      })

    }
    else if(this.selectedSportItems[0]['id'] === '5ebc1code68br4bik5b0814'){
      let finalCupMarket = {
        sport: {
          id: this.selectedSportItems[0]['id'],
          name: this.selectedSportItems[0]['itemName']
        },
        volume: 0,
        minStack: 0,
        maxStack: 0,
        maxProfit: 0,
        maxLoss: 0,
        betDelay: 0,
        minOdds: 0,
        maxOdds: 0,
        preInPlayProfit: 0,
        preInPlayStack: 0
      };

      this.gameSettingService.addNewCupSetting(finalCupMarket).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.modal.hide();
        if(response.status === true){
          let finalUserObject = {
            sport: {
              id: this.selectedSportItems[0]['id'],
              name: this.selectedSportItems[0]['itemName']
            },
            minStack: 0,
            maxStack: 0,
            maxProfit: 0,
            minOdds: 0,
            maxOdds: 0,
            maxLoss: 0,
            betDelay: 0,
            preInPlayProfit: 0,
            preInPlayStack: 0
          };
          this.gameSettingService.addUserSetting(finalUserObject).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
            if (response.status === true) {
              // this.addUserSettingWhtLbl(finalUserObject);
              this.utilityService.popToast('success','Success', 3000 , 'User setting created successfully');
            }else{
              this.utilityService.popToast('error','Error', 3000 , response.message);
            }
          }, error =>{
            this.utilityService.popToast('error','Error', 3000 , error.message);
            console.error("error in add user setting", error);
          });



          this.getCupSetting();
          // this.addNewCupSettingWhtLbl(finalCupMarket);
          this.utilityService.popToast('success','Success', 3000 , 'Cup market setting created successfully');
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }, error =>{
        this.utilityService.popToast('error','Error', 3000 , error.message);
        console.error("error in add user setting", error);
      })

    }
    else{
      let finalDataObject = {
        sport: {
          id: this.selectedSportItems[0]['id'],
          name: this.selectedSportItems[0]['itemName']
        },
        volume: 0,
        minStack: 0,
        maxStack: 0,
        maxProfit: 0,
        maxLoss: 0,
        betDelay: 0,
        minOdds: 0,
        maxOdds: 0,
        preInPlayProfit: 0,
        preInPlayStack: 0
      };
      this.gameSettingService.addNewGameSetting(finalDataObject).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status === true){
          this.utilityService.popToast('success','Success', 3000 , 'Game setting created successfully');

            let finalUserObject = {
              sport: {
                id: this.selectedSportItems[0]['id'],
                name: this.selectedSportItems[0]['itemName']
              },
              minStack: 0,
              maxStack: 0,
              maxProfit: 0,
              maxLoss: 0,
              betDelay: 0,
              minOdds: 0,
              maxOdds: 0,
              preInPlayProfit: 0,
              preInPlayStack: 0
            };
            this.gameSettingService.addUserSetting(finalUserObject).subscribe(response =>{
                response = this.utilityService.gsk(response.auth);
                response =JSON.parse(response);
                if (response.status === true) {
                    // this.addUserSettingWhtLbl(finalUserObject);
                    this.utilityService.popToast('success','Success', 3000 , 'User setting created successfully');
                }else{
                    this.utilityService.popToast('error','Error', 3000 , response.message);
                }
            }, error =>{
              this.utilityService.popToast('error','Error', 3000 , error.message);
              console.error("error in add user setting", error);
            })

            // this.addNewGameSettingWhtLbl(finalDataObject);

          this.getGameSetting();
          this.modal.hide();
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }, error =>{
        console.error("error in update game setting", error);
      })
    }


  }

  /****
   * add new game setting in office panel
   * match odds with value 0
   * @param data
   */
  addNewGameSettingWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        let x = response.data;
        /* Hear X is Multiple Whitelable Data*/
        for(let i = 0;i < x.length; i++){
            this.gameSettingService.addNewGameSettingWhtLbl(data ,  x[i]).subscribe(response => {
            });
        }
    }).catch(error =>{
      console.error("errro in get white label");
    });
    // this.gameSettingService.addNewGameSettingWhtLbl(data).subscribe(response =>{
    //   if(response.status === true){
    //     this.utilityService.popToast('success','Success', 3000 , 'Game setting update Whtlbl successfully');
    //   }else{
    //     this.utilityService.popToast('error','Error', 3000 , response.message);
    //   }
    // }, error =>{
    //   console.error("error in update game setting", error);
    //   this.utilityService.popToast('error','Error', 3000 , error.message);
    // })
  }

  /****
   * add new game setting in office panel
   * match odds with value 0
   * @param data
   */
  addNewCupSettingWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        let x = response.data;
        /* Hear X is Multiple Whitelable Data*/
        for(let i = 0;i < x.length; i++){
            this.gameSettingService.addNewCupSettingWhtLbl(data ,  x[i]).subscribe(response => {
            });
        }
    }).catch(error =>{
      console.error("errro in get white label");
    });
    // this.gameSettingService.addNewGameSettingWhtLbl(data).subscribe(response =>{
    //   if(response.status === true){
    //     this.utilityService.popToast('success','Success', 3000 , 'Game setting update Whtlbl successfully');
    //   }else{
    //     this.utilityService.popToast('error','Error', 3000 , response.message);
    //   }
    // }, error =>{
    //   console.error("error in update game setting", error);
    //   this.utilityService.popToast('error','Error', 3000 , error.message);
    // })
  }
  /****
   * add new user setting in office panel
   * user setting with value 0
   * @param data
   */
  addUserSettingWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        let x = response.data;
        /* Hear X is Multiple Whitelable Data*/
        for(let i = 0;i < x.length; i++){
            this.gameSettingService.addUserSettingWhtLbl(data ,  x[i]).subscribe(response => {
            });
        }
    }).catch(error =>{
      console.error("errro in get white label");
    });
    // this.gameSettingService.addUserSettingWhtLbl(data).subscribe(response =>{
    //   if(response.status === true){
    //     this.utilityService.popToast('success','Success', 3000 , 'Game setting update Whtlbl successfully');
    //   }else{
    //     this.utilityService.popToast('error','Error', 3000 , response.message);
    //   }
    // }, error =>{
    //   console.error("error in update game setting", error);
    //   this.utilityService.popToast('error','Error', 3000 , error.message);
    // })
  }
  /****
   * add new bookmaker setting in office panel
   * match odds with value 0
   * @param data
   */
  addBookmakerSettingWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        let x = response.data;
        /* Hear X is Multiple Whitelable Data*/
        for(let i = 0;i < x.length; i++){
            this.gameSettingService.addBookmakerSettingWhtLbl(data ,  x[i]).subscribe(response => {
            });
        }
    }).catch(error =>{
      console.error("errro in get white label");
    });
    // this.gameSettingService.addBookmakerSettingWhtLbl(data).subscribe(response =>{
    //   if(response.status === true){
    //     this.utilityService.popToast('success','Success', 3000 , 'Game setting update Whtlbl successfully');
    //   }else{
    //     this.utilityService.popToast('error','Error', 3000 , response.message);
    //   }
    // }, error =>{
    //   console.error("error in update game setting", error);
    //   this.utilityService.popToast('error','Error', 3000 , error.message);
    // })
  }


  /****
   * add new Line Market setting in office panel
   * match odds with value 0
   * @param data
   */
  addLineMarketSettingWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        let x = response.data;
        /* Hear X is Multiple Whitelable Data*/
        for(let i = 0;i < x.length; i++){
            this.gameSettingService.addLineMarketSettingWhtLbl(data ,  x[i]).subscribe(response => {
            });
        }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  /****
   * add new fancy setting in office panel
   * fancy with value 0
   * @param data
   */
  addFancySettingWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        let x = response.data;
        /* Hear X is Multiple Whitelable Data*/
        for(let i = 0;i < x.length; i++){
            this.gameSettingService.addFancySettingWhtLbl(data ,  x[i]).subscribe(response => {
            });
        }
    }).catch(error =>{
      console.error("errro in get white label");
    });
    // this.gameSettingService.addFancySettingWhtLbl(data).subscribe(response =>{
    //   if(response.status === true){
    //     this.utilityService.popToast('success','Success', 3000 , 'Game setting update Whtlbl successfully');
    //   }else{
    //     this.utilityService.popToast('error','Error', 3000 , response.message);
    //   }
    // }, error =>{
    //   console.error("error in update game setting", error);
    //   this.utilityService.popToast('error','Error', 3000 , error.message);
    // })
  }


  /*-------------------- Match Odds-------------------------------------------*/
  /******match odds setting get, update , update in white label START****************/

  /**
   * get all match odds settings
   * from office panel
   */
  getGameSetting(){
    this.spinner.show();
    this.gameSettingService.getAllGameSetting(this.filter).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.gameSettings = response.data;
        this.spinner.hide();
    }, error =>{
        this.spinner.hide();
        console.error("error in get game setting", error);
    })
  }

  /**
   * get all casino odds settings
   * from office panel
   */
  getCasinoSetting(){
    this.spinner.show();
    this.gameSettingService.getAllCasinoSetting(this.filter).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.casinoSettings = response.data;
        this.spinner.hide();
    }, error =>{
        this.spinner.hide();
        console.error("error in get game setting", error);
    })
  }

  /*-------------------- Match Odds-------------------------------------------*/
  /******cup setting get, update , update in white label START****************/

  /**
   * get all match odds settings
   * from office panel
   */
  getCupSetting(){
    this.spinner.show()
    this.gameSettingService.getAllCupSetting(this.filter).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.cupSettings = response.data;
        this.spinner.hide()
    }, error =>{
        this.spinner.hide()
        console.error("error in get cup setting", error);
    })
  }

  /***
   * update in only office panel
   * database
   * @param data
   */
  updateGlobalSetting(data , item){
    if(item === 'odds'){
      this.gameSettingService.updateGameSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status === true){
          this.spinner.hide();
          this.getGameSetting();
          this.utilityService.popToast('success','Success', 3000 , 'Game setting updated successfully');
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }, error =>{
        console.error("error in update game setting", error);
        this.utilityService.popToast('error','Error', 3000 , error.message);
      })
    }else if(item === 'casino'){
      this.gameSettingService.updateCasinoSetting(data).subscribe(response =>{
        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
           this.spinner.hide();
          this.getCasinoSetting();
          this.utilityService.popToast('success','Success', 3000 , 'casino setting updated successfully');
      }, error =>{
        console.error("error in update cup setting", error);
        this.utilityService.popToast('error','Error', 3000 , error.message);
      })
    }else {
      this.gameSettingService.updateCupSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status === true){
          this.spinner.hide();
          this.getCupSetting();
          this.utilityService.popToast('success','Success', 3000 , 'Cup setting updated successfully');
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }, error =>{
        console.error("error in update cup setting", error);
        this.utilityService.popToast('error','Error', 3000 , error.message);
      })
    }

  }

  /***
   * update all game setting in office panel
   * as well as in all white label function call
   * @param data
   */

  updateGlobalSettingToAllMarket(data , typ){
    if(typ === 'odds'){
    this.gameSettingService.updateAllMarketSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if (response.status === true) {
        this.spinner.hide();
        /*update in white label function call*/
        // this.updateGameSettingToAllWhtLbl(data);
        this.utilityService.popToast('success','Success', 3000 , 'Game setting update to all market successfully');
      }else{
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }
    }, error =>{
      this.utilityService.popToast('error','Error', 3000 , error.message);
      console.error("error in update market");
    })
    }else {
      this.gameSettingService.updateAllCupSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status === true) {
          this.spinner.hide();
          /*update in white label function call*/
          // this.updateCupSettingToAllWhtLbl(data);
          this.utilityService.popToast('success','Success', 3000 , 'Cup setting update to all market successfully');
        }else{
          this.utilityService.popToast('error','Error', 3000 , response.message);
        }
      }, error =>{
        this.utilityService.popToast('error','Error', 3000 , error.message);
        console.error("error in update cup");
      })
    }
  }


  /***
   * update setting in all white label
   * market table game setting data
   * @param data
   */

  updateGameSettingToAllWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      let x = response.data;
      for(let i = 0;i < x.length; i++){
        this.gameSettingService.updateGameSettingToAllWhtLbl(data, x[i]).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
          if (response.status === true) {
            this.spinner.hide();
            // this.utilityService.popToast('success','Success', 3000 , 'Fancy setting update to all market successfully');
          }else{
            this.spinner.hide();
            // this.utilityService.popToast('error','Error', 3000 , response.message);
          }
        }, error =>{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , error.message);
          console.error("error in update market");
        })
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });


  }
  /***
   * update setting in all white label
   * market table game setting data
   * @param data
   */

  updateCupSettingToAllWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      let x = response.data;
      for(let i = 0;i < x.length; i++){
        this.gameSettingService.updateCupSettingToAllWhtLbl(data, x[i]).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
          if (response.status === true) {
            this.spinner.hide();
            // this.utilityService.popToast('success','Success', 3000 , 'Fancy setting update to all market successfully');
          }else{
            this.spinner.hide();
            // this.utilityService.popToast('error','Error', 3000 , response.message);
          }
        }, error =>{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , error.message);
          console.error("error in update market");
        })
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });


  }

  /******match odds setting get, update , update in white label END****************/


  /*-------------------------------fancy settings----------------------*/
  /******fancy setting get, update , update in white label START****************/

  /***
   * get global fancy setting
   * office panel
   */
  getFancySetting(){
    this.spinner.show();
    this.gameSettingService.getAllFancySetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.fancySettingData = response.data;
        this.spinner.hide()
    }, error =>{
      this.spinner.hide();
      console.error("error in get fancy setting", error);
    })
  }



  /***
   * update fancy setting
   * in office panel
   * @param data
   */
  updateFancySetting(data){
    this.gameSettingService.updateFancySetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if(response.status === true){
        this.getFancySetting();

        this.utilityService.popToast('success','Success', 3000 , 'Fancy setting updated successfully');
      }else{
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }
    }, error =>{
      console.error("error in update fancy setting", error);
    })
  }

  /***
   * update facny setting in office panel fancy global setting
   * as well as in all white label all fancy
   * open, and active
   * @param data
   */
  updateFancySettingToAll(data){
    this.gameSettingService.updateAllFancySetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if (response.status === true) {
         // this.updateFancySettingToAllWhtLbl(data);
        this.utilityService.popToast('success','Success', 3000 , 'Fancy setting update to all market successfully');
      }else{
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }
    }, error =>{
      this.utilityService.popToast('error','Error', 3000 , error.message);
      console.error("error in update market");
    })
  }

  /*****call muluiple while label*****/

  updateFancySettingToAllWhtLbl(data){

    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      let x = response.data;
      for(let i = 0;i < x.length; i++){
        this.gameSettingService.updateFancySettingToAllWhtLbl(data, x[i]).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
          if (response.status === true) {
            // this.utilityService.popToast('success','Success', 3000 , 'Fancy setting update to all market successfully');
          }else{
            // this.utilityService.popToast('error','Error', 3000 , response.message);
          }
        }, error =>{
          this.utilityService.popToast('error','Error', 3000 , error.message);
          console.error("error in update market");
        })
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });

  }

  /******fancy setting get, update , update in white label END****************/

  /*-----------------------bookmaker setting ------------------------------- */

  /******Bookmaker setting get, update , update in white label START****************/

  /**
   * get bookmaker global setting from
   * office panel
   */
  getBookmakerSetting(){
    this.spinner.show()
    this.gameSettingService.getAllBookmakerSetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.bookmakerSettingData = response.data;
        console.log(this.bookmakerSettingData)
        this.spinner.hide()
    }, error =>{
        this.spinner.hide()
        console.error("error in get bookmaker setting", error);
    })
  }

  /**
   * update bookmaker global setting in
   * office panel
   */
  updateBookmakerSetting(data){
    this.gameSettingService.updateBookmakerSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status === true){
            this.getBookmakerSetting();
            this.utilityService.popToast('success','Success', 3000 , 'Bookmaker setting updated successfully');
        }else{
            this.utilityService.popToast('error','Error', 3000 , response.message);
        }
    }, error =>{
      this.utilityService.popToast('error','Error', 3000 , error.message);
      console.error("error in update bookmaker setting", error);
    })
  }


  /**
   * update bookmaker setting in market table
   * in all white label
   */
  updateBookmakerSettingToAll(data){
    this.gameSettingService.updateAllBookMakerSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status === true) {
            // this.updateBookmakerSettingToAllWhtLbl(data);
            this.utilityService.popToast('success','Success', 3000 , 'Bookmaker setting update to all market successfully');
        }else{
            this.utilityService.popToast('error','Error', 3000 , response.message);
        }
    }, error =>{
      this.utilityService.popToast('error','Error', 3000 , error.message);
      console.error("error in update market");
    })
  }



  /*******call fucntion for white lable ******/

  updateBookmakerSettingToAllWhtLbl(data){

    this.utilityService.getAllWhiteLabel().then(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        let x = response.data;
        for(let i = 0;i < x.length; i++){
            this.gameSettingService.updateBookmakerSettingToAllWhtLbl(data, x[i]).subscribe(response =>{
            if (response.status === true) {
                // this.utilityService.popToast('success','Success', 3000 , 'Fancy setting update to all market successfully');
            }else{
                // this.utilityService.popToast('error','Error', 3000 , response.message);
            }
            }, error =>{
            this.utilityService.popToast('error','Error', 3000 , error.message);
            console.error("error in update market");
            })
        }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }


  /******Bookmaker setting get, update , update in white label EMD****************/

  singleGameSettingObj:any;
  setSingleGameSettingObj(data) {
    this.singleGameSettingObj = data;
  }

  /**
   * @developed: TR
   * get fancy configuare settings
   * from office panel
   */
  getFancyConfigSetting(){
    this.spinner.show()
    this.gameSettingService.getAllfancyConfgSetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.fancyConfgSettings = response.data;
        this.spinner.hide();
    }, error =>{
      this.spinner.hide();
      console.error("error in get game setting", error);
    });
  }

  /**
   * @developed: TR
   * get fancy configuare settings
   * from office panel
   */
  getLineConfigSetting(){
    this.spinner.show()
    this.gameSettingService.getAllLineConfgSetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.lineConfgSettings = response.data;
        this.spinner.hide();
    }, error =>{
      this.spinner.hide();
      console.error("error in get game setting", error);
    });
  }

  /**
   * @developed: TR
   * Update fancy configuare settings
   * from office panel
   */
  updatefancyConfg(){
    this.spinner.show();
   let fancyCongObj = {
      _id: this.fancyConfgSettings[0]._id,
      rateRange: Number(this.fancyConfgSettings[0].rateRange),
      ballStart: Number(this.fancyConfgSettings[0].ballStart),
      rateDiffrence: Number(this.fancyConfgSettings[0].rateDiffrence)
   };
    this.gameSettingService.updatefancyConfgSetting(fancyCongObj).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.utilityService.popToast('success','Success', 3000 , 'Fancy configure setting updated successfully');
        this.getFancyConfigSetting();
        this.spinner.hide();
    }, error =>{
      this.spinner.hide();
      console.error("error in get game setting", error);
    });
  }

  /**
   * @developed: TR
   * Update line configuare settings
   * from office panel
   */
  updateLineConfg(){
    this.spinner.show();
    let lineCongObj = {
      _id: this.lineConfgSettings[0]._id,
      rateRange: Number(this.lineConfgSettings[0].rateRange),
      ballStart: Number(this.lineConfgSettings[0].ballStart),
      rateDiffrence: Number(this.lineConfgSettings[0].rateDiffrence)
    };
    this.gameSettingService.updatelineConfgSetting(lineCongObj).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.utilityService.popToast('success','Success', 3000 , 'Line configure setting updated successfully');
        this.getFancyConfigSetting();
        this.spinner.hide();
    }, error =>{
      this.spinner.hide();
      console.error("error in get game setting", error);
    });
  }

  /***
   * get global Line setting
   * office panel
   */
  lineMarketSettings(){
    this.spinner.show()
    this.gameSettingService.getAllLineSetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.LineSettingData = response.data.docs;
        this.spinner.hide()
    }, error =>{
      this.spinner.hide()
      console.error("error in get fancy setting", error);
    })
  }

  /**
   * @developed: TR
   * Update fancy configuare settings
   * from office panel
   */
  updateLineMarket(data){
    this.spinner.show();

    this.gameSettingService.updateLineMarketSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.utilityService.popToast('success','Success', 3000 , 'Fancy configure setting updated successfully');
        this.getFancyConfigSetting();
        this.spinner.hide();
    }, error =>{
      this.spinner.hide();
      console.error("error in get game setting", error);
    });
  }

  /**
   * update Line setting in market table
   * in all white label
   */
  updateLineMarketSettingToAll(data){
    this.gameSettingService.updateAllLineSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if (response.status === true) {
         // this.updateLineSettingToAllWhtLbl(data);
        this.utilityService.popToast('success','Success', 3000 , 'Line setting update to all market successfully');
      }else{
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }
    }, error =>{
      this.utilityService.popToast('error','Error', 3000 , error.message);
      console.error("error in update market");
    })
  }

  updateLineSettingToAllWhtLbl(data){
    this.utilityService.getAllWhiteLabel().then(response =>{
      let x = response.data;
      for(let i = 0;i < x.length; i++){
        this.gameSettingService.updateLineSettingToAllWhtLbl(data, x[i]).subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
          if (response.status === true) {
            this.spinner.hide();
            // this.utilityService.popToast('success','Success', 3000 , 'Fancy setting update to all market successfully');
          }else{
            // this.utilityService.popToast('error','Error', 3000 , response.message);
          }
        }, error =>{
          this.spinner.hide();
          this.utilityService.popToast('error','Error', 3000 , error.message);
          console.error("error in update market");
        })
      }
    }).catch(error =>{
      this.spinner.hide();
      console.error("errro in get white label");
    });
  }

}
