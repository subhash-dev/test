import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {GlobalSettingComponent} from './global-setting.component';
import {GameSettingComponent} from './game-setting/game-setting.component';
import {UserGlobalSettingComponent} from './user-global-setting/user-global-setting.component';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {WhiteLabelSettingComponent} from './white-label-setting/white-label-setting.component';
import {WhiteLabelAddComponent} from './white-label-add/white-label-add.component';

const routes: Routes = [
  {
    path: 'globalsetting',
    canActivate: [AuthGuard],
    component: GlobalSettingComponent,
    children: [
      {
        path: 'gamesetting',
        canActivate: [AuthGuard,RoleGuard],
        component: GameSettingComponent,
      },
      {
        path: 'usersetting',
        canActivate: [AuthGuard,RoleGuard],
        component: UserGlobalSettingComponent,
      },
      {
        path: 'whitelabelsetting',
        canActivate: [AuthGuard,RoleGuard],
        component: WhiteLabelSettingComponent,
      },
      {
        path: 'whitelabelsettingadd',
        canActivate: [AuthGuard,RoleGuard],
        component: WhiteLabelAddComponent,
      }
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GlobalSettingRoutingModule {
}
