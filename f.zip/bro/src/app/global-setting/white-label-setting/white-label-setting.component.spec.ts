import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhiteLabelSettingComponent } from './white-label-setting.component';

describe('WhiteLabelSettingComponent', () => {
  let component: WhiteLabelSettingComponent;
  let fixture: ComponentFixture<WhiteLabelSettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhiteLabelSettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhiteLabelSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
