import {Component, OnInit, ViewChild} from '@angular/core';
import {isUndefined} from 'util';
import {UtilityService} from '../../globals/utilityService';
import {Router} from '@angular/router';
import {ModalDirective} from 'ngx-bootstrap';
import {WhiteLabelSettingService} from '../../services/whitelabelsetting.service';
import {GameSettingService} from '../../services/gameSettingService.service';
import {SportService} from '../../services/sport.service';
import {NgxSpinnerService} from 'ngx-spinner';

declare let _: any;
declare let $: any;

@Component({
  selector: 'app-white-label-setting',
  templateUrl: './white-label-setting.component.html',
  styleUrls: ['./white-label-setting.component.scss']
})
export class WhiteLabelSettingComponent implements OnInit {
  accessRole: any;
  patnershipCommison: any;
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild("addSport", {static: false}) sportsValue;
  @ViewChild('addWhiteLabel', {static: false}) formValues; // Added this
  @ViewChild('sportModal', {static: false}) sportModal: ModalDirective;

  constructor(private utilityService: UtilityService,
              private router: Router,
              private gameSettingService: GameSettingService,
              private spinner: NgxSpinnerService,
              private sportService: SportService,
              private whiteLabelSettingService: WhiteLabelSettingService) {
  }

  whiteLabelFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  sportList = [];
  partnershipList = [];
  percentTxtBox = false;
  sportSettings = {
    singleSelection: true,
    text: 'Select Sport',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
  };
  addSportObject = {
    id: null,
    sport: null,
    followingSport: null,
    chekOperation: false,
    percentage: null,
  };

  sportDownPartnership : any;
  sportOwnPartnership : any;
  sportDownCommission : any;
  sportOwnCommission : any;
  sportDown :any;
  sportOwn :any;
  layout :any;
  downPartnershipBind :any;
  ownPartnershipBind :any;

  whiteLabels: any;
  selectedPartnershipWhitlable: any;
  bookmakerSettingData: any;
  fancySettingData: any;
  gameSettingsData: any;
  casinoSettingsData: any;
  cupSettingsData: any;
  userGlobalSettingData: any;
  tempWhiteLabelObject: any;
  lineMarketSettingData: any;
  roles: any;
  moduleAccess = [];


  /* it is use for store temp white label data for app_url and app_token*/
  openModal() {
    this.router.navigate(['/globalsetting/whitelabelsettingadd']);
  }

  closeModel() {
    this.modal.hide();
    this.formValues.resetForm(); // Added this
  }

  ngOnInit() {

    this.roles = this.utilityService.returnLocalStorageData('role') ? JSON.parse(this.utilityService.returnLocalStorageData('role')) : null;
    this.moduleAccess = this.utilityService.returnLocalStorageData('userData') ? JSON.parse(this.utilityService.returnLocalStorageData('userData')).role['modules'] : null;
    if (this.moduleAccess) {
      this.moduleAccess = this.moduleAccess.map(data => {
        return data.moduleName;
      });
    }

    if (isUndefined(this.utilityService.returnAccessRole('WHITELABELSETTING'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('WHITELABELSETTING');
    }
    this.getAllWhiteLabel();
  }

  /**
   * @author kc
   * @date : 27-02-2020;
   * get all White Label Setting
   */
  getAllWhiteLabel() {
    this.spinner.show()
    this.whiteLabelSettingService.getAllWhiteLabel(this.whiteLabelFilter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.whiteLabels = response.data;
        this.spinner.hide()
      }, error => {
        console.error('error in get all white label');
      })
  }

  /**
   * @author TR
   * @date : 28-12-2020;
   * update White Label Setting
   */
  updateWtlableLayout(data) {
    this.spinner.show();
    this.whiteLabelSettingService.updateWhiteLabelLayout(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response){
          this.spinner.hide()
        }else{
          this.spinner.hide()
        }

      }, error => {
        this.spinner.hide()
        console.error('error in update white label');
      })
  }



  /**
   * @author kc
   * @date : 20-02-2020;
   * create new White Label Setting
   */
  updateWhiteLabel(data) {

    /* check hand-shake with white label db*/
    let handShakeObject = {
      domainName: data.app_domainName,
      token: data.app_token,
      url: data.app_url
    };
    this.whiteLabelSettingService.handshakeWithWhitelabel(handShakeObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status === true) {
          this.whiteLabelSettingService.updateWhiteLabelSetting(data).subscribe(response => {
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
              if (response.status === true) {
                this.utilityService.popToast('success', 'Success', 1500, 'White Label setting updated successfully');
              } else {
                this.utilityService.popToast('error', 'Error', 3000, response.message);
              }
            }, error => {
              if (error.error.data.code === 11000) {
                this.utilityService.popToast('error', 'Error', 3000, 'Some value is duplicate please replace it');
              } else {
                this.utilityService.popToast('error', 'Error', 3000, error.message);
              }
              console.error('error in add new White Label Setting');
            })
        } else {
          this.utilityService.popToast('error', 'Error', 3000, 'Please valid Domain Name or token');
        }
      }, error => {
        this.utilityService.popToast('error', 'Error', 3000, 'Please valid Domain Name or token');
      })
  }


  openAddSportModal(partnership){
    this.sportModal.show();
    this.getAllSportName(partnership);
  }

  sportCloseModel(data) {
    this.sportModal.hide();
  }

  addPercentage(){
    this.percentTxtBox = true;
  }

  addSportPartnership() {
    let apiObj = {
      newSportId : this.addSportObject.sport[0].id,
      sportId : this.addSportObject.followingSport[0].id,
      newSportName : this.addSportObject.sport[0].itemName,
      percentage : (Number(this.addSportObject.percentage))? Number(this.addSportObject.percentage):0,
      chekOperation : (this.addSportObject.chekOperation)?this.addSportObject.chekOperation:'add'
    }

    this.whiteLabelSettingService.addNewSport(apiObj,this.tempWhiteLabelObject).subscribe(response => {
        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
      const lastItem = response.updatedSport[0].sportData[response.updatedSport[0].sportData.length - 1];
      let newItem = {
        sportName : lastItem.sportName.substring(0, lastItem.sportName.indexOf('(')),
        sportId : lastItem.sportId,
        ownPartnership : lastItem.upperPartnership,
        downPartnership : lastItem.ownPartnership,
        ownCommission : lastItem.upperCommission,
        downCommission : lastItem.ownCommission,
        parentId :  this.utilityService.returnLocalStorageData('userId')
      };
      this.sportModal.hide();

      if(response.status == true){
        this.whiteLabelSettingService.addNewSportintoOffice(newItem , this.tempWhiteLabelObject._id).subscribe(response => {
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
            if(response){
                this.modal.hide();
            }
        })
      }
    });
  }

  updateValue(value , check){
    this.sportDown = this.sportDownPartnership;
    this.sportOwn = this.sportOwnPartnership;
    if(check.chekOperation === 'add'){
      this.downPartnershipBind = this.sportDown + Number(value);
      this.ownPartnershipBind = this.sportOwn - Number(value);
    } else {
      this.downPartnershipBind = this.sportDown - Number(value);
      this.ownPartnershipBind = this.sportOwn + Number(value);
    }

  }

  /**
   * get game, fancy, bookmaker, user-global-setting
   * @param data
   */
  getAllSettings(data) {
    this.getCasinoSettings(data);
    this.tempWhiteLabelObject = data; // it use for url and app token
    this.whiteLabelSettingService.getWhitelabelSettings(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);

        this.fancySettingData = response.fancySettingObject;
        this.bookmakerSettingData = response.bookmakerSettingObject;
        this.gameSettingsData = response.gameSettingObject;
        this.cupSettingsData = response.cupSettingsObject;
        this.userGlobalSettingData = response.userGlobalSettingObject;
        this.lineMarketSettingData = response.lineMarketSettingObject;
        this.patnershipCommison = this.tempWhiteLabelObject.partnershipCommission;
        this.modal.show();
      }, error => {
        console.error('error in get whitelabel settings');
      })
  }

  /**
   * get game, fancy, bookmaker, user-global-setting
   * @param data
   */
  getCasinoSettings(data) {
    this.tempWhiteLabelObject = data; // it use for url and app token
    this.whiteLabelSettingService.getCasinoSettings(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.casinoSettingsData = response.data.docs;
      }, error => {
        console.error('error in get whitelabel settings');
      })
  }

  getAllSportName(partnership) {
    let filter = {
      page:1,
      limit: -1
    };
    this.sportService.getAllSport(filter).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.sportList = response.data.docs.map(data => {
        return {id: data.id, itemName: data.name + '( ' + data.id + ' )', sportId: data.id};
      });
      this.partnershipList = partnership.map(data => {
        return {
          id: data.sportId,
          itemName: data.sportName + '( ' + data.sportId + ' )',
          sportId: data.sportId,
          downPartnership : data.downPartnership,
          downCommission : data.downCommission,
          ownCommission : data.ownCommission,
          ownPartnership : data.ownPartnership
        };
      });


    }, error => {
      console.error('error in getting all sports', error);
    });
  }


  getAllSport(){
    let filter = {
      page:1,
      limit: -1
    };
    this.sportService.getAllSport(filter).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.patnershipCommison = response.data.docs.map(data =>{
            let custData = { //here make custom object for add commission and partnership
              sportName : data.name,
              sportId : data.id,
              ownPartnership : 100,
              downPartnership: 0,
              ownCommission : 100,
              downCommission: 0,
              parentId: this.utilityService.returnLocalStorageData('userId'),
            };
          return custData;
        })
      }, error =>{
        console.error("error in get all sport", error);
      });
  }

  closeModal() {
    this.modal.hide();
  }

  /***
   * @author kc
   * update all white label setting
   * type wise
   * @param object
   * @param type
   */
  updateSetting(object, type) {
    if (type === 'gameSetting') {
      let data = {
        gameSetting: object
      };
      this.whiteLabelSettingService.updateWhitelabelSettingsWithWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
          if (response) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Game setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }
    if (type === 'casinoSetting') {

      this.whiteLabelSettingService.updateCasinoSettings(object , this.tempWhiteLabelObject).subscribe(response => {
        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
          if (response) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Casino setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }
    if (type === 'cupSetting') {
      let data = {
        cupSetting: object
      };
      this.whiteLabelSettingService.updateWhitelabelSettingsWithWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
        if (response) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'cup setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'fancySetting') {

      let data = {
        fancySetting: object
      };
      this.whiteLabelSettingService.updateWhitelabelSettingsWithWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Fancy setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'bookmakerSetting') {
      let data = {
        bookmakerSetting: object
      };
      this.whiteLabelSettingService.updateWhitelabelSettingsWithWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Bookmaker setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'userGlobalSetting') {
      let data = {
        userGlobalSetting: object
      };
      this.whiteLabelSettingService.updateWhitelabelSettingsWithWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'User Global setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'lineSetting') {

      let data = {
        lineSetting: object
      };
      console.log(data, this.tempWhiteLabelObject)
      this.whiteLabelSettingService.updateWhitelabelSettingsWithWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Line setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }
  }

  /***
   * @author kc
   * update params in setting table as well as in market
   * table
   * @param obj
   * @param type
   */
  updateAllMarket(obj, type) {

    if (type === 'gameSetting') {
      let data = {
        gameSetting: obj
      };
      this.whiteLabelSettingService.updateWlSettingsWithMarketWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
        if (response.status === true) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Game setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'cupSetting') {
      let data = {
        cupSetting: obj
      };
      this.whiteLabelSettingService.updateWlSettingsWithMarketWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
          if (response.status === true) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'cup setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'fancySetting') {

      let data = {
        fancySetting: obj
      };
      this.whiteLabelSettingService.updateWlSettingsWithMarketWebHook(data, this.tempWhiteLabelObject).subscribe(response => {
        // response = this.utilityService.gsk(response.auth);
        // response =JSON.parse(response);
        if (response.status === true) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Fancy setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'bookmakerSetting') {
      let data = {
        bookmakerSetting: obj
      };
      this.whiteLabelSettingService.updateWlSettingsWithMarketWebHook(data, this.tempWhiteLabelObject)
        .subscribe(response => {
            // response = this.utilityService.gsk(response.auth);
            // response =JSON.parse(response);
          if (response.status === true) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Bookmaker setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'userGlobalSetting') {
      let data = {
        userGlobalSetting: obj
      };
      console.log("updateAll", data)
      this.whiteLabelSettingService.updateWlSettingsWithMarketWebHook(data, this.tempWhiteLabelObject)
        .subscribe(response => {
            // response = this.utilityService.gsk(response.auth);
            // response =JSON.parse(response);
          if (response.status === true) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'User Global setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }

    if (type === 'lineSetting') {

      let data = {
        lineSetting: obj
      };
      this.whiteLabelSettingService.updateWlSettingsWithMarketWebHook(data, this.tempWhiteLabelObject)
        .subscribe(response => {
            // response = this.utilityService.gsk(response.auth);
            // response =JSON.parse(response);
          if (response.status === true) {
            this.modal.hide();
            this.utilityService.popToast('success', 'Success', 1500, 'Line setting updated successfully');
          } else {
            this.utilityService.popToast('error', 'Error', 1500, response.message);
          }
        }, error => {
          this.utilityService.popToast('error', 'Error', 1500, error.error.message);
        });
    }
  }

  getSportPart(event){
    this.sportDownPartnership =  event.downPartnership;
    this.sportOwnPartnership =  event.ownPartnership;
    this.sportDownCommission =  event.downCommission;
    this.sportOwnCommission =  event.ownCommission;
    this.downPartnershipBind = this.sportDownPartnership;
    this.ownPartnershipBind = this.sportOwnPartnership;
  }



}

