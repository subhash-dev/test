import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhiteLabelAddComponent } from './white-label-add.component';

describe('WhiteLabelAddComponent', () => {
  let component: WhiteLabelAddComponent;
  let fixture: ComponentFixture<WhiteLabelAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhiteLabelAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhiteLabelAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
