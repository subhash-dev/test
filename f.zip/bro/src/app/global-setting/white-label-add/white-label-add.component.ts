import { Component, OnInit } from '@angular/core';
import {isUndefined} from "util";
import {UtilityService} from '../../globals/utilityService';
import {GameSettingService} from '../../services/gameSettingService.service';
import {WhiteLabelSettingService} from '../../services/whitelabelsetting.service';
import {Router} from '@angular/router';
import {SportService} from '../../services/sport.service';
import {NgxSpinnerService} from "ngx-spinner";
declare let _ : any;
declare let $ : any;
@Component({
  selector: 'app-white-label-add',
  templateUrl: './white-label-add.component.html',
  styleUrls: ['./white-label-add.component.scss']
})
export class WhiteLabelAddComponent implements OnInit {
  accessRole: any;
  patnershipCommison: any;
  constructor(private utilityService: UtilityService,
              private router: Router,
              private gameSettingService: GameSettingService,
              private sportService: SportService,
              private spinner: NgxSpinnerService,
              private whiteLabelSettingService: WhiteLabelSettingService

  ) { }
  finalWhiteLabelObject = {
    gameSettings:null,
    fancySetting : null,
    bookmakerSetting: null,
    UserGlobalSettings:null,
    patnershipCommison:null
  };



  addWhiteLableObject = {
    app_name: null,
    app_url: null,
    app_domainName: null,
    app_currency: null,
    app_logo: null,
    app_token: null,
    app_orderNo: null,

  };
  orderNoList = [];
  ngOnInit() {

    let numberArray = _.range(1, 51) . map(num => String(num).padStart(2, '0'));
    this.orderNoList = numberArray.map(Number);
    // this.orderNoList = this.orderNoList.map(data =>{
    //   let x = {id : data}
    //   return x;
    // });
    if (isUndefined(this.utilityService.returnAccessRole('WHITELABELSETTING'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('WHITELABELSETTING');
    }
    this.getAllSport();
    this.getGameSetting();
    this.getFancySetting();
    this.getBookmakerSetting();
    this.getUserSetting();
  }


  getAllSport(){
    let filter = {
      page:1,
      limit: -1
    };
    this.sportService.getAllSport(filter).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.patnershipCommison = response.data.docs.map(data =>{
            let custData = { //here make custom object for add commission and partnership
              sportName : data.name,
              sportId : data.id,
              ownPartnership : 100,
              downPartnership: 0,
              ownCommission : 100,
              downCommission: 0,
              parentId: this.utilityService.returnLocalStorageData('userId'),
            };
          return custData;
        })
      }, error =>{
        console.error("error in get all sport", error);
      });
  }

  /**
   * calculate partnership value
   * @param data
   */
  checkPartnership(data){

    this.patnershipCommison.map(sportData =>{
      if(sportData.sportId === data.sportId){
        if((data.downPartnership) > 100){
          sportData.downPartnership = 100;
          sportData.ownPartnership = (100 - sportData.downPartnership)
        }else{
          sportData.ownPartnership = (100 - sportData.downPartnership)
        }
        return sportData;
      }
    })

  }

  /**
   * calculate commission value
   * @param data
   */
  checkCommission(data){

    this.patnershipCommison.map(sportData =>{
      if(sportData.sportId === data.sportId){
        if((data.downCommission) > 100){
          sportData.downCommission = 100;
          sportData.ownCommission = (100 - sportData.downCommission)
        }else{
          sportData.ownCommission = (100 - sportData.downCommission)
        }
        return sportData;
      }
    })

  }

  /**
   * @author kc
   * @date : 20-02-2020;
   * create new White Label Setting
   */
  createWhiteLabel() {
    /* check hand-shake with white label db*/
    let handShakeObject= {
      domainName : this.addWhiteLableObject.app_domainName,
      token : this.addWhiteLableObject.app_token,
      url: this.addWhiteLableObject.app_url
    };
    this.whiteLabelSettingService.handshakeWithWhitelabel(handShakeObject).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if(response.status === true){
          this.addWhiteLableObject['partnershipCommission'] = this.patnershipCommison;
          this.whiteLabelSettingService.addNewWhiteLabelSetting(this.addWhiteLableObject).subscribe(response => {
            response = this.utilityService.gsk(response.auth);
            response =JSON.parse(response);
              if(response.status === true){
                this.router.navigate(['/globalsetting/whitelabelsetting'])
                this.sendWebHookForGlobalSettings();
                this.utilityService.popToast('success','Success', 3000 , 'White Label setting add successfully');
              }else{
                this.utilityService.popToast('error','Error', 3000 , response.message);
              }
            }, error => {
              if(error.error.data.code === 11000){
                this.utilityService.popToast('error','Error', 3000 , 'Some value is duplicate please replace it');
              }else{
                this.utilityService.popToast('error','Error', 3000 , error.message);
              }
              console.error('error in add new White Label Setting');
            })
        }else {
          this.utilityService.popToast('error','Error', 3000 , 'Please valid Domain Name, url or token');
        }
      }, error =>{
        console.log("******************");
        this.utilityService.popToast('error','Error', 3000 , 'Please valid Domain Name or token');
      })

  }



  /**
   * get game settings
   */
  getGameSetting(){
    let data = {
      page:1,
      limit: -1
    };
    this.gameSettingService.getAllGameSetting(data).subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.finalWhiteLabelObject.gameSettings = response.data.docs;
    },error =>{
        console.error("error in game setting", error);
    });

  }

  /**
   * get all fancy setting
   */
  getFancySetting(){
    this.gameSettingService.getAllFancySetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.finalWhiteLabelObject.fancySetting = response.data.docs;
      },error =>{
        console.error("error in fancy setting", error);
      })
  }
  /**
   * get all bookmaker setting
   */
  getBookmakerSetting(){
    this.gameSettingService.getAllBookmakerSetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.finalWhiteLabelObject.bookmakerSetting = response.data.docs;
      }, error =>{
        console.error("error in bookmaker setting", error);
      })
  }
  /***
   * get all user settings
   */
  getUserSetting(){
    this.gameSettingService.getAllUserSetting().subscribe(response =>{
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.finalWhiteLabelObject.UserGlobalSettings = response.data.docs;
    }, error =>{
      console.error("error in get game setting", error);
    })
  }


  /**
   * send web hook call for create whitelabel setting and commison
   */
  sendWebHookForGlobalSettings(){
    let newPartnerCommission = this.patnershipCommison;
    newPartnerCommission = newPartnerCommission.map(data =>{
      let downp = Number(data.downPartnership);
      let downc = Number(data.downCommission);
      data['upperPartnership'] = data.ownPartnership
      data['upperCommission']  = data.ownCommission
      data['ownPartnership'] =downp;
      data['ownCommission'] = downc;
      return data;
    })
    this.finalWhiteLabelObject.patnershipCommison = newPartnerCommission;
    this.whiteLabelSettingService.createWhiteLableSettings(this.finalWhiteLabelObject, this.addWhiteLableObject.app_url,this.addWhiteLableObject.app_token)
      .subscribe(response =>{

      }, error =>{
        console.error("error in add settings using webhook");
      })
  }

}
