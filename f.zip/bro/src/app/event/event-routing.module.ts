import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {EventComponent} from './event.component';
import {CricketComponent} from './cricket/cricket.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path: 'event',
  canActivate: [AuthGuard, RoleGuard],
  component: EventComponent,
  children: [
    {
      path: 'cricket',
      canActivate: [AuthGuard, RoleGuard],
      component: CricketComponent,
    },

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EventRoutingModule {
}
