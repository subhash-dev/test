import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventRoutingModule } from './event-routing.module';
import { EventComponent } from './event.component';
import { CricketComponent } from './cricket/cricket.component';

@NgModule({
  declarations: [EventComponent, CricketComponent],
  imports: [
    CommonModule,
    EventRoutingModule
  ]
})
export class EventModule { }
