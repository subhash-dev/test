import { Component, OnInit,ViewChild,ElementRef,HostListener } from '@angular/core';

@Component({
  selector: 'app-commentary-view',
  templateUrl: './commentary-view.component.html',
  styleUrls: ['./commentary-view.component.scss']
})
export class CommentaryViewComponent implements OnInit {
  @ViewChild('focusInput' ,  {static: false}) focusInput: ElementRef;
  constructor() { }

  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if(event.sourceCapabilities) {

    }else {
      this.setFocusToInput();
    }
  }

  ngOnInit() {
  }

  setFocusToInput() {
    this.focusInput.nativeElement.focus();
  }

}
