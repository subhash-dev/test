import { ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MarketService } from '../../services/market.service';
import { UtilityService } from '../../globals/utilityService';
import { MatchService } from '../../services/match.service';
import { ModalDirective } from 'ngx-bootstrap';
import { CommentaryService } from '../../services/commentary.service';

@Component({
  selector: 'app-commentary-show',
  templateUrl: './commentary-show.component.html',
  styleUrls: ['./commentary-show.component.scss']
})


export class CommentaryShowComponent implements OnInit {
  @ViewChild(ModalDirective, { static: false }) modal: ModalDirective;
  @ViewChild('edit', { static: false }) edit: ModalDirective;
  @ViewChild('focusInput', { static: false }) focusInput: ElementRef;
  @ViewChild("createCommentry", { static: false }) commentryValue;

  paramId: any;
  matchName: any;
  commentaryName = {
    name: null,
    id: null,
    isActive: null
  };

  commentaryList: any;
  commentaryEdit = {
    name: null,
    isActive: null,
    id: null
  };
  isActiveUpdate = {
    isActive: null,

  }
  commentaryListAll: any;
  constructor(private route: ActivatedRoute, private marketService: MarketService,
    private utilityService: UtilityService, private matchService: MatchService,
    private commentaryService: CommentaryService) { }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    let x = event.keyCode;
    if (x === 27) {
      this.addStatus('ballRunning')
    }
    if (x === 13) {
      this.addStatus('live')
    }
    if (x === 32) {
      this.addStatus('suspend')
    }
  }
  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if (event.sourceCapabilities) {

    } else {
      this.setFocusToInput();
    }
  }
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.commentryValue.resetForm();
    }
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.paramId = params['id'];
      if (this.paramId) {
        this.getmatchById(this.paramId)
      }
    });

    this.getAllCommentry();
    this.getAllCommentryAll();
  }
  setFocusToInput() {

    this.focusInput.nativeElement.focus();
  }

  getmatchById(id) {
    this.matchService.getMatchById(id)
      .subscribe(response => {
        if (response) {
          this.matchName = response.data.name;
        }
      }, error => {
      })
  }
  addStatus(data) {
    if (data === 'ballRunning') {
      let marketStatus = {
        id: 'MS950763',
        name: 'ballstart',
        value: 'BALLSTART'
      };
      this.updateMarketStatus(marketStatus);
    } else if (data === 'suspend') {
      let marketStatus = {
        id: 'MS940896',
        name: 'suspend',
        value: 'SUSPENDED'
      };
      this.updateMarketStatus(marketStatus);
    } else if (data === 'live') {
      let marketStatus = {
        id: 'MS940896',
        name: 'open',
        value: 'OPEN'
      };
      this.updateMarketStatus(marketStatus);
    }

  }

  updateMarketStatus(marketStatus) {
    let data = {
      marketStatus: marketStatus,
      matchId: this.paramId
    };
    this.marketService.updateMarketStatus(data)
      .subscribe(response => {
        this.updateWhtLblMarket(data);
      }, error => {
      })
  }

  /***
   * update in market data in  multiple white label
   * @param data
   */
  updateWhtLblMarket(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      for (let i = 0; i < x.length; i++) {
        this.marketService.updateWhtLblMarketStatus(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });
  }


  openModal() {
    this.commentaryName.name = null;
    this.modal.show();
  }

  closeModel() {
    this.commentaryName.name = null;
    this.modal.hide();
    this.edit.hide();
  }

  getAllCommentry() {
    this.commentaryService.getAllCommentry().subscribe(response => {
      if (response.status == true) {
        this.commentaryList = response.data;
      }
      // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
    }, error => {

    });
  }

  getAllCommentryAll() {
    this.commentaryService.getAllCommentryIsActive().subscribe(response => {
      if (response.status == true) {
        this.commentaryListAll = response.data;

      }
      // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
    }, error => {

    });
  }


  createCommentry() {
    let data = {
      name: this.commentaryName.name.toUpperCase(),
      isActive: true
    }
    this.commentaryService.createCommentry(data).subscribe(response => {
      if (response.status == true) {
        this.getAllCommentry();
        this.getAllCommentryAll();
        this.commentaryName.name = '';

        this.utilityService.popToast('success', 'Success', 1000, 'commentary Added successfully.');
      } else {
        this.utilityService.popToast('error', 'Error', 1000, 'Something Wrog');
      }
    }, error => {

    });
  }

  clickDelete(id) {
    this.commentaryService.deleteCommentry(id).subscribe(response => {
      if (response.status == true) {
        this.getAllCommentry();
        this.getAllCommentryAll();
        this.commentaryName.name = '';

        this.utilityService.popToast('success', 'Success', 1000, 'commentary Delete successfully.');
      } else {
        this.utilityService.popToast('error', 'Error', 1000, 'Something Wrog');
      }
    }, error => {

    });
  }
  clickEdit(id) {
    this.commentaryService.getEditCommentry(id).subscribe(response => {
      if (response.status == true) {

        this.commentaryEdit.name = response.data[0].name;
        this.commentaryEdit.id = response.data[0]._id;
        this.commentaryEdit.isActive = response.data[0].isActive;
        // console.log(this.commentaryEdit);
        this.edit.show();
        this.modal.hide();
      } else {
      }
    }, error => {

    });

  }
  commentryUpdate(id) {

    let data = {
      name: this.commentaryEdit.name.toUpperCase(),

    }
    if (this.commentaryEdit.name) {
      this.commentaryService.getUpdateCommentry(id, data).subscribe(response => {
        if (response.status == true) {

          this.getAllCommentry();
          this.getAllCommentryAll();
          this.utilityService.popToast('success', 'Success', 1000, 'Commentary Update successfully.');
          this.edit.hide();
          this.modal.hide();
        } else {
        }
      }, error => {

      });
    } else {
      this.utilityService.popToast('error', 'Error', 1000, 'Something Wrong.');
    }
  }

  onchange(id, status) {
    if (status == true) {
      this.isActiveUpdate = {
        isActive: status,

      }
    }
    if (status == false) {
      this.isActiveUpdate = {
        isActive: false,

      }
    }
    this.commentaryService.updateStatusCommentry(id, this.isActiveUpdate).subscribe(response => {
      if (response.status == true) {

        this.getAllCommentry();
        // this.getAllCommentryAll();
        this.utilityService.popToast('success', 'Success', 1000, 'Commentary Status Update successfully.');
        this.modal.show();
        // this.edit.show();
      } else {
      }
    }, error => {

    });

  }
}
