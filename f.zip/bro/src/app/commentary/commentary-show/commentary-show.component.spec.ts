import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommentaryShowComponent } from './commentary-show.component';

describe('CommentaryShowComponent', () => {
  let component: CommentaryShowComponent;
  let fixture: ComponentFixture<CommentaryShowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommentaryShowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommentaryShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
