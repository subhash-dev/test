import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommentaryRoutingModule } from './commentary-routing.module';
import { CommentaryViewComponent } from './commentary-view/commentary-view.component';
import { CommentaryComponent } from './commentary.component';
import { CommentaryShowComponent } from './commentary-show/commentary-show.component';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ModalModule} from 'ngx-bootstrap';
import { FormsModule } from '@angular/forms';
import { DemoMaterialModule } from 'src/material-module';
import { commonDerectivenModule } from '../auth-gaurd/commonDerective.module';

@NgModule({
  declarations: [CommentaryViewComponent,CommentaryComponent, CommentaryShowComponent],
  imports: [
    CommonModule,
    CommentaryRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    ModalModule.forRoot(),
    FormsModule,
    DemoMaterialModule,
    commonDerectivenModule
  ]
})
export class CommentaryModule { }
