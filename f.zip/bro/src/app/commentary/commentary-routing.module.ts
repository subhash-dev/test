import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {CommentaryViewComponent} from './commentary-view/commentary-view.component';
import {CommentaryComponent} from './commentary.component';
import {CommentaryShowComponent} from './commentary-show/commentary-show.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path: 'commentary',
  canActivate: [AuthGuard, RoleGuard],
  component: CommentaryComponent,
  children: [
    {
      path: 'view/:id',
      canActivate: [AuthGuard, RoleGuard],
      component: CommentaryViewComponent,
    },
    {
      path: 'show/:id',
      canActivate: [AuthGuard, RoleGuard],
      component: CommentaryShowComponent,
    },

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CommentaryRoutingModule {
}
