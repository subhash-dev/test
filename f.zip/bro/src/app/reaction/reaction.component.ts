import {ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from 'ngx-bootstrap';
import {Router} from '@angular/router';
import {isUndefined} from 'util';
import {ToasterConfig} from 'angular2-toaster';
import { HttpClient} from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import {UtilityService} from '../globals/utilityService';
import * as env from '../globals/env';
import {NgxSpinnerService} from "ngx-spinner";
import { WhiteLabelSettingService } from '../services/whitelabelsetting.service';


var aes256 = require('aes256');
declare let $: any;

class Reaction {
  id: number;
  sportname: string;
  isActive: string;
  isManual:string;
  displayOrder:number;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-reaction',
  templateUrl: './reaction.component.html',
  styleUrls: ['./reaction.component.scss']
})
export class ReactionComponent implements OnInit {
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('conformationModal', {static: false}) conformationModal: ModalDirective;
  @ViewChild('statusChangeModal', {static: false}) statusChangeModal: ModalDirective;
  @ViewChild("addSport", {static: false}) sportsValue;
  @ViewChild("conformationForm", {static: false}) passwordFormReset;
  @ViewChild(DataTableDirective, {static: false})
  // @ViewChild("focus") nameField: ElementRef;

  @ViewChild('focusInput' ,  {static: false}) focusInput: ElementRef;

  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();

  reaction: Reaction[];
  resData;
  server_url: any = env.server_url();

  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });

  accessRole: any;
  tempSportObj: any;
  conformationPassword: any;


  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private whiteLabelSettingService : WhiteLabelSettingService,
    private http: HttpClient) { }

    dataTable: any;

  filter = {
    page: 1,
    limit: 300,
    search: null
  };

 

  ngOnInit() {
    console.log("dasting");
    this.newDatatable();
  }

  newDatatable(){
    this.spinner.show();
    const that = this;
    let url = this.server_url + 'whiteLabelSetting/reaction'; 
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      serverSide: true,
      // autoWidth: true,
      // scrollX: true,
      // scrollCollapse:true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [5, 10, 25, 50, 75, 100,200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords:    '',
        emptyTable:     'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },

      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            dataTablesParameters,
            {}
          ).subscribe(resp => {
              this.spinner.hide();
              this.resData = resp.data;

            if(this.resData.docs.length > 0){
              this.reaction = this.resData.docs;
              $('.dataTables_empty').css('display', 'none');
            }else {
              $('.dataTables_empty').css('display', 'table-cell');
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },

      columns: [ { data: '' },{ data: 'action_name' }, { data: 'game_name'},{ data: 'game_type' }, { data: 'wlb_name' },{ data: '' }],
      columnDefs: [ { orderable: false, targets: [0] },{ orderable: false, targets: [4] }]
    };
  }

  updateWhtlbl(whtlData){
    this.whiteLabelSettingService.reactionOnwhtlbl(whtlData).subscribe(response => {
      if (response.status === true) {
        this.utilityService.popToast('success', 'Success', 3000, 'Reaction Successfully.');
       this.rerender();
      }else{
        this.utilityService.popToast('error', 'Error', 3000, "Server is stop");
      }
    })
  }

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }
}
