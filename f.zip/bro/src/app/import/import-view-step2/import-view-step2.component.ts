import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {switchMap} from 'rxjs/internal/operators';
import {ImportService} from '../../services/import.service';
import * as $ from 'jquery';
import '../../../../node_modules/datatables.net';
import '../../../../node_modules/datatables.net-dt';
import {UtilityService} from '../../globals/utilityService';
import {NgxSpinnerService} from "ngx-spinner";

@Component({
    selector: 'app-import-view-step2',
    templateUrl: './import-view-step2.component.html',
    styleUrls: ['./import-view-step2.component.scss']
})
export class ImportViewStep2Component implements OnInit {

    constructor(private route: ActivatedRoute,
                private router: Router,
                private importService: ImportService,
                private spinner: NgxSpinnerService,
                private chRef: ChangeDetectorRef,
                private utilityService: UtilityService) {
    }

    dataTable: any;
    importStep2Response: any;
    ngOnInit() {
        this.route.params.pipe(
            switchMap((params: Params) => this.importService.importApiStep2(params.id)))
            .subscribe(response => {
                this.importStep2Response = response[0];
                this.chRef.detectChanges();
                const table: any = $('table');
                this.dataTable = table.DataTable({
                    /* serverSide : true,
                     processing : true*/
                  pageLength: 50,   // -- trying to set to 5 records only
                  lengthMenu: [50, 75, 100, 200]
                });
            });
    }

    backLocation() {
        this.router.navigate(['/import/view']);
    }

    getImportStep3(data) {
        this.router.navigate(['/import/step3', data.competition.id]);
    }
}
