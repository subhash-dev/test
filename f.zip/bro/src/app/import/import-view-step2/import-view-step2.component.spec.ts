import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportViewStep2Component } from './import-view-step2.component';

describe('ImportViewStep2Component', () => {
  let component: ImportViewStep2Component;
  let fixture: ComponentFixture<ImportViewStep2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportViewStep2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportViewStep2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
