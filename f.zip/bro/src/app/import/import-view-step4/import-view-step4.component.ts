import {ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {Location} from '@angular/common';
import {UtilityService} from '../../globals/utilityService';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {switchMap} from 'rxjs/internal/operators';
import {ImportService} from '../../services/import.service';
import * as $ from 'jquery';
import '../../../../node_modules/datatables.net';
import '../../../../node_modules/datatables.net-dt';
import {ModalDirective} from 'ngx-bootstrap';
import {SportService} from '../../services/sport.service';
import {TournamentService} from '../../services/tournament.service';
import {MatchService} from '../../services/match.service';
import {MarketService} from '../../services/market.service';
import {GameSettingService} from '../../services/gameSettingService.service';
import {NgxSpinnerService} from "ngx-spinner";
import {UserService} from '../../services/user.service';
import {RoleService} from '../../services/role.service';


declare let _: any;

@Component({
  selector: 'app-import-view-step4',
  templateUrl: './import-view-step4.component.html',
  styleUrls: ['./import-view-step4.component.scss']
})
export class ImportViewStep4Component implements OnInit {

  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('openSelection', {static: false}) selectionModal: ModalDirective;
  @ViewChild("selectType", {static: false}) formResetValue;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private importService: ImportService,
              private chRef: ChangeDetectorRef,
              private utilityService: UtilityService,
              private sportService: SportService,
              private userService: UserService,
              private roleService: RoleService,
              private tournamentService: TournamentService,
              private matchService: MatchService,
              private marketService: MarketService,
              private gameSettingService: GameSettingService,
              private spinner: NgxSpinnerService,
              private location: Location) {}

  dataTable: any;
  importStep4Response: any;
  step5Data: any;
  tempAsiignToName: any;
  fancyTypeId: any;
  selectedUser: any;
  fancyUserList = [];
  hideImportBtn = false;
  addImportError = false;
  createGameSettingObject: any;
  oddsType : any;
  teamData : any;
  UserSettings = {
    singleSelection: true,
    text: 'Select line user',
    selectAllText: 'Select',
    unSelectAllText: 'UnSelect',
    enableSearchFilter: false,
  };

  ngOnInit() {
    this.route.params.pipe(
      switchMap((params: Params) => this.importService.importApiStep4(params.id)))
      .subscribe(response => {
        this.importStep4Response = response[0];
        this.importStep4Response.result = this.importStep4Response.result.map(data => {
          data['hideImportBtn'] = false;
          return data;
        });
        this.chRef.detectChanges();
        const table: any = $('table');
        this.dataTable = table.DataTable({
          /* serverSide : true,
           processing : true*/
          pageLength: 50,   // -- trying to set to 5 records only
          lengthMenu: [50, 75, 100, 200]
        });
      });
    this.getAllModule();
  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * back to last location
   */
  backLocation() {
    this.location.back();
  }

  /**
   * @author kc
   * @date : 28-01-2020
   * get step 5 data from market id
   */
  // getImportStep5(data) {
  //   this.importService.importApiStep5(data.marketId).subscribe(response => {
  //     this.step5Data = response[0].result[0];
  //     this.saveImport(this.step5Data,data);
  //   }, error => {
  //     console.error('getting error from import api', error);
  //   });
  // }

  openSelectionModal(data){
    this.teamData = data;
    this.selectionModal.show();
  }

  importModalData(){
    this.spinner.show();
    this.importService.importApiStep5(this.teamData.marketId).subscribe(response => {
      this.spinner.hide();
      this.step5Data = response[0].result[0];
      // console.log("this.step5Data+++++++++++");
      // console.log(this.step5Data , this.oddsType);
      // return false;
      this.saveImport(this.step5Data,this.oddsType);
    }, error => {
      console.error('getting error from import api', error);
    });

  }

  /**
   * @author kc
   * @date : 28-01-2020;
   * save import data after getting step 5 data in import table
   */
  saveImport(data,odds) {
    let saveImportData = data;
    saveImportData.eventType.name = saveImportData.eventType.name.toUpperCase();
    saveImportData.eventType.type = odds;
    /* save sport data */
    this.sportService.addNewSport(saveImportData.eventType).subscribe(sportResponse => {
      /* create tournament object */
      let tournamentObject = {
        id: saveImportData.competition.id,
        name: saveImportData.competition.name,
        sport: {
          id: saveImportData.eventType.id,
          name: (saveImportData.eventType.name + '( ' + saveImportData.eventType.id + ' )')
        }
      };
      /* create tournament*/
      this.tournamentService.addNewTournament(tournamentObject).subscribe(tournamentResponse => {
        if (tournamentResponse) {
          /* create match object */
          let matchObject = {
            id: saveImportData.event.id,
            name: saveImportData.event.name,
            countryCode: saveImportData.event.countryCode,
            timezone: saveImportData.event.timezone,
            openDate: saveImportData.event.openDate,
            tournament: {
              id: saveImportData.competition.id,
              name: (saveImportData.competition.name + '( ' + saveImportData.competition.id + ' )')
            },
            sport: {
              id: saveImportData.eventType.id,
              name: (saveImportData.eventType.name + '( ' + saveImportData.eventType.id + ' )')
            }
          };
          /* create match*/
          this.matchService.addNewMatch(matchObject).subscribe(matchResponse => {
            if (matchResponse) {

              /* create market object */
              let marketObject = {
                marketId: saveImportData.marketId,
                marketType: saveImportData.marketName,

                marketTypeId: this.utilityService.marketType.map(data => {
                  if (data.name === saveImportData.eventType.type) {
                    return data.id;
                  } else {
                    return null;
                  }
                }),
                marketStartTime: saveImportData.marketStartTime,
                totalMatched: saveImportData.totalMatched,
                runners: saveImportData.runners,
                isActive: true,
                match: {
                  id: saveImportData.event.id,
                  name: (saveImportData.event.name + '( ' + saveImportData.event.id + ' )')
                },
                tournament: {
                  id: saveImportData.competition.id,
                  name: (saveImportData.competition.name + '( ' + saveImportData.competition.id + ' )')
                },
                sport: {
                  id: saveImportData.eventType.id,
                  name: (saveImportData.eventType.name + '( ' + saveImportData.eventType.id + ' )')
                },
                gameSetting: null,
                cupSetting: null,
              };

              if(saveImportData.eventType.type === "Line"){
                marketObject.marketType = "Line";
                marketObject['lineName'] = saveImportData.marketName;
                marketObject['lineId'] = (Math.floor(Math.random() * (88888888 - 10000 * 1) * 1000));
                marketObject['assignTo'] = this.selectedUser;
              }

              marketObject['marketStatus'] = {
                id : 'MS081893',
                name : 'OPEN'
              };

              marketObject.marketTypeId = _.without(marketObject.marketTypeId, null);
                marketObject.gameSetting = null;
                marketObject.cupSetting = null;

                if(saveImportData.eventType.type === "Match Odds") {

                this.gameSettingService.getGameSettingBySportId(saveImportData.eventType.id).subscribe(settingsResponse =>{
                  if(settingsResponse){
                      if(settingsResponse.data){
                        marketObject.gameSetting = settingsResponse.data;
                      }
                  }
                })
                }
              if(saveImportData.eventType.type === "Cup") {
                marketObject.marketType = 'Winner';
                this.gameSettingService.getCupSettingBySportId('5ebc1code68br4bik5b0814').subscribe(settingsResponse =>{
                  if(settingsResponse){
                    if(settingsResponse.data){
                      marketObject.cupSetting = settingsResponse.data;
                    }
                  }
                })
              }
                this.marketService.addNewMarket(marketObject).subscribe(marketResponse => {
                  this.closeSelection();
                  this.modal.show();
                  if (marketResponse.status === false) {
                    this.addImportError = true;
                    this.importStep4Response.result = this.importStep4Response.result.map(data => {
                      if (saveImportData.marketId === data.marketId) {
                        data.hideImportBtn = true;
                      } else {
                        data.hideImportBtn = false;
                      }
                      return data;
                    });
                  } else {
                    this.addImportError = false;

                    this.importStep4Response.result = this.importStep4Response.result.map(data => {
                      if (saveImportData.marketId === data.marketId) {
                        data.hideImportBtn = true;
                      } else {
                        data.hideImportBtn = false;
                      }
                      return data;
                    });
                  }



                }, marketError => {
                  console.error('error in add market', marketError);
                });

               // console.log("sasaaaaaaaa");
                this.utilityService.getAllWhiteLabel().then(response =>{
                  let x = response.data;
                  /* Hear X is Multiple Whitelable Data*/
                  for(let i = 0;i < x.length; i++){
                    // this.importService.addImportWhtLbl(marketObject , x[i]).subscribe(resposne => {
                    //   if(resposne.status === true){
                    //     // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
                    //   }
                    // });
                  }

                  // this.importService.addImportWhtLbl(marketObject , '').subscribe(resposne => {
                  //   if(resposne.status === true){
                  //     // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
                  //   }
                  // });
                }).catch(error =>{
                  console.error("errro in get white label");
                });

            }
          }, matchError => {
            console.error('error in add match', matchError);
          });
        }
      }, tournamentError => {
        console.error('error in add tournament', tournamentError);
      });
    }, sportError => {
      console.error('error in add sport', sportError);
    });
    /* this.importService.addImport(data)
         .subscribe(response => {
             this.modal.show();
             this.hideImportBtn = true;
         }, errors => {
             console.error('error in save import data ');
         });*/
  }

  /**
   * close model after getting success record
   */
  closeModel() {
    this.modal.hide();
  }

  closeSelection(){
    this.selectionModal.hide();
    this.formResetValue.resetForm();
  }

  /**
   * get only fancy user
   */
  getFancyUser() {
    this.userService.fancyUser(this.fancyTypeId).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response =JSON.parse(response);
      this.fancyUserList = response.data.map(data => {
        return {id: data._id , itemName: data.name , userName: data.userName , userType: data.userType}
      });
      console.log(this.fancyUserList)
    }, error => {
      console.error('error in get fancy user');
    });
  }

  /**
   * get all modules list
   */
  getAllModule() {
    this.roleService.getAllModules().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response =JSON.parse(response);
      response.data.docs.map(data => {
        if (data.moduleName === 'FANCY') {
          this.fancyTypeId = data._id;
        }
      });
      this.getFancyUser()
    }, error => {
      console.error('error in get modules');
    });

  }

  /**
   * assign user to fancy
   * @param e
   * @param fancy
   */
  selectAssignTo(e, fancy) {
         let selectedUserData = {
          id: e.id,
          name: e.itemName
        };
    this.selectedUser = selectedUserData;
  }


}
