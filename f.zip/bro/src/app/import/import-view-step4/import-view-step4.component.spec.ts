import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportViewStep4Component } from './import-view-step4.component';

describe('ImportViewStep4Component', () => {
  let component: ImportViewStep4Component;
  let fixture: ComponentFixture<ImportViewStep4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportViewStep4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportViewStep4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
