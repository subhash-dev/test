import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {ImportRoutingModule} from './import-routing.module';
import {ImportComponent} from './import.component';
import {ImportViewComponent} from './import-view/import-view.component';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DemoMaterialModule} from '../../material-module';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {ImportService} from '../services/import.service';
import { ImportViewStep2Component } from './import-view-step2/import-view-step2.component';
import { ImportViewStep3Component } from './import-view-step3/import-view-step3.component';
import { ImportViewStep4Component } from './import-view-step4/import-view-step4.component';
import {ModalModule} from 'ngx-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import {AngularMultiSelectModule} from 'angular2-multiselect-dropdown';


@NgModule({
    declarations: [ImportComponent, ImportViewComponent, ImportViewStep2Component, ImportViewStep3Component, ImportViewStep4Component],
    imports: [
        CommonModule,
        ImportRoutingModule,
        BrowserModule,
        BrowserAnimationsModule,
        DemoMaterialModule,
        FormsModule,
        HttpClientModule,
      AngularMultiSelectModule,
        ModalModule.forRoot(),
        DataTablesModule
    ],
    providers:[ImportService]
})
export class ImportModule {
}
