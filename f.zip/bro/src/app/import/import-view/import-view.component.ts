import {ChangeDetectorRef, Component, OnInit, ViewChild} from '@angular/core';
import {ImportService} from '../../services/import.service';
import * as $ from 'jquery';
import '../../../../node_modules/datatables.net';
import '../../../../node_modules/datatables.net-dt';
import {Router} from '@angular/router';
import {NgxSpinnerService} from "ngx-spinner";

@Component({
    selector: 'app-import-view',
    templateUrl: './import-view.component.html',
    styleUrls: ['./import-view.component.scss']
})
export class ImportViewComponent implements OnInit {
    dataTable: any;
    constructor(private importService: ImportService,
                private chRef: ChangeDetectorRef,
                private spinner: NgxSpinnerService,
                private router: Router
    ) {
    }

    importStep1Response: any;

    ngOnInit() {
        this.getImportStep1();
    }

    /***
     * @author kc
     * @date 23-01-2020
     *import step 1 function get all sport with event id
     */
    getImportStep1() {
        this.importService.importApiStep1().subscribe(response => {
            if(response[0].result){
                this.importStep1Response = response[0];
                this.chRef.detectChanges();
                const table1: any = $('table');
                this.dataTable = table1.DataTable({
                  info:false,
                    /* serverSide : true,
                     processing : true*/
                     pageLength: 50,   // -- trying to set to 5 records only
                     lengthMenu: [50, 75, 100, 200],
                });
            }else{
                this.importService.generateToken().subscribe(token =>{
                    if(token.status === 'SUCCESS'){
                        this.importService.importApiStep1().subscribe(response => {
                            this.importStep1Response = response[0];
                            this.chRef.detectChanges();
                            const table1: any = $('table');
                            this.dataTable = table1.DataTable({
                                /* serverSide : true,
                                 processing : true*/
                            });
                        }, error2 => {
                            console.error('getting error from import api', error2);
                        });
                    }else{
                        console.error("error from refresh token");
                    }
                }, error =>{
                    console.error("error from refresh token");
                });
            }

        }, error => {
            console.error('getting error from import api', error);
        });
    }

    getImportStep2(data){
        this.router.navigate(['/import/step2', data.eventType.id]);
    }
}
