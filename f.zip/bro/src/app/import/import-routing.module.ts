import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ImportComponent} from './import.component';
import {ImportViewComponent} from './import-view/import-view.component';
import {ImportViewStep2Component} from './import-view-step2/import-view-step2.component';
import {ImportViewStep3Component} from './import-view-step3/import-view-step3.component';
import {ImportViewStep4Component} from './import-view-step4/import-view-step4.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [
  {
    path: 'import',
    canActivate: [AuthGuard],
    component: ImportComponent,
    children: [
      {
        path: 'view',
        canActivate: [AuthGuard,RoleGuard],
        component: ImportViewComponent,
      },
      {
        path: 'step2/:id',
        canActivate: [AuthGuard,RoleGuard],
        component: ImportViewStep2Component,
      },
      {
        path: 'step3/:id',
        canActivate: [AuthGuard,RoleGuard],
        component: ImportViewStep3Component,
      },
      {
        path: 'step4/:id',
        canActivate: [AuthGuard,RoleGuard],
        component: ImportViewStep4Component,
      }

    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ImportRoutingModule {
}
