import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportViewStep3Component } from './import-view-step3.component';

describe('ImportViewStep3Component', () => {
  let component: ImportViewStep3Component;
  let fixture: ComponentFixture<ImportViewStep3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportViewStep3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportViewStep3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
