import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {UtilityService} from '../../globals/utilityService';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {switchMap} from 'rxjs/internal/operators';
import {ImportService} from '../../services/import.service';
import * as $ from 'jquery';
import '../../../../node_modules/datatables.net';
import '../../../../node_modules/datatables.net-dt';
import {Location} from '@angular/common';
import {NgxSpinnerService} from "ngx-spinner";

@Component({
    selector: 'app-import-view-step3',
    templateUrl: './import-view-step3.component.html',
    styleUrls: ['./import-view-step3.component.scss']
})
export class ImportViewStep3Component implements OnInit {

    constructor(private route: ActivatedRoute,
                private router: Router,
                private importService: ImportService,
                private spinner: NgxSpinnerService,
                private chRef: ChangeDetectorRef,
                private utilityService: UtilityService,
                private location: Location) {
    }

    dataTable: any;
    importStep3Response: any;

    ngOnInit() {
        this.route.params.pipe(
            switchMap((params: Params) => this.importService.importApiStep3(params.id)))
            .subscribe(response => {
                this.importStep3Response = response[0];
                this.chRef.detectChanges();
                const table: any = $('table');
                this.dataTable = table.DataTable({
                    /* serverSide : true,
                     processing : true*/
                  pageLength: 50,   // -- trying to set to 5 records only
                  lengthMenu: [50, 75, 100, 200]
                });
            });
    }

    backLocation() {
        this.location.back();
    }
    getImportStep4(data){
        this.router.navigate(['/import/step4', data.event.id]);
    }


}
