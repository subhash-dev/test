import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import {UserService} from '../services/user.service';
import {Router} from '@angular/router';
import {ToasterConfig} from 'angular2-toaster';
import {UtilityService} from '../globals/utilityService';
import {SocketService} from '../globals/socketService';
import {SocketServiceRedis} from '../globals/socketServiceRedis';


declare let $:any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  userData:any;
  constructor(private spinner: NgxSpinnerService,
              private userService: UserService,
              private router: Router,
              private utilityService: UtilityService,
              private socketService : SocketService,
              private socketServiceRedis : SocketServiceRedis,
              ) { }

  ngOnInit() {
    if(window.console) {
      // window.console.log = function(){};
      // window.console.warn = function(){};
      // window.console.error = function(){};
      // window.console.time = function(){};
      // window.console.timeEnd = function(){};
      // window.console.info = function(){};
      // window.console.trace= function(){};
      // console.clear = function(){};
      // console.clear();
   }
   this.socketService.connect();
   this.socketServiceRedis.connect();

    if(localStorage.getItem('userData')){
      this.userData = JSON.parse(this.utilityService.returnLocalStorageData('userData'));
    }

    // var checkStorage = this.utilityService.returnLocalStorageData('userId');
    // var checkSession = this.utilityService.returnSessionStorageData('userId');
    // if(checkStorage === checkSession && checkStorage && checkSession) {
    // }else {
    //   // localStorage.clear();
    //   // sessionStorage.clear();
    //   this.router.navigate(['/login']);
    // }

    this.spinner.hide();

    this.socketService.logoutBySuperAdmin().subscribe((res) => {
      if (res) {
        if(res._id == this.userData.user_id){
          this.userLogout();

        }
      }

    });

  }

  userLogout(){
    this.userService.logOut().subscribe(response =>{
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.utilityService.popToast('success','Success', 3000 , 'Logout successfully.');
      localStorage.clear();
      sessionStorage.clear();
      this.socketService.disconnect();
      this.socketServiceRedis.disconnect();
      this.router.navigate(['']);
    }, error =>{
      this.utilityService.popToast('error','Error', 3000 , error.message); 
      console.error("error in logout");
    })
  }

}
