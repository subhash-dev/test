import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApisettingViewComponent } from './apisetting-view.component';

describe('ApisettingViewComponent', () => {
  let component: ApisettingViewComponent;
  let fixture: ComponentFixture<ApisettingViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApisettingViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApisettingViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
