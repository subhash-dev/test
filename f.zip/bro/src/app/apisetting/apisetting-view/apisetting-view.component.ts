import { ChangeDetectorRef, Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { MarketService } from '../../services/market.service';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap';
import { UtilityService } from 'src/app/globals/utilityService';
import { UserService } from '../../services/user.service';
import { ToasterConfig } from 'angular2-toaster';
@Component({
  selector: 'app-apisetting-view',
  templateUrl: './apisetting-view.component.html',
  styleUrls: ['./apisetting-view.component.scss']
})

export class ApisettingViewComponent implements OnInit {
  @ViewChild(ModalDirective, { static: false }) modal: ModalDirective;
  @ViewChild('modaleditModal', { static: false }) modaleditModal: ModalDirective;
  @ViewChild('conformationModal', { static: false }) conformationModal: ModalDirective;
  @ViewChild("addSApiSeeting", { static: false }) addApiSeeting;
  // @ViewChild('focusInput', { static: false }) focusInput: ElementRef;
  @ViewChild('focusInputAdd', { static: false }) focusInputAdd: ElementRef;

  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-top-right', limit: 2
  });

  constructor(
    private marketService: MarketService,
    private http: HttpClient,
    private router: Router,
    private chRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    private utilityService: UtilityService,
    private userService: UserService
  ) { }

  marketapidata: any;
  addMarketApi = {
    apiName: null,
    apiUrl: null,
    isActive: true,
  };
  apiNameEdit: any;
  urlEdit: any;
  editData: any;
  editId: any;
  editForm = false;
  tempApiSettingObj: any;
  conformationPassword: any;
  editIdStatus: any;
  ChangeStatus: boolean;

  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if (event.sourceCapabilities) {
    } else {
      this.setFocusToInput();
    }
  }


  ngOnInit() {
    this.getMarketApiData();
  }

  setFocusToInput() {
    // this.focusInput.nativeElement.focus();
    this.focusInputAdd.nativeElement.focus();
  }
  openModal() {
    this.addMarketApi = {
      apiName: null,
      apiUrl: null,
      isActive: true,
    }
    this.modal.show();
  }

  closeModel(data) {
    if (data === 'addModel') {
      this.modal.hide();
      this.addApiSeeting.resetForm();
    } else if (data === 'edit') {
      this.modaleditModal.hide();
    }
    else {
      this.conformationModal.hide();
    }
    this.getMarketApiData();
  }

  getMarketApiData() {
    this.marketService.getMarketApi().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      this.marketapidata = response.data;
    }, error => {
      this.spinner.hide();
      console.error('error', error);
    })

  }

  createMarketApiNew() {
    this.marketService.createMarketApi(this.addMarketApi).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      if (response.status === true) {
        this.spinner.hide();
        this.utilityService.popToast('success', 'Success', 3000, 'ApiSetting created successfully.');
        this.getMarketApiData();
        this.modal.hide();
      } else {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, response.message);
      }
    }, error => {
      this.spinner.hide();
      console.error('error', error);
    })

  }



  getMarketApiById(id) {
    this.getMarketApiData();
    for (let i = 0; i < this.marketapidata.length; i++) {
      if (id == this.marketapidata[i]._id) {
        this.apiNameEdit = this.marketapidata[i].apiName;
        this.urlEdit = this.marketapidata[i].apiUrl;
        this.editId = this.marketapidata[i]._id;
      }
    }
    this.modaleditModal.show();
  }

  updateMarketApiNew(editId) {
    let data = {
      apiName: this.apiNameEdit,
      apiUrl: this.urlEdit,
    }
    this.marketService.updateMarketApiById(editId, data).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      if (response.status == true) {
        this.utilityService.popToast('success', 'Success', 3000, 'ApiSetting Update successfully.');
        this.getMarketApiData();
        this.modaleditModal.hide();
      } else {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 3000, response.message);
      }
    }, error => {
      console.error("get user error", error);
    });

  }

  delete(id) {
    this.marketService.deleteMarketApiById(id).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response =JSON.parse(response);
        this.getMarketApiData();
      }, error => {
        console.error("get user error", error);
      });
  }

  onchange(object) {
    this.tempApiSettingObj = object;
    this.conformationModal.show();

  }

  updateUserStatus() {
    this.spinner.show();
    let checkUserObj = {
      id: this.utilityService.returnLocalStorageData('userId'),
      password: this.conformationPassword
    };
    if (this.tempApiSettingObj.isActive === true) {
      this.ChangeStatus = false;
    } else {
      this.ChangeStatus = true;
    }
    let data = {
      apiName: this.tempApiSettingObj.apiName,
      apiUrl: this.tempApiSettingObj.apiUrl,
      isActive: this.ChangeStatus
    }
    this.editIdStatus = this.tempApiSettingObj._id;
    this.userService.checkUser(checkUserObj)
      .subscribe(checkUserResponse => {
        checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
			  checkUserResponse =JSON.parse(checkUserResponse);
        this.conformationModal.hide();
        if (checkUserResponse.status === true) {
          this.marketService.updateMarketApiById(this.editIdStatus, data)
            .subscribe(response => {
              response = this.utilityService.gsk(response.auth);
			        response =JSON.parse(response);
              response.data;
            }, error => {
              console.error("get user error", error);
            });

        } else {
          this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
        }

      }, error => {
        this.utilityService.popToast('error', 'Error', 3000, error.error.message);
      });

  }

  updateUserStatusdata() {
      this.marketService.updateMarketApiStatus(this.tempApiSettingObj._id, this.tempApiSettingObj)
        .subscribe(response => {
          response = this.utilityService.gsk(response.auth);
			    response =JSON.parse(response);
          this.conformationModal.hide();
          this.utilityService.popToast('success', 'Success', 3000, 'Status Update Successfully');
        }, error => {
          console.error("get user error", error);
        });

  }
}
