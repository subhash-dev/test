import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apisetting',
  templateUrl: './apisetting.component.html',
  styleUrls: ['./apisetting.component.scss']
})
export class ApisettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
