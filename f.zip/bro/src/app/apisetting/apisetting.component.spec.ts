import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApisettingComponent } from './apisetting.component';

describe('ApisettingComponent', () => {
  let component: ApisettingComponent;
  let fixture: ComponentFixture<ApisettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApisettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApisettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
