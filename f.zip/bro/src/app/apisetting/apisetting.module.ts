import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApisettingRoutingModule } from './apisetting-routing.module';
import { ApisettingComponent } from './apisetting.component';
import { ApisettingViewComponent } from './apisetting-view/apisetting-view.component';
import { DataTablesModule } from 'angular-datatables';
import { FormsModule } from '@angular/forms';
import {NgbDateParserFormatter, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {ModalModule} from 'ngx-bootstrap';
import { commonDerectivenModule } from '../auth-gaurd/commonDerective.module';
import { EventmasterRoutingModule } from '../eventmaster/eventmaster-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DemoMaterialModule } from 'src/material-module';
import { HttpClientModule } from '@angular/common/http';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@NgModule({
  declarations: [ApisettingComponent, ApisettingViewComponent],
  imports: [
    CommonModule,
    ApisettingRoutingModule,
    DataTablesModule,   
    commonDerectivenModule,
    FormsModule,
    NgbModule,
    ModalModule.forRoot(),
    EventmasterRoutingModule,
    BrowserModule,
    AngularMultiSelectModule,
    MatSlideToggleModule
  ]
})
export class ApisettingModule { }
