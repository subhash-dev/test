import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhitelabelWelcomeMassageComponent } from './whitelabel-welcome-massage.component';

describe('WhitelabelWelcomeMassageComponent', () => {
  let component: WhitelabelWelcomeMassageComponent;
  let fixture: ComponentFixture<WhitelabelWelcomeMassageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhitelabelWelcomeMassageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhitelabelWelcomeMassageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
