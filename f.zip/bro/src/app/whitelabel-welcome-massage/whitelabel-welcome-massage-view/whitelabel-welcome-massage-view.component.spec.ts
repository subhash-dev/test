import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WhitelabelWelcomeMassageViewComponent } from './whitelabel-welcome-massage-view.component';

describe('WhitelabelWelcomeMassageViewComponent', () => {
  let component: WhitelabelWelcomeMassageViewComponent;
  let fixture: ComponentFixture<WhitelabelWelcomeMassageViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WhitelabelWelcomeMassageViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhitelabelWelcomeMassageViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
