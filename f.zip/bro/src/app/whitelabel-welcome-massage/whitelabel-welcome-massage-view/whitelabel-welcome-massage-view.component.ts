import { Component, OnInit,ViewChild } from '@angular/core';
import { WhiteLabelSettingService } from 'src/app/services/whitelabelsetting.service';
import { UtilityService } from 'src/app/globals/utilityService';
import { NgxSpinnerService } from 'ngx-spinner';
import { WhiteLabelWelcomeMassageService } from 'src/app/services/white-label-welcome-massage.service';

@Component({
  selector: 'app-whitelabel-welcome-massage-view',
  templateUrl: './whitelabel-welcome-massage-view.component.html',
  styleUrls: ['./whitelabel-welcome-massage-view.component.scss']
})
export class WhitelabelWelcomeMassageViewComponent implements OnInit {
  @ViewChild("addmassageform", {static: false}) addmassageString;

  addmassage:any
  massage:any;
  whiteLabels: any;
  whiteLabelFilter = {
    page: 1,
    limit: 10,
    search: null
  };
  userData:any
  constructor(
      private whiteLabelSettingService: WhiteLabelSettingService,
      private utilityService: UtilityService,
      private spinner: NgxSpinnerService,
      private whiteLabelWelcomeMassageService:WhiteLabelWelcomeMassageService

    ){}

  ngOnInit() {
    if(localStorage.getItem('userData')){
      this.userData = JSON.parse(this.utilityService.returnLocalStorageData('userData'));
    }
    this.getAllWhiteLabel();
    this.welcomeMassages();
  }

  getAllWhiteLabel() {
    this.spinner.show();
    this.whiteLabelSettingService.getAllWhiteLabel(this.whiteLabelFilter)
      .subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.whiteLabels = response.data.docs;
        this.spinner.hide();
      }, error => {
        console.error('error in get all white label');
      })
  }

  createMassage() {

    this.whiteLabelWelcomeMassageService.addWelcomeMassage(this.addmassage).subscribe(resposne => {
      resposne = this.utilityService.gsk(resposne.auth);
      resposne =JSON.parse(resposne);
      if(resposne){
        this.utilityService.popToast('success','Success', 3000 , 'white lable welcome massage successfully.');
        this.createMassageWhiteLable();
      }else{
        this.spinner.hide();
        this.utilityService.popToast('error','Error', 3000 , resposne.message);
      }
      //$('#addModel').modal('hide');
    }, error => {
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error.message);
    });
  }

  createMassageWhiteLable() {

    let addMassage ={
      id:this.userData.user_id,
      token:localStorage.getItem('token'),
      massage:this.addmassage
    }
    console.log("addMassage",addMassage)
    this.utilityService.getAllWhiteLabel().then(response =>{
      // response = this.utilityService.gsk(response.auth);
      // response =JSON.parse(response);
      // console.log(response)
      let x = response.data;
      /* Hear X is Multiple Whitelable Data*/
      for(let i = 0;i < x.length; i++){

        this.whiteLabelWelcomeMassageService.addWelcomeMassageWhiteLable(addMassage , x[i]).subscribe(resposne => {
          response = this.utilityService.gsk(response.auth);
          response =JSON.parse(response);
          if(resposne.status === true){
            console.log("addMassage",resposne)
            // this.utilityService.popToast('success','Success', 1000 , 'Sports created successfully.');
          }
        });
      }
    }).catch(error =>{
      console.error("errro in get white label");
    });
  }

  welcomeMassages() {
    this.whiteLabelWelcomeMassageService.welcomeMassage().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response =JSON.parse(response);
      console.log(response)
      if(response && response.data){
        this.addmassage = response.data.massage;
      }else{
        this.addmassage = '';
      }
    }, error => {
      console.error("error");
    })
  }

}
