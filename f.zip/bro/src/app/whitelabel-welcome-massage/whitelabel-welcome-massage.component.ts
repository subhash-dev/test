import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-whitelabel-welcome-massage',
  templateUrl: './whitelabel-welcome-massage.component.html',
  styleUrls: ['./whitelabel-welcome-massage.component.scss']
})
export class WhitelabelWelcomeMassageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
