import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../auth-gaurd/auth-guard.service';
import { RoleGuard } from '../auth-gaurd/role-guard.service';
import { WhitelabelWelcomeMassageComponent } from './whitelabel-welcome-massage.component';
import { WhitelabelWelcomeMassageViewComponent } from './whitelabel-welcome-massage-view/whitelabel-welcome-massage-view.component';

const routes: Routes = [{
  path: "whitelabel-come",
  canActivate: [AuthGuard],
  component: WhitelabelWelcomeMassageComponent,
  children: [
    {
      path: "view",
      canActivate: [AuthGuard, RoleGuard],
      component: WhitelabelWelcomeMassageViewComponent,
    },
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WhitelabelWelcomeMassageRoutingModule { }
