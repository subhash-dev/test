import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WhitelabelWelcomeMassageRoutingModule } from './whitelabel-welcome-massage-routing.module';
import { WhitelabelWelcomeMassageViewComponent } from './whitelabel-welcome-massage-view/whitelabel-welcome-massage-view.component';
import { DataTablesModule } from 'angular-datatables';
import { commonDerectivenModule } from '../auth-gaurd/commonDerective.module';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModalModule } from 'ngx-bootstrap';
import { EventmasterRoutingModule } from '../eventmaster/eventmaster-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { MatSlideToggleModule } from '@angular/material';
import { WhitelabelWelcomeMassageComponent } from './whitelabel-welcome-massage.component';

@NgModule({
  declarations: [WhitelabelWelcomeMassageComponent, WhitelabelWelcomeMassageViewComponent],
  imports: [
    CommonModule,
    WhitelabelWelcomeMassageRoutingModule,
    CommonModule,
    DataTablesModule,   
    commonDerectivenModule,
    FormsModule,
    NgbModule,
    ModalModule.forRoot(),
    EventmasterRoutingModule,
    BrowserModule,
    AngularMultiSelectModule,
    MatSlideToggleModule
  ]
})
export class WhitelabelWelcomeMassageModule { }
