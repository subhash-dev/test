import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from 'ngx-bootstrap';
import { UserIdleService } from 'angular-user-idle';
import {ActivatedRoute, Router} from '@angular/router';
import {UtilityService} from '../globals/utilityService';
import { UserService } from '../services/user.service';
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  roles: any;
  moduleAccess: any;
  counter: any;
  @ViewChild('childModal', { static: false }) childModal: ModalDirective;
  constructor( private router: Router , 
               private utilityService: UtilityService,  
               private userIdle: UserIdleService , 
               private route:ActivatedRoute,
               private userService:UserService
               ) {

    // Session Maintain ideal 30 minute logout
    this.userIdle.startWatching();

    // Start watching when user idle is starting.
    this.userIdle.onTimerStart().subscribe(count => {
        this.counter = count;
        this.childModal.show();
      }
    );

    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() =>{
        this.userService.logOut().subscribe(response =>{
            response = this.utilityService.gsk(response.auth);
            response = JSON.parse(response);
          if(response){
            this.utilityService.popToast('success','Success', 3000 , 'Logout successfully.');
            localStorage.clear();
            this.router.navigate(['']);
          }
        }, error =>{
          this.utilityService.popToast('error','Error', 3000 , error.message); 
          console.error("error in logout");
        })
      
      this.childModal.hide();
      localStorage.clear();
      sessionStorage.clear();
      this.router.navigate(['']);
      setTimeout(function(){ window.location.reload(); }, 3000);

    });
  }

  ngOnInit() {
    this.roles = this.utilityService.returnLocalStorageData('role') ? JSON.parse(this.utilityService.returnLocalStorageData('role')) : null;
    this.moduleAccess = this.utilityService.returnLocalStorageData('userData') ? JSON.parse(this.utilityService.returnLocalStorageData('userData')).role['modules'] : null;
    if (this.moduleAccess) {
      this.moduleAccess = this.moduleAccess.map(data => {
        return data.moduleName;
      });
    }
  }

  hideChildModal() {
    this.userIdle.resetTimer();
    this.childModal.hide();
  }


  stay() {
    this.userIdle.resetTimer();
    this.childModal.hide();
  }
}
