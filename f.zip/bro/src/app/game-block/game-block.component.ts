import { Component, OnInit } from '@angular/core';
import {NgxSpinnerService} from 'ngx-spinner';
import {MarketService} from '../services/market.service';
import {UtilityService} from '../globals/utilityService';

@Component({
  selector: 'app-game-block',
  templateUrl: './game-block.component.html',
  styleUrls: ['./game-block.component.scss']
})
export class GameBlockComponent implements OnInit {

  constructor( private marketService: MarketService , private spinner: NgxSpinnerService, private utilityService: UtilityService) { }
  gameBlockAll: any;
  ngOnInit() {
    this.gameBlockList();
  }

  gameBlockList() {
    // this.spinner.show();
    // const items = {
    //   lockGameBy : ''
    // };
    // this.utilityService.getAllWhiteLabel().then(response =>{
    //   let x = response.data;
    //   /* Hear X is Multiple Whitelable Data*/
    //   for(let i = 0;i < x.length; i++){
    //     this.marketService.getAllBetBlock(items ,  x[i]).subscribe(response => {
    //       console.log(response)
    //     });
    //   }
    // }).catch(error =>{
    //   console.error("errro in get white label");
    // });
    // this.marketService.getAllBetBlock(items).subscribe(response => {
    //   this.gameBlockAll = response.data;
    //   this.spinner.hide();
    //   console.log(this.gameBlockAll);
    // });
  }

}


