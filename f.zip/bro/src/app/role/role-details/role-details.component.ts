import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';
import {switchMap} from 'rxjs/internal/operators';
import {RoleService} from '../../services/role.service';
import {NgxSpinnerService} from "ngx-spinner";
import { UtilityService } from 'src/app/globals/utilityService';

@Component({
  selector: 'app-role-details',
  templateUrl: './role-details.component.html',
  styleUrls: ['./role-details.component.scss']
})
export class RoleDetailsComponent implements OnInit {
  addRoleObject: any;

  constructor(private route: ActivatedRoute,
              private spinner: NgxSpinnerService,
              private roleService : RoleService,
              private utilityService: UtilityService,

  ) { }

  ngOnInit() {
    this.route.params.pipe(
      switchMap((params: Params) => this.roleService.getRoleById(params.id))).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
        this.addRoleObject = response.data;
      });
  }

}
