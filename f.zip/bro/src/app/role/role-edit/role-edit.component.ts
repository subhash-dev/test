import {Component, OnInit} from '@angular/core';
import {RoleService} from '../../services/role.service';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {switchMap} from 'rxjs/internal/operators';
import {UtilityService} from '../../globals/utilityService';
import {ToasterConfig} from 'angular2-toaster';
import {NgxSpinnerService} from "ngx-spinner";
declare let _ : any;
@Component({
  selector: 'app-role-edit',
  templateUrl: './role-edit.component.html',
  styleUrls: ['./role-edit.component.scss']
})
export class RoleEditComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  constructor(private roleService: RoleService,
              private route: ActivatedRoute,
              private spinner: NgxSpinnerService,
              private utilityService: UtilityService,
              private router: Router) {
  }

  moduleList: any;
  showModuleError = false;
  addRoleObject: any;

  ngOnInit() {

    this.route.params.pipe(
      switchMap((params: Params) => this.roleService.getRoleById(params.id)))
      .subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.addRoleObject = response.data;
        this.getAllModules();
      });

  }


  /**
   * @author kc
   * @date 21-01-2020
   * get all modules list
   */
  getAllModules() {
    this.roleService.getAllModules().subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        this.moduleList = response.data;
        this.moduleList.docs = this.moduleList.docs.map(data => {
        data['selectAllAccess'] = false;
        data['addIt'] = false;
        data['count'] = 0;
        return data;

      });


      this.moduleList.docs.map(moduleList => {

        this.addRoleObject.modules.map(module => {
          if (module._id === moduleList._id) {
            moduleList.viewAccess = module.viewAccess;
            moduleList.createAccess = module.createAccess;
            moduleList.updateAccess = module.updateAccess;
            moduleList.deleteAccess = module.deleteAccess;
            moduleList.allowBet = module.allowBet;
            moduleList.applyCommission = module.applyCommission;
            moduleList.limit = module.limit;
            moduleList.message = module.message;
            moduleList.suspended = module.suspended;
            moduleList.enterRate = module.enterRate;
            moduleList.commentary = module.commentary;
            moduleList.result = module.result;
            moduleList['addIt'] = true;
            moduleList['count'] = module.count;
            moduleList['selectAllAccess'] = module.selectAllAccess;
          }

        });
        return moduleList;
      });

    }, error => {
      console.error('get error from module list');
    });
  }

  /***
   * select
   * @param e
   * @param data
   * @return {any}
   */
  selectAllAccess(e, data) {
    if (e.target.checked === true) {
      data.viewAccess = true;
      data.createAccess = true;
      data.updateAccess = true;
      data.deleteAccess = true;
      data.allowBet = true;
      data.applyCommission = true;
      data.limit = true;
      data.message = true;
      data.suspended = true;
      data.enterRate = true;
      data.commentary = true;
      data.liveTv = true;
      data.result = true;
      data.addIt = true;
      data['count'] = 13;
      this.addRoleObject.modules.push(data);
      return data;
    } else {
      data.viewAccess = false;
      data.createAccess = false;
      data.updateAccess = false;
      data.deleteAccess = false;
      data.allowBet = false;
      data.applyCommission = false;
      data.limit = false;
      data.message = false;
      data.suspended = false;
      data.enterRate = false;
      data.commentary = false;
      data.liveTv = false;
      data.result = false;
      data.addIt = false;
      data['count'] = 0;
      return data;
    }
  }

  /**
   * check module insert or not in array list
   */
  checkModuleInsert() {
    if (this.addRoleObject.modules && this.addRoleObject.modules.length === 0) {
      this.showModuleError = true;
    } else {
      this.showModuleError = false;
    }
  }

  check(e, data) {
    let eventData= {
      checked : e.target.checked
    };
    this.showModuleError = false;
    this.addModuleInRole(eventData, data)
  }

  /***
   * add and remove module in array
   * @param e
   * @param data
   */
  addModuleInRole(e, data) {
    if (e.checked === true) {
      let checkMsExistOrNot = _.some(this.moduleList.docs, {"_id": data._id});
      if(checkMsExistOrNot === false){
        data['count'] = 1;
        this.moduleList.docs.push(data);
      }else{
        data.count = (Number(data.count) + 1);
        if(data['count'] === 13){
          data.selectAllAccess =true;
        }
      }

    } else {
      this.moduleList.docs = this.moduleList.docs.map(module => {
        if (module._id === data._id) {
          data.count = (Number(data.count) - 1);
        }

        if(module.selectAllAccess === true){
          module.selectAllAccess = false;
        }
        return module
      });
      if (this.moduleList.docs && this.moduleList.docs.length === 0) {
        this.showModuleError = true;
      }
    }
  }
  /***
   * create role
   */
  createRoles() {

    this.addRoleObject.modules = this.moduleList.docs;

    this.addRoleObject.modules.map(data =>{
      data.addIt = true;
      return data
    });
    this.addRoleObject.modules = this.addRoleObject.modules.filter(fDate =>{
      return fDate.count > 0;
    });

    if (this.addRoleObject.modules.length === 0) {
      alert("Please Select Role")
    }else {


      this.roleService.updateRole(this.addRoleObject).subscribe(response => {
          console.log("test--------------------",response);
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status === true) {
          this.utilityService.popToast('success', 'Success', 3000, 'Role updated successfully');
          this.router.navigate(['/role/view']);
        } else {
          this.utilityService.popToast('error', 'Error', 3000, response.message);
        }
      }, error => {
        console.error('role is not inserted pelase try again');
      });
    }

  };
}
