import {Component, OnInit, ViewChild,ElementRef,HostListener} from '@angular/core';
import {RoleService} from '../../services/role.service';
import {ModalDirective} from 'ngx-bootstrap';
import {ToasterConfig} from 'angular2-toaster';
import {UtilityService} from '../../globals/utilityService';
import {Router} from '@angular/router';
import {NgxSpinnerService} from "ngx-spinner";

@Component({
  selector: 'app-module-access',
  templateUrl: './module-access.component.html',
  styleUrls: ['./module-access.component.scss']
})
export class ModuleAccessComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  moduleList: any;
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('editmodal', {static: false}) editmodal: ModalDirective;
  @ViewChild('focusInput' ,  {static: false}) focusInput: ElementRef;

  constructor(private roleService: RoleService,
              private utilityService: UtilityService,
              private spinner: NgxSpinnerService,
              private router: Router
              ) {
  }

  addModuleObject = {
    moduleName: null,
    alias: null,
    createAccess: false,
    viewAccess: false,
    updateAccess: false,
    deleteAccess: false,
    allowBet: false,
    applyCommission: false,
    limit: false,
    message: false,
    suspended: false,
    enterRate: false,
    commentary: false,
    liveTv:false,
    result: false
  };
  updateModuleObject: any;

  @HostListener('focusout', ['$event']) public onListenerTriggered(event: any): void {
    if(event.sourceCapabilities) {

    }else {
      this.setFocusToInput();
    }
  }

  ngOnInit() {
    this.getAllModules()
  }
  setFocusToInput() {

    this.focusInput.nativeElement.focus();
  }

  /**
   * @author kc
   * @date 21-01-2020
   * get all modules list
   */
  getAllModules() {
    this.spinner.show()
    this.roleService.getAllModules().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      this.moduleList = response.data;
      this.spinner.hide()
      this.moduleList.docs = this.moduleList.docs.map(data => {
        data['selectAllAccess'] = false;
        data['addIt'] = false;
        return data;

      });
    }, error => {
      console.error('get error from module list');
    });
  }

  openModel() {
    this.addModuleObject = {
      moduleName: null,
      alias: null,
      createAccess: false,
      viewAccess: false,
      updateAccess: false,
      deleteAccess: false,
      allowBet: false,
      applyCommission: false,
      limit: false,
      message: false,
      suspended: false,
      enterRate: false,
      commentary: false,
      liveTv:false,
      result: false
    };
    this.modal.show();
  }

  closeModel() {
    this.modal.hide();
    this.addModuleObject = {
      moduleName: null,
      alias: null,
      createAccess: false,
      viewAccess: false,
      updateAccess: false,
      deleteAccess: false,
      allowBet: false,
      applyCommission: false,
      limit: false,
      message: false,
      suspended: false,
      enterRate: false,
      commentary: false,
      liveTv:false,
      result: false
    };
  }

  createModule() {
    this.roleService.createModule(this.addModuleObject).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      this.modal.hide();

      if (response.status === true) {
        this.utilityService.popToast('success','Success', 3000 , 'Module created successfully');
        this.getAllModules();
      }else{
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }
    }, error => {
      console.error('add module error', error);
    })
  }

  openEditModel(e) {
    this.editmodal.show();
    this.roleService.getModuleById(e).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      this.updateModuleObject = response.data;

    }, error => {
      console.error('error in get module', error);
    })
  }

  closeEditModel() {
    this.editmodal.hide()
  }
  updateModuleFunction() {
    this.roleService.updateModule(this.updateModuleObject).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      this.editmodal.hide();
      if (response.status === true) {
        this.utilityService.popToast('success','Success', 3000 , 'Module updated successfully');
        this.getAllModules();
      }else{
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }
    }, error => {
      console.error('update module error', error);
    })
  }

}
