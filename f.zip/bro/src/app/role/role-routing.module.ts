import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {RoleComponent} from './role.component';
import {RoleViewComponent} from './role-view/role-view.component';
import {RoleCreateComponent} from './role-create/role-create.component';
import {RoleEditComponent} from './role-edit/role-edit.component';
import {ModuleAccessComponent} from './module-access/module-access.component';
import {RoleDetailsComponent} from './role-details/role-details.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path: 'role',
  canActivate: [AuthGuard],
  component: RoleComponent,
  children: [
    {
      path: 'view',
      canActivate: [AuthGuard,RoleGuard],
      component: RoleViewComponent,
    },
    {
      path: 'create',
      canActivate: [AuthGuard,RoleGuard],
      component: RoleCreateComponent,
    },
    {
      path: 'edit/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: RoleEditComponent,
    },
    {
      path: 'details/:id',
      canActivate: [AuthGuard,RoleGuard],
      component: RoleDetailsComponent,
    },
    {
      path: 'module',
      canActivate: [AuthGuard,RoleGuard],
      component: ModuleAccessComponent,
    },
  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleRoutingModule {
}
