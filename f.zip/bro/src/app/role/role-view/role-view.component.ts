import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {RoleService} from '../../services/role.service';
import {DataTable} from '../../../../node_modules/datatables.net/js/jquery.dataTables.min.js';
import {NgxSpinnerService} from "ngx-spinner";
import { UtilityService } from 'src/app/globals/utilityService';
declare let $  :any;
@Component({
  selector: 'app-role-view',
  templateUrl: './role-view.component.html',
  styleUrls: ['./role-view.component.scss']
})
export class RoleViewComponent implements OnInit {
    constructor(private roleService: RoleService, private spinner: NgxSpinnerService,  private chRef: ChangeDetectorRef,private utilityService: UtilityService) {
    }
  dataTable: any;
    roles:any;
    filter = {
        page: 1,
        limit: 10,
        search: null
    };

    ngOnInit() {

       $('#table_id').DataTable();

        this.getAllRolesFn();
        let x = new Date();
        this.convertUTCDateToLocalDate(x);
    }

    getAllRolesFn() {
      this.spinner.show();
        this.roleService.getAllRoles(this.filter).subscribe(response => {
			response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
          this.roles = response.data;
          this.spinner.hide();
          this.chRef.detectChanges();
          const table: any = $('table');
          this.dataTable = table.DataTable({
            paging:   false,
            ordering: false,
            info:     false
            // serverSide : true,
            // processing : true,
            // data : this.roleUserList
            // ajax: {
            //   type: "GET",
            //   url: 'http://localhost:5060/digi/api/v1/user?page=1&limit=10',
            //   contentType: 'application/json; charset=utf-8',
            //   data: data => {
            //     console.log(data);
            //     return data = JSON.stringify(data);
            //   }
            // },
          });
        }, error => {
          this.spinner.hide();
            console.error('get roles error');
        });
    }


    convertUTCDateToLocalDate(date) {
       /* var newDate = new Date(date.getTime()+date.getTimezoneOffset()*60*1000);
        console.log(">>>>>>>>>>>>", newDate)
        var offset = date.getTimezoneOffset() / 60;
        var hours = date.getHours();
        var hours1 = date.getTimezoneOffset();
        console.log(">>>>>>>>>>>>", offset)
        newDate.setHours(hours - offset);*/
        console.log(date);
        var dateString = date;
        dateString = new Date(dateString).toUTCString();
        dateString = dateString.split(' ').slice(5, 9).join(' ');
        console.log(dateString);

        //return newDate;
    }



}
