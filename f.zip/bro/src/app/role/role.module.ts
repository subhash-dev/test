import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {RoleRoutingModule} from './role-routing.module';
import {RoleComponent} from './role.component';
import {RoleViewComponent} from './role-view/role-view.component';
import {RoleCreateComponent} from './role-create/role-create.component';
import {RoleService} from '../services/role.service';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule} from '@angular/forms';
import {DemoMaterialModule} from '../../material-module';
import {HttpClientModule} from '@angular/common/http';
import {RoleEditComponent} from './role-edit/role-edit.component';
import {ModuleAccessComponent} from './module-access/module-access.component';
import {ModalModule} from 'ngx-bootstrap';
import { RoleDetailsComponent } from './role-details/role-details.component';
import {commonDerectivenModule} from "../auth-gaurd/commonDerective.module";

@NgModule({
  declarations: [RoleComponent, RoleViewComponent, RoleCreateComponent, RoleEditComponent, ModuleAccessComponent, RoleDetailsComponent],
  imports: [
    CommonModule,
    RoleRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    commonDerectivenModule,
    FormsModule,
    HttpClientModule,
    ModalModule.forRoot(),
  ],
  providers: [RoleService]
})
export class RoleModule {
}
