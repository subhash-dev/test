import {Component, OnInit} from '@angular/core';
import {RoleService} from '../../services/role.service';
import {resolveSanitizationFn} from '@angular/compiler/src/render3/view/template';
import {Router} from '@angular/router';
import {UtilityService} from '../../globals/utilityService';
import {ToasterConfig} from 'angular2-toaster';
import {NgxSpinnerService} from "ngx-spinner";
declare let _ : any;
@Component({
  selector: 'app-role-create',
  templateUrl: './role-create.component.html',
  styleUrls: ['./role-create.component.scss']
})
export class RoleCreateComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
  constructor(private roleService: RoleService,
              private utilityService: UtilityService,
              private spinner: NgxSpinnerService,
              private router: Router) {
  }

  moduleList: any;
  moduleAccess: any;
  showModuleError = false;
  addRoleObject = {
    role_name: null,
    description: null,
    modules: []
  };

  ngOnInit() {
    this.getAllModules();
    this.showModuleError = true;

  }


  /**
   * @author kc
   * @date 21-01-2020
   * get all modules list
   */
  getAllModules() {
    this.roleService.getAllModules().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      this.moduleList = response.data;
      this.moduleList.docs = this.moduleList.docs.map(data => {
        data['selectAllAccess'] = false;
        data['addIt'] = false;
        data['count'] = 0;
        return data;

      });

    }, error => {
      console.error('get error from module list');
    });
  }

  /***
   * select
   * @param e
   * @param data
   * @return {any}
   */
  selectAllAccess(e, data) {
    if (e.target.checked === true) {
      data['addIt'] = true;
      this.showModuleError = false;
      data.viewAccess = true;
      data.createAccess = true;
      data.updateAccess = true;
      data.deleteAccess = true;
      data.allowBet = true;
      data.applyCommission = true;
      data.limit = true;
      data.message = true;
      data.suspended = true;
      data.enterRate = true;
      data.commentary = true;
      data.liveTv = true;
      data.result = true;
      data['count'] = 13;
      this.addRoleObject.modules.push(data);
      return data;


    } else {
      data['addIt'] = false;
      this.showModuleError = true;
      data.viewAccess = false;
      data.createAccess = false;
      data.updateAccess = false;
      data.deleteAccess = false;
      data.allowBet = false;
      data.applyCommission = false;
      data.limit = false;
      data.message = false;
      data.suspended = false;
      data.enterRate = false;
      data.commentary = false;
      data.liveTv = false;
      data.result = false;
      data['count'] = 0;
      return data;
    }
  }



  /**
   * check module insert or not in array list
   */
  checkModuleInsert() {
    if (this.addRoleObject.modules && this.addRoleObject.modules.length === 0) {
      this.showModuleError = true;
    } else {
      this.showModuleError = false;
    }
  }


  check(e, data) {
    let eventData= {
        checked : e.target.checked
    };
    this.showModuleError = false;
    this.addModuleInRole(eventData, data)
  }


  /***
   * add and remove module in array
   * @param e
   * @param data
   */
  addModuleInRole(e, data) {
    if (e.checked === true) {
      let checkMsExistOrNot = _.some(this.addRoleObject.modules, {"_id": data._id});
      if(checkMsExistOrNot === false){
        data.count = (Number(data.count) + 1);
        this.addRoleObject.modules.push(data);
      }else{
        data.count = (Number(data.count) + 1);
        if(data['count'] === 13){
          data.selectAllAccess =true;
        }
      }

    } else {
      this.addRoleObject.modules = this.addRoleObject.modules.map(module => {
        if (module._id === data._id) {
          data.count = (Number(data.count) - 1);
          }

          if(module.selectAllAccess === true){
            module.selectAllAccess = false;
          }
        return module
      });
      if (this.addRoleObject.modules && this.addRoleObject.modules.length === 0) {
        this.showModuleError = true;
      }
    }
  }

  /***
   * create role
   */
  createRoles() {

    this.addRoleObject.modules.map(data =>{
      data.addIt = true;
      return data
    });
    this.addRoleObject.modules = this.addRoleObject.modules.filter(fDate =>{
      return fDate.count > 0;
    });

    if (this.addRoleObject.modules.length === 0) {
        alert("Please Select Role")
    }else {
    this.roleService.addNewRole(this.addRoleObject).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
			response =JSON.parse(response);
      if (response.status === true) {
        this.utilityService.popToast('success','Success', 3000 , 'Role created successfully');
        this.router.navigate(['/role/view']);
      }else{
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }

    }, error => {
      console.error('role is not inserted pelase try again');
    });
    }
  };

}
