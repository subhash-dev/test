import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BettingRoutingModule } from './betting-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BettingRoutingModule
  ]
})
export class BettingModule { }
