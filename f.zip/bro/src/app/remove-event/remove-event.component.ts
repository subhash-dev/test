import { ChangeDetectorRef, Component, HostListener, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { SportService } from '../services/sport.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatchService } from '../services/match.service';
import { TournamentService } from '../services/tournament.service';
import { MarketService } from '../services/market.service';
import { UtilityService } from '../globals/utilityService';
import { RoleService } from '../services/role.service';
import { UserService } from '../services/user.service';
import { isUndefined } from 'util';
import { GameSettingService } from '../services/gameSettingService.service';
import { ToasterConfig } from 'angular2-toaster';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as env from '../globals/env';
import { NgxSpinnerService } from "ngx-spinner";
import { SocketService } from "../globals/socketService";

declare let $: any;
var aes256 = require('aes256');
class Market {
  id: number;
  match: string;
  market: string;
  marketType: string;
  createdAt: string;
  isActive: string;
  allowBat: string;
  inPlay: string;
  message: string;
  isDisplayRate: string;
  displayOrder: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}

@Component({
  selector: 'app-remove-event',
  templateUrl: './remove-event.component.html',
  styleUrls: ['./remove-event.component.scss']
})

export class RemoveEventComponent implements OnInit {
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right', limit: 2
  });
 

  @ViewChild('modal', { static: false }) modal: ModalDirective;
  @ViewChild(DataTableDirective, { static: false })
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  markets: Market[];
  resData;
  settings: any;
  server_url: any = env.server_url();
  accessRole: any;
  paramId: any;
  getAllMarkets: any;
  fancyConfigObject: any;
  time: any;
  marketTypes: any;
  matchSerch:any;
  matchListSerchdata:any;
  dataTable: any;
  deleteObj:any;
  SelecTmatch:any;

  constructor(private route: ActivatedRoute,
    private matchService: MatchService,
    private marketService: MarketService,
    private tournamentService: TournamentService,
    private sportService: SportService,
    private utilityService: UtilityService,
    private chRef: ChangeDetectorRef,
    private roleService: RoleService,
    private userService: UserService,
    private gameSettingService: GameSettingService,
    private socketService: SocketService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private http: HttpClient) {
  }
  ngOnInit() {
    if (isUndefined(this.utilityService.returnAccessRole('MARKET'))) {
      this.router.navigate(['accessdenied']);
    } else {
      this.accessRole = this.utilityService.returnAccessRole('MARKET');
    }
   
    this.getMarketsDt(); //get all market by datatable
    // this.getAllModules();
    this.matchListSerch();
  }

  rerender(): void {
    $('.dataTable').dataTable().fnClearTable();
  }

  getMarketsDt() {
    let userId = '';
    if (JSON.parse(this.utilityService.returnLocalStorageData('userData')).userType === 'STAFF') {
      userId = (JSON.parse(this.utilityService.returnLocalStorageData('userData')).user_id)
    }
    this.spinner.show();
    const that = this;
    let url = this.server_url + 'market/get-all';
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 50,   // -- trying to set to 5 records only
      paging: true,
      // autoWidth: false,
      // scrollX: true,
      // scrollCollapse:true,
      serverSide: true,
      processing: true,
      responsive: true,
      lengthChange: true,
      order: [[ 0, "" ]],
      lengthMenu: [50, 75, 100, 200],
      language: {
        lengthMenu: '_MENU_',
        zeroRecords: '',
        emptyTable: 'No record found',
        paginate: {
          first: 'First', last: 'Last',
          next: '<i class="fa fa-chevron-circle-right">',
          previous: '<i class="fa fa-chevron-circle-left">'
        }
      },
      ajax: (dataTablesParameters: any, callback) => {
        that.http
          .post<DataTablesResponse>(
            url,
            Object.assign(dataTablesParameters, { matchId: this.paramId, userId: userId, matchName: this.matchSerch }),
            {}
          ).subscribe(resp => {
            this.resData = resp;
            this.resData = this.utilityService.gsk(this.resData.auth);
            this.resData =JSON.parse(this.resData);
            this.resData = this.resData.data;
            this.spinner.hide();
            let uniqueArr = [];
            if (this.resData.docs.length > 0) {
              that.markets = this.resData.docs;
              this.resData.docs.map(data => {
                uniqueArr.push(data.match);
              });
            
            }
            this.dtTrigger.next();
            callback({
              recordsTotal: this.resData.total,
              recordsFiltered: this.resData.total,
              data: []
            });
          });
      },
      columns: [{ data: '' }, { data: 'marketType' }, { data: 'match.name' }, { data: 'marketType' }, { data: 'marketStartTime' }, { data: 'createdAt' }, { data: 'isActive' }],
      columnDefs: [{ orderable: false, targets: [0] }]
    };

  }

  /**
   * get all modules list
   */
  // getAllModules() {
  //   this.roleService.getAllModules().subscribe(response => {
  //       response = this.utilityService.gsk(response.auth);
  //       response =JSON.parse(response);
  //     response.data.docs.map(data => {
  //       if (data.moduleName === 'FANCY') {
  //         this.fancyId = data._id;
  //       }
  //     });
  //   }, error => {
  //     console.error('error in get modules');
  //   });
  // }

  openModal(market){
    this.deleteObj = null;
    if(market && market.marketType === "Fancy"){
      this.deleteObj = {
          marketType : market.marketType,
          fancyId : market.fancyId
        }
    }
    if(market && market.marketType === "Line"){
      this.deleteObj = {
        marketType : market.marketType,
        lineId : market.lineId
      }
    }
    if(market && market.marketType === "Winner" || market && market.marketType === "Match Odds" || market && market.marketType === "Bookmaker"){
      this.deleteObj = {
        marketType : market.marketType,
        marketId : market.marketId
      }
    }
    this.modal.show();
  }
  /**
   * close modal
   */
   closeModel(data) {
    this.deleteObj = null;
    this.modal.hide();
    this.rerender();
  }

  deleteEvent(){
    if(this.deleteObj){
      this.marketService.removeEvent(this.deleteObj).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status === true) {
          this.rerender();
          this.modal.hide();
          this.spinner.hide();
        }
      }, error => {
        this.spinner.hide();
        this.modal.hide();
        console.error('error in priority', error);
      })
    }
  }
   /**
   * get all match list
   */
    matchListSerch() {
      let type = 'All';
      this.marketService.getMatchListSerch(type).subscribe(response => {
          response = this.utilityService.gsk(response.auth);
          response =JSON.parse(response);
        this.matchListSerchdata =response.data;
        console.log("this.matchListSerchdata",this.matchListSerchdata);
      }, error => {
        console.error('error');
      });
    }
    searchSettleData() {
      console.log(this.SelecTmatch)
      if (this.SelecTmatch) {
        this.matchSerch = this.SelecTmatch;
        this.getMarketsDt();
        this.rerender();
      }
    }
    clear() {
      if (this.SelecTmatch) {
        this.matchSerch = '';
        this.SelecTmatch = '';
        this.getMarketsDt();
        this.rerender();
      }
    }
}

