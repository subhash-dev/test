import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {FancyComponent} from './fancy.component';
import {FancyViewComponent} from './fancy-view/fancy-view.component';
import {RoleGuard} from '../auth-gaurd/role-guard.service';
import {AuthGuard} from '../auth-gaurd/auth-guard.service';

const routes: Routes = [{
  path: 'fancy',
  canActivate: [AuthGuard, RoleGuard],
  component: FancyComponent,
  children: [
    {
      path: 'view/:id',
      canActivate: [AuthGuard, RoleGuard],
      component: FancyViewComponent,
    },

  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FancyRoutingModule {
}
