import { Component, OnInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToasterConfig } from 'angular2-toaster';
import { CommonService } from './../../services/common.service';
import { FancyService } from './../../services/fancy.service';
import { SocketService } from './../../globals/socketService';
import { SocketServiceRedis } from 'src/app/globals/socketServiceRedis';
import { UtilityService } from './../../globals/utilityService';
import { UserService } from '../../services/user.service';
import * as $ from 'jquery';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { ModalDirective } from 'ngx-bootstrap';
import { Observable, timer } from 'rxjs';
import { interval } from 'rxjs';

import { take, map, finalize } from 'rxjs/operators';
import * as env from '../../globals/env';
import { GameSettingService } from "../../services/gameSettingService.service";
import { NgxSpinnerService } from "ngx-spinner";
import { MarketService } from "../../services/market.service";
var aes256 = require('aes256');
import * as _ from 'lodash';
@Component({
  selector: 'app-fancy-view',
  templateUrl: './fancy-view.component.html',
  styleUrls: ['./fancy-view.component.scss']
})
export class FancyViewComponent implements OnInit {
  @ViewChild('gameEnd', { static: false }) gameEnd: ModalDirective;
  @ViewChild('fancyConfigure', { static: false }) fancyConfigure: ModalDirective;
  @ViewChild('fancySetting', { static: false }) fancySetting: ModalDirective;
  @ViewChild("endGameForm", { static: false }) formResetValue;
  @ViewChild('conformationModal', { static: false }) conformationModal: ModalDirective;

  value1: any = '';
  value2: any = '';
  noFirst;
  noFirstVol;
  noSecond;
  noSecondVol;
  noThird;
  noThirdVol;
  yesFirst;
  yesFirstVol;
  yesSecond;
  yesSecondVol;
  yesThird;
  yesThirdVol;
  rateInput;
  preVal;
  preValSec;
  preVol1;
  preVol2;
  fancyRateAry;
  inputVal;
  limit = "";
  lastObj = {};
  ballStatus :any;
  paramId = "";
  fancyDetail: any;
  fancyId = "";
  counter$: Observable<number>;
  count = env.OTP_SECONDS;
  countCompleted = false;
  revCounter :any = 0;
  rateRange;
  getMarketId : any;
  lastInput : any;
  allowBet : any;
  tempVar = false;
  rateDiffrence;
  endGameObject = {
    result: null,
    password: null
  };
  endSubmit = false;
  fancyConfgSettings: any;
  settel:any = 'false';
  fancyMode = 'Auto';
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right'
  });

  Toast = {
    type: '',
    title: '',
    timeout: 0,
    body: ''
  };


  constructor(private userService: UserService,
    private route: ActivatedRoute,
    private commonService: CommonService,
    private fancyService: FancyService,
    private gameSettingService: GameSettingService,
    private socketService: SocketService,
    private socketServiceRedis: SocketServiceRedis,
    private marketService: MarketService,
    private spinner: NgxSpinnerService,
    private utilityService: UtilityService,
    private elementRef: ElementRef
  ) { }

  ngOnInit() {
    this.settel = 'false';
    this.route.params.subscribe(params => {
      this.paramId = params['id'];
      this.socketService.joinRoom(this.paramId);

      this.fancyService.getMarketById(this.paramId).subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne =JSON.parse(resposne);
        if (resposne.status == true) {
          if (resposne.data != null) {
              this.socketServiceRedis.joinRoom(resposne.data.fancyId);
            this.fancyConfgSettings = resposne.data.fancyConfigurationSetting;
            this.allowBet = resposne.data.allowBat;
            this.fancyDetail = resposne.data;
            this.fancyMode = resposne.data.fancyMode;
            this.getMarketId = this.fancyDetail.fancyId;
            this.rateDiffrence = (this.fancyDetail.fancyConfigurationSetting) ? this.fancyDetail.fancyConfigurationSetting.rateDiffrence : 1;
            this.rateRange = (this.fancyDetail.fancyConfigurationSetting) ? this.fancyDetail.fancyConfigurationSetting.rateRange : 15;
            this.rateInput = resposne.data.master_code_id;
            this.fancyId = resposne.data.fancyId;
            this.ballStatus = this.fancyDetail.marketStatus.id === 'MS950763' ? 'Ball Start' :  this.fancyDetail.marketStatus.id === 'MS081893' ? 'Live' : 'Suspended' ;
            //this.rateCalculator(resposne.data.master_code_id);
          }
        }
      });
    });


    this.fancyService.getVolumeApi().subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne =JSON.parse(resposne);
      (resposne.status && resposne.status == true) ? this.fancyRateAry = resposne.data : []
    });

    this.fancyService.getLatestRate(this.paramId).subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne =JSON.parse(resposne);
      if (resposne.status == true) {
        if (resposne.data != null) {
          this.inputVal = resposne.data.master_code_id;
          this.rateInput = resposne.data.master_code_id;
          this.revCounter = Number(resposne.data.rateTime);
          //this.rateCalculator(resposne.data.master_code_id);
        }
      }
    });

    this.socketServiceRedis.fancyRate().subscribe((response) => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      if (response) {
        if(this.fancyMode == "Auto"){
          this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol  = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";
          const fancyId = response.srno;
          // if(response.srno == "2624367"){
          // }
          if (response.status == '1') {
            this.ballStatus = "Ball Running";
          } else if (response.status == '2') {
            this.ballStatus = "Suspend";
          } else {
            this.ballStatus = "Live";
            if (response.rates) {
              for (const [key, value] of Object.entries(response.rates)) {
                if (key == '0') {
                  this.noSecond = value['rate_1']
                  this.noSecondVol = value['value_1'];
                  this.yesSecond = value['rate_2'];
                  this.yesSecondVol = value['value_2'];
                }
                if (key == '1') {
                  this.noFirst = value['rate_1']
                  this.noFirstVol = value['value_1'];
                  this.yesFirst = value['rate_2'];
                  this.yesFirstVol = value['value_2'];
                }
                if (key == '2') {
                  this.noThird = value['rate_1']
                  this.noThirdVol = value['value_1'];
                  this.yesThird = value['rate_2'];
                  this.yesThirdVol = value['value_2'];
                }
                // // Fancy market append live rate for manual
              }
            } else {
            }

          }
        }else{
        }
      }
    })

    this.socketService.getTimer().subscribe((message) => {
       // console.log(message);
        let timers = message.rateTime;
        if(timers === 1){
          this.ballStatus = "Ball Start";
        }
        //this.revCounter = message.rateTime;
      });


        this.revCounter = timer(0, 1000)
        .subscribe(() => {
          if(this.revCounter > 0){
            if(this.revCounter == 1){
              this.timerStop();
            }
            --this.revCounter;
          }else{
            this.revCounter = 0;
          }
        })

      //this.socketService.sendCounter(this.paramId)

  }


  radioChange(event) {
    let data = {
      fancyMode: event.target.value
    };
    this.marketService.fancyModeUpdate(this.getMarketId, data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
      this.fancyMode = response.data.fancyMode;
      this.socketService.changeMode(this.getMarketId, response);
      this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";

      this.utilityService.getAllWhiteLabel().then(response => {
        let x = response.data;
        /* Hear X is Multiple Whitelable Data*/
        for (let i = 0; i < x.length; i++) {
          this.marketService.fancyModeUpdateWebHook(this.getMarketId, data, x[i])
            .subscribe(checkUserResponse => {
              if (event.target.value == 'Manual') {
              }
            });
        }
      }).catch(error => {
        console.error('errro in get white label');
      });
    });
  }


  /*
    Developer: Ravi
    Date: 28-jan-2020
    title: rate enter calculaton
    Use: This function is use rate calculation
  */

  enterRate(event) {
    setTimeout(() => {
      event.target.select();
    }, 100);
    var inputValue = event.target.value;
    this.lastInput = event.target.value;
    if (!inputValue) {
      return false;
    }
    this.rateCalculator(inputValue);
  }

  /*
     Developer: TR
     Date: 23-02/2020
     title: Open end game modal
     Use: This function end game result declare
   */
  openModal() {
    this.formResetValue.resetForm();
    this.endGameObject = {
      result: null,
      password: null
    };
    this.gameEnd.show();
  }

  /*
     Developer: TR
     Date: 08-06/2020
     title: Open fancy Configuration modal
     Use: This function fancy Configuration declare
   */
  openFancyConfgModal() {
    this.fancyConfigure.show();
  }
  /*
     Developer: TR
     Date: 09-06/2020
     title: Open fancy Setting modal
     Use: This function fancy Setting declare
   */
  openFancySettngModal() {
    this.fancySetting.show();
  }

  /*
     Developer: TR
     Date: 08-06/2020
     title: Open fancy Config close modal
     Use: This function end game result declare
   */
  closeFancyConfgModal() {
    this.fancyConfigure.hide();
  }

  /*
     Developer: TR
     Date: 09-06/2020
     title: Open fancy setting close modal
     Use: This function end game result declare
   */
  closeFancySettngModal() {
    this.fancySetting.hide();
  }

  /*
     Developer: TR
     Date: 23-02/2020
     title: Open end game modal
     Use: This function end game result declare
   */
  closeModal() {
    this.gameEnd.hide();
  }


  /*
     Developer: RK
     Date: 23-02/2020
     title: modal Submit
     Use: This function end game result declare
   */
  addEndGame(fancyId) {
          if(this.endSubmit) {
              return;
          }
          this.endSubmit = true;
          let key = env.constantKey();
          let token = this.endGameObject.password;
          var encrypted = aes256.encrypt(key, token);
          let marketObj = {
            market_uniq_id: fancyId,
            type: "fancy",
            result: this.endGameObject.result,
            token: encrypted
          };

          //settled fancy from office
          this.fancyService.fancySettledOffice(marketObj).subscribe(checkUserResponse => {
            checkUserResponse = this.utilityService.gsk(checkUserResponse.auth);
            checkUserResponse =JSON.parse(checkUserResponse);
              this.closeModal();
              this.settel = 'true';
              // if(checkUserResponse.status == true){
              //   delete marketObj.token;
              //   this.utilityService.getAllWhiteLabel().then(response => {
              //     let x = response.data;
              //     let totalWht = x.length;
              //     /* Hear X is Multiple Whitelable Data*/
              //     for (let i = 0; i < totalWht; i++) {
              //       this.fancyService.fancySettled(marketObj,x[i])
              //       .subscribe(checkUserResponse => {
              //         this.closeModal();
              //         this.settel = 'true';
              //         this.utilityService.popToast('success', 'Success', 3000, "Fancy Settled.");
              //       });
              //     }
              //   }).catch(error =>{
              //     console.error("errro in get white label");
              //   });
              // }else
                if(checkUserResponse.status == 'False'){
                this.utilityService.popToast('error', 'Error', 3000, checkUserResponse.message);
                this.endSubmit = false;
              }else{
                this.closeModal();
                this.settel = 'true';
                this.utilityService.popToast('success', 'Success', 3000, "Fancy Settled.");
              }
            }, error =>{
              this.endSubmit = false;
              this.utilityService.popToast('error','Error', 3000 , error.error.message);
            })

        }

  /*
    Developer: Ravi
    Date: 31-jan-2020
    title: Store fancy rate
    Use: This function validate the rate
  */

  rateCalculator(inputValue) {
    // console.log(this.rateDiffrence);
    // console.log(this.rateRange);

    //duplicate word not allowed and only alphanumeric, plus, minus, dot, star, slash, backslash are allowed
    var numberRegExp = /^[0-9]+$/;
    var restrictRegexp = /^[a-zA-Z0-9\+\-\.\*\/\\]+$/;
    var regexp_plus_minus = /^((\+)|(\-))([0-9.*/\\])?$/;
    var regexp = /^\d{1,}((\+)|(\-)?)([a-zA-Z.*\\]?)((\+[a-zA-Z.*\\])|(\-[a-zA-Z.*\\]))?$/;
    var backSlashReg = /^\d{1,}((\/)|(\,)?)([0-9\\]?)(([0-9\\]))?$/;

    this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";


    var minRangeVal = parseInt(this.preVal) - this.rateRange;
    minRangeVal = minRangeVal >= 0 ? minRangeVal : 0;
    var maxRangeVal = parseInt(this.preVal) + this.rateRange;

    if (regexp.test(inputValue) || regexp_plus_minus.test(inputValue) || backSlashReg.test(inputValue)) {
      //Find last character
      var lastChar = inputValue.charAt(inputValue.length - 1);

      if ((inputValue == '0') || inputValue === '+' || inputValue === '-' || (inputValue.trim() == '') || (lastChar == "+") || (lastChar == "-")) {
        console.log("first");
        this.invalidRate();  //Calling invalid function
        return false;
      }

      if (regexp_plus_minus.test(inputValue)) {
        if (typeof (this.preVal) == 'undefined') {
          console.log("second");
          this.invalidRate();  //Calling invalid function
          return false;
        }

        var marketVar = parseInt(this.preVal) + parseInt(inputValue);

        if (this.preVal && (marketVar < minRangeVal || marketVar > maxRangeVal) && (marketVar > 0)) { //this condition is check number minumum and maximum limit condition
          // this.invalidRate();  //Calling invalid function
          // return false;
        } else { //This code execusion when input having plus and increment number for e.g. +2, +3
          this.noSecond = marketVar;
          this.noSecondVol = this.preVol1;
          if(this.preVol1 == "100" && this.preVol2 == "100"){
            this.yesSecond = marketVar + parseInt(this.rateDiffrence);
          }else{
            this.yesSecond = marketVar;
          }
          this.yesSecondVol = this.preVol2;
          this.preVal = marketVar;
          //this.rateInput = marketVar;
          this.storeFancyRate(inputValue)
          this.inputVal = inputValue;
          this.rateInput = marketVar;
          $(document).on("click", "#rateInput", function () {
            $(this).select();
          });

          return false;
        }
      }

      var numVal = parseInt(inputValue.match(/(\d+)/g)); //extract number from string
      var charVal = inputValue.replace(numVal, '');
      var result = charVal.endsWith('/');
      if (charVal.split('-').length > 2 || charVal.split('+').length > 2 || result == true || ((charVal.charAt(0) == '+' || charVal.charAt(0) == '-') && (charVal.charAt(1) == '-' || charVal.charAt(1) == '+'))) {
        this.invalidRate();  //Calling invalid function
        return false;
      }

      //out of range error msg
      if(this.tempVar !== true){
      if (this.preVal && (numVal < minRangeVal || numVal > maxRangeVal)) {
        // this.invalidRate();  //Calling invalid function
        this.conformationModal.show();
        return false;
      }
        this.tempVar = false;
      }
      this.tempVar = false;

      if (charVal) { //This code is execute when input having number and digit for e.g 5+q-3 || 5q
        if (charVal.length > 3) {   //This is for 3 digit calculation  for e.g 5+q-3
          var firstCharSign = charVal.charAt(0);
          var secondCharSign = charVal.charAt(2);
          if ((firstCharSign == "+" && secondCharSign == "+") || (firstCharSign == "-" && secondCharSign == "-")) {
            this.invalidRate();  //Calling invalid function
            return false;
          }

          if (firstCharSign == "+") { //Condition for first sign is plus for eg. 55+q
            var keyValueFirst = this.fancyRateAry.filter(obj => {
              return obj.key == charVal.charAt(1).toUpperCase();
            });
            if (keyValueFirst.length > 0) {
              if (keyValueFirst[0].value2 == "") {
                this.noSecond = numVal;
                this.noSecondVol = 100
                this.yesSecond = numVal + parseInt(keyValueFirst[0].value1);
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + parseInt(keyValueFirst[0].value1);
                this.preVol1 = 100;
                this.preVol2 = 100;
              } else {
                this.noFirst = numVal + 1;
                this.noSecond = numVal;
                this.noFirstVol = keyValueFirst[0].value1;
                this.noSecondVol = 100
                this.yesFirst = numVal + 1;
                this.yesSecond = numVal + 1;
                this.yesFirstVol = keyValueFirst[0].value2;
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + 1;
                this.preVol1 = 100;
                this.preVol2 = 100;
              }
            }
          }

          if (secondCharSign == "+") { //Condition for first sign is plus for eg. q+w
            var keyValueSecond = this.fancyRateAry.filter(obj => {
              return obj.key == charVal.charAt(3).toUpperCase();
            });
            if (keyValueSecond.length > 0) {
              if (keyValueSecond[0].value2 == "") { //check condition if digit don't have volume
                this.noSecond = numVal;
                this.noSecondVol = 100
                this.yesSecond = numVal + parseInt(keyValueSecond[0].value1);
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + parseInt(keyValueSecond[0].value1);
                this.preVol1 = 100;
                this.preVol2 = 100;
              } else {
                this.noFirst = numVal + 1;
                this.noSecond = numVal;
                this.noFirstVol = keyValueSecond[0].value1;
                this.noSecondVol = 100
                this.yesFirst = numVal + 1;
                this.yesSecond = numVal + 1;
                this.yesFirstVol = keyValueSecond[0].value2;
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + 1;
                this.preVol1 = keyValueSecond[0].value1;
                this.preVol2 = keyValueSecond[0].value2;
              }
            }
          }

          if (firstCharSign == "-") { //Condition for first sign is - for eg. 55-q
            var keyValueFirst = this.fancyRateAry.filter(obj => {
              return obj.key == charVal.charAt(1).toUpperCase();
            });
            if (keyValueFirst.length > 0) {
              if (keyValueFirst[0].value2 == "") { //check condition if digit don't have volume
                this.noSecond = numVal;
                this.noSecondVol = 100
                this.yesSecond = numVal + parseInt(keyValueFirst[0].value1);
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + parseInt(keyValueFirst[0].value1);
                this.preVol1 = 100;
                this.preVol2 = 100;
              } else {
                this.noThird = numVal;
                this.noSecond = numVal;
                this.noThirdVol = keyValueFirst[0].value1;
                this.noSecondVol = 100
                this.yesThird = numVal;
                this.yesSecond = numVal + 1;
                this.yesThirdVol = keyValueFirst[0].value2;
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + 1;
                this.preVol1 = keyValueFirst[0].value1;
                this.preVol2 = keyValueFirst[0].value2;
              }
            }
          }

          if (secondCharSign == "-") { //Condition for first sign is - for eg. q-w
            var keyValueSecond = this.fancyRateAry.filter(obj => {
              return obj.key == charVal.charAt(3).toUpperCase();
            });
            if (keyValueSecond.length > 0) {
              if (keyValueSecond[0].value2 == "") { //check condition if digit don't have volume
                this.noSecond = numVal;
                this.noSecondVol = 100
                this.yesSecond = numVal + parseInt(keyValueSecond[0].value1);
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + parseInt(keyValueSecond[0].value1);
                this.preVol1 = 100;
                this.preVol2 = 100;
              } else {
                this.noThird = numVal;
                this.noSecond = numVal;
                this.noThirdVol = keyValueSecond[0].value1;
                this.noSecondVol = 100
                this.yesThird = numVal;
                this.yesSecond = numVal + 1;
                this.yesThirdVol = keyValueSecond[0].value2;
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + 1;
                this.preVol1 = keyValueSecond[0].value1;
                this.preVol2 = keyValueSecond[0].value2;
              }
            }
          }
        } else {  //This is for 2 digit calculation  for e.g 5+q or 5h
          var charSign = charVal.charAt(0);
          var keyValue = this.fancyRateAry.filter(obj => {
            return obj.key == lastChar.toUpperCase();
          });
          if (charSign == "+") {  //Condition for sign is - for e.g. 55+q
            if (keyValue.length > 0) {
              if (keyValue[0].value2 == "") { //check condition if digit don't have volume
                this.noSecond = numVal;
                this.noSecondVol = 100
                this.yesSecond = numVal + parseInt(keyValue[0].value1);
                this.yesSecondVol = 100;
                this.yesSecondVol = 100;
                this.preVal = numVal;
                this.preValSec = numVal + parseInt(keyValue[0].value1);
                this.preVol1 = 100;
                this.preVol2 = 100;
              }
              this.noFirst = numVal + 1;
              this.noSecond = numVal;
              this.noFirstVol = keyValue[0].value1;
              this.noSecondVol = 100
              this.yesFirst = numVal + 1;
              this.yesSecond = numVal + 1;
              this.yesFirstVol = keyValue[0].value2;
              this.yesSecondVol = 100;
              this.preVal = numVal;
              this.preValSec = numVal + 1;
              this.preVol1 = keyValue[0].value1;
              this.preVol2 = keyValue[0].value2;
              this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";
            }
          } else if (charSign == "-") { //Condition for sign is - for e.g. 55-q
            if (keyValue.length > 0) {
              this.noThird = numVal;
              this.noSecond = numVal;
              this.noThirdVol = keyValue[0].value1;
              this.noSecondVol = 100;
              this.yesThird = numVal;
              this.yesSecond = numVal + 1;
              this.yesThirdVol = keyValue[0].value2;
              this.yesSecondVol = 100;
              this.preVal = numVal;
              this.preValSec = numVal + 1;
              this.preVol1 = keyValue[0].value1;
              this.preVol2 = keyValue[0].value2;
            }
            this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = "";
          } else if (charSign == "/") { //Condition for sign is / for e.g. 55/4
            this.noSecond = numVal;
            this.noSecondVol = 100;
            this.yesSecond = numVal + parseInt(lastChar);
            this.yesSecondVol = 100;
            this.preVal = numVal;
            this.preValSec = numVal + parseInt(lastChar);
            this.preVol1 = 100;
            this.preVol2 = 100;
          } else if (charSign == ",") { //Condition for sign is , for e.g. 55,4
            this.noSecond = numVal;
            this.noSecondVol = 100;
            this.yesSecond = numVal + 1;
            this.yesSecondVol = 100;
            this.preVal = numVal;
            this.preValSec = numVal + 1;
            this.preVol1 = 100;
            this.preVol2 = 100;
          } else {  //Condition for no sign - for e.g. 55q
            if (charVal.length > 1) {
              this.invalidRate();  //Calling invalid function
              return false;
            }
            if (keyValue[0].value2 == "") { //check condition if digit don't have volume
              this.noSecond = numVal;
              this.noSecondVol = 100;
              this.yesSecond = numVal + parseInt(keyValue[0].value1);
              this.yesSecondVol = 100;
              this.preVal = numVal;
              this.preValSec = numVal + parseInt(keyValue[0].value1);
              this.preVol1 = 100;
              this.preVol2 = 100;
              return false;
            }
            this.noSecond = numVal;
            this.noSecondVol = keyValue[0].value1;
            this.yesSecond = numVal;
            this.yesSecondVol = keyValue[0].value2;
            this.preVal = numVal;
            this.preValSec = numVal + parseInt(keyValue[0].value1);
            this.preVol1 = keyValue[0].value1;
            this.preVol2 = keyValue[0].value2;
          }
        }
        this.inputVal = inputValue;
        this.storeFancyRate(inputValue)
        return false;
      }

      //This code is execute when input having number only for e.g 55 OR 75
      this.noSecond = inputValue;
      this.noSecondVol = 100;
      this.yesSecond = parseInt(inputValue) + parseInt(this.rateDiffrence);
      this.yesSecondVol = 100;
      this.preVal = inputValue;
      this.preValSec = parseInt(inputValue) + parseInt(this.rateDiffrence);
      this.preVol1 = 100;
      this.preVol2 = 100;
      this.inputVal = inputValue;
      this.storeFancyRate(inputValue)
    } else {
      console.log("thierd");
      this.invalidRate();  //Calling invalid function
      return false;
    }
  }

  /*
    Developer: Ravi
    Date: 31-jan-2020
    title: Store fancy rate
    Use: This function is use store fancy rate
  */

  storeFancyRate(masterCode) {
    // console.log("this.fancyId-------------------",this.fancyId);
    this.revCounter = Number(this.fancyDetail.fancyConfigurationSetting.ballStart);
    this.ballStatus = "Live";
    let type = "fancy"
    let statusValue = this.utilityService.marketStatusArray.filter(obj => obj.name === 'active');
    let apiObj = {
      master_code_id: masterCode,
      id: this.paramId,
      fancyId: this.fancyId,
      no1: this.noFirst,
      no1Vol: this.noFirstVol,
      no2: this.noSecond,
      no2Vol: this.noSecondVol,
      no3: this.noThird,
      no3Vol: this.noThirdVol,
      yes1: this.yesFirst,
      yes1Vol: this.yesFirstVol,
      yes2: this.yesSecond,
      yes2Vol: this.yesSecondVol,
      yes3: this.yesThird,
      yes3Vol: this.yesThirdVol,
      limit: this.limit,
      statusValue: statusValue
    }
    this.lastObj = apiObj;
    this.socketService.rateBroadcast(this.paramId, apiObj, type);
    this.fancyService.addFancyRate(apiObj).subscribe(resposne => {
    });
  }

  /*
    Developer: Ravi
    Date: 28-jan-2020
    title: Invalid rate
    Use: This function is use invalid rate
  */

  invalidRate() {
    this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";
    this.rateInput = "";
    this.Toast.title = 'Error';
    this.Toast.type = 'error';
    this.Toast.body = "Invalid input";
    this.commonService.popToast(this.Toast);
  }


  /*
    Developer: Ravi
    Date: 05-feb-2020
    title: action button click
    Use: This function is use save action of fancy
  */

  actionBtnClick(action) {
    if (action == "ballstart") {
      this.revCounter = 0;
      this.ballStatus = "Ball Start";
      this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";
    } else if (action == "suspend") {
      this.revCounter = 0;
      this.ballStatus = "Suspended";
      this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";
    } else if (action == "active") {
      this.ballStatus = "Live";
      this.rateCalculator(this.inputVal);
    }
    var obj = {
      fancy_id: this.fancyId,
      status: action,
      type: "fancy"
    }
    this.socketService.changeStatus(obj);

    let statusValue = this.utilityService.marketStatusArray.filter(obj => obj.name === action);
    let apiObj = {
      fancy_id: this.paramId,
      fancyStatus: statusValue
    }
    this.fancyService.updateFancyStatus(apiObj).subscribe(resposne => {
    });
  }

  @HostListener('document:keydown', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if(event.altKey == true && event.code === 'KeyS'){
      this.revCounter = 0;
      this.ballStatus = "Suspend";
      var obj = {
        fancy_id: this.fancyId,
        status: "suspend",
        type: "fancy"
      }
      this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";
      this.socketService.changeStatus(obj);

      let statusValue = this.utilityService.marketStatusArray.filter(obj => obj.name === "ballstart");
      let apiObj = {
        fancy_id: this.paramId,
        fancyStatus: statusValue
      }
      this.fancyService.updateFancyStatus(apiObj).subscribe(resposne => {
      });
    }

    if(event.code === 'Escape'){
      this.revCounter = 0;
      this.ballStatus = "Ball Start";
      var obj = {
        fancy_id: this.fancyId,
        status: "ballstart",
        type: "fancy"
      }
      this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";
      this.socketService.changeStatus(obj);

      let statusValue = this.utilityService.marketStatusArray.filter(obj => obj.name === "ballstart");
      let apiObj = {
        fancy_id: this.paramId,
        fancyStatus: statusValue
      }
      this.fancyService.updateFancyStatus(apiObj).subscribe(resposne => {
      });

    }

  }


  /*
    Developer: TR
    Date: 08-06-2020
    title: action button click
    Use: update fancyConfigSetting
  */
  fancyConfigureUpdate() {
    this.fancyDetail.fancyConfigurationSetting = this.fancyConfgSettings;
    this.fancyService.updateFancyConfgSetting(this.fancyDetail).subscribe(responseSett => {
        responseSett = this.utilityService.gsk(responseSett.auth);
        responseSett =JSON.parse(responseSett);
        this.rateDiffrence = (responseSett.data.fancyConfigurationSetting) ? responseSett.data.fancyConfigurationSetting.rateDiffrence : 1;
        this.rateRange = (responseSett.data.fancyConfigurationSetting) ? responseSett.data.fancyConfigurationSetting.rateRange : 15;
        this.utilityService.popToast('success', 'Success', 3000, 'Fancy configure setting updated successfully');
        this.fancyConfigure.hide();
    });
  }
  fancySettingUpdate() {
    this.fancyDetail.fancySetting.minStack = Number(this.fancyDetail.fancySetting.minStack);
    this.fancyDetail.fancySetting.maxStack = Number(this.fancyDetail.fancySetting.maxStack);
    this.fancyDetail.fancySetting.maxProfit = Number(this.fancyDetail.fancySetting.maxProfit);
    this.fancyDetail.fancySetting.betDelay = Number(this.fancyDetail.fancySetting.betDelay);
    this.fancyDetail.fancySetting.maxStackPerOdds = Number(this.fancyDetail.fancySetting.maxStackPerOdds);
    console.log("fancy update Obj", this.fancyDetail);
    this.marketService.updateMarketData(this.fancyDetail).subscribe(responseSett => {
        responseSett = this.utilityService.gsk(responseSett.auth);
        responseSett =JSON.parse(responseSett);
        delete this.fancyDetail.fancyConfigurationSetting;
        this.updateWhtLblMarket(this.fancyDetail);
        this.utilityService.popToast('success', 'Success', 3000, 'Fancy setting updated successfully');
        this.fancySetting.hide();
    });
  }


  /***
   * update in market data in  multiple white label
   * @param data
   */
  updateWhtLblMarket(data) {
    this.utilityService.getAllWhiteLabel().then(response => {
      let x = response.data;
      for (let i = 0; i < x.length; i++) {
        this.marketService.updateWhtLblMarket(data, x[i])
          .subscribe(response => {
            // this.utilityService.popToast('success','Success', 1000 , 'white market updated successfully.');
          }, error => {

          });
      }
    }).catch(error => {
      console.error("errro in get white label");
    });
  }
  /***
  * subhash
  * 8/8/2020
  */
  enterTab1(key, event) {
    let data = {
      key: key,
      value1: event.target.value
    }
    if (event.target.value && event.target.value > 0) {
      this.fancyService.fancycodeMeter(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status == true) {
          this.fancyService.getVolumeApi().subscribe(resposne => {
            (resposne.status && resposne.status == true) ? this.fancyRateAry = resposne.data : []
          });
        }
      });
    } else {
      this.utilityService.popToast('error', 'error', 1000, 'invalid Value');
      this.fancyService.getVolumeApi().subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne =JSON.parse(resposne);
        (resposne.status && resposne.status == true) ? this.fancyRateAry = resposne.data : []
      });
    }
  }

  enterTab2(key, event) {
    let data = {
      key: key,
      value2: event.target.value
    }
    if (event.target.value && event.target.value > 0) {
      this.fancyService.fancycodeMeter(data).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response =JSON.parse(response);
        if (response.status == true) {
          this.fancyService.getVolumeApi().subscribe(resposne => {
            (resposne.status && resposne.status == true) ? this.fancyRateAry = resposne.data : []
          });
        }
      });
    } else {
      this.utilityService.popToast('error', 'error', 1000, 'invalid Value');
      this.fancyService.getVolumeApi().subscribe(resposne => {
        resposne = this.utilityService.gsk(resposne.auth);
        resposne =JSON.parse(resposne);
        (resposne.status && resposne.status == true) ? this.fancyRateAry = resposne.data : []
      });
    }
  }

  timerStop(){
    this.revCounter = 1;
    this.ballStatus = "Ball Start";
    var obj = {
      fancy_id: this.fancyId,
      status: "ballstart",
      type: "fancy"
    }
    this.noFirst = this.noFirstVol = this.yesFirst = this.yesFirstVol = this.noSecond = this.noSecondVol = this.yesSecond = this.yesSecondVol = this.noThird = this.noThirdVol = this.yesThird = this.yesThirdVol = "";
    this.socketService.changeStatus(obj);

    let statusValue = this.utilityService.marketStatusArray.filter(obj => obj.name === "ballstart");
    let apiObj = {
      fancy_id: this.paramId,
      fancyStatus: statusValue
    }
    this.fancyService.updateFancyStatus(apiObj).subscribe(resposne => {
    });
  }

  fancyIdDataUpdate(fancyData){
    this.marketService.updateMarket(fancyData).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if (response.status == true) {
        this.fancyDetail = response.data
      }
    });
  }
  closeModel(){
    this.conformationModal.hide();
    this.tempVar = false;
  }
  enterGo(){
    this.conformationModal.hide();
    this.tempVar = true;
    this.rateCalculator(this.lastInput);
  }
}
