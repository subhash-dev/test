import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FancyViewComponent } from './fancy-view.component';

describe('FancyViewComponent', () => {
  let component: FancyViewComponent;
  let fixture: ComponentFixture<FancyViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FancyViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FancyViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
