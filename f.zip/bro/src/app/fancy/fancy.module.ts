import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {FancyRoutingModule} from './fancy-routing.module';
import {FancyComponent} from './fancy.component';
import {FancyViewComponent} from './fancy-view/fancy-view.component';
import {FormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {DemoMaterialModule} from '../../material-module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {HttpClientModule} from '@angular/common/http';
import {commonDerectivenModule} from '../auth-gaurd/commonDerective.module';
import {ModalModule} from 'ngx-bootstrap';

@NgModule({
    declarations: [FancyComponent, FancyViewComponent],
    imports: [
        CommonModule,
        FancyRoutingModule,
        BrowserModule,
        BrowserAnimationsModule,
        DemoMaterialModule,
        commonDerectivenModule,
        FormsModule,
      ModalModule.forRoot(),
        HttpClientModule,
    ]
})
export class FancyModule {
}
