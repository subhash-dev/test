import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fancy',
  templateUrl: './fancy.component.html',
  styleUrls: ['./fancy.component.scss']
})
export class FancyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
