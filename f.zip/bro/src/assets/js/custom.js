
$(document).on('click', '.dropdown-toggle', function() {
    $('#sidebar li ul').removeClass('show');
    $(this).addClass('show');

  });
  $(document).on('click', '#sidebar li a', function() {
    $('a[aria-expanded]').attr('aria-expanded', 'false');
    $(this).parent().addClass('active').siblings().removeClass('active');

  });

  $(document).on('click', '#sidebarCollapse' , function () {
    $('#sidebar').toggleClass('active');
    $('#content').toggleClass('active');
    $('a[aria-expanded=true]').attr('aria-expanded', 'false');
  });

  $(document).on('click', '#sidebarCollapse1' , function () {
    $('#sidebar').toggleClass('active');
    $('#content').toggleClass('active');
    $('a[aria-expanded=true]').attr('aria-expanded', 'false');
  });
  // $("#sidebar").mCustomScrollbar({
  //   theme: "minimal"
  // });
  $(".runner_suspend").addClass("radio_1");
  $(document).on('keydown', function(event) {
    if (event.key == "Escape") {
      $(".ball_running").addClass("ballRunning");
      $(".ball-running-btn").addClass("active");
      $(".active-btn").removeClass("active");
      $(".suspend-btn").removeClass("active");
      $(".both-btn").removeClass("active");
      $(".ball_running").removeClass("suspend");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").removeClass("radio_2");
    }
});
  $(document).on('keydown', function(event) {
    if(event.key == "Enter"){
      $(".active-btn").addClass("active");
      $(".ball-running-btn").removeClass("active");
      $(".ball_running").removeClass("ballRunning");
      $(".suspend-btn").removeClass("active");
      $(".ball_running").removeClass("suspend");
      $(".both-btn").removeClass("active");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_2");
      $(".runner_suspend").removeClass("radio_0");
    }
  });


  $(document).on('click', '.rate-change-click' , function () {
      $(".active-btn").addClass("active");
      $(".ball-running-btn").removeClass("active");
      $(".ball_running").removeClass("ballRunning");
      $(".suspend-btn").removeClass("active");
      $(".ball_running").removeClass("suspend");
      $(".both-btn").removeClass("active");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").removeClass("radio_2");
  });


    $(document).on('click', '.ball-running-btn' , function () {
      $(".ball_running").addClass("ballRunning");
    });

    $(document).on('click', '.ball-running-btn' , function () {
      $(".ball-running-btn").addClass("active");
      $(".active-btn").removeClass("active");
      $(".suspend-btn").removeClass("active");
      $(".both-btn").removeClass("active");
      $(".ball_running").removeClass("suspend");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").removeClass("radio_2");
    });
    $(document).on('click', '.active-btn' , function () {
      $(".active-btn").addClass("active");
      $(".ball-running-btn").removeClass("active");
      $(".ball_running").removeClass("ballRunning");
      $(".suspend-btn").removeClass("active");
      $(".ball_running").removeClass("suspend");
      $(".both-btn").removeClass("active");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_2");
      $(".runner_suspend").removeClass("radio_0");
    });
    $(document).on('click', '.suspend-btn' , function () {
      $(".ball_running").addClass("suspend");
      $(".suspend-btn").addClass("active");
      $(".ball-running-btn").removeClass("active");
      $(".ball_running").removeClass("ballRunning");
      $(".active-btn").removeClass("active");
      $(".both-btn").removeClass("active");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").removeClass("radio_2");
    });
    $(document).on('click', '.both-btn' , function () {
      $(".both-btn").addClass("active");
      $(".ball-running-btn").removeClass("active");
      $(".ball_running").removeClass("ballRunning");
      $(".ball_running").removeClass("suspend");
      $(".active-btn").removeClass("active");
      $(".suspend-btn").removeClass("active");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").removeClass("radio_2");
      $( ".radioCheck" ).prop( "checked", false );
    });
    $(document).on('click', '.main-back-btn' , function () {
      $(".main-back-btn").toggleClass("active");
      $(".ball-running-btn").removeClass("active");
      $(".ball_running").removeClass("ballRunning");
      $(".ball_running").removeClass("suspend");
      $(".ball_running").removeClass("back");
      $(".ball_running").addClass("lay");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").removeClass("radio_2");
      
    });
    $(document).on('click', '.main-lay-btn' , function () {
      $(".ball-running").removeClass("active");
      $(".main-lay-btn").toggleClass("active");
      $(".ball_running").removeClass("ballRunning");
      $(".ball_running").removeClass("suspend");
      $(".ball_running").addClass("back");
      $(".ball_running").removeClass("lay");
      $(".runner_suspend").removeClass("radio_1");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").removeClass("radio_2");
    });
    $(document).on('click', '.main-back-btn , .main-lay-btn' , function () {
    $(".ball-running-btn").removeClass("active");
  });
    $(document).on('click', '.toggle-password' , function () {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
      input.attr("type", "text");
    } else {
      input.attr("type", "password");
    }
  });
    $(document).on('click', '.search-option-btn' , function () {
    $(".create-and-edit-form").toggleClass("search-option");
  });
//
// $(document).on('click' ,  '.sport_focus' , function(){
//   $('#password3').attr('autoFocus')
// });

  $(document).on('click', '.radioCheck' , function () {
    if (this.id == 'radio_0') {
      $(".runner_suspend").addClass("radio_0");
      $(".runner_suspend").removeClass("radio_1");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
    }
    if (this.id == 'radio_1') {
      $(".runner_suspend").addClass("radio_1");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").addClass("radio_2");
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
    }
    if (this.id == 'radio_2') {
      $(".ball_running").removeClass("lay");
      $(".ball_running").removeClass("back");
      $(".runner_suspend").addClass("radio_2");
      $(".runner_suspend").removeClass("radio_0");
      $(".runner_suspend").removeClass("radio_1");
    }
  });


