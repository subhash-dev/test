#sidebar > eventMaster > fancy Component > fancy Id static

#note : please add module on live server with this name
because we use this in some logic

module Name :

> USERSETTING
> GAMESETTING
> REOPENGAME
> OPENGAME
> LIVETV
> COMMENTARY
> EVENTLIST
> DASHBOARD
> IMPORT
> ROLE
> USER
> BOOKMAKER
> FANCY
> MARKET
> MATCHES
> TOURNAMENTS
> SPORT
> WHITELABELSETTING
> CURRANCYMASTER

-- if you are add any new column in role management than update count in
  select all function write now count is 13
