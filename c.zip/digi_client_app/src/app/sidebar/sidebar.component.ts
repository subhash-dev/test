import {Component, HostListener, OnInit, ViewChild} from '@angular/core';
import {MarketService} from "../services/market.service";
import {SocketService} from "../globals/socketService";
import {Router} from "@angular/router";
import {NgxSpinnerService} from "ngx-spinner";
import {ModalDirective} from 'ngx-bootstrap';
import {UserIdleService} from 'angular-user-idle';
import {UtilityService} from '../globals/utilityService';
import {SocketServiceClient} from '../globals/socketServiceClient';
import {UserService} from "../services/user.service";
import { CommonService } from "../services/common.service";
declare let _: any;

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  @ViewChild('childModal', { static: false }) childModal: ModalDirective;
  marketFilter = {
    page: 1,
    limit: 10,
    search: null,
    userId : this.utilityService.returnLocalStorageData('userId')
  };
  getAllMarkets :any;
  counter: any;
  stockMarket: any;
  getAll = [];
  constructor(
    private marketService: MarketService ,
    private utilityService: UtilityService ,
    private userIdle: UserIdleService ,
    private  socketService: SocketService,
    private  socketServiceClient: SocketServiceClient ,
    private  spinner: NgxSpinnerService ,
    private commonService: CommonService,
    private router: Router,
    private userService: UserService,
  ) { }

  ngOnInit() {
    this.getMarketOdds();
    this.getLayoutSetting();
    this.socketService
      .changeFlag()
      .subscribe((response) => {
          if(response){
            setTimeout(res =>{
              this.getMarketOdds();
            },2000)
          }
      });

    this.socketServiceClient
      .marketCreate()
      .subscribe((response) => {
          if(response){
           this.getMarketOdds();
          }
      });

    this.socketServiceClient
      .updateSport()
      .subscribe((response) => {
        if(response){
          this.getMarketOdds();
        }
      });

    this.socketServiceClient
      .updateTournament()
      .subscribe((response) => {
        if(response){
          this.getMarketOdds();
        }
      });

    this.socketServiceClient
      .updateMatch()
      .subscribe((response) => {
        if(response){
          this.getMarketOdds();
        }
      });

    this.userIdle.startWatching();

    // Start watching when user idle is starting.
    this.userIdle.onTimerStart().subscribe(count => {
        this.counter = count;
        // this.childModal.show();
      }
    );

    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() =>{
      this.utilityService.userLogout();
      localStorage.clear();
      sessionStorage.clear();
      this.router.navigate(['']);
      setTimeout(function(){ window.location.reload(); }, 3000);
      this.childModal.hide();
    });

    // document.addEventListener("visibilitychange", function() {
    //   if(document.hidden){
    //     setTimeout(function(){
    //       // this.utilityService.userLogout();
    //       localStorage.clear();
    //       sessionStorage.clear();
    //       window.location.reload();
    //       }, 300000);
    //   }else{
    //
    //   }
    // }, false);
  }

  /**
   * @author TR
   * @date : 26-02-2020
   * get all market
   */
  getMarketOdds() {
    this.marketService.getAllMarketForSidebar(this.marketFilter).subscribe(response => {

      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if(response){
      this.getAllMarkets = response.data;
      }
     // console.log(this.getAllMarkets);
      // this.getAllMarkets.data = this.getAllMarkets.data.map(data =>{
      //   data.doc = _.unique(data.doc, function (datas) {
      //       return datas.match.id;
      //     });
      //   return data;
      // })
    });
  }

  hideChildModal() {
    this.userIdle.resetTimer();
    // this.childModal.hide();
  }


  stay() {
    this.userIdle.resetTimer();
    // this.childModal.hide();
  }

  getLayoutSetting(){
    this.marketService.getLayoutSetting().subscribe(response => {
      if (response.status) {
        this.stockMarket = response.data.stockMarket;
      } else {
        // this.commonService.popToast('error','Error', 3000 , 'not found market rules.');
      }
    }, error => {
      this.commonService.popToast('error', 'Error', 3000, 'not found.');
    });
  }



}
