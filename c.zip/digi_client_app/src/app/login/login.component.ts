'use strict';
import {SocketService} from "../globals/socketService";

declare var require: any;
import { Component, OnInit,ViewChild } from '@angular/core';
import {Route, Router} from '@angular/router';
import * as env from '../globals/env';
import { CommonService } from '../services/common.service';
import { UserService } from '../services/user.service';
import {SocketServiceClient} from "../globals/socketServiceClient";
var aes256 = require('aes256');
import { UtilityService } from '../globals/utilityService';
import {environment} from '../../environments/environment';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  currentApplicationVersion = environment.appVersion;
  @ViewChild("loginForm", { static: false }) loginForm;
  logo: any = env.PROJECT_LOGO_URL;
  loginResponse: any;
  loginObject = {
    userName: null,
    password: null,
    deviceId : "",
    fcmToken : "",
    channel : "WEB",
    userType : "CLIENT"
  };
  showPassword = false;
  Toast = {
    type: '',
    title: '',
    timeout: 0,
    body: ''
  };
  endSubmit = false;
  constructor( private router: Router,
    private commonService: CommonService,
    private socketService: SocketService,
    private socketServiceClient: SocketServiceClient,
    private utilityService: UtilityService ,
    private userService:UserService
    ) { }

  ngOnInit() {
    localStorage.clear();
    this.socketService.disconnect()
    this.socketServiceClient.disconnect()
    let data = JSON.parse(this.utilityService.returnLocalStorageData('userData'));
    if (!this.utilityService.returnLocalStorageData('userId')) {
    } else {
      if(data && data.userType === 'CLIENT'){
        localStorage.clear();
         // this.router.navigate(['/dashboard']);
      }
    }
  }
/*
  Developer: Ravi
  Date: 09-jan-2020
  title: Login method from backend
  Use: This function is use login from backend
*/

login() {
  if(this.endSubmit) {
    return;
}
this.endSubmit = true;
   let key = env.constantKey();
  this.userService.loginApi(this.loginObject).subscribe(resposne =>{
    this.endSubmit = false;
    resposne = this.utilityService.gsk(resposne.auth);
    resposne = JSON.parse(resposne);
    if(resposne.status === true){
      sessionStorage.setItem('balance', 'true');
      sessionStorage.setItem('available', 'true');
      sessionStorage.setItem('exposure', 'true');
      sessionStorage.setItem('pl', 'true');
      //this.showToster('Success','success', resposne.message);

      var descryptJson = aes256.decrypt(key, resposne.data);
      let resposne1 = JSON.parse(descryptJson);
      let userData = JSON.stringify(resposne1);
      let userId = resposne1.user_id;
      let ip = resposne1.ipAddress;
      let dateTime = resposne1.dateTime;
      var userData1 = aes256.encrypt(key, userData);
      var userId1 = aes256.encrypt(key, userId);
      var ip1 = aes256.encrypt(key, ip);
      var dateTime1 = aes256.encrypt(key, dateTime);
      localStorage.setItem('userData', userData1);
      localStorage.setItem('userId', userId1);
      localStorage.setItem('token', resposne.token);
      localStorage.setItem('ip', ip1);
      localStorage.setItem('dateTime', dateTime1);
      sessionStorage.setItem('userId', userId1);
      sessionStorage.setItem('token', resposne.token);

      if(resposne1.changePassword === true){
        this.router.navigate(['/dashboard']);
      }else{
        this.router.navigate(['/new-user']);
      }
    }else{
      this.loginObject.password = '';
      this.showToster('Error','error', resposne.message);
    }
  }, error =>{
    console.log(error)
    let input = document.getElementById('userName');
    input.focus();
    this.loginObject.password = '';
    this.loginForm.resetForm();
    this.showToster('Error','error', error.error.message);
  });
}



/*
    Developer: Ravi
    Date: 05-mar-2020
    title: Toster message
    Use: This function is use to throgh toster message
  */

 showToster(title,type,message){
  this.Toast.title = title;
  this.Toast.type = type;
  this.Toast.body = message;
  this.commonService.popToast('error','Error', 3000 , message);
}

  showPass(){
    this.showPassword = (this.showPassword === true) ?  false : true;
  }

}
