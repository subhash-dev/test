import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import * as env from '../globals/env';


@Injectable({
  providedIn: 'root'
})
export class LockGameService {
  server_url: any = env.adminServer_url();

  constructor(private http: HttpClient,) {
  }

  /**
   *@author kc
   * @date 17-03-2020
   * @param filter
   * @returns {Observable<any>}
   *add chips successfully
   */

  addMasterLockGame(data): Observable<any> {
    return this.http.post(this.server_url + 'lockmatch', data)
      .pipe(tap(_ => this.log(`add masters successfully`)));
  }

  /**
   *@author kc
   * @date 17-03-2020
   * @param filter
   * @returns {Observable<any>}
   *find one by login user
   */

  findRecordExist(data): Observable<any> {
    //console.log(data)
    return this.http.post(this.server_url + 'lockmatch/find', data)
      .pipe(tap(_ => this.log(`update masters  successfully`)));
  }
  /**
   *@author kc
   * @date 17-03-2020
   * @param filter
   * @returns {Observable<any>}
   *add chips successfully
   */

  updateStatus(data): Observable<any> {
    return this.http.put(this.server_url + 'lockmatch/update', data)
      .pipe(tap(_ => this.log(`update masters  successfully`)));
  }

  /**
   *@author kc
   * @date 17-03-2020
   * @param filter
   * @returns {Observable<any>}
   *add chips successfully
   */

  deleteLockGame(data): Observable<any> {
    return this.http.post(this.server_url + 'lockmatch/delete', data)
      .pipe(tap(_ => this.log(`update masters  successfully`)));
  }


  /***
   * @author kc
   * @date 01-04-2020
   * @param data
   * @returns {Observable<any>}
   * Game status update
   */
  updateAllowBetStatus(data): Observable<any> {
    return this.http.put(this.server_url + 'lockmatch/betlock', data)
      .pipe(tap(_ => this.log(`Bet Lock update successfully`)));
  }



  log(message) {
    console.log(message);
  }


}
