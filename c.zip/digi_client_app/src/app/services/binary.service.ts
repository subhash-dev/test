import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';
import {ToasterService} from "angular2-toaster";
import {UtilityService} from '../globals/utilityService';

@Injectable({
  providedIn: 'root'
})
export class BinaryService {
  private headers = new HttpHeaders({'Authorization' : 'Bearer ' + this.utilityService.returnLocalStorageData('token')});
  private toasterService: ToasterService;

  server_url: any = env.adminServer_url();
  constructor(private http: HttpClient, private utilityService:UtilityService
              ) { }


    /**
     *@author TR
     * @date 18-05-2020
     * @param filter
     * @returns {Observable<any>}
     * get all Exchange
     */
    getAllExcahnge(): Observable<any> {
        return this.http.get(this.server_url + 'sharemarket/getexchange')
            .pipe(tap(_ => this.log(`Get instrument successfully`)));
    }


  /**
   *@author TR
   * @date 26-05-2020
   * @param filter
   * @returns {Observable<any>}
   * add portfolio
   */
  addDefault(filter): Observable<any> {
    return this.http.post(this.server_url + 'sharemarket/portfoio/create' , filter)
      .pipe(tap(_ => this.log(`create portfolio successfully`)));
  }

  /**
   *@author TR
   * @date 26-05-2020
   * @param filter
   * @returns {Observable<any>}
   * add portfolio
   */
  removeDefault(filter): Observable<any> {
    return this.http.post(this.server_url + 'sharemarket/portfoio/deleteall' , filter)
      .pipe(tap(_ => this.log(`delete portfolio successfully`)));
  }

  /**
   *@author TR
   * @date 26-05-2020
   * @param filter
   * @returns {Observable<any>}
   * get all intrument for portfolio
   */
  getAllInstDefault(item): Observable<any> {
    return this.http.get(this.server_url + 'sharemarket/getinstruments/'+item)
      .pipe(tap(_ => this.log(`Get instrument successfully`)));
  }

  /**
   *@author TR
   * @date 20-07-2020
   * @param filter
   * @returns {Observable<any>}
   * placebet market
   */
  placeBet(item): Observable<any> {
    return this.http.post(this.server_url + 'sharemarket/placeorder', item)
      .pipe(tap(_ => this.log(`place order successfully`)));
  }

  /**
   *@author TR
   * @date 27-07-2020
   * @param filter
   * @returns {Observable<any>}
   * Get all Transaction History
   */
  getAllTransaction(data): Observable<any> {
    return this.http.post(this.server_url + 'sharemarket/get/clientorder', data)
      .pipe(tap(_ => this.log(`place order successfully`)));
  }

  /**
   *@author TR
   * @date 04-08-2020
   * @param filter
   * @returns {Observable<any>}
   * Get all Open History
   */
  getAllOpenPosition(data): Observable<any> {
    return this.http.post(this.server_url + 'sharemarket/get/clientOpenPosition', data)
      .pipe(tap(_ => this.log(`Get net position successfully`)));
  }

  /**
   *@author TR
   * @date 04-08-2020
   * @param filter
   * @returns {Observable<any>}
   * Get all Open History
   */
  getAllBalance(data): Observable<any> {
    return this.http.post(this.server_url + 'sharemarket/userShareMarketBalanceSetting', data)
      .pipe(tap(_ => this.log(`Get balance successfully`)));
  }

  /**
   *@author TR
   * @date 04-08-2020
   * @param filter
   * @returns {Observable<any>}
   * Get all Open History
   */
  getAllDeals(data): Observable<any> {
    return this.http.post(this.server_url + 'sharemarket/get/dealHistory', data)
      .pipe(tap(_ => this.log(`Get Deals successfully`)));
  }

  /**
   *@author TR
   * @date 04-08-2020
   * @param filter
   * @returns {Observable<any>}
   * delete pending order
   */
  deletePendingOrder(data): Observable<any> {
    return this.http.post(this.server_url + 'sharemarket/delete/pendingClientOrder', data)
      .pipe(tap(_ => this.log(`Delete order successfully`)));
  }
  log(message) {
    // console.log(message);
  }
}
