import { TestBed } from '@angular/core/testing';

import { PlacebetService } from './placebet.service';

describe('PlacebetService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlacebetService = TestBed.get(PlacebetService);
    expect(service).toBeTruthy();
  });
});
