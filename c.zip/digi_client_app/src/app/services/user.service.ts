import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient,HttpHeaders} from '@angular/common/http';

import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  server_url: any = env.adminServer_url();
  office_url: any = env.office_url();


  constructor(private http: HttpClient) { }

    /**
   *@author Ravi Kadia
   * @date 09-01-2020
   * @param filter
   * @returns {Observable<any>}
   * add new user
   */

  loginApi(data): Observable<any> {
    return this.http.post(this.server_url + 'user/login' , data)
      .pipe(tap(_ => this.log(`user login successfully`)));
  }

  newUser(data):Observable<any>{
    console.log("data",this.server_url + 'user/new-user/change/password',data);

    return this.http.post(this.server_url + 'user/new-user/change/password',data)
      .pipe(tap(_ => this.log(`new-user changepassword`)));
  }

      /**
   *@author Ravi Kadia
   * @date 09-01-2020
   * @param filter
   * @returns {Observable<any>}
   * get balance
   */

  getBalance(data): Observable<any> {
    let headers = new HttpHeaders({'Method-Name': "balance"});
    return this.http.post(this.server_url + 'user/getBalance/',data,{headers : headers})
      .pipe(tap(_ => this.log(`get balance`)));

  }

  /**
   * @author TR
   * @date : 28/04
   * user logout function
   */


  logOut() :Observable<any>{
    return this.http.get(this.server_url + 'user/logout')
      .pipe(tap(_ => this.log(` user logout successfully`)));
  }

  /**
   * @author TR
   * @date : 24/06
   * user password change
   */


  passwordChange(data) :Observable<any>{
    delete data.confNewPassword;
    return this.http.put(this.server_url + 'user/resetClientPassword/' + data.userId, data)
      .pipe(tap(_ => this.log(` user password update successfully`)));
  }




  /**
   *@author TR
   * @date 01-07-2020
   * @param filter
   * @returns {Observable<any>}
   * get account summary report
   */

  getAllTransactionByGame(filter): Observable<any> {
    filter.userType = 'CLIENT';
    console.log("filter",filter);
    return this.http.post(this.server_url + 'placebet/get-all-transactions/betlist' , filter)
      .pipe(tap(_ => this.log(`User transaction successfully`)));
  }

  /**
   *@author TR
   * @date 16-07-2020
   * @param filter
   * @returns {Observable<any>}
   * get account summary report
   */

  getAllTransaction(filter): Observable<any> {

    return this.http.post(this.server_url + 'placebet/get-all-transactions-sport' , filter)
      .pipe(tap(_ => this.log(`User transaction successfully`)));
  }

  getBalanceUpdated(id): Observable<any> {
    return this.http.get(this.server_url + 'user/getBalance-update/' + id)
      .pipe(tap(_ => this.log(`User transaction successfully`)));
  }

  getUserById(id): Observable<any> {
    return this.http.get(this.server_url + 'user/getUserData/' + id)
      .pipe(tap(_ => this.log(`User transaction successfully`)));
  }

  storeStudioData(id,token): Observable<any> {
    return this.http.get(this.server_url + 'user/store-user-data/' + id + "/" + token)
      .pipe(tap(_ => this.log(`User transaction successfully`)));
  }

  /**
   //subhash
   */

  getOpeningBalance(filter): Observable<any> {
    return this.http.post(this.server_url + 'chipscash/opening-balace' , filter)
      .pipe(tap(_ => this.log(`get User Opening Balace`)));
  }

  welcomeMassage(): Observable<any> {
    return this.http.get(this.server_url + 'white-lable-welcome-massage')
      .pipe(tap(_ => this.log(`White Lable Welcome Massage`)));
  }

  log(message) {
    console.log(message);
  }
}
