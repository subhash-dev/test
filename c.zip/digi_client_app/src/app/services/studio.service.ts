import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/index';
import {HttpClient} from '@angular/common/http';
import {tap} from 'rxjs/internal/operators';
import {isUndefined} from 'util';
import * as env from '../globals/env';


@Injectable({
  providedIn: 'root'
})
export class StudioService {

  server_url: any = env.adminServer_url();
  office_url: any = env.office_url();
  studio_url: any = env.studio_url();
  
  
  
  constructor(private http: HttpClient) { }

  /**
   *@author Ravi Kadia
  * @date 06-03-2020
  * @param filter
  * @returns {Observable<any>}
  * Add place bet 
**/

  storeUserData(data): Observable<any> {
    return this.http.post(this.studio_url + '/auth/store-user-data', data)
      .pipe(tap(_ => this.log(`get all market successfully`)));
  }


  log(message) {
    console.log(message);
  }
}
