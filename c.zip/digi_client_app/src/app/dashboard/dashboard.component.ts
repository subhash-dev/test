import {Component, OnInit, ViewChild} from '@angular/core';
import {MarketService} from "../services/market.service";
import {SocketService} from "../globals/socketService";

import {NgxSpinnerService} from "ngx-spinner";
import {UtilityService} from '../globals/utilityService';
import {SocketServiceClient} from '../globals/socketServiceClient';
import {SocketServiceRedis} from '../globals/socketServiceRedis';
import { CommonService } from '../services/common.service';
// declare let _: any;
import _ from "lodash";
import * as $ from "jquery";
import {Router} from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  constructor(private marketService: MarketService, private router: Router,private commonService: CommonService, private utilityService: UtilityService , private spinner: NgxSpinnerService, private socketService: SocketService, private socketServiceRedis: SocketServiceRedis, private socketServiceClient: SocketServiceClient) {
  }

  marketFilter = {
    page: 1,
    limit: 10,
    search: null,
    data: null
  };
  contentHide = false;
  getAllMarkets = [];
  getAllMarket = [];
  getAllSports = [];
  selectedUniqIndx: any;
  marketID: any;
  marketMulID = [];
  marketApi: any;
  runners: any;
  runnersData = [];
  marketSel = [];
  Toast = {
    type: '',
    title: '',
    timeout: 0,
    body: ''
  };

  ngOnInit() {
    setRandomColor();
    const query = window.matchMedia("(max-width: 1023px)");
    if(query.matches){
      this.selectedUniqIndx = 10;
      this.getAllSportsData(10);
    }else {
      this.getAllSportsData('');
    }



    this.socketService
      .changeFlag()
      .subscribe((response) => {
        if(response){
            this.getAllSportsData('');
        }
      });

    this.socketServiceClient
      .marketCreate()
      .subscribe((response) => {
        if(response){
          this.getAllSportsData('');
        }
      });

    this.socketServiceClient
      .updateSport()
      .subscribe((response) => {
        if(response){
          this.getAllSportsData('');
        }
      });

    this.socketServiceClient
      .updateTournament()
      .subscribe((response) => {
        if(response){
          this.getAllSportsData('');
        }
      });

    this.socketServiceClient
      .updateMatch()
      .subscribe((response) => {
        if(response){
          this.getAllSportsData('');
        }
      });

      this.socketServiceRedis
      .oddsRate()
      .subscribe((response) => {
        if (response) {
          if (response.status == 'OPEN') {
            const linerMarId = response.marketId;
            let marketId = response.marketId.toString().replace('.', '');
              let runtypes = response.runners;
              let runners = 0;
              if (response.numberOfActiveRunners) {
                runners = response.numberOfActiveRunners;
              } else {
                runners = response.runners.length;
              }

              $("#" + marketId + "_back_1_odds").html((runtypes[0].ex.availableToBack[0]) ? runtypes[0].ex.availableToBack[0].price : '-');
              $("#" + marketId + "_lay_1_odds").html((runtypes[0].ex.availableToLay[0]) ? runtypes[0].ex.availableToLay[0].price : '-');
              if (runners == 3) {
                $("#" + marketId + "_back_3_odds").html((runtypes[1].ex.availableToBack[0]) ? runtypes[1].ex.availableToBack[0].price : '-');
                $("#" + marketId + "_lay_3_odds").html((runtypes[1].ex.availableToLay[0]) ? runtypes[1].ex.availableToLay[0].price : '-');
                $("#" + marketId + "_back_2_odds").html((runtypes[2].ex.availableToBack[0]) ? runtypes[2].ex.availableToBack[0].price : '-');
                $("#" + marketId + "_lay_2_odds").html((runtypes[2].ex.availableToLay[0]) ? runtypes[2].ex.availableToLay[0].price : '-');
              } else {
                if (runtypes[1] && runtypes[1].ex) {
                  $("#" + marketId + "_back_3_odds").html((runtypes[1].ex.availableToBack[0]) ? runtypes[1].ex.availableToBack[0].price : '-');
                  $("#" + marketId + "_lay_3_odds").html((runtypes[1].ex.availableToLay[0]) ? runtypes[1].ex.availableToLay[0].price : '-');
                }
              }
          }
        }
      });
  }


  getMarketOdds(data, index) {
    $('#inplay').removeClass('active');
    this.getAllMarkets = [1];
    this.contentHide = false;
    this.selectedUniqIndx = index;
    this.marketFilter.data = data;
    let userId = this.utilityService.returnLocalStorageData('userId');
    this.marketService.getAllMarketForDashboard(this.marketFilter, userId).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.getAllMarkets = response.data;
      console.log(this.getAllMarkets)
      this.getAllMarkets.map(marketLoop =>{
        marketLoop.doc = marketLoop.doc.map(firstLoop =>{
          firstLoop.data.map(secondLoop =>{
            if(secondLoop.marketId && secondLoop.marketId.length > 0) {
              secondLoop.marketIdDec = secondLoop.marketId[0].toString().replace('.', '');
              this.socketServiceRedis.joinRoom(secondLoop.marketId[0]);
            }
          });
          return firstLoop;
        });
        return marketLoop;
      });
    });
    this.contentHide = true;
      this.spinner.hide();
  }



  getAllSportsData(ite) {
    this.marketService.getAllSport().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if(response) {
        this.getAllSports = response.data;
        if (this.getAllSports.length > 0 && ite !== 10) {
          let index = this.selectedUniqIndx ? this.selectedUniqIndx : 0;
          this.getMarketOdds(this.getAllSports[index].id, index);
        } else {
          this.getAllMatchData();
        }
      }
    });
  }


  getAllMatchData() {
    this.contentHide = true;
    $('#mytab a').removeClass('active');
    $('#inplay').addClass('active');
    this.marketService.getAllMatchInMarket().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.getAllMarkets = response.data;
      this.getAllMarkets.map(marketLoop =>{
        marketLoop.doc = marketLoop.doc.map(firstLoop =>{
          firstLoop.data.map(secondLoop =>{
            if(secondLoop.marketId && secondLoop.marketId.length > 0){
            secondLoop.marketIdDec = secondLoop.marketId[0].toString().replace('.', '');
                this.socketServiceRedis.joinRoom(secondLoop.marketId[0]);
            }
          });
          return firstLoop;
        });
        return marketLoop;
      });
    });
  }

  commingSoon(){
    this.showToster('Error','error', "Comming Soon");
  }


  showToster(title,type,message){
    this.Toast.title = title;
    this.Toast.type = type;
    this.Toast.body = message;
    this.commonService.popToast('success','Success', 3000 , message);
  }

}

function getRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}





function setRandomColor() {
  $(".title-hd").css("background-color", getRandomColor());
}
