import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SportsModule } from './sports/sports.module';
import {SocketService} from './globals/socketService';
import { SocketServiceClient } from './globals/socketServiceClient';
import { SocketServiceBbMarket } from './globals/socketServiceBbMarket';
import { FancyService } from './services/fancy.service';
import { PlacebetService } from './services/placebet.service';
import { FormsModule }   from '@angular/forms';
import { NgxSpinnerModule } from "ngx-spinner";
import { NgxSpinnerService } from "ngx-spinner";
import {ToasterModule} from 'angular2-toaster';
import { ReportsModule } from './reports/reports.module';
import {commonDerectivenModule} from "./auth-gaurd/commonDerective.module";
import {AuthGuard} from "./auth-gaurd/auth-guard.service";
import {DefaultRequestOptions} from "./auth-gaurd/default-request-options.provider";
import {ModalModule} from 'ngx-bootstrap';
import {UtilityService} from "./globals/utilityService";
import { UserIdleModule } from 'angular-user-idle';
import {SocketServiceRedis} from './globals/socketServiceRedis';
import { StudioService } from './services/studio.service';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { NewUserComponent } from './new-user/new-user.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    SidebarComponent,
    NewUserComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ToasterModule.forRoot(),
    SportsModule,
    ReportsModule,
    ModalModule.forRoot(),
    NgxSpinnerModule,
    commonDerectivenModule,
    UserIdleModule.forRoot({idle: 3600, timeout: 10, ping: 10}),
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],

  providers: [SocketService,
    SocketServiceClient,
    SocketServiceBbMarket,
    SocketServiceRedis,
    FancyService,
    PlacebetService,
    StudioService,
    NgxSpinnerService,
    UtilityService,
    AuthGuard ,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: DefaultRequestOptions,
      multi: true
    },
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule { }
