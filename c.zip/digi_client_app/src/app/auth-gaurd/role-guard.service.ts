import { Injectable } from '@angular/core';
import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, Route, ActivatedRoute} from '@angular/router';
import { Observable } from 'rxjs';
import {AuthService} from './auth.service';
import {UtilityService} from '../globals/utilityService';

@Injectable()
export class RoleGuard implements CanActivate {


  constructor(private _authService: AuthService,
              private _router: Router,
              private utilityService: UtilityService,
              private route: ActivatedRoute,
  ) {
  }


  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this._authService.isAuthenticated()) {

      // let userType = JSON.parse(this.utilityService.returnLocalStorageData('userData'));
      // let currentRoute = state.url;
      // let componentName = (next.routeConfig.path);
      //
       //console.log("userType=====",userType)
      //console.log("currentRoute=====",currentRoute)
      //console.log("componentName=====",componentName)


      // let checkRolePermission = userType.map(data =>{
      //   if(('/' + (data.moduleName.toLowerCase() + '/view')) === currentRoute ){
      //         if(data.viewAccess === false){
      //           this._router.navigate(['/403']);
      //         }
      //   }else if(('/' + (data.moduleName.toLowerCase() + '/new')) === currentRoute ){
      //     if(data.createAccess === false){
      //       this._router.navigate(['/403']);
      //     }
      //   }else if(('/' + (data.moduleName.toLowerCase() + '/update')) === currentRoute){
      //     if(data.updateAccess === false){
      //       this._router.navigate(['/403']);
      //     }
      //   }else if(('/' + (data.moduleName.toLowerCase() + '/details')) === currentRoute){
      //     if(data.viewAccess === false){
      //       this._router.navigate(['/403']);
      //     }
      //   }else{
      //     return true;
      //   }
      // });
      // return true;
    }


    // navigate to login page
    this._router.navigate(['/login']);
    // you can save redirect url so after authing we can move them back to the page they requested
    return false;
  }
}
