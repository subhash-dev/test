// Modules
import {NgModule} from '@angular/core';
import {OnlynumberDirective} from './onlyNumber';
import {EllipsisPipe} from './ellipsis.pipe';
import {DisableRightClickDirective} from './right -click';
import {MatchValueDirective} from './match-value.directive';
import {AutofocusDirective} from "./autofocus.directive";
import {SafePipe} from './safePipe';
import {NoCommaPipe} from './commaRemove';
@NgModule({
  declarations: [
    OnlynumberDirective,
    EllipsisPipe,
    DisableRightClickDirective,
    MatchValueDirective,
    AutofocusDirective,
    SafePipe,
    NoCommaPipe
  ],
  exports: [
    OnlynumberDirective,
    EllipsisPipe,
    DisableRightClickDirective,
    MatchValueDirective,
    AutofocusDirective,
    SafePipe,
    NoCommaPipe
  ]
})
export class commonDerectivenModule{}
