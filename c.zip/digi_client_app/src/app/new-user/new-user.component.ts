import { Component, OnInit,ViewChild } from '@angular/core';
declare var require: any;
import { Router } from '@angular/router';
import { SocketService } from '../globals/socketService';
import { SocketServiceClient } from '../globals/socketServiceClient';
import { UtilityService } from '../globals/utilityService';
import { CommonService } from '../services/common.service';
import { UserService } from '../services/user.service';
import * as env from '../globals/env';
var aes256 = require('aes256');

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss']
})
export class NewUserComponent implements OnInit {

  @ViewChild("newUserForm", { static: false }) newUserForm;
  loginResponse: any;
  newuserObject = {
    newPassword: null,
    password: null,
    userId:null
  };
  confNewPassword: any;
  oldPassword: any;
  newPassword: any;

  constructor(private router: Router,
    private commonService: CommonService,
    private socketService: SocketService,
    private socketServiceClient: SocketServiceClient,
    private userService:UserService,
    private utilityService: UtilityService
    ) { }

  ngOnInit() {
  }

  changePassword(){
    
    this.newuserObject.userId = this.utilityService.returnLocalStorageData('userId');
    let key = env.constantKey();
    this.userService.newUser(this.newuserObject).subscribe(resposne =>{
        this.utilityService.popToast('success','Success', 1000,'password update successfully');
        sessionStorage.clear();
        localStorage.clear();
        this.router.navigate(['']);
    }, error =>{
      let input = document.getElementById('password');
      input.focus();
      this.newUserForm.password = '';
      this.newUserForm.resetForm();
    });
  }


  passwordChangeNewUser(){
    let data = {
      oldPass: this.utilityService.returnEncrypt(this.oldPassword),
      newPass: this.utilityService.returnEncrypt(this.newPassword),
      cinfNewPass: this.utilityService.returnEncrypt(this.confNewPassword),
      userId: this.utilityService.returnLocalStorageData('userId')
    };
    this.userService.passwordChange(data).subscribe(response => {
      if (response.status === true) {
        localStorage.clear();
        sessionStorage.clear();
        this.router.navigate(['/login']);
      } else {
        this.commonService.popToast('error', 'Error', 1500, 'password does not match.');
      }
    }, error => {
      this.commonService.popToast('error', 'Error', 1500, 'password does not match.');
      console.error("error in logout");
    });
  }

}
