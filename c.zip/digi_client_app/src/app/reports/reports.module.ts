import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {commonDerectivenModule} from "../auth-gaurd/commonDerective.module";
import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './reports.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { ProfitLossComponent } from './profit-loss/profit-loss.component';
import {BrowserModule} from "@angular/platform-browser";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {FormsModule} from "@angular/forms";
import {ModalModule} from "ngx-bootstrap";
import {HttpClientModule} from "@angular/common/http";
import {DataTablesModule} from "angular-datatables";
import { OpenBetComponent } from './open-bet/open-bet.component';
import { NgbDateMomentParserFormatter } from '../auth-gaurd/date_format';
import { NgbModule, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [ReportsComponent, AccountStatementComponent, ProfitLossComponent, OpenBetComponent],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ModalModule.forRoot(),
    HttpClientModule,
    DataTablesModule,
    NgbModule,
    commonDerectivenModule
  ],
  providers: [
    {
      provide: NgbDateParserFormatter,
      useFactory: () => { return new NgbDateMomentParserFormatter('DD/MM/YYYY') }
    }
  ],
})
export class ReportsModule { }
