import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportsComponent } from './reports.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';
import { ProfitLossComponent } from './profit-loss/profit-loss.component';
import {AuthGuard} from "../auth-gaurd/auth-guard.service";
import {OpenBetComponent} from './open-bet/open-bet.component';



const routes: Routes = [{
  path: 'reports',
  component: ReportsComponent,
  children: [
    {
      path: 'as-view',
      canActivate: [AuthGuard],
      component: AccountStatementComponent,
    },
    {
      path: 'pl-view',
      canActivate: [AuthGuard],
      component: ProfitLossComponent,
    },
    {
      path: 'bt-view',
      canActivate: [AuthGuard],
      component: OpenBetComponent,
    },
  ]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
