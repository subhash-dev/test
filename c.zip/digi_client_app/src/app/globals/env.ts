'use strict';
import {isDevMode} from '@angular/core';


// This is url to get data from office panel JSON API
export function server_url() {
  if (isDevMode()) {
    return 'https://localhost:2021/api/v1/';
  } else {
    return 'http://localhost:2021/api/v1/';
    // return 'https://server.titanexch9.com/api/v1/';
  }
}


// This is url to get data from white label panel JSON API
export function adminServer_url() {
  if (isDevMode()) {
    return 'https://localhost:2020/api/v1/';
  } else {
    return 'http://localhost:2020/api/v1/';
    // return 'https://server.titanexch9.com/api/v1/';
  }
}

// This is socekt url to get data from office panel SOCKET
export function socket_url() {
  if (isDevMode()) {
    // return 'ws://localhost:2021';
  } else {
  //  return 'ws://173.249.31.102:2220';
    //  return 'https://socket.titanexch9.com';
    // return 'ws://35.176.244.62:2021';
    // return 'ws:localhost:2020';
  }
}

// This is socekt url to get data from office panel SOCKET
export function client_socket_url() {
  if (isDevMode()) {
    return 'ws:localhost:2020';
  } else {
    // return 'ws:localhost:2020';
   return 'ws://35.176.244.62:2020';
    //  return 'https://server.titanexch9.com';
  }
}


// This is socekt url to get data from office panel SOCKET
export function client_socket_redis() {
    return 'https://sslbhav.rdsconn.com';
}

// This is socekt url to get data from office panel SOCKET
export function studio_url() {
  if (isDevMode()) {
    return 'https://studio.premiumgames.xyz';
  } else {
    return 'https://studio.premiumgames.xyz';
  }


}



// This is url to get data from office panel JSON API
export function office_url() {
  if (isDevMode()) {
    return 'https://localhost:2021/api/v1/';
  } else {
    return 'http://localhost:2021/api/v1/';
  //  return 'https://socket.titanexch9.com/api/v1/';
  }
}

export function constantKey() {
  return 'bqwOlSSbg9VLtQuMp3mB7OAWQQwrvj6V';
}

export function socketPrefix() {
  return 'titan9-';
}


// import server ip
export function import_url() {
  return 'https://games555.ml';
}
// production
export function production() {
  return false;
}


// project config
export const PROJECT_LOGO_URL = 'assets/images/digi_logo.png';
export let EXPOSURE = 0;



