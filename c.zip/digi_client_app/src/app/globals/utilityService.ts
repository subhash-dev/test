'use strict';
declare var require: any;
import {Component, OnInit, Inject, Injectable} from '@angular/core';
import {DOCUMENT} from '@angular/common';
import {Router} from '@angular/router';
import {Location} from '@angular/common';
import {Toast, ToasterConfig, ToasterService} from 'angular2-toaster';
import { UserService } from '../services/user.service';
import { CommonService } from '../services/common.service';
import { SocketService } from './socketService';
import * as env from './env';
declare var $: any;
var aes256 = require('aes256');
@Injectable()

export class UtilityService {

  private toasterService: ToasterService;
  public config1: ToasterConfig = new ToasterConfig({
    positionClass: 'toast-bottom-right',
    limit:2
  });
  roles:any;
  constructor(@Inject(DOCUMENT) private document: any,
              private router: Router,
              toasterService : ToasterService,
              private userService :UserService,
              private commonService : CommonService,
              private socketService : SocketService,
              private location: Location) {
    this.toasterService = toasterService;
  }

  popToast(type,title ,timeout, body ) {
    const toast: Toast = {
      type: type,
      title: title,
      timeout: timeout,
      body: body
    };
    this.toasterService.pop(toast);
  }

  returnLocalStorageData(pwd){

    let data =  localStorage.getItem(pwd);
    let key = env.constantKey();
    if(data){
      let dnzepto = aes256.decrypt(key, data);
      return dnzepto;
    }else{
      return false;
    }
  }
  
  gsk(auth){
    var firstTF = auth.substring(0, 25);
    firstTF = firstTF.substr(firstTF.length - 20);
    firstTF = this.reverseString(firstTF);
    let lastTF = auth.substring(25);    
    let data = aes256.decrypt(firstTF,lastTF);
    return data;
  }

  reverseString(str){
    var splitString = str.split(""); // var splitString = "hello".split("");
    var reverseArray = splitString.reverse();
    var joinArray = reverseArray.join("");
    return joinArray;
  }

  userLogout() {
    this.userService.logOut().subscribe(response => {
      this.commonService.popToast('success', 'Success', 1500, 'Logout successfully.');
      localStorage.clear();
      let lastJoinRoom = sessionStorage.getItem("lastJoinRoom");
      if (lastJoinRoom) {
        this.socketService.leaveRoom(lastJoinRoom);
      }
      this.socketService.disconnect();
      sessionStorage.clear();
      this.router.navigate(['']);
    }, error => {
      this.commonService.popToast('error', 'Error', 1500, error.message);
      console.error("error in logout");
    });
  }
  returnSessionStorageData(pwd){
    // console.log('=================',pwd);
    let data =  sessionStorage.getItem(pwd);
    let key = env.constantKey();
    if(data){
      let dnzepto = aes256.decrypt(key, data);
      return dnzepto;
    }else{
      return false;
    }
  }

  returnEncrypt(pwd){
    let key = env.constantKey();
    if(pwd){
      let enpozito = aes256.encrypt(key, pwd);
      return enpozito;
    }else{
      return false;
    }
  }
  

  getRandomString(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }
}
