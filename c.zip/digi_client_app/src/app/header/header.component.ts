import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { CommonService } from "../services/common.service";
import { UserService } from '../services/user.service';
import {ActivatedRoute, Router} from '@angular/router';
import { SocketService } from "../globals/socketService";
declare let _: any;
import { CurrencyService } from "../services/currency.service";
import { ModalDirective } from 'ngx-bootstrap';
import { SocketServiceClient } from "../globals/socketServiceClient";
import { SocketServiceRedis } from "../globals/socketServiceRedis";
import { SocketServiceBbMarket } from "../globals/socketServiceBbMarket";



import {UtilityService} from '../globals/utilityService';
import { PlacebetService } from '../services/placebet.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @ViewChild(ModalDirective, { static: false }) currencyModal: ModalDirective;
  @ViewChild('changePassModal', { static: false }) changePassModal: ModalDirective;
  @ViewChild('exposureDetails', { static: false }) exposureDetails: ModalDirective;
  @ViewChild('newUserchangePassModal', { static: false }) newUserchangePassModal: ModalDirective;

  userBalance = 0;
  userExposer = 0;
  userPl = 0;
  userAvaBalance = 0;
  userName = 0;
  currencyAll: any;
  currencyAllMaster:any;
  confNewPassword: any;
  oldPassword: any;
  newPassword: any;
  marketRules: any;
  userData:any;
  changePassword:any;
  mycurrentRoute = '';
  masterId:any;
  massage:any = '';
  userLoginId:any;
  exposureData = [];
  balance_sec_key:any;
  public BalanceHideShow: boolean = true;
  public AvailableHideShow: boolean = true;
  public ExposureHideShow: boolean = true;
  public PlHideShow : boolean = true;
  constructor(
    private socketServiceClient: SocketServiceClient,
    private socketServiceRedis: SocketServiceRedis,
    private socketServiceBbMarket: SocketServiceBbMarket,
    private commonService: CommonService,
    private currencyService: CurrencyService,
    private utilityService: UtilityService,
    private placebetService: PlacebetService,
    private router: Router,
    private route: ActivatedRoute,
    private userService: UserService,
    private socketService: SocketService,
  ) { }
  /**
   * @author TR
   * @date : 05-06-2020
   * esc click to close modal with reset form
   */
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.currencyModal.hide();
    }
  }

  ngAfterViewInit() {
    let datauser = JSON.parse(this.utilityService.returnLocalStorageData('userData'));
    this.changePassword = datauser.changePassword;
    if(this.changePassword === false){
      this.router.navigate(['/new-user']);
    }

  }
  ngOnInit() {
    let datauser = JSON.parse(this.utilityService.returnLocalStorageData('userData'));
    this.changePassword = datauser.changePassword;
    if(this.changePassword === false){
      this.router.navigate(['/new-user']);
    }

    this.route.params.subscribe(params => {
      // this.mycurrentRoute = this.router.url.slice(0, this.router.url.lastIndexOf("/"));
      // console.log(this.mycurrentRoute)
      // if(this.mycurrentRoute === '/sports/card-view/mob') {
      //   $('.main-top-header').css('display' , 'none');
      // }else {
      //   $('.main-top-header').css('display' , 'block');
      // }

      let checkStorage = this.utilityService.returnLocalStorageData('userId');
      if(checkStorage) {
      }else {
        this.router.navigate(['/login']);
      }
    });
    // console.log(this.mycurrentRoute)

    this.userData = JSON.parse(this.utilityService.returnLocalStorageData('userData'));
    this.masterId = this.userData.masterId;

    let items = sessionStorage.getItem('balance');
    this.BalanceHideShow = JSON.parse(items);

    let available = sessionStorage.getItem('available');
    this.AvailableHideShow = JSON.parse(available);

    let exposure = sessionStorage.getItem('exposure');
    this.ExposureHideShow = JSON.parse(exposure);

    let pl = sessionStorage.getItem('pl');
    this.PlHideShow = JSON.parse(pl);

    let users = this.commonService.getLocalStorage();
    let userId = users.userId;
    let balanceObj = {
      ids: userId
    };
    this.socketServiceClient.connect();
    this.socketService.connect();
    this.socketServiceRedis.connect();
    this.socketServiceBbMarket.connect();

    this.userLoginId = users.userId;
    this.socketService.joinRoom(this.userLoginId);
    this.socketServiceClient.joinRoom( this.userLoginId);

    this.socketServiceClient.balaceSettel().subscribe((res) => {
      if (res) {
            this.userBalance = 0;
            this.userExposer = 0;
            this.userAvaBalance = 0;

            this.userBalance = res[0].balance;
            this.userExposer = res[0].exposer;
            this.userPl = res[0].p_and_l + res[0].cash;
            this.userAvaBalance = res[0].available_balance;
            this.userName = res[0].userName;
      }
    });


    this.socketServiceClient.updateBalancebyAdmin().subscribe((res) => {
      if (res) {
        let users = this.commonService.getLocalStorage();
        let userId = users.userId;
          this.userService.getBalanceUpdated(res[1].receiverId).subscribe(res => {
            this.userBalance = 0;
            this.userExposer = 0;
            this.userAvaBalance = 0;
            if (res.status == true) {
              this.userBalance = res.data[0].balance;
              this.userExposer = res.data[0].exposure;
              this.userPl = res.data[0].p_and_l + res.data[0].cash;
              this.userAvaBalance = res.data[0].available_balance;
              this.userName = res.data[0].userName;
            }
          });


      }

    });

    this.socketServiceClient.welcomeMassage().subscribe((res) => {
      if (res) {
        this.massage = res.massage;
      }
    });

    this.socketServiceRedis
      .reconnections()
      .subscribe((response) => {
        this.getbalance();
      });

    this.getbalance();
    //Get latest transaction from socket
    this.socketServiceClient
      .updateBalance()
      .subscribe((response) => {
        if (response) {
          this.userBalance = response.balance;
          this.userExposer = response.exposer;
          //this.userPl = response.p_and_l + response.cash;
          if(response){
          this.userPl = response.p_and_l + response.cash;
          }
          this.userAvaBalance = response.available_balance
        }
      });

    // //Get latest transaction from socket
    // this.socketService
    //   .updateBalance()
    //   .subscribe((response) => {
    //     if (response) {
    //       this.userBalance = response.balance;
    //       this.userExposer = response.exposer;
    //       //this.userPl = response.p_and_l + response.cash;
    //       if(response){
    //         this.userPl = response.p_and_l + response.cash;
    //       }
    //       this.userAvaBalance = response.available_balance
    //     }
    //   });


    //Get latest transaction from socket
    this.socketServiceClient
      .cancelMarket()
      .subscribe((response) => {
          this.userService.getBalance(balanceObj).subscribe(res => {
            if (res.status == true) {
              this.userBalance = res.data[0].balance;
              this.userExposer = res.data[0].exposure;
              // this.userPl = res.data[0].p_and_l + res.data[0].cash;
              this.userAvaBalance = res.data[0].available_balance;
              this.userName = res.data[0].userName;
            }
          });
      });
      
    this.socketService.logoutByAdminAll().subscribe((response) => {
      if (response) {
        
      }
    });

    this.socketService.logoutByAdmin().subscribe((response) => {
      if (response) {
        if (userId == response._id) {
          if (response.isLogin == false && response.isActive == true) {
            this.commonService.popToast('success', 'Success', 1500, 'Logout successfully By Admin.');
          }
          if (response.isActive == false) {
            this.commonService.popToast('success', 'Success', 1500, 'Your Account is InActive By Admin.');
          }
          localStorage.clear();
          sessionStorage.clear();
          this.router.navigate(['/login']);
        }
      }
    });
    this.getRules();
    this.welcomeMassages();

    this.socketService.logoutByAdminInctive().subscribe((response) => {
      if (response) {
        if (_.includes(this.masterId, response._id)) {
          if (response.isActive == false) {
            localStorage.clear();
            sessionStorage.clear();
            this.router.navigate(['/login']);
            this.commonService.popToast('success', 'Success', 1500, 'Logout successfully By Admin.');
          }
        }
      }
    });

  }

  updatePlacebetResponse(response){
    // if(response){
    //   this.userBalance = response.balance;
    //       this.userExposer = response.exposer;
    //       //this.userPl = response.p_and_l + response.cash;
    //       if(response){
    //       this.userPl = response.p_and_l + response.cash;
    //       }
    //       this.userAvaBalance = response.available_balance
    // }
}
  welcomeMassages() {
    this.userService.welcomeMassage().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if(response && response.data){
        this.massage = response.data.massage;
      }else{
        this.massage = '';
      }
    }, error => {
      this.commonService.popToast('error', 'Error', 1500, error.message);
      console.error("error");
    })
  }


  userLogout() {
    this.userService.logOut().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.commonService.popToast('success', 'Success', 1500, 'Logout successfully.');
      localStorage.clear();
      let lastJoinRoom = sessionStorage.getItem("lastJoinRoom");
      let userJoinRoom = this.utilityService.returnSessionStorageData('userId');
      this.socketService.disconnect();
      this.socketServiceClient.disconnect();
      this.socketServiceRedis.disconnect();
      this.socketServiceBbMarket.disconnect();
      if (lastJoinRoom) {
        this.socketService.leaveRoom(lastJoinRoom);
      }
      if (userJoinRoom) {
        this.socketServiceClient.leaveRoom(userJoinRoom);
      }
      sessionStorage.clear();
      this.router.navigate(['']);
    }, error => {
      this.commonService.popToast('error', 'Error', 1500, error.message);
      console.error("error in logout");
    })
  }

  /**
   * @author TR
   * @date : 05-06-2020
   * get Currency
   */
  getUserCurrency() {
    let data = {
      userId: this.utilityService.returnLocalStorageData('userId')
    };
    this.currencyService.getUserCurrency(data).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.currencyAll = response.data;
    });
  }

   /**
   * @author subhash
   * @date : 28/10/2020
   * get master Currency
   */
  resetCurrencyModel() {
    let data = {
      userId: this.userData.parentId
    };
    this.currencyService.getUserCurrency(data).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.currencyAll[0].buttons = response.data[0].buttons;
      if(response){
        this.currencyService.updateCurrency(this.currencyAll[0]).subscribe(response => {
          response = this.utilityService.gsk(response.auth);
          response = JSON.parse(response);
          this.getUserCurrency();
          // this.currencyModal.hide();
        });
      }
  });
  }

  /**
   * @author TR
   * @date : 05-06-2020
   * update Currency
   */
  updateCurrency() {
    this.currencyService.updateCurrency(this.currencyAll[0]).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.currencyModal.hide();
      this.getUserCurrency();
    });
  }
  /**
   * @author TR
   * @date : 05-06-2020
   * close currency model
   */
  closeCurrencyModel() {
    this.currencyModal.hide();
  }
  /**
   * @author TR
   * @date : 05-06-2020
   * open currency model
   */
  openChipsModal() {
    this.getUserCurrency();
    this.currencyModal.show();
  }

  /**
   * @author TR
   * @date : 24-06-2020
   * open change password model
   */
  openPassModal() {
    this.changePassModal.show();
  }

  /**
   * @author TR
   * @date : 24-06-2020
   * close change password model
   */
  closeModalPass() {
    this.changePassModal.hide();
  }

  /**
   * @author TR
   * @date : 24-06-2020
   * password changes api calling
   */


  passChange() {
    let data = {
      oldPass: this.utilityService.returnEncrypt(this.oldPassword),
      newPass: this.utilityService.returnEncrypt(this.newPassword),
      cinfNewPass: this.utilityService.returnEncrypt(this.confNewPassword),
      userId: this.utilityService.returnLocalStorageData('userId')
    };
    this.userService.passwordChange(data).subscribe(response => {
      if (response.status === true) {
        this.changePassModal.hide();
        localStorage.clear();
        sessionStorage.clear();
        this.router.navigate(['/login']);
      } else {
        this.commonService.popToast('error', 'Error', 1500, 'password does not match.');
      }
    }, error => {
      this.commonService.popToast('error', 'Error', 1500, 'password does not match.');
      console.error("error in logout");
    });
  }

  /**
   * @author TR
   * @date : 24-06-2020
   * password changes api calling
   */

  getRules() {
    this.currencyService.getRestriction().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if (response.status === true) {
        this.marketRules = response.data[0];
      } else {
        // this.commonService.popToast('error','Error', 3000 , 'not found market rules.');
      }
    }, error => {
      this.commonService.popToast('error', 'Error', 1500, 'not found market rules.');
    });
  }

  Balance(check) {
    sessionStorage.setItem('balance', check);
    let item = sessionStorage.getItem('balance');
    this.BalanceHideShow = JSON.parse(item);
  }
  Available(available) {
    sessionStorage.setItem('available', available);
    let item = sessionStorage.getItem('available');
    this.AvailableHideShow = JSON.parse(item);
  }
  Exposure(exposure) {
    sessionStorage.setItem('exposure', exposure);
    let item = sessionStorage.getItem('exposure');
    this.ExposureHideShow = JSON.parse(item);
  }
  Pl(pl) {
    sessionStorage.setItem('pl', pl);
    let item = sessionStorage.getItem('pl');
    this.PlHideShow = JSON.parse(item);
  }

  exploserData(){
    this.exposureDetails.show();
    let data = {
      userId :this.userLoginId
    }
    this.placebetService.getExploserMatchData(data).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if (response.status === true) {
        this.exposureData = response.data;
        // console.log("this.exposureData",this.exposureData)
        // console.log("fancy",this.exposureData[1].FancyData[0].match.name)
        // console.log("Line",this.exposureData[5].MarketData[0].match.name)
      } else {
        // this.commonService.popToast('error','Error', 3000 , 'not found market rules.');
      }
    }, error => {
      this.commonService.popToast('error', 'Error', 1500, 'not found.');
    });

  }

  exposureClose(){
    this.exposureDetails.hide();
  }
  redirection(data){
    this.router.navigateByUrl('/sports/game-view/' + data.marketId);
    this.exposureDetails.hide();
  }
  reload(){
    this.route.params.subscribe(params => {
      this.mycurrentRoute = this.router.url;
      if(this.mycurrentRoute === '/dashboard') {
        location.reload();
      }else {

      }
    });
  }

  getbalance(){
    let balanceObj = {
      ids: this.userLoginId
    };
    this.userService.getBalance(balanceObj).subscribe(res => {
      res = this.utilityService.gsk(res.auth);
      res = JSON.parse(res);
      if (res.status == true) {
        this.userBalance = res.data[0].balance;
        this.userExposer = res.data[0].exposure;
        this.userPl = res.data[0].p_and_l;
        this.userAvaBalance = res.data[0].available_balance;
        this.userName = res.data[0].userName;
      }
    });
  }

}
