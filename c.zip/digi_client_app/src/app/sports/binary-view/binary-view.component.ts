import {Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from "@angular/router";
import {CommonService} from "../../services/common.service";
import {PlacebetService} from "../../services/placebet.service";
import {MarketService} from "../../services/market.service";
import {CurrencyService} from "../../services/currency.service";
import {NgxSpinnerService} from "ngx-spinner";
import {LockGameService} from "../../services/lockGame.service";
import {SocketServiceClient} from "../../globals/socketServiceClient";
import {FancyService} from "../../services/fancy.service";
import {SocketService} from "../../globals/socketService";
import { SocketServiceBbMarket } from './../../globals/socketServiceBbMarket';
import {DragulaService } from 'ng2-dragula';
import * as $ from 'jquery';
import {ModalDirective} from "ngx-bootstrap";
import {BinaryService} from "../../services/binary.service";
import {UtilityService} from "../../globals/utilityService";
import { interval } from 'rxjs';

declare let _:any;
@Component({
  selector: 'app-binary-view',
  templateUrl: './binary-view.component.html',
  styleUrls: ['./binary-view.component.scss']
})
export class BinaryViewComponent implements OnInit , OnDestroy {
  @ViewChild(ModalDirective, {static: false}) modal: ModalDirective;
  @ViewChild('infoModal', {static: false}) infoModal: ModalDirective;
  @ViewChild('openBetModal', {static: false}) openBetModal: ModalDirective;
  @ViewChild('removeScript', {static: false}) removeScript: ModalDirective;
  @ViewChild("placebetForm", { static: false }) placebetFormReset;
  @ViewChild('focusInput' ,  {static: false}) focusInput: ElementRef;
  constructor(
    private route: ActivatedRoute,
    private socketService : SocketService,
    private socketServiceClient : SocketServiceClient,
    private fancyService : FancyService,
    private marketService : MarketService,
    private lockGameService : LockGameService,
    private commonService: CommonService,
    private binaryService: BinaryService,
    private currencyService: CurrencyService,
    private utilityService: UtilityService,
    private placebetService : PlacebetService,
    private dragulaService: DragulaService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private socketServiceBbMarket : SocketServiceBbMarket,
  ) {
    // dragulaService.setOptions('bag-one', {
    //   revertOnSpill: true
    // });
  }

  moduleList = [];
  moduleList1 = [];
  addDefaultData = [];

  searchVal:any;
  totalPL = 0;
  allDeals:any;
  informationData:any;
  completedOrder:any;
  pendingOrder:any;
  getAllExchng:any;
  filterData = false;
  selectedValue= 'ALL';
  filterDataObjects:any;
  transactionResponse:any;
  userLoginId:any;
  openPositionResponse:any;
  allBalance:any;

  instrumentTokenIds = [];
  defaultScript: any = [];
  randomString = this.utilityService.returnLocalStorageData('userId');
  betObj = {
    orderType: 'MARKET',
    qty: 1,
    limit: ''
  };
  usersPartnership :any;
  subscription;
  subscriptionDetail;
  subscriptionInstrument;
  detailInstrumentId;
  userId = this.utilityService.returnLocalStorageData('userId')
  @HostListener('focusin', ['$event']) public onListenerTriggered(event: any): void {
    if(event.sourceCapabilities) {
        //console.log("event")
    }else {
      this.setFocusToInput();
     }
  }
  ngOnInit() {
    let users = this.commonService.getLocalStorage();
    this.userLoginId = users.userId;
    this.socketService.joinRoom(this.userLoginId);
    this.socketServiceClient.joinRoom( this.userLoginId);
    this.getAlldefaultScript();
     this.getAllExcahnge();
     this.getAllOpenPosition();
     this.getAllBalance();
     this.getAllDeals();
    this.getAllTransactionForMarket();

    //Get latest transaction from socket
    this.socketServiceClient
      .getPlaceBetShareMarket()
      .subscribe((response) => {``
        this.getAllTransactionForMarket();
          this.getAllOpenPosition();
      });

    //Get latest transaction from socket
    this.socketServiceClient
      .getPlaceBetShareMarketBalance()
      .subscribe((response) => {
          this.getAllBalance();
      });

  }



  ngOnDestroy() {
    // this.dragulaService.destroy('bag-one');
  }
  setFocusToInput() {
    // this.focusInput.nativeElement.focus();
    // this.focusInput.nativeElement.select();
  }

  /**
   * @author TR
   * @date : 05-06-2020
   * get All Default Script
   */

  getAlldefaultScript(){
    this.spinner.show();
    let data = {
      userId: this.utilityService.returnLocalStorageData('userId'),
    };

    this.currencyService.getAlldefaultScript(data).subscribe(response => {
      if(response.status === true){
        let item = response.data;
        this.defaultScript = item;
        if(response.data.length > 0){
          // let defaultPort = response.data[0].defaultPortfolio;
          // let ownPort = response.data[0].ownPortfolio;
          // let item = _.union(defaultPort, ownPort);

          let totalRec = this.defaultScript.length;
          this.defaultScript.map((ite, index) =>{

            if(ite !== null) {
            this.instrumentTokenIds.push(ite.data.instrumentToken);
            if(totalRec - 1 === index){
                this.callSocketRate(this.instrumentTokenIds);
                this.getRate();
            }
            }
          });
          this.spinner.hide();

        }
      }
    });

  }


  callSocketRate(tokens){
    let uniqId = "";
    let tokenIds =  tokens.toString();
    //socket service market join
    var requested = {
                  "roomId": this.randomString,
                  "instrument_token": tokenIds,
                  "uniqId":this.commonService.getRandomString(10),
                  "response_type" : 'full'
                };
          // this.socketServiceBbMarket.leaveRoom(this.randomString);
          // this.socketServiceBbMarket.joinRoom(JSON.stringify(requested));
          if(this.subscription){
            this.clearSubscription(this.subscription);
          }
          var observable = interval(600);
          this.subscription = observable.subscribe(x => {
            this.socketServiceBbMarket.setInstrument(JSON.stringify(requested));
          });
  }

  clearSubscription(timer){
    let storeTimer = timer;
    setTimeout(function(){
      storeTimer.unsubscribe();
    },3000);
  }




getRate(){

    this.socketServiceBbMarket
    .getInstrument()
    .subscribe((response) => {
      if(response.data.length > 0){
        if(response.roomId == "temp_" + this.userId){
          this.getDetailRate(response);
        }else if(response.roomId == "instrumentSocket_" + this.userId){
          this.getInstrumentRate(response);
        }else{
          response.data.map((result, index) =>{
          if(result){
            let data = result;
            $("#" + data.instrument_token + "_buy_price_0").html(data['buy_price_0']);
            $("#"+  data.instrument_token + '_buy_price_0_netChange').html(data['buy_price_0']);
            $("#"+  data.instrument_token + '_buy_price_0_netChange_mob').html(data['buy_price_0']);

           $("#"+  data.instrument_token + '_sell_price_0_netChange').html(data['sell_price_0']);
            $("#"+  data.instrument_token + '_sell_price_0_netChange_mob').html(data['sell_price_0']);

          let preAmntBuy = $("#prev_" + data.instrument_token + "_buy_price_0").val();
            if(data['buy_price_0'] > preAmntBuy){
              $("#" + data.instrument_token  + "_buy_price_0").removeClass('red').addClass('green');
              $("#" + data.instrument_token + "_buy_price_0_mob").removeClass('red').addClass('green');
            }else{
              $("#" + data.instrument_token  + "_buy_price_0").removeClass('green').addClass('red');
              $("#" + data.instrument_token + "_buy_price_0_mob").removeClass('green').addClass('red');
            }
            $("#prev_" + data.instrument_token + "_buy_price_0").val(data['buy_price_0']);


            let preAmntSell = $("#prev_" + data.instrument_token + "_sell_price_0").val();
            if(data['sell_price_0'] > preAmntSell){
              $("#" + data.instrument_token  + "_sell_price_0").removeClass('red').addClass('green');
              $("#" + data.instrument_token + "_sell_price_0_mob").removeClass('red').addClass('green');
            }else{
              $("#" + data.instrument_token  + "_sell_price_0").removeClass('green').addClass('red');
              $("#" + data.instrument_token + "_sell_price_0_mob").removeClass('green').addClass('red');
            }
            $("#prev_" + data.instrument_token + "_sell_price_0").val(data['sell_price_0']);

            $("#" + data.instrument_token + "_sell_price_0").html(data['sell_price_0']);
            $("#" + data.instrument_token + "_last_price").html(data['last_price']);
            $("#" + data.instrument_token + "_net_change").html(data['net_change']);
            $("#" + data.instrument_token + "_ohlc_high").html(data['ohlc_high']);
            $("#" + data.instrument_token + "_ohlc_low").html(data['ohlc_low']);
            $("#" + data.instrument_token + "_last_trade_time").html(data['last_trade_time']);

            $("#" + data.instrument_token + "_buy_price_0_mob").html(data['buy_price_0']);
            $("#" + data.instrument_token + "_sell_price_0_mob").html(data['sell_price_0']);
            $("#" + data.instrument_token + "_last_price_mob").html(data['last_price']);
            $("#" + data.instrument_token + "_net_change_mob").html(data['net_change']);
            $("#" + data.instrument_token + "_ohlc_high_mob").html(data['ohlc_high']);
            $("#" + data.instrument_token + "_ohlc_low_mob").html(data['ohlc_low']);
            $("#" + data.instrument_token + "_last_trade_time_mob").html(data['last_trade_time']);

            if(data['net_change'] >0){
              $("#"+data.instrument_token + ' ' + 'i').removeClass('fa fa-arrow-circle-down red');
              $("#"+data.instrument_token + ' ' + 'i').addClass('fa fa-arrow-circle-up green');
              $("#"+data.instrument_token + '_mob').removeClass('red1');
              $("#"+data.instrument_token + '_mob').addClass('green1');
              $("#"+data.instrument_token + '_net_change_mob').removeClass('red');
              $("#"+data.instrument_token + '_net_change_mob').addClass('green');
            }else{
              $("#"+data.instrument_token + ' ' + 'i').removeClass('fa fa-arrow-circle-up green');
              $("#"+data.instrument_token + ' ' + 'i').addClass('fa fa-arrow-circle-down red');
              $("#"+data.instrument_token + '_mob').removeClass('green1');
              $("#"+data.instrument_token + '_mob').addClass('red1');
              $("#"+data.instrument_token + '_net_change_mob').removeClass('green');
              $("#"+data.instrument_token + '_net_change_mob').addClass('red');
            }

              // if(Object.keys(data).length !== 0){
              //   if(data['$setOnInsert']){
              //     delete data['$setOnInsert'];
              //   }

              //   Object.keys(data).forEach((key,index) => {
              //     $("#" + data.instrument_token + "_" + key).html(data[key]);
              //     $("#" + data.instrument_token + "_" + key + '_mob').html(data[key]);
              //     $("#"+  data.instrument_token + "_" + key + '_netChange').html(data[key]);
              //     $("#"+  data.instrument_token + "_" + key + '_netChange_mob').html(data[key]);

              //     // Net Position Logic implementation

              //     let sellRate = $("#" + data.instrument_token + "_buy_price_0_netChange").html();
              //     let buyRate = $("#" + data.instrument_token + "_sell_price_0_netChange").html();
              //     let averPrice = $("#" + data.instrument_token + "_averagePrice").html();
              //     let openQny = $("#" + data.instrument_token + "_openQuantity").html();
              //     let lotSize = $("#" + data.instrument_token + "_lotSize").html();
              //     let type = $("#" + data.instrument_token + "_type").html();


              //     if(type === 'SELL'){
              //       let TotalCal = ((Number(averPrice)  - Number(buyRate)) * Number(openQny)) * Number(lotSize);
              //       let TotalValue = TotalCal.toFixed(2);
              //       $("#"+data.instrument_token + "_" + key + '_netChange1').html(String(TotalValue));
              //       $("#"+data.instrument_token + "_" + key + '_netChange1_mob').html(String(TotalValue));
              //       if(Number(TotalValue) > 0){
              //         $("#" + data.instrument_token  + "_" + key + '_netChange1').removeClass('red-color').addClass('green-color'); //use current element
              //         $("#" + data.instrument_token  + "_" + key + '_netChange1_mob').removeClass('red-color').addClass('green-color'); //use current element
              //       }else{
              //         $("#" + data.instrument_token  + "_" + key + '_netChange1').removeClass('green-color').addClass('red-color'); //use current element
              //         $("#" + data.instrument_token  + "_" + key + '_netChange1_mob').removeClass('green-color').addClass('red-color'); //use current element
              //       }
              //     } else {
              //       let TotalCal = ((Number(sellRate)  - Number(averPrice)) * Number(openQny)) * Number(lotSize);

              //       let TotalValue = TotalCal.toFixed(2);

              //       $("#"+data.instrument_token + "_" + key + '_netChange1').html(String(TotalValue));
              //       $("#"+data.instrument_token + "_" + key + '_netChange1_mob').html(String(TotalValue));
              //       if(Number(TotalValue) > 0){
              //         $("#" + data.instrument_token  + "_" + key + '_netChange1').removeClass('red-color').addClass('green-color'); //use current element
              //         $("#" + data.instrument_token  + "_" + key + '_netChange1_mob').removeClass('red-color').addClass('green-color'); //use current element
              //       }else{
              //         $("#" + data.instrument_token  + "_" + key + '_netChange1').removeClass('green-color').addClass('red-color'); //use current element
              //         $("#" + data.instrument_token  + "_" + key + '_netChange1_mob').removeClass('green-color').addClass('red-color'); //use current element
              //       }
              //     }

              //     // End Net position Logic

              //     if(key == "buy_price_0" || key == "sell_price_0"){ //this code for buy price and sell price
              //       let preAmnt = $("#prev_" + data.instrument_token + "_" + key).val();
              //       if(data[key] > preAmnt){
              //         $("#" + data.instrument_token  + "_" + key).removeClass('red').addClass('green'); //use current element
              //         $("#" + data.instrument_token + "_" + key + "_mob").removeClass('red').addClass('green'); //use current element
              //       }else{
              //         $("#" + data.instrument_token  + "_" + key).removeClass('green').addClass('red'); //use current element
              //         $("#" + data.instrument_token + "_" + key + "_mob").removeClass('green').addClass('red'); //use current element
              //       }
              //       $("#prev_" + data.instrument_token + "_" + key).val(data[key]);
              //     }

              //     if(key == "net_change"){
              //       if(data[key] >0){
              //         $("#"+data.instrument_token + ' ' + 'i').removeClass('fa fa-arrow-circle-down red');
              //         $("#"+data.instrument_token + ' ' + 'i').addClass('fa fa-arrow-circle-up green');
              //         $("#"+data.instrument_token + '_mob').removeClass('red1');
              //         $("#"+data.instrument_token + '_mob').addClass('green1');
              //         $("#"+data.instrument_token + '_net_change_mob').removeClass('red');
              //         $("#"+data.instrument_token + '_net_change_mob').addClass('green');
              //       }else{
              //         $("#"+data.instrument_token + ' ' + 'i').removeClass('fa fa-arrow-circle-up green');
              //         $("#"+data.instrument_token + ' ' + 'i').addClass('fa fa-arrow-circle-down red');
              //         $("#"+data.instrument_token + '_mob').removeClass('green1');
              //         $("#"+data.instrument_token + '_mob').addClass('red1');
              //         $("#"+data.instrument_token + '_net_change_mob').removeClass('green');
              //         $("#"+data.instrument_token + '_net_change_mob').addClass('red');
              //       }
              //     }
              //   });
              // }
          }
          });
        }
      }
      // response.map((result, index) =>{
      //   console.log("result+++++++++++",result);
      //   console.log("result+++++++++++",result);

      //   if(result){
      //     let data = result.data;
      //       if(Object.keys(data).length !== 0){
      //         if(data['$setOnInsert']){
      //           delete data['$setOnInsert'];
      //         }

      //         Object.keys(data).forEach((key,index) => {
      //           $("#" + result.token + "_" + key).html(data[key]);
      //           $("#" + result.token + "_" + key + '_mob').html(data[key]);
      //           $("#"+result.token + "_" + key + '_netChange').html(data[key]);
      //           $("#"+result.token + "_" + key + '_netChange_mob').html(data[key]);

      //           // Net Position Logic implementation

      //           let sellRate = $("#" + result.token + "_buy_price_0_netChange").html();
      //           let buyRate = $("#" + result.token + "_sell_price_0_netChange").html();
      //           let averPrice = $("#" + result.token + "_averagePrice").html();
      //           let openQny = $("#" + result.token + "_openQuantity").html();
      //           let lotSize = $("#" + result.token + "_lotSize").html();
      //           let type = $("#" + result.token + "_type").html();


      //           if(type === 'SELL'){
      //             let TotalCal = ((Number(averPrice)  - Number(buyRate)) * Number(openQny)) * Number(lotSize);
      //             let TotalValue = TotalCal.toFixed(2);
      //             $("#"+result.token + "_" + key + '_netChange1').html(String(TotalValue));
      //             $("#"+result.token + "_" + key + '_netChange1_mob').html(String(TotalValue));
      //             if(Number(TotalValue) > 0){
      //               $("#" + result.token  + "_" + key + '_netChange1').removeClass('red-color').addClass('green-color'); //use current element
      //               $("#" + result.token  + "_" + key + '_netChange1_mob').removeClass('red-color').addClass('green-color'); //use current element
      //             }else{
      //               $("#" + result.token  + "_" + key + '_netChange1').removeClass('green-color').addClass('red-color'); //use current element
      //               $("#" + result.token  + "_" + key + '_netChange1_mob').removeClass('green-color').addClass('red-color'); //use current element
      //             }
      //           } else {
      //             let TotalCal = ((Number(sellRate)  - Number(averPrice)) * Number(openQny)) * Number(lotSize);

      //             let TotalValue = TotalCal.toFixed(2);

      //             $("#"+result.token + "_" + key + '_netChange1').html(String(TotalValue));
      //             $("#"+result.token + "_" + key + '_netChange1_mob').html(String(TotalValue));
      //             if(Number(TotalValue) > 0){
      //               $("#" + result.token  + "_" + key + '_netChange1').removeClass('red-color').addClass('green-color'); //use current element
      //               $("#" + result.token  + "_" + key + '_netChange1_mob').removeClass('red-color').addClass('green-color'); //use current element
      //             }else{
      //               $("#" + result.token  + "_" + key + '_netChange1').removeClass('green-color').addClass('red-color'); //use current element
      //               $("#" + result.token  + "_" + key + '_netChange1_mob').removeClass('green-color').addClass('red-color'); //use current element
      //             }
      //           }

      //           // End Net position Logic

      //           if(key == "buy_price_0" || key == "sell_price_0"){ //this code for buy price and sell price
      //             let preAmnt = $("#prev_" + result.token + "_" + key).val();
      //             if(data[key] > preAmnt){
      //               $("#" + result.token  + "_" + key).removeClass('red').addClass('green'); //use current element
      //               $("#" + result.token + "_" + key + "_mob").removeClass('red').addClass('green'); //use current element
      //             }else{
      //               $("#" + result.token  + "_" + key).removeClass('green').addClass('red'); //use current element
      //               $("#" + result.token + "_" + key + "_mob").removeClass('green').addClass('red'); //use current element
      //             }
      //             $("#prev_" + result.token + "_" + key).val(data[key]);
      //           }

      //           if(key == "net_change"){
      //             if(data[key] >0){
      //               $("#"+result.token + ' ' + 'i').removeClass('fa fa-arrow-circle-down red');
      //               $("#"+result.token + ' ' + 'i').addClass('fa fa-arrow-circle-up green');
      //               $("#"+result.token + '_mob').removeClass('red1');
      //               $("#"+result.token + '_mob').addClass('green1');
      //               $("#"+result.token + '_net_change_mob').removeClass('red');
      //               $("#"+result.token + '_net_change_mob').addClass('green');
      //             }else{
      //               $("#"+result.token + ' ' + 'i').removeClass('fa fa-arrow-circle-up green');
      //               $("#"+result.token + ' ' + 'i').addClass('fa fa-arrow-circle-down red');
      //               $("#"+result.token + '_mob').removeClass('green1');
      //               $("#"+result.token + '_mob').addClass('red1');
      //               $("#"+result.token + '_net_change_mob').removeClass('green');
      //               $("#"+result.token + '_net_change_mob').addClass('red');
      //             }
      //           }
      //         });
      //       }
      //   }
      // });
    });
  }

getDetailRate(response){
  if(response){
      let res = response.data[0];
      if(res.instrument_token == this.detailInstrumentId){
        $("#" + res.instrument_token +  "_ohlc_open_single").html(res.ohlc_open);
        $("#" + res.instrument_token +  "_ohlc_close_single").html(res.ohlc_close);
        $("#" + res.instrument_token +  "_ohlc_high_bet_single").html(res.ohlc_high);
        $("#" + res.instrument_token +  "_ohlc_low_bet_single").html(res.ohlc_low);
        $("#" + res.instrument_token +  "_last_price_bet_single").html(res.last_trade_time.substring(20, res.last_trade_time.lastIndexOf(" ")+1));
        $("#" + res.instrument_token +  "_volume_single").html(res.volume);
        $("#"+res.instrument_token+"_buy_price_0_single_input").val(res.buy_price_0);
        $("#"+res.instrument_token+"_sell_price_0_single_input").val(res.sell_price_0);

        $("#"+res.instrument_token+"_buy_price_0_single").html(res.buy_price_0);
        $("#"+res.instrument_token+"_sell_price_0_single").html(res.sell_price_0);
        let preAmntBuy = $("#prev_" + res.instrument_token + "_buy_price_0").val();

        if(res.buy_price_0 > preAmntBuy){
          $("#" + res.instrument_token  + "_buy_price_0_single").removeClass('red').addClass('green'); //use current element
        }else{
          $("#" + res.instrument_token  + "_buy_price_0_single").removeClass('green').addClass('red'); //use current element
        }

        let preAmntSell = $("#prev_" + res.instrument_token + "_sell_price_0").val();
        if(res.sell_price_0 > preAmntSell){
          $("#" + res.instrument_token  + "_sell_price_0_single").removeClass('red').addClass('green'); //use current element
        }else{
          $("#" + res.instrument_token  + "_sell_price_0_single").removeClass('green').addClass('red'); //use current element
        }
      }
  }
}

getInstrumentRate(response){

  response.data.map((result, index) =>{
    if(result){
      let data = result;
      $("#"+  data.instrument_token + '_buy_price_0_netChange').html(data['buy_price_0']);
      $("#"+  data.instrument_token + '_buy_price_0_netChange_mob').html(data['buy_price_0']);

     $("#"+  data.instrument_token + '_sell_price_0_netChange').html(data['sell_price_0']);
      $("#"+  data.instrument_token + '_sell_price_0_netChange_mob').html(data['sell_price_0']);
        let sellRate = $("#" + data.instrument_token + "_buy_price_0_netChange").html();
            let buyRate = $("#" + data.instrument_token + "_sell_price_0_netChange").html();
            let averPrice = $("#" + data.instrument_token + "_averagePrice").html();
            let openQny = $("#" + data.instrument_token + "_openQuantity").html();
            let lotSize = $("#" + data.instrument_token + "_lotSize").html();
            let type = $("#" + data.instrument_token + "_type").html();


            if(type === 'SELL'){
              let TotalCal = ((Number(averPrice)  - Number(buyRate)) * Number(openQny)) * Number(lotSize);
              let TotalValue = TotalCal.toFixed(2);
              $("#"+data.instrument_token +'_sell_price_0_netChange1').html(String(TotalValue));
              $("#"+data.instrument_token + '_sell_price_0_netChange1_mob').html(String(TotalValue));
              if(Number(TotalValue) > 0){
                $("#" + data.instrument_token  +  '_sell_price_0_netChange1').removeClass('red-color').addClass('green-color'); //use current element
                $("#" + data.instrument_token  + '_sell_price_0_netChange1_mob').removeClass('red-color').addClass('green-color'); //use current element
              }else{
                $("#" + data.instrument_token  +  '_sell_price_0_netChange1').removeClass('green-color').addClass('red-color'); //use current element
                $("#" + data.instrument_token  + '_sell_price_0_netChange1_mob').removeClass('green-color').addClass('red-color'); //use current element
              }
            } else {
              let TotalCal = ((Number(sellRate)  - Number(averPrice)) * Number(openQny)) * Number(lotSize);

              let TotalValue = TotalCal.toFixed(2);

              $("#"+data.instrument_token + '_sell_price_0_netChange1').html(String(TotalValue));
              $("#"+data.instrument_token + '_sell_price_0_netChange1_mob').html(String(TotalValue));
              if(Number(TotalValue) > 0){
                $("#" + data.instrument_token  + '_sell_price_0_netChange1').removeClass('red-color').addClass('green-color'); //use current element
                $("#" + data.instrument_token  + '_sell_price_0_netChange1_mob').removeClass('red-color').addClass('green-color'); //use current element
              }else{
                $("#" + data.instrument_token  + '_sell_price_0_netChange1').removeClass('green-color').addClass('red-color'); //use current element
                $("#" + data.instrument_token  + '_sell_price_0_netChange1_mob').removeClass('green-color').addClass('red-color'); //use current element
              }
            }
    }
  });
}



  openScriptModal(){
     this.instrumentList();
      this.modal.show();
  }

  openInfoModal(data){

    this.openBetModal.hide();
    this.informationData = data;

    this.infoModal.show();
  }

  betModal(data){
    let tempInst = "temp_" + this.userId;
    this.detailInstrumentId = data.instrumentToken;
    //this.socketServiceBbMarket.leaveRoom(tempInst);

    var requested = {
      "roomId": tempInst,
      "instrument_token": data.instrumentToken,
      "uniqId":this.commonService.getRandomString(10),
      "response_type" : 'full'
    };
    console.log(requested);
    if(this.subscriptionDetail){
      this.clearSubscription(this.subscriptionDetail);
    }
    var observable = interval(600);
    this.subscriptionDetail = observable.subscribe(x => {
      this.socketServiceBbMarket.detailInstrument(JSON.stringify(requested));
    });
    // this.socketServiceBbMarket.joinRoom(JSON.stringify(requested));

    /*this.socketServiceBbMarket
    .getBbMarketRate(this.randomString)
    .subscribe((response) => {
      if(response.length > 0 ){
        if(response[0].roomId === tempInst){
          let res = response[0].data;
          $("#" + data.instrumentToken +  "_ohlc_open_single").html(res.ohlc_open);
          $("#" + data.instrumentToken +  "_ohlc_close_single").html(res.ohlc_close);
          $("#" + data.instrumentToken +  "_ohlc_high_bet_single").html(res.open_interest_high);
          $("#" + data.instrumentToken +  "_ohlc_low_bet_single").html(res.open_interest_low);
          $("#" + data.instrumentToken +  "_last_price_bet_single").html(res.last_trade_time.substring(20, res.last_trade_time.lastIndexOf(" ")+1));
          $("#" + data.instrumentToken +  "_volume_single").html(res.volume);
          $("#"+data.instrumentToken+"_buy_price_0_single_input").val(res.buy_price_0);
          $("#"+data.instrumentToken+"_sell_price_0_single_input").val(res.sell_price_0);

          $("#"+data.instrumentToken+"_buy_price_0_single").html(res.buy_price_0);
          $("#"+data.instrumentToken+"_sell_price_0_single").html(res.sell_price_0);
          let preAmntBuy = $("#prev_" + data.instrumentToken + "_buy_price_0").val();



          if(res.buy_price_0 > preAmntBuy){
            $("#" + data.instrumentToken  + "_buy_price_0_single").removeClass('red').addClass('green'); //use current element
          }else{
            $("#" + data.instrumentToken  + "_buy_price_0_single").removeClass('red').addClass('green'); //use current element
          }

          let preAmntSell = $("#prev_" + data.instrumentToken + "_sell_price_0").val();
          if(res.sell_price_0 > preAmntSell){
            $("#" + data.instrumentToken  + "_sell_price_0_single").removeClass('red').addClass('green'); //use current element
          }else{
            $("#" + data.instrumentToken  + "_sell_price_0_single").removeClass('red').addClass('green'); //use current element
          }

        }
      }
    });*/

    let buy_price_0 =  $("#" + data.instrumentToken + "_placeBetReq").data('data-buy_price_0');

    // this.setFocusToInput()
    this.informationData = data;
    this.informationData.buy_price_0 = buy_price_0;

    // this.instrumentList();
    this.openBetModal.show();
  }

  closeinfoModel(){
    if(this.subscriptionDetail){
      this.clearSubscription(this.subscriptionDetail);
    }
    this.betObj.orderType = 'MARKET';
    this.betObj.qty = 1;
    this.betObj.limit = '0';
    this.openBetModal.hide();
    this.infoModal.hide();
  }
  getAllExcahnge(){
    this.binaryService.getAllExcahnge().subscribe(response => {
      this.getAllExchng = response.data;
      this.spinner.hide();
    }, error => {
      console.error('error in get users settings');
    });
  }
  instrumentList() {
    this.binaryService.getAllInstDefault(this.selectedValue).subscribe(response => {
      this.addDefaultData = response.data;
      this.spinner.hide();
    }, error => {
      console.error('error in get default');
    });
  }





  /**
   * @author TR_buy_price_0_single_inputvalue
   */

  onSelectionChange(e){
    this.selectedValue = e;
    this.instrumentList();
  }


  /**
   * @author TR
   * @date : 12-06-2020
   * check list add portfolio
   */

  check(e, data) {
    if (e.target.checked === true) {
      this.addDefaultData = this.addDefaultData.map(mDats =>{

        if(mDats.instrumentToken === data.instrumentToken){

          this.moduleList.push(data.instrumentToken);
          mDats.checkBoxValue = true
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList, data.instrumentToken);

      this.moduleList = arr2;
      this.addDefaultData = this.addDefaultData.filter(mDats =>{

        if(mDats.instrumentToken === data.instrumentToken){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }

  /**
   * @author TR
   * @date : 12-06-2020
   * check list delete portfolio
   */

  checkRm(e, data) {
    if (e.target.checked === true) {
      this.defaultScript = this.defaultScript.map(mDats =>{

        if(mDats.data.instrumentToken === data.instrumentToken){

          this.moduleList1.push(data.instrumentToken);
          mDats.checkBoxValue = true;
        }
        return mDats;
      });
      return data;
    } else {

      let arr2 = _.without(this.moduleList1, data.instrumentToken);

      this.moduleList1 = arr2;
      this.defaultScript = this.defaultScript.filter(mDats =>{

        if(mDats.data.instrumentToken === data.instrumentToken){
          mDats.checkBoxValue = false
        }
        return mDats;
      });
      return data;
    }
  }

  /**
   * @author TR
   * @date : 12-06-2020
   * Local Search Functionality
   */

  mySearch(){
    const x = this.searchVal.toLowerCase();
    this.filterDataObjects = _.filter(this.addDefaultData, function(item) {
      if (item.name.toLowerCase().indexOf(x) !== -1) {
        return item;
      }
    });

    if (this.filterDataObjects && this.filterDataObjects.length > 0) {
      this.filterData = true;
    } else {
      this.filterData = false;
    }
  }



  /**
   * @author TR
   * @date : 26-05-2020
   * add portfolio
   * @method: POST
   */
  addDefault(){
    let data = {
      userId: this.utilityService.returnLocalStorageData('userId'),
      id: this.moduleList.toString()
    };
    this.binaryService.addDefault(data).subscribe(response => {
        this.modal.hide();
        this.moduleList = [];
         this.getAlldefaultScript();
         this.utilityService.popToast('success','Success', 3000 , 'Add Default successfully.');
        this.spinner.hide();
      }, error => {
        // this.utilityService.popToast('error','Error', 3000 , error);
      });
  }


  closeModel(){
  this.modal.hide();
  }

  openDeleteScriptModal(){
    this.removeScript.show();
  }

  closeModelRemove(){
  this.removeScript.hide();
  }

  removeDefault(){
    let data = {
      userId: this.utilityService.returnLocalStorageData('userId'),
      id: this.moduleList1.toString()
    };
    this.binaryService.removeDefault(data).subscribe(response => {
      this.removeScript.hide();
      if(response){
      this.getAlldefaultScript();
      }
      this.utilityService.popToast('success','Success', 3000 , 'Delete default successfully.');
      this.spinner.hide();
    }, error => {
      // this.utilityService.popToast('error','Error', 3000 , error);
    });
  }
  /**
   * @author TR
   * @date : 20-07-2020
   * placebet
   * @method: POST
   */

  marketPlaceBet(data , type) {
    this.spinner.show();
    var sellPrice = $('#' + data.instrumentToken + '_buy_price_0_single_input').val();
    var buyPrice = $('#' + data.instrumentToken + '_sell_price_0_single_input').val();
    this.usersPartnership = this.commonService.getLocalStorage();
    this.usersPartnership = JSON.parse(this.usersPartnership.userData);

    let userData = this.utilityService.returnLocalStorageData('userData')
    let ip = this.utilityService.returnLocalStorageData('ip')
    let userId = this.utilityService.returnLocalStorageData('userId')
    let placeReq = {
      InstrumentId: data._id,
      InstrumentToken: data.instrumentToken,
      // userId: userId,
      orderPrice: (this.betObj.orderType === 'StopLoss' || this.betObj.orderType === 'Limit') ? this.betObj.limit : (type === 'BUY') ? buyPrice : sellPrice,
      quantity: this.betObj.qty,
      type: type,
      orderType: this.betObj.orderType,
      // expiryDate: data.expiry,
      // ipAddress: ip,
      // masterIds: this.usersPartnership.masterId,
      // parentId: this.usersPartnership.parentId,
      // tradingsymbol: data.tradingsymbol
    }
    if(this.subscriptionDetail){
      this.clearSubscription(this.subscriptionDetail);
    }
    this.openBetModal.hide();

    this.binaryService.placeBet(placeReq).subscribe(response => {
      this.betObj.orderType = 'MARKET';
      this.betObj.qty = 1;
      this.betObj.limit = '0';
      if (response.status === true) {
        this.playAudio();
        this.utilityService.popToast('success', 'Success', 1500, response.message);
        this.spinner.hide();
      } else {
        this.spinner.hide();
        this.utilityService.popToast('error', 'Error', 1500, response.message);
      }
    }, error => {
      this.betObj.orderType = 'MARKET';
      this.betObj.qty = 1;
      this.betObj.limit = '0';
      this.spinner.hide();
      this.utilityService.popToast('error','Error', 3000 , error);
    });
  }


  getAllTransactionForMarket(){
    let data = {
      "draw": 1,
      "columns": [
        {
          "data": "userId",
          "name": "",
          "searchable": true,
          "orderable": true,
          "search": {
            "value": "",
            "regex": false
          }
        }
      ],
      "order": [
        {
          "column": 0,
          "dir": "asc"
        }
      ],
      "start": 0,
      "length": 25,
      "search": {
        "value": "",
        "regex": false
      },
      "userId": this.utilityService.returnLocalStorageData('userId')
    }
    this.binaryService.getAllTransaction(data).subscribe(response => {
      this.transactionResponse = response.data.docs;
      this.pendingOrder = _.filter(this.transactionResponse , function (rest) {
        if(rest.orderStatus === 'PENDING'){
          return rest;
        }
      });

      this.completedOrder = _.filter(this.transactionResponse , function (rest) {
        if(rest.orderStatus === 'COMPLETED'){
          return rest;
        }
      });
      // this.utilityService.popToast('success','Success', 3000 , 'Delete default successfully.');
      this.spinner.hide();
    }, error => {
      // this.utilityService.popToast('error','Error', 3000 , error);
    });
  }

  getAllOpenPosition(){
    let data = {
      userId : this.utilityService.returnLocalStorageData('userId')
    };
    this.binaryService.getAllOpenPosition(data).subscribe(response => {
      let instrumentTokenAry = [];
      this.openPositionResponse = response.data;
      this.openPositionResponse.map((ite, index) =>{
        instrumentTokenAry.push(ite.instrumentToken);
      });
      let tokenIds =  instrumentTokenAry.toString();
      var requested = {
        "roomId": "instrumentSocket_" + this.userId,
        "instrument_token": tokenIds,
        "uniqId":this.commonService.getRandomString(10),
        "response_type" : 'full'
      };
      if(this.subscription){
        this.clearSubscription(this.subscriptionInstrument);
      }
      var observable = interval(600);
      this.subscriptionInstrument = observable.subscribe(x => {
        this.socketServiceBbMarket.setInstrument(JSON.stringify(requested));
      });
      this.getRate();
      // this.utilityService.popToast('success','Success', 3000 , 'Delete default successfully.');
      if(this.openPositionResponse.length > 0){
        setInterval(function()
          {
            const cls = document.getElementById('#MarketWatchM2M').getElementsByTagName('td');
            var sum = 0;
            for (var i = 0; i < cls.length; i++){
              if(cls[i].className === 'rate-td width-25 text-center f-12 l-h-33 countableSec red-color'){
                sum += isNaN(Number(cls[i].innerHTML)) ? 0 : Number(cls[i].innerHTML);
              } else if (cls[i].className === 'rate-td width-25 text-center f-12 l-h-33 countableSec green-color') {
                sum += isNaN(Number(cls[i].innerHTML)) ? 0 : Number(cls[i].innerHTML);
              }
            }
            let balance = $('#balanceCl').text();

            let checkVal = Math.sign(sum);
            if(checkVal > 0) {
              const pl = Number(balance) + sum;
              const totalPlPos = String(pl.toFixed(2));
              $('#netPL').html(totalPlPos);
              $('#m2mTotal').removeClass('red-color').addClass('green-color');
              $('#netPL').removeClass('red-color').addClass('green-color');

              //Mob view
              $('#netPLMob').html(totalPlPos);
              $('#m2mTotalMob').removeClass('red-color').addClass('green-color');
              $('#netPLMob').removeClass('red-color').addClass('green-color');
            } else {
              const pls = Number(balance) + sum;
              const totalPlNG = String(pls.toFixed(2));
              $('#netPL').html(totalPlNG);
              $('#m2mTotal').removeClass('green-color').addClass('red-color');
              $('#netPL').removeClass('green-color').addClass('red-color');

              // Mobile View
              $('#netPLMob').html(totalPlNG);
              $('#m2mTotalMob').removeClass('green-color').addClass('red-color');
              $('#netPLMob').removeClass('green-color').addClass('red-color');
            }
            let total = String(sum.toFixed(2));
            $('#m2mTotal').html(total);
            $('#m2mTotalMob').html(total);
          },
          3000);
      }
      this.spinner.hide();
    }, error => {
      // this.utilityService.popToast('error','Error', 3000 , error);
    });
  }

  getAllBalance(){
    let data = {
      userId : this.utilityService.returnLocalStorageData('userId')
    };
    this.binaryService.getAllBalance(data).subscribe(response => {
      this.allBalance = response.data;
       // this.utilityService.popToast('success','Success', 3000 , 'Get Balance successfully.');
      this.spinner.hide();
    }, error => {
      // this.utilityService.popToast('error','Error', 3000 , error);
    });
  }
  playAudio(){
    let audio = new Audio();
    audio.src = '../../../assets/audio/notification-1.ogg';
    audio.load();
    audio.play();
  }

  getAllDeals(){
    let datas = {
      userId : this.utilityService.returnLocalStorageData('userId'),
      type: 'client'
    };
    this.binaryService.getAllDeals(datas).subscribe(response => {
      this.allDeals = response.data;
      // this.utilityService.popToast('success','Success', 3000 , 'Get Deals successfully.');
      this.spinner.hide();
    }, error => {
       this.utilityService.popToast('error','Error', 3000 , error);
    });
  }


  deletePending(data){
    this.spinner.show();
    let datas = {
      trnxId:data._id,
      type:data.type,
      orderType:data.orderType
    }

    this.binaryService.deletePendingOrder(datas).subscribe(response => {
      if(response && response.status){
        this.utilityService.popToast('success','Success', 3000 , 'Delete  successfully.');
        this.getAllTransactionForMarket();
      }else {
        this.utilityService.popToast('error','Error', 3000 , response.message);
      }
      this.spinner.hide();
    }, error => {
      this.spinner.hide();
       this.utilityService.popToast('error','Error', 3000 , error);
    });
  }
}

