import { HeaderComponent } from './../../header/header.component';
import {Component, OnInit, ViewChild, ElementRef, AfterContentInit, AfterViewInit} from '@angular/core';
import {ActivatedRoute, Router,NavigationEnd} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

import * as $ from 'jquery';
import {PlacebetService} from '../../services/placebet.service';
import {CommonService} from '../../services/common.service';
import {MarketService} from '../../services/market.service';
import {FancyService} from '../../services/fancy.service';
import {SocketService} from '../../globals/socketService';
import {SocketServiceClient} from '../../globals/socketServiceClient';
import { SocketServiceBbMarket } from './../../globals/socketServiceBbMarket';


import * as env from '../../globals/env';
import {LockGameService} from '../../services/lockGame.service';
import { retry } from 'rxjs/internal/operators';
import { allSettled, timeout } from 'q';
import {CurrencyService} from '../../services/currency.service';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { ModalDirective } from 'ngx-bootstrap';

import {isUndefined} from 'util';
import {SocketServiceRedis} from '../../globals/socketServiceRedis';
import {UtilityService} from '../../globals/utilityService';
import _ from "lodash";
@Component({
  selector: 'app-game-view',
  templateUrl: './game-view.component.html',
  styleUrls: ['./game-view.component.scss'],
  providers : [HeaderComponent]
})
export class GameViewComponent implements OnInit , AfterContentInit, AfterViewInit {
  @ViewChild('betview', { static: false }) betview: ModalDirective;
  @ViewChild('betviewLine', { static: false }) betviewLine: ModalDirective;
  @ViewChild('betviewall', { static: false }) betviewall: ModalDirective;
  @ViewChild('placeBetModel', { static: false }) placeBetModel: ModalDirective;
  @ViewChild('betviewMatchOdds', { static: false }) betviewMatchOdds: ModalDirective;
  @ViewChild('chart', { static: false }) chart: ModalDirective;

  safeSrc: SafeResourceUrl;
  safeSrcimg = '';
  constructor(

    private route: ActivatedRoute,
    private socketService: SocketService,
    private socketServiceClient: SocketServiceClient,
    private socketServiceBbMarket: SocketServiceBbMarket,
    private socketServiceRedis: SocketServiceRedis,
    private fancyService: FancyService,
    private utilityService: UtilityService,
    private marketService: MarketService,
    private lockGameService: LockGameService,
    private commonService: CommonService,
    private hostElement: ElementRef,
    private currencyService: CurrencyService,
    private placebetService: PlacebetService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private sanitizer: DomSanitizer,
    private headerComponent:HeaderComponent
    ) {
      this.router.events.subscribe((e) => {
        if (e instanceof NavigationEnd) {
        }
     });

  }
  no2;
  no2Vol;
  yes2;
  yes2Vol;
  fancyData = [];
  stack: any;
  currencyAll: any;
  lineId: any;
  getMarketByIds: any = [];
  getMarketById: any;
  getMarketCheckActiveBat: any;
  marketId: any;
  tvFeet= false;
  channelUrl: any;
  matchOddsData: any;
  bookmakerData: any;
  modeSetting: any;
  fancyMarketData: any;
  lineMarketData: any;
  allTransactions = [];
  allTransactionsAsMatch: [];
  allTransactionsAsLine: [];
  usersPartnership: any;
  lockGame = false;
  betLock = true;
  apiObj: any;
  channelFeed: any;
  checkSport: any;
  lockGameObj: any;
  mycurrentRoute: any;
  chartAry = [];
  users = this.commonService.getLocalStorage();
  userId = this.users.userId;
  chartFancyName: any;
  lastJoinRoom: any = '';
  marketSel: any = '';
  bookmakerId: any = '';
  roomPrfx: any = 'odds_';
  currentTranPro: any = 0;
  Toast = {
    type: '',
    title: '',
    timeout: 0,
    body: ''
  };
  fancyName: any;
  lineName: any;
  marketVolume = 1;
  marketStatus = '';
  allTransactionsAsMatchOdds: any;
  confirmRate: Boolean = false;
  confirmRateMob: Boolean = false;
  marketIdBooKmakerUsed = '';
  endSubmit = false;

  ngOnInit() {
    this.matchOddsData = [];
    this.fancyData = [];
    this.mycurrentRoute = this.router.url;
    this.route.params.subscribe(params => {
      this.confirmRate = false;
      this.confirmRateMob = false;
      this.getMarketByIds = [];
      this.fancyData = [];
      this.lineMarketData = [];
      this.bookmakerData = [];
      const oldMatch = sessionStorage.getItem('lastJoinmatch');
      const oldfancy = sessionStorage.getItem('lastJoinRoom');
      this.socketServiceRedis.leaveRoom(oldfancy);
      this.socketServiceRedis.leaveRoom(oldMatch);
      const id = params.id;
      this.marketId = id;
      const userId = this.utilityService.returnLocalStorageData('userId');
      this.getMarketIdData(this.marketId , userId);
      // this.getAllFancyList();
      this.getUserCurrency();

      sessionStorage.setItem('lastJoinmatch', this.marketId);
      this.socketServiceRedis.joinRoom(this.marketId);
      const transactionObj = {
        marketId: this.marketId,
        userId: this.userId,
        gameId: this.marketId
      };
      this.getAllTransaction(transactionObj);

      const findRecordObj = {
        userId: this.utilityService.returnLocalStorageData('userId'),
        matchId: Number(id),
      };
      this.lockGameObj = findRecordObj;
      this.checkLockGame(this.lockGameObj);
      $('.scoreCard').html('');
    });

    // First join room by marketId
    this.socketService.joinRoom(this.userId);
    this.socketServiceClient.joinRoom(this.userId);

    // socket service market join
    const randomString = this.commonService.getRandomString(10);
    const requested = {
                roomName: randomString,
                subscribe: '55324679,55529479'
            };
    this.socketServiceBbMarket.joinRoom(JSON.stringify(requested));


    this.socketServiceBbMarket
      .getBbMarketRate(randomString)
      .subscribe((response) => {
      });

    this.socketServiceRedis
      .reconnections()
      .subscribe((response) => {
        this.getMarketByIds = [];
        this.fancyData = [];
        this.lineMarketData = [];
        this.bookmakerData = [];
        const oldMatch = sessionStorage.getItem('lastJoinmatch');
        const oldfancy = sessionStorage.getItem('lastJoinRoom');
        this.socketServiceRedis.leaveRoom(oldfancy);
        this.socketServiceRedis.leaveRoom(oldMatch);
        sessionStorage.setItem('lastJoinmatch', this.marketId);
        this.socketServiceRedis.joinRoom(this.marketId);
         // this.getAllFancyList();
        this.getMarketIdData(this.marketId , this.userId);
        this.confirmRateMob = false;
        this.confirmRate =  false;
        const transactionObj = {
          marketId: this.marketId,
          userId: this.userId,
          gameId: this.marketId
        };
        this.getAllTransaction(transactionObj);
        this.getAllTransactionAsMactch(transactionObj);
        this.getAllTransactionAsLine(transactionObj);
        $('.scoreCard').html('');
      });

    this.socketServiceClient
      .cancelMarket()
      .subscribe((response) => {

        const transactionObj = {
          marketId: this.marketId,
          userId: this.userId,
          gameId: this.marketId
        };
        if (response && response.fancyId) {
          this.fancyData = _.filter(this.fancyData, function(user) {
            return user.fancyId !== response.fancyId;
          });
          this.allTransactions = _.filter(this.allTransactions, function(tran) {
            return tran.gameId !== Number(response.fancyId);
          });

          // this.getAllTransaction(transactionObj);
        }
        if (response && response.lineId) {
          this.lineMarketData = _.filter(this.lineMarketData, function(user) {
            return user.lineId !== response.lineId;
          });
          this.allTransactions = _.filter(this.allTransactions, function(tran) {
            return tran.gameId !== response.marketId;
          });
          this.getAllTransactionAsLine(transactionObj);
        }
        if (response && response.marketId) {
          this.matchOddsData = _.filter(this.matchOddsData, function(user) {
            return user.marketId !== response.marketId;
          });
          this.allTransactions = _.filter(this.allTransactions, function(tran) {
            return tran.gameId !== response.marketId;
          });
        }

        if (response && response.marketId && response.marketType === 'Bookmaker') {
          this.bookmakerData = _.filter(this.bookmakerData, function(user) {
            return user.marketId !== response.marketId;
          });
          this.allTransactions = _.filter(this.allTransactions, function(tran) {
            return tran.gameId !== response.marketId;
          });
        }

      });


        this.socketServiceRedis
        .oddsRate()
        .subscribe((response) => {
          if (response) {
            if (response.status === 'OPEN') {
              const linerMarId = response.marketId;
              const marketId = response.marketId.toString().replace('.', '');
              if (this.marketStatus !== 'MS940896') {
                  $('.' + marketId + '_market').removeClass('market_suspend');
                  $('.' + marketId + '_market_mob').removeClass('market_suspend');
              } else {
                  $('.' + marketId + '_market').addClass('market_suspend');
                  $('.' + marketId + '_market_mob').addClass('market_suspend');
              }


              let runners = 0;
              if (response.numberOfRunners) {
                runners = response.numberOfRunners;
              } else {
                runners = response.runners.length;
              }
              if(runners > 3){
                const marketobj = this.matchOddsData.find(o => o.marketId == linerMarId);
                if(marketobj){
                  let matchRunners = this.matchOddsData[0].runners;
                  var indexObject = _.reduce(response.runners, function(result, currentObject) {
                      result[currentObject.selectionId] = currentObject;
                      return result;
                  }, {});
                  response.runners = _.map(matchRunners, function(currentGUID) {
                    return indexObject[currentGUID.selectionId]
                  });
                  //this code is for only cup
                  for (let i = 0; i < runners; i++) {
                    if (marketId === this.marketSel) {
                      let selectionId = response.runners[i].selectionId;
                      const volume = this.marketVolume;
                      if (this.marketStatus === 'MS940896') {
                        $('.' + marketId + '_market').addClass('market_suspend');
                      }
                      const availableBack = response.runners[i].ex.availableToBack;
                        // update bhav to market
                      $('#' + this.marketSel + '_' + i + '_back_0_odds').html((availableBack[0]) ? availableBack[0].price : ''), $('#' + this.marketSel + '_' + i + '_back_0_odds_mob').html((availableBack[0]) ? availableBack[0].price : '');

                      // Start Blinking Rate change Odds
                      const currOddsRate =  $('#' + this.marketSel + '_' + i + '_back_0_odds').text();
                      const prevOddsRate = $('#' + this.marketSel + '_' + i + '_back_0_odds_hiddne').val();

                      if (currOddsRate === prevOddsRate) {
                        $('#' + this.marketSel + '_' + i + '_back_0_odds_blink').removeClass('yellow');
                        $('#' + this.marketSel + '_' + i + '_back_0_odds_mob_blink').removeClass('yellow');
                      } else {
                        $('#' + this.marketSel + '_' + i + '_back_0_odds_blink').addClass('yellow');
                        $('#' + this.marketSel + '_' + i + '_back_0_odds_mob_blink').addClass('yellow');
                      }

                      // End Blinking Rate change Odds
                      $('#' + this.marketSel + '_' + i + '_back_0_vol').html((availableBack[0]) ? String(Math.round(availableBack[0].size * volume)) : ''),   $('#' + this.marketSel + '_' + i + '_back_0_vol_mob').html((availableBack[0]) ? String(Math.round(availableBack[0].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_back_1_odds').html((availableBack[1]) ? availableBack[1].price : ''), $('#' + this.marketSel + '_' + i + '_back_1_odds_mob').html((availableBack[1]) ? availableBack[1].price : '');
                      $('#' + this.marketSel + '_' + i + '_back_1_vol').html((availableBack[1]) ? String(Math.round(availableBack[1].size * volume)) : ''),   $('#' + this.marketSel + '_' + i + '_back_1_vol_mob').html((availableBack[1]) ? String(Math.round(availableBack[1].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_back_2_odds').html((availableBack[2]) ? availableBack[2].price : ''), $('#' + this.marketSel + '_' + i + '_back_2_odds_mob').html((availableBack[2]) ? availableBack[2].price : '');
                      $('#' + this.marketSel + '_' + i + '_back_2_vol').html((availableBack[2]) ? String(Math.round(availableBack[2].size * volume)) : ''),   $('#' + this.marketSel + '_' + i + '_back_2_vol_mob').html((availableBack[2]) ? String(Math.round(availableBack[2].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_back_0_odds_hiddne').val((availableBack[0]) ? availableBack[0].price : '');

                      const availableLay = response.runners[i].ex.availableToLay;
                      $('#' + this.marketSel + '_' + i + '_lay_0_odds').html((availableLay[0]) ? availableLay[0].price : ''), $('#' + this.marketSel + '_'  + i + '_lay_0_odds_mob').html((availableLay[0]) ? availableLay[0].price : '');

                      // Start Blinking Rate change Lays
                      const currLaysRate =  $('#' + this.marketSel + '_' + i + '_lay_0_odds').text();
                      const prevLaysRate =  $('#' + this.marketSel + '_' + i + '_lay_0_odds_hiddne').val();
                      if (currLaysRate === prevLaysRate) {
                        $('#' + this.marketSel + '_' + i + '_lay_0_odds_blink').removeClass('yellow');
                        $('#' + this.marketSel + '_' + i + '_lay_0_odds_mob_blink').removeClass('yellow');
                      } else {
                        $('#' + this.marketSel + '_' + i + '_lay_0_odds_blink').addClass('yellow');
                        $('#' + this.marketSel + '_' + i + '_lay_0_odds_mob_blink').addClass('yellow');
                      }
                      // End Blinking Rate change Lays

                      $('#' + this.marketSel + '_' + i + '_lay_0_vol').html((availableLay[0]) ? String(Math.round(availableLay[0].size * volume)) : ''),   $('#' + this.marketSel + '_'  + i + '_lay_0_vol_mob').html((availableLay[0]) ? String(Math.round(availableLay[0].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_lay_1_odds').html((availableLay[1]) ? availableLay[1].price : ''), $('#' + this.marketSel + '_'  + i + '_lay_1_odds_mob').html((availableLay[1]) ? availableLay[1].price : '');
                      $('#' + this.marketSel + '_' + i + '_lay_1_vol').html((availableLay[1]) ? String(Math.round(availableLay[1].size * volume)) : ''),   $('#' + this.marketSel + '_'  + i + '_lay_1_vol_mob').html((availableLay[1]) ? String(Math.round(availableLay[1].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_lay_2_odds').html((availableLay[2]) ? availableLay[2].price : ''), $('#' + this.marketSel + '_'  + i + '_lay_2_odds_mob').html((availableLay[2]) ? availableLay[2].price : '');
                      $('#' + this.marketSel + '_' + i + '_lay_2_vol').html((availableLay[2]) ? String(Math.round(availableLay[2].size * volume)) : ''),   $('#' + this.marketSel + '_'  + i + '_lay_2_vol_mob').html((availableLay[2]) ? String(Math.round(availableLay[2].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_lay_0_odds_hiddne').val((availableLay[0]) ? availableLay[0].price : '');
                    }
                    if (this.lineMarketData) {
                      const linerobj = this.lineMarketData.find(o => o.marketId === linerMarId);
                      if (linerobj) {
                        if (linerobj.lineMode == 'Auto') {
                          let lineMultipler = 0;
                          if (linerobj.lineSetting) {
                            lineMultipler = linerobj.lineSetting.MultiplierVolume;
                          }

                          // console.log("lineMultipler++++++++++++++++++++++",lineMultipler);
                            // In live market rate is reverse
                          const availableBack = response.runners[i].ex.availableToLay;
                          $('#' + linerobj.marketIdDec + '_back').html((availableBack[0]) ? String(Math.round(availableBack[0].price)) : ''), $('#' + linerobj.marketIdDec + '_back_mob').html((availableBack[0]) ? String(Math.round(availableBack[0].price)) : '');
                          $('#' + linerobj.marketIdDec + '_back_vol').html((availableBack[0]) ? String(Math.round(availableBack[0].size * lineMultipler)) : ''),   $('#' + linerobj.marketIdDec + '_back_mob_vol').html((availableBack[0]) ? String(Math.round(availableBack[0].size * lineMultipler)) : '');

                          const availableLay = response.runners[i].ex.availableToBack;
                          $('#' + linerobj.marketIdDec + '_lay').html((availableLay[0]) ? String(Math.round(availableLay[0].price)) : ''), $('#' + linerobj.marketIdDec + '_lay_mob').html((availableLay[0]) ? String(Math.round(availableLay[0].price)) : '');
                          $('#' + linerobj.marketIdDec + '_lay_vol').html((availableLay[0]) ? String(Math.round(availableLay[0].size * lineMultipler)) : ''), $('#' + linerobj.marketIdDec + '_lay_mob_vol').html((availableLay[0]) ? String(Math.round(availableLay[0].size * lineMultipler)) : '');
                        }
                      }
                    }
                  }
                }
              }

                //this code is for only market
                for (let i = 0; i < runners; i++) {
                    if (marketId === this.marketSel) {
                      let selectionId = response.runners[i].selectionId;
                      const volume = this.marketVolume;
                      if (this.marketStatus === 'MS940896') {
                        $('.' + marketId + '_market').addClass('market_suspend');
                      }
                      const availableBack = response.runners[i].ex.availableToBack;
                        // update bhav to market
                      $('#' + this.marketSel + '_' + i + '_back_0_odds').html((availableBack[0]) ? availableBack[0].price : ''), $('#' + this.marketSel + '_' + i + '_back_0_odds_mob').html((availableBack[0]) ? availableBack[0].price : '');

                      // Start Blinking Rate change Odds
                      const currOddsRate =  $('#' + this.marketSel + '_' + i + '_back_0_odds').text();
                      const prevOddsRate = $('#' + this.marketSel + '_' + i + '_back_0_odds_hiddne').val();

                      if (currOddsRate === prevOddsRate) {
                        $('#' + this.marketSel + '_' + i + '_back_0_odds_blink').removeClass('yellow');
                        $('#' + this.marketSel + '_' + i + '_back_0_odds_mob_blink').removeClass('yellow');
                      } else {
                        $('#' + this.marketSel + '_' + i + '_back_0_odds_blink').addClass('yellow');
                        $('#' + this.marketSel + '_' + i + '_back_0_odds_mob_blink').addClass('yellow');
                      }

                      // End Blinking Rate change Odds
                      $('#' + this.marketSel + '_' + i + '_back_0_vol').html((availableBack[0]) ? String(Math.round(availableBack[0].size * volume)) : ''),   $('#' + this.marketSel + '_' + i + '_back_0_vol_mob').html((availableBack[0]) ? String(Math.round(availableBack[0].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_back_1_odds').html((availableBack[1]) ? availableBack[1].price : ''), $('#' + this.marketSel + '_' + i + '_back_1_odds_mob').html((availableBack[1]) ? availableBack[1].price : '');
                      $('#' + this.marketSel + '_' + i + '_back_1_vol').html((availableBack[1]) ? String(Math.round(availableBack[1].size * volume)) : ''),   $('#' + this.marketSel + '_' + i + '_back_1_vol_mob').html((availableBack[1]) ? String(Math.round(availableBack[1].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_back_2_odds').html((availableBack[2]) ? availableBack[2].price : ''), $('#' + this.marketSel + '_' + i + '_back_2_odds_mob').html((availableBack[2]) ? availableBack[2].price : '');
                      $('#' + this.marketSel + '_' + i + '_back_2_vol').html((availableBack[2]) ? String(Math.round(availableBack[2].size * volume)) : ''),   $('#' + this.marketSel + '_' + i + '_back_2_vol_mob').html((availableBack[2]) ? String(Math.round(availableBack[2].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_back_0_odds_hiddne').val((availableBack[0]) ? availableBack[0].price : '');

                      const availableLay = response.runners[i].ex.availableToLay;
                      $('#' + this.marketSel + '_' + i + '_lay_0_odds').html((availableLay[0]) ? availableLay[0].price : ''), $('#' + this.marketSel + '_'  + i + '_lay_0_odds_mob').html((availableLay[0]) ? availableLay[0].price : '');

                      // Start Blinking Rate change Lays
                      const currLaysRate =  $('#' + this.marketSel + '_' + i + '_lay_0_odds').text();
                      const prevLaysRate =  $('#' + this.marketSel + '_' + i + '_lay_0_odds_hiddne').val();
                      if (currLaysRate === prevLaysRate) {
                        $('#' + this.marketSel + '_' + i + '_lay_0_odds_blink').removeClass('yellow');
                        $('#' + this.marketSel + '_' + i + '_lay_0_odds_mob_blink').removeClass('yellow');
                      } else {
                        $('#' + this.marketSel + '_' + i + '_lay_0_odds_blink').addClass('yellow');
                        $('#' + this.marketSel + '_' + i + '_lay_0_odds_mob_blink').addClass('yellow');
                      }
                      // End Blinking Rate change Lays

                      $('#' + this.marketSel + '_' + i + '_lay_0_vol').html((availableLay[0]) ? String(Math.round(availableLay[0].size * volume)) : ''),   $('#' + this.marketSel + '_'  + i + '_lay_0_vol_mob').html((availableLay[0]) ? String(Math.round(availableLay[0].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_lay_1_odds').html((availableLay[1]) ? availableLay[1].price : ''), $('#' + this.marketSel + '_'  + i + '_lay_1_odds_mob').html((availableLay[1]) ? availableLay[1].price : '');
                      $('#' + this.marketSel + '_' + i + '_lay_1_vol').html((availableLay[1]) ? String(Math.round(availableLay[1].size * volume)) : ''),   $('#' + this.marketSel + '_'  + i + '_lay_1_vol_mob').html((availableLay[1]) ? String(Math.round(availableLay[1].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_lay_2_odds').html((availableLay[2]) ? availableLay[2].price : ''), $('#' + this.marketSel + '_'  + i + '_lay_2_odds_mob').html((availableLay[2]) ? availableLay[2].price : '');
                      $('#' + this.marketSel + '_' + i + '_lay_2_vol').html((availableLay[2]) ? String(Math.round(availableLay[2].size * volume)) : ''),   $('#' + this.marketSel + '_'  + i + '_lay_2_vol_mob').html((availableLay[2]) ? String(Math.round(availableLay[2].size * volume)) : '');
                      $('#' + this.marketSel + '_' + i + '_lay_0_odds_hiddne').val((availableLay[0]) ? availableLay[0].price : '');
                    }
                    if (this.lineMarketData) {
                      const linerobj = this.lineMarketData.find(o => o.marketId === linerMarId);
                      if (linerobj) {
                        if (linerobj.lineMode == 'Auto') {
                          let lineMultipler = 0;
                          if (linerobj.lineSetting) {
                            lineMultipler = linerobj.lineSetting.MultiplierVolume;
                          }

                          // console.log("lineMultipler++++++++++++++++++++++",lineMultipler);
                            // In live market rate is reverse
                          const availableBack = response.runners[i].ex.availableToLay;
                          $('#' + linerobj.marketIdDec + '_back').html((availableBack[0]) ? String(Math.round(availableBack[0].price)) : ''), $('#' + linerobj.marketIdDec + '_back_mob').html((availableBack[0]) ? String(Math.round(availableBack[0].price)) : '');
                          $('#' + linerobj.marketIdDec + '_back_vol').html((availableBack[0]) ? String(Math.round(availableBack[0].size * lineMultipler)) : ''),   $('#' + linerobj.marketIdDec + '_back_mob_vol').html((availableBack[0]) ? String(Math.round(availableBack[0].size * lineMultipler)) : '');

                          const availableLay = response.runners[i].ex.availableToBack;
                          $('#' + linerobj.marketIdDec + '_lay').html((availableLay[0]) ? String(Math.round(availableLay[0].price)) : ''), $('#' + linerobj.marketIdDec + '_lay_mob').html((availableLay[0]) ? String(Math.round(availableLay[0].price)) : '');
                          $('#' + linerobj.marketIdDec + '_lay_vol').html((availableLay[0]) ? String(Math.round(availableLay[0].size * lineMultipler)) : ''), $('#' + linerobj.marketIdDec + '_lay_mob_vol').html((availableLay[0]) ? String(Math.round(availableLay[0].size * lineMultipler)) : '');
                        }
                      }
                    }
                }

            } else {
              let market_id = response.marketId.toString().replace('.', '');
              $('.' + market_id + '_market').addClass('market_suspend');
              $('.' + market_id + '_market_mob').addClass('market_suspend');
            }
          }
        });


    this.socketServiceRedis
      .fancyRate()
      .subscribe((response) => {
        if (response) {
          //find fancy from auto response
          const fancyobj = this.fancyData.find(o => o.fancyId == response.srno);
          if (fancyobj) {
              if (fancyobj.fancyMode == 'Auto') {
                appendStatus(fancyobj.fancyId, 'active');
                this.appendFancyRateAuto(response);
              }
          }else{
            appendStatus(response.srno, 'active');
            this.appendFancyRateAuto(response);
          }

           //find fancy from auto response
          if(this.bookmakerData && this.bookmakerData.length > 0) {
          //  const bookmakerObj = this.bookmakerData.find(o => o.marketId == response.srno);
            if(this.bookmakerData[0].marketId  == response.srno){
              this.appendBMRateAuto(this.bookmakerData[0], response);
            }
          }
        }
      }, this);



    this.socketService
    .getRate()
    .subscribe((response) => {
      if (response.type == 'line') {
        const marketId = response.id.toString().replace('.', '');
        const data = response.data;
        $('#' + marketId + '_lay').html(data.no2), $('#' + marketId + '_lay_mob').html(data.no2);
        $('#' + marketId + '_lay_vol').html(data.no2Vol), $('#' + marketId + '_lay_mob_vol').html(data.no2Vol);
        $('#' + marketId + '_back').html(data.yes2), $('#' + marketId + '_back_mob').html(data.yes2);
        $('#' + marketId + '_back_vol').html(data.yes2Vol), $('#' + marketId + '_back_mob_vol').html(data.yes2Vol);
        appendStatusLine(marketId, 'active');
      } else {
        const fancyId = response.data.fancyId;
        $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId + ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
        $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId + + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

        $('#' + fancyId + '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId + '_first,#mob_' + fancyId + '_third,#' + fancyId + '_forth').hide();
        $('#' + fancyId + '_second').removeClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').removeClass('fancy_ballstart');
        $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');
        appendRate(response.data);
        appendStatus(fancyId, 'active');
      }
     });

    this.socketServiceRedis
    .getScoreCard()
    .subscribe((response) => {
      if (response) {
          if(response.data && response.data != 'null'){
            // $('.scoreCard').css('display','block');
            $('.scoreCard').html(response.data);
        }else {
            $('.scoreCard').html('');
            // $('.scoreCard').css('display','none');
          }
      }
     });

    this.socketService
    .changeFlag()
    .subscribe((response) => {
      if (response) {
      }
    });

    this.socketServiceClient
      .BetLock()
      .subscribe((response) => {
        if (response) {
          if(response == this.marketId && this.mycurrentRoute === '/sports/game-view/' + response){
            this.router.navigateByUrl('/dashboard');
          }
        }
      });
    // this.socketService
    //   .BetLock()
    //   .subscribe((response) => {
    //     if (response) {
    //       alert(this.mycurrentRoute)
    //       if(this.mycurrentRoute === '/sports/game-view/' + response){
    //
    //         this.router.navigateByUrl('/dashboard');
    //       }
    //     }
    //   });

    this.socketServiceClient
    .fancySettled()
    .subscribe((response) => {
      if (response) {
        const transactionObjs = {
          gameId: this.marketId,
          marketId: this.marketId,
          userId: this.userId
        };
        if (response && response.marketType == 'Fancy') {
          this.fancyData = _.filter(this.fancyData, function(user) {
            return user.fancyId !== response.fancyId;
          });
          if (this.matchOddsData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0 || this.bookmakerData.length > 0) {
          } else {
             if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
              }
          }

          this.allTransactions = _.filter(this.allTransactions, function(tran) {
            return Number(tran.gameId) !== Number(response.fancyId);
          });

          // this.getAllTransaction(transactionObjs);
        } else if (response && response.marketType == 'Line') {
          this.lineMarketData = _.filter(this.lineMarketData, function(user) {
            return user.lineId !== response.lineId;
          });
          if (this.matchOddsData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0 || this.bookmakerData.length > 0) {
          } else {
            if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
            }
          }
          this.getAllTransactionAsLine(transactionObjs);
          this.allTransactions = _.filter(this.allTransactions, function(tran) {
            return tran.gameId !== response.marketId;
          });
        } else if(response && response.marketType == 'Bookmaker') {
          this.bookmakerData = _.filter(this.bookmakerData, function(user) {
            return user.marketId !== response.marketId;
          });
          if (this.matchOddsData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0 || this.bookmakerData.length > 0) {
          } else {
            if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
            }
          }
          this.getAllTransactionAsMactch(transactionObjs);
          this.allTransactions = _.filter(this.allTransactions, function(tran) {
            return tran.gameId !== response.marketId;
          });
        }else {
          this.matchOddsData = _.filter(this.matchOddsData, function(user) {
            return user.marketId !== response.marketId;
          });
          if (this.matchOddsData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0 || this.bookmakerData.length > 0) {
          } else {
            if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
            }
          }
          this.getAllTransactionAsMactch(transactionObjs);
          this.allTransactions = _.filter(this.allTransactions, function(tran) {
            return tran.gameId !== response.marketId;
          });
        }
      }
    });

    this.socketServiceClient
    .marketCreate()
    .subscribe((response) => {
      if (response && response.lineId) {
        let lastJoinrm = [];
        lastJoinrm = JSON.parse(sessionStorage.getItem('lastJoinRoom'));
        lastJoinrm.push(response.marketId);
        sessionStorage.setItem('lastJoinRoom', JSON.stringify(lastJoinrm));

        const markId = response.marketId.toString().replace('.', '');
        if (response.marketStatus.id === 'MS940896') {
          appendStatusLine(markId, 'suspend');
        }
        if (response.isActive) {

          const count = _.filter(this.lineMarketData, function(user) {
            return user.lineId === response.lineId;
          });
          if (count.length > 0) {

          } else {
            if (this.marketId === response.match.id) {
              response.marketIdDec = markId;
              this.lineMarketData.push(response);
              if (response.marketStatus.id === 'MS940896') {
                appendStatus(response.lineId, 'suspend');
              }
            }
          }
        }

        this.socketServiceRedis.joinRoom(response.marketId); // socket join room
      }
      if (response && response.marketType === 'Bookmaker') {
        let lastJoinrm = [];
        lastJoinrm = JSON.parse(sessionStorage.getItem('lastJoinRoom'));
        lastJoinrm.push(response.marketId);
        sessionStorage.setItem('lastJoinRoom', JSON.stringify(lastJoinrm));

        const markId = response.marketId.toString().replace('.', '');
        if (response.marketStatus.id === 'MS940896') {
          appendStatus(markId, 'suspend');
        }
        if (response.isActive) {
          const count = _.filter(this.bookmakerData, function(user) {
            return user.marketId === response.marketId;
          });
          if (count.length > 0) {

          } else {
            if (this.marketId === response.match.id) {
              response.marketIdDec = markId;
              response.exposer = {
                "AMOUNT": 0,
                "RUNNERS": []
              };
              this.bookmakerData.push(response);
              if (response.marketStatus.id === 'MS940896') {
                appendStatus(response.marketIdDec, 'suspend');
              }
            }
          }
        }
        this.socketServiceRedis.joinRoom(response.marketId); // socket join room
      }
    });

    this.socketService
    .getLineRate()
    .subscribe((response) => {
      if (response) {
          if (response.manualRes != null) {
            response = JSON.parse(response.manualRes);
            const marketId = response.id.toString().replace('.', '');
            const linerobj = this.lineMarketData.find(o => o.marketId == response.id);
            if (linerobj) {
                if (linerobj.lineMode == 'Manual') {
                  const data = response;
                  $('#' + marketId + '_lay').html(data.no2), $('#' + marketId + '_lay_mob').html(data.no2);
                  $('#' + marketId + '_lay_vol').html(data.no2Vol), $('#' + marketId + '_lay_mob_vol').html(data.no2Vol);
                  $('#' + marketId + '_back').html(data.yes2), $('#' + marketId + '_back_mob').html(data.yes2);
                  $('#' + marketId + '_back_vol').html(data.yes2Vol), $('#' + marketId + '_back_mob_vol').html(data.yes2Vol);
                }
            }
          }
      }
    });


    this.socketService
    .getLineStatus()
    .subscribe((response) => {
      if (response) {
          const marketId = response.marketId.toString().replace('.', '');
          if (response.status == 'MS950763') {
            response.status = 'ballstart';
            appendStatusLine(marketId, response.status);
          } else if (response.status == 'MS940896') {
            response.status = 'suspend';
            appendStatusLine(marketId, response.status);
          }
      }
    });



    this.socketService
    .changeMode()
    .subscribe((response) => {
      if (response) {
        if (response.data.data.marketType == 'Fancy') {
          const modeSetting = response.data.data.fancyMode;
          const fancyId = response.data.data.fancyId;
          if (modeSetting == 'Auto') {
              this.socketServiceRedis.joinRoom(fancyId);
              appendStatus(fancyId, 'active');
           } else {
              appendStatus(fancyId, 'ballstart');
           }
          const fanobj =  this.fancyData.find(o => o.fancyId == response.data.data.fancyId);
          if (fanobj) {
            fanobj.fancyMode = response.data.data.fancyMode;
           }
        } else {
          this.modeSetting = response.data.data.lineMode;
          const marketId = response.data.data.marketId.toString().replace('.', '');
          $('#' + marketId + '_lay' + ',#' + marketId + '_back' + ',#' + marketId + '_lay_mob' + ',#' + marketId + '_back_mob').html('');
          $('#' + marketId + '_lay_vol' + ',#' + marketId + '_back_vol' + ',#' + marketId + '_lay_mob_vol' + ',#' + marketId + '_back_mob_vol' ).html('');
          $('#' + marketId + '_line').removeClass('fancy_suspend'), $('#' + marketId + '_mob_line').removeClass('fancy_suspend');
          $('#' + marketId + '_line').addClass('fancy_ballstart'), $('#' + marketId + '_mob_line').addClass('fancy_ballstart');
          if (this.modeSetting == 'Auto') {
             setTimeout(function() {
               $('#' + marketId + '_line').removeClass('fancy_ballstart');
             }, 2000);
           }
          const linerobj = this.lineMarketData.find(o => o.marketId == response.data.data.marketId);
          if (linerobj) {
             linerobj.lineMode = response.data.data.lineMode;
           }
        }
      }
    });


    this.socketServiceClient
    .deleteBet()
    .subscribe((response) => {
      if (response) {
          this.allTransactions = _.filter(this.allTransactions, function(user) {
            return user._id !== response._id;
          });
      }
    });

    // this.socketServiceClient
    // .getPlaceBet()
    // .subscribe((response) => {
    //   if (response) {
    //       this.allTransactions.push(response)
    //   }
    // });

    this.socketServiceClient
    .updateSport()
    .subscribe((response) => {
          if (response.isActive) {
          } else {
            const sportUnqId = String(response.id);
            if (this.checkSport[0].sport.id === sportUnqId) {
              this.router.navigateByUrl('dashboard');
            }
          }
    });

    this.socketServiceClient
      .updateTournament()
      .subscribe((response) => {
        if (response.isActive) {
        } else {
          const sportUnqId = String(response.id);
          if (this.checkSport[0].tournament.id === sportUnqId) {
            this.router.navigateByUrl('dashboard');
          }
        }
      });

    this.socketServiceClient
      .updateMatch()
      .subscribe((response) => {
        if (response.isActive) {
        } else {
          const sportUnqId = String(response.id);
          if (this.checkSport[0].match.id === sportUnqId) {
            this.router.navigateByUrl('dashboard');
          }
        }
        const currentUser = this.utilityService.returnLocalStorageData('userId');
        const matchIds = String(response.id);
        if (response.isPlay && matchIds === this.marketId) {
            // this.getMarketIdData(this.marketId, currentUser);
          $('#' + matchIds + '_inPlay').removeClass('noPlay');
          $('#' + matchIds + '_inPlay').addClass('inPlay');
          $('#' + matchIds + '_inPlayMob').removeClass('noPlay');
          $('#' + matchIds + '_inPlayMob').addClass('inPlay');
          } else {
          $('#' + matchIds + '_inPlay').removeClass('inPlay');
          $('#' + matchIds + '_inPlay').addClass('noPlay');
          $('#' + matchIds + '_inPlayMob').removeClass('inPlay');
          $('#' + matchIds + '_inPlayMob').addClass('noPlay');
        }
      });

    this.socketServiceClient
      .fancyAutoUpdate()
      .subscribe((response) => {
        if (response.isActive) {
          const count = _.filter(this.fancyData, function(user) {
            return user.fancyId === response.fancyId;
          });
          if (count.length > 0) {
            this.fancyData = _.filter(this.fancyData, function(user) {
              if (user.fancyId === response.fancyId) {
                return response;
              }
            });
          } else {
            if (this.marketId === response.match.id) {
              this.fancyData.push(response);
            }
          }
        } else {
          this.fancyData = _.filter(this.fancyData, function(user) {
            return user.fancyId !== response.fancyId;
          });
        }
      });

    this.socketServiceClient
      .fancyAdd()
      .subscribe((response) => {
        const fncy = this.fancyData;
        const matchId = Number(this.marketId);
        let socket = this.socketServiceRedis ;
        _.map(response, function(fancyData) {
          let matchIdRes = Number(fancyData.match.id)
          if (fancyData.fancyMode === 'Auto') {
            let lastJoinrm;
            lastJoinrm = JSON.parse(sessionStorage.getItem('lastJoinRoom'));
            lastJoinrm.push(fancyData.fancyId);
            socket.joinRoom(fancyData.fancyId); // socket join room
            sessionStorage.setItem('lastJoinRoom', JSON.stringify(lastJoinrm));
          }
          if (fancyData.isActive && matchId === matchIdRes) {
            fancyData.exposer = 0;
            fncy.push(fancyData);
          }
        }, this);
        // this.fancyData = fncy;
        // this.fancyData = _.sortBy(this.fancyData);
        this.fancyData = _.sortBy(fncy, function(fancyObj) {
          return fancyObj.displayOrder;
        });
        setTimeout(res => {
          _.map(response, function(fancyData) {
            appendStatus(fancyData.fancyId, 'suspend');
          });
        }, 500);

      });

    this.socketServiceClient
    .suspendStatus()
    .subscribe((response) => {
      if (response && response.fancyId) {
        if (response.isActive) {
          const count = _.filter(this.fancyData, function(user) {
            if(user.fancyId == response.fancyId){
            user.fancySetting = response.fancySetting;
            }
            return user.fancyId === response.fancyId;
          });
          if (count.length > 0) {

          } else {
            if (this.marketId === response.match.id) {

              this.fancyData.push(response);
              const fancyObj = {
                    fancy : response.fancyId
                  };
              this.fancyData = _.sortBy(this.fancyData, function(fancyObj) {
                return fancyObj.displayOrder;
              });
              this.fancyService.getFancyByRedis(fancyObj).subscribe(resposne => {
                  if (resposne) {
                    this.socketServiceRedis.joinRoom(response.fancyId);
                      if (resposne.status == false) {
                        appendStatus(response.fancyId, 'suspend');
                      } else {
                        this.socketServiceRedis.joinRoom(response.fancyId);
                        appendRate(resposne.data);
                        appendStatus(fancyObj.fancy, resposne.data.statusValue[0].name);
                      }
                  } else {
                      appendStatus(response.fancyId, 'suspend');
                  }
                });

            }
          }
        } else {
          this.fancyData = _.filter(this.fancyData, function(user) {
            return user.fancyId !== response.fancyId;
          });
          if (this.matchOddsData.length > 0 || this.bookmakerData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0) {
          } else {
            if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
            }
          }
        }
        if (response.marketStatus.id === 'MS940896') {
          appendStatus(response.fancyId, 'suspend');
        }
        if (response.message) {
          $('#' + response.fancyId +  '_message').html('<marquee>' + response.message + '</marquee>');
          $('#' + response.fancyId +  '_messageMob').html('<marquee>' + response.message + '</marquee>');
        } else {
          $('#' + response.fancyId +  '_message').html('');
          $('#' + response.fancyId +  '_messageMob').html('');
        }
      }
      if (response && response.lineId) {
        this.socketServiceRedis.joinRoom(response.marketId); // socket join room

        // update line setting
        _.map(this.lineMarketData , function(res) {
              if (res.marketId == response.marketId) {
                  res.lineSetting = response.lineSetting;
              }
          });

        const markId = response.marketId.toString().replace('.', '');
        if (response.marketStatus.id === 'MS940896') {
          appendStatusLine(markId, 'suspend');
        }
        if (response.marketStatus.id === 'MS081893') {
          appendStatusLine(markId, 'Open');
          this.socketServiceRedis.joinRoom(response.marketId); // socket join room
        }
        if (response.isActive) {
          const count = _.filter(this.lineMarketData, function(user) {
            if(user.lineId == response.lineId){
              user.lineSetting = response.lineSetting;
            }
            return user.lineId === response.lineId;
          });
          if (count.length > 0) {

          } else {
            if (this.marketId === response.match.id) {
              response.marketIdDec = markId;
              this.lineMarketData.push(response);
              if (response.marketStatus.id === 'MS940896') {
                appendStatusLine(markId, 'suspend');
              }
              if (response.marketStatus.id === 'MS081893') {
                appendStatusLine(markId, 'Open');
                this.socketServiceRedis.joinRoom(response.marketId); // socket join room
              }
            }
          }
        } else {
          this.lineMarketData = _.filter(this.lineMarketData, function(user) {
            return user.lineId !== response.lineId;
          });
          if (this.matchOddsData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0) {

          } else {

            if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
            }
          }
        }
        if (response.message) {
          $('#' + response.lineId +  '_message').html('<marquee>' + response.message + '</marquee>');
          $('#' + response.lineId +  '_messageMob').html('<marquee>' + response.message + '</marquee>');
        } else {
          $('#' + response.lineId +  '_message').html('');
          $('#' + response.lineId +  '_messageMob').html('');
        }
      }
      if ( response && response.marketId && response.marketType === 'Match Odds') {
        if (response.marketStatus.id === 'MS940896') {
          this.marketStatus = 'MS940896';
          const marketIds_str =  response.marketId.toString().replace('.', '');
          $('.' + marketIds_str + '_market').addClass('market_suspend');
          $('.' + marketIds_str + '_market_mob').addClass('market_suspend');
        }
        if (response.marketStatus.id === 'MS081893') {
          this.marketStatus = 'MS081893';
          const marketIds_str =  response.marketId.toString().replace('.', '');
          $('.' + marketIds_str + '_market').removeClass('market_suspend');
          $('.' + marketIds_str + '_market_mob').removeClass('market_suspend');
        }

        if (response.isActive) {
          const count = _.filter(this.matchOddsData, function(user) {
            if(user.marketId == response.marketId){
              user.gameSetting = response.gameSetting;
            }
            return user.marketId === response.marketId;
          });
          if (count.length > 0) {

          } else {
            if (this.marketId === response.match.id) {
              response.exposer = {
                "AMOUNT": 0,
                "RUNNERS": []
              };
              this.matchOddsData.push(response);
              if (response.marketStatus.id === 'MS940896') {
                const marketIds_str =  response.marketId.toString().replace('.', '');
                $('.' + marketIds_str + '_market').addClass('market_suspend');
                $('.' + marketIds_str + '_market_mob').addClass('market_suspend');
              }
            }
          }
        } else {
          this.matchOddsData = _.filter(this.matchOddsData, function(user) {
            return user.marketId !== response.marketId;
          });
          if (this.matchOddsData.length > 0 || this.bookmakerData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0) {

          } else {

            if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
            }
          }
        }
        const markId = response.marketId.toString().replace('.', '');
        if (response.message) {

          $('#' + markId +  '_message').html('<marquee>' + response.message + '</marquee>');
          $('#' + markId +  '_messageMob').html('<marquee>' + response.message + '</marquee>');
        } else {
          $('#' + markId +  '_message').html('');
          $('#' + markId +  '_messageMob').html('');
        }
      }
      if ( response && response.marketId && response.marketTypeId === '5ebc1code68br4bik5b0814') {
        if (response.marketStatus.id === 'MS940896') {
          this.marketStatus = 'MS940896';
          const marketIds_str =  response.marketId.toString().replace('.', '');
          $('.' + marketIds_str + '_market').addClass('market_suspend');
          $('.' + marketIds_str + '_market_mob').addClass('market_suspend');
        }
        if (response.marketStatus.id === 'MS081893') {
          this.marketStatus = 'MS081893';
          const marketIds_str =  response.marketId.toString().replace('.', '');
          $('.' + marketIds_str + '_market').removeClass('market_suspend');
          $('.' + marketIds_str + '_market_mob').removeClass('market_suspend');
        }

        if (response.isActive) {
          const count = _.filter(this.matchOddsData, function(user) {
            return user.marketId === response.marketId;
          });
          if (count.length > 0) {

          } else {
            if (this.marketId === response.match.id) {
              response.exposer = {
                "AMOUNT": 0,
                "RUNNERS": []
              };
              this.matchOddsData.push(response);
              if (response.marketStatus.id === 'MS940896') {
                const marketIds_str =  response.marketId.toString().replace('.', '');
                $('.' + marketIds_str + '_market').addClass('market_suspend');
                $('.' + marketIds_str + '_market_mob').addClass('market_suspend');
              }
            }
          }
        } else {
          this.matchOddsData = _.filter(this.matchOddsData, function(user) {
            return user.marketId !== response.marketId;
          });
          if (this.matchOddsData.length > 0 || this.bookmakerData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0) {

          } else {

            if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
            }
          }
        }
        const markId = response.marketId.toString().replace('.', '');
        if (response.message) {

          $('#' + markId +  '_message').html('<marquee>' + response.message + '</marquee>');
          $('#' + markId +  '_messageMob').html('<marquee>' + response.message + '</marquee>');
        } else {
          $('#' + markId +  '_message').html('');
          $('#' + markId +  '_messageMob').html('');
        }
      }
      if ( response && response.marketId && response.marketType === 'Bookmaker') {
        if (response.marketStatus.id === 'MS940896') {
          this.marketStatus = 'MS940896';
          const bookmakerId =  response.marketId.toString().replace('.', '');
          $('.' + bookmakerId + '_bookmaker').addClass('market_suspend');
          $('.' + bookmakerId + '_bookmaker_mob').addClass('market_suspend');
        }
        if (response.marketStatus.id === 'MS081893') {
          this.marketStatus = 'MS081893';
          const bookmakerId =  response.marketId.toString().replace('.', '');
          $('.' + bookmakerId + '_bookmaker').removeClass('market_suspend');
          $('.' + bookmakerId + '_bookmaker_mob').removeClass('market_suspend');
        }

        if (response.isActive) {
          const count = _.filter(this.bookmakerData, function(user) {
            if(user.marketId == response.marketId){
              user.bookmakerSetting = response.bookmakerSetting;
            }
            return user.marketId === response.marketId;
          });
          if (count.length > 0) {

          } else {
            if (this.marketId === response.match.id) {
              response.exposer = {
                "AMOUNT": 0,
                "RUNNERS": []
              };
              this.bookmakerData.push(response);
              if (response.marketStatus.id === 'MS940896') {
                const bookmakerId =  response.marketId.toString().replace('.', '');
                $('.' + bookmakerId + '_bookmaker').addClass('market_suspend');
                $('.' + bookmakerId + '_bookmaker_mob').addClass('market_suspend');
              }
            }
          }
        } else {
          this.bookmakerData = _.filter(this.bookmakerData, function(user) {
            return user.marketId !== response.marketId;
          });
          if (this.matchOddsData.length > 0 || this.bookmakerData.length > 0 || this.lineMarketData.length > 0 || this.fancyData.length > 0) {

          } else {
            if (this.marketId === response.match.id && this.mycurrentRoute === '/sports/game-view/' + this.marketId) {
              // this.router.navigateByUrl('/dashboard');
            }
          }
        }
        const markId = response.marketId.toString().replace('.', '');
        if (response.message) {

          $('#' + markId +  '_message').html('<marquee>' + response.message + '</marquee>');
          $('#' + markId +  '_messageMob').html('<marquee>' + response.message + '</marquee>');
        } else {
          $('#' + markId +  '_message').html('');
          $('#' + markId +  '_messageMob').html('');
        }
      }
    });


    this.socketService
    .changeStatus()
    .subscribe((response) => {

        if(response.type == 'fancy'){
          this.appendStatus(response.fancy_id, response.status);
        }
       if(response.marketType === 'Bookmaker'){
         _.map(response.runners , function(e) {
           // const marketId = e.selctionId.toString().replace('.', '');
           appendStatusBM(e.selectionId, response.marketStatus.name);
         });

       }
      if (response.type == 'line') {
        const marketId = response.marketId.toString().replace('.', '');
        appendStatusLine(marketId, response.status);
      } else if (response.type === 'fancyStatusAll') {
        let status = response.status.name.toLowerCase();
        if (status === 'open') {
          status = 'active';
        }

        if (status === 'active' && response.fancyData.rate.length > 0) {
          appendRate(response.fancyData.rate[0]);
        }
        if (response.fancyData && response.fancyData.rate.length > 0) {
          appendStatus(response.fancyData.fancyId, status);
        }
      } else if (response.type === 'updateEvent') {

      } else if (response.type === 'updateEventTimer') {
        appendStatus(response.fancyId, 'ballstart');

      } else {
        const fancyId = response.fancy_id;
        appendStatus(fancyId, response.status);
        const fancyObj = {
          fancy : fancyId
        };
        this.fancyService.getFancyByRedis(fancyObj).subscribe(resposne => {

          if (resposne) {
              if (resposne.status == false) {
              } else {
              if(resposne.data){
                if (resposne.data.statusValue[0]['id'] ===  'MS960523') {
                  appendRate(resposne.data);
                }
              }
                // this.appendStatus(resposne.data.fancyId, resposne.data.statusValue[0].name);
              }
          } else {
              appendStatus(response.fancyId, 'suspend');
          }
        });
      }
    });

    this.socketService
      .changeFlag()
      .subscribe((response) => {
        if (response) {
          let marketId = String(response)
            if(this.mycurrentRoute === '/sports/game-view/' + marketId && this.marketId === marketId){
            const userId = this.utilityService.returnLocalStorageData('userId');
            this.getMarketIdData(this.marketId , userId);
            // this.getAllFancyList();
            this.checkLockGame(this.lockGameObj);
            }
        }
      });

    this.socketServiceClient.bookMakerRateChange().subscribe((response) => {
        if (response) {
          response.runners.map(res => {
            if (res && (res.back > 0 || res.lay > 0)) {
              $('#' + res.selectionId + '_bookmaker').removeClass('market_suspend');
              $('#' + res.selectionId + '_back_odds').html(res.back);
              $('#' + res.selectionId + '_lay_odds').html(res.lay);
            }else {
              $('#' + res.selectionId + '_bookmaker').addClass('market_suspend');
            }
          });
        }

      });



  }
  // ----------------On init complete ----------------//


  ngAfterContentInit() {

  }

  ngAfterViewInit() {

  }
  getAllFancyList() {
    this.fancyData = [];
    const matchIdObj = {
      matchId: this.marketId,
      userId : this.userId
    };
    this.fancyService.getAllFancy(matchIdObj).subscribe(resposne => {
      resposne = this.utilityService.gsk(resposne.auth);
      resposne = JSON.parse(resposne);
      if (resposne.status === true ) {
        this.fancyData = resposne.data;
        this.fancyData.map(res => {
          if(res.fancyMode === 'Manual'){
            this.socketServiceRedis.joinRoom(res.fancyId);
            appendStatus(res.fancyId, res.marketStatus.name);
          }

          if (res.fancyMode == 'Auto') {
            this.socketServiceRedis.joinRoom(res.fancyId);
          }
        }, this);
        setTimeout(() => {
            // this.upendFancyRate(this.fancyData);
        }, 2000);
      }
    });
  }

  getAllTransaction(transactionObj) {
    transactionObj.limitData = 50;
    this.marketService.getAllTransactions(transactionObj).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if (response.status == true) {
        this.allTransactions = response.data;
      }
    });
  }

  getAllTransactionAsMactch(transactionObj) {
     this.marketService.getAllTransactionsAsMatch(transactionObj).subscribe(response => {
      if (response.status == true) {
        this.allTransactionsAsMatch = response.data;
      }
    });
  }
  getAllTransactionAsLine(transactionObj) {
     // get all transaction
     this.marketService.getAllTransactionsAsLine(transactionObj).subscribe(response => {

      if (response.status == true) {
        this.allTransactionsAsLine = response.data;
      }
    });
  }

  upendFancyRate(fancyData) {
    fancyData.map(function(fancy) {
      if (fancy.latestRate) {
        if (fancy.fancyMode !== 'Auto') {
          appendRate(fancy.latestRate);
          appendStatus(fancy.fancyId, fancy.latestRate.statusValue[0].name);
        } else {
          //appendStatus(fancy.fancyId, 'suspend');
        }
      } else {
        // if (fancy.fancyMode !== 'Auto') {
        //   appendStatus(fancy.fancyId, 'suspend');
        // } else {
        //   appendStatus(fancy.fancyId, 'suspend');
        // }
      }
    });
  }

  startRate() {
    if (this.confirmRate == false) {
      setTimeout(() => {
        this.upendFancyRate(this.fancyData);
      }, 100);
    }
    this.confirmRate = true;
  }

  startRateMob() {
    if (this.confirmRateMob == false) {
      setTimeout(() => {
        this.upendFancyRate(this.fancyData);
      }, 100);
    }
    this.confirmRateMob = true;
  }



  appendRate(response) {
    if (response.type == 'line') {
      const lineId = response.lineId.toString().replace('.', '');
      if (response.no2 != '' && response.yes2 != '' && response.lineId ) {
        // Line market append live rate for manual
        $('#' + lineId + '_lay').html(response.no2), $('#mob_' + lineId + '_lay').html(response.no2);
        $('#' + lineId + '_back').html(response.yes2Vol), $('#mob_' + lineId + '_back').html(response.yes2Vol);
        $('#' + lineId + '_lay_vol').html(response.no2Vol), $('#mob_' + lineId + '_lay_vol').html(response.no2Vol);
        $('#' + lineId + '_back_vol').html(response.yes2), $('#mob_' + lineId + '_back_vol').html(response.yes2);
      }
    }
    const fancyId = response.fancyId;

    $('#' + fancyId + '_third').hide(), $('#mob_' + fancyId + '_third').hide();
    $('#' + fancyId + '_first').hide(), $('#mob_' + fancyId + '_first').hide();
    $('#' + fancyId + '_forth').hide(), $('#mob_' + fancyId + '_forth').hide();

    if (response.no1 != '' && response.yes1 != '' ) {
        $('#' + fancyId + '_first').show(), $('#mob_' + fancyId + '_first').show();
        $('#no1_' + fancyId).html(response.no1), $('#mob_no1_' + fancyId).html(response.no1);
        $('#no1Vol_' + fancyId).html(response.no1Vol), $('#mob_no1Vol_' + fancyId).html(response.no1Vol);
        $('#yes1_' + fancyId).html(response.yes1), $('#mob_yes1_' + fancyId).html(response.yes1);
        $('#yes1Vol_' + fancyId).html(response.yes1Vol), $('#mob_yes1Vol_' + fancyId).html(response.yes1Vol);
      }
    if (response.no2 != '' && response.yes2 != '' ) {
        // Fancy market append live rate for manual
        $('#no2_' + fancyId).html(response.no2), $('#mob_no2_' + fancyId).html(response.no2);
        $('#no2Vol_' + fancyId).html(response.no2Vol), $('#mob_no2Vol_' + fancyId).html(response.no2Vol);
        $('#yes2_' + fancyId).html(response.yes2), $('#mob_yes2_' + fancyId).html(response.yes2);
        $('#yes2Vol_' + fancyId).html(response.yes2Vol), $('#mob_yes2Vol_' + fancyId).html(response.yes2Vol);
        $('#' + fancyId + '_second').show(), $('#mob_' + fancyId + '_second').show();
      }
    if (response.no3 != '' && response.yes3 != '' ) {
        $('#' + fancyId + '_third').show(), $('#mob_' + fancyId + '_third').show();
        $('#no3_' + fancyId).html(response.no3), $('#mob_no3_' + fancyId).html(response.no3);
        $('#no3Vol_' + fancyId).html(response.no3Vol), $('#mob_no3Vol_' + fancyId).html(response.no3Vol);
        $('#yes3_' + fancyId).html(response.yes3), $('#mob_yes3_' + fancyId).html(response.yes3);
        $('#yes3Vol_' + fancyId).html(response.yes3Vol), $('#mob_yes3Vol_' + fancyId).html(response.yes3Vol);
      }
    }

    appendStatus(fancyId, status) {
      if (status == 'ballstart') {
        $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId + + ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
        $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

        $('#' + fancyId +  '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId +  '_first,#mob_' + fancyId + '_third,#mob_' + fancyId + '_forth').hide();
        $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');
        $('#' + fancyId + '_second').addClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').addClass('fancy_ballstart');
      }
      if (status && status.name === 'Close') {
        $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId + ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
        $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId  + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

        $('#' + fancyId +  '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId +  '_first,#mob_' + fancyId + '_third,#mob_' + fancyId + '_forth').hide();
        $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');
        $('#' + fancyId + '_second').addClass('fancy_close'), $('#mob_' + fancyId + '_second').addClass('fancy_close');
      }
      if (status == 'suspend') {
        $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId + ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
        $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId  + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

        $('#' + fancyId +  '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId +  '_first,#mob_' + fancyId + '_third,#mob_' + fancyId + '_forth').hide();        $('#' + fancyId + '_second').removeClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').removeClass('fancy_ballstart');
        $('#' + fancyId + '_second').addClass('fancy_suspend'), $('#mob_' + fancyId + '_second').addClass('fancy_suspend');
      }
      if (status == 'settled') {
        $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId + ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
        $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId  + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

        $('#' + fancyId +  '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId +  '_first,#mob_' + fancyId + '_third,#mob_' + fancyId + '_forth').hide();        $('#' + fancyId + '_second').removeClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').removeClass('fancy_ballstart');
        $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');

        $('#' + fancyId + '_second').addClass('fancy_settled'), $('#mob_' + fancyId + '_second').addClass('fancy_settled');
      }
      if (status == 'active') {
        $('#' + fancyId + '_second').removeClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').removeClass('fancy_ballstart');
        $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');
      }
    }

    appendStatusLine(marketId, status) {

      if (status == 'ballstart') {
        $('#' + marketId + '_lay' + ',#' + marketId + '_back' + ',#' + marketId + '_lay_mob' + ',#' + marketId + '_back_mob').html('');
        $('#' + marketId + '_lay_vol' + ',#' + marketId + '_back_vol' + ',#' + marketId + '_lay_mob_vol' + ',#' + marketId + '_back_mob_vol' ).html('');
        $('#' + marketId + '_line').removeClass('fancy_suspend'), $('#' + marketId + '_mob_line').removeClass('fancy_suspend');
        $('#' + marketId + '_line').addClass('fancy_ballstart'), $('#' + marketId + '_mob_line').addClass('fancy_ballstart');
      }
      if (status == 'suspend') {
        // $('#' + marketId + '_lay' + ',#' + marketId + '_back' + ',#' + marketId + '_lay_mob' + ',#' + marketId + '_back_mob').html('');
        // $('#' + marketId + '_lay_vol' + ',#' + marketId + '_back_vol' + ',#' + marketId + '_lay_mob_vol' + ',#' + marketId + '_back_mob_vol' ).html('');
        $('#' + marketId + '_line').removeClass('fancy_ballstart'), $('#' + marketId + '_mob_line').removeClass('fancy_ballstart');
        $('#' + marketId + '_line').addClass('fancy_suspend'), $('#' + marketId + '_mob_line').addClass('fancy_suspend');
      }
      if (status == 'settled') {
        $('#' + marketId + '_lay' + ',#' + marketId + '_back' + ',#' + marketId + '_lay_mob' + ',#' + marketId + '_back_mob').html('');
        $('#' + marketId + '_lay_vol' + ',#' + marketId + '_back_vol' + ',#' + marketId + '_lay_mob_vol' + ',#' + marketId + '_back_mob_vol' ).html('');
        $('#' + marketId + '_line').addClass('fancy_settled'), $('#' + marketId + '_mob_line').addClass('fancy_settled');
      }
      if (status == 'active') {
        $('#' + marketId + '_line').removeClass('fancy_ballstart'), $('#' + marketId + '_line').removeClass('fancy_suspend');
        $('#' + marketId + '_mob_line').removeClass('fancy_ballstart'), $('#' + marketId + '_mob_line').removeClass('fancy_suspend');
      }
      if (status == 'Open') {
        $('#' + marketId + '_line').removeClass('fancy_ballstart'), $('#' + marketId + '_line').removeClass('fancy_suspend');
        $('#' + marketId + '_mob_line').removeClass('fancy_ballstart'), $('#' + marketId + '_mob_line').removeClass('fancy_suspend');
      }
    }

    appendStatusBM(teamID,status){
        $("#" + teamID + "_bookmaker").removeClass('bookmaker_ballstart'),$("#" + teamID + "_bookmaker_mob").removeClass('bookmaker_ballstart');
        $("#" + teamID + "_bookmaker").removeClass('market_suspend'),$("#" + teamID + "_bookmaker_mob").removeClass('market_suspend');

        if (status == 'ballstart') {
          $("#" + teamID + "_bookmaker").addClass('bookmaker_ballstart'),$("#" + teamID + "_bookmaker_mob").addClass('bookmaker_ballstart');
        }
        if (status == 'suspend') {
          $("#" + teamID + "_bookmaker").addClass('market_suspend'),$("#" + teamID + "_bookmaker_mob").addClass('market_suspend');
        }
    }


  getMarketIdData(data , filter) {
    const totalLineSct = [];
    this.getMarketByIds = [];
    this.marketService.getMarketById(data , filter).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if(response.data.total == 0) {
        this.router.navigateByUrl('/dashboard');
      }
      this.getMarketCheckActiveBat = response.data;
      this.getMarketById = response.data.docs;
      this.checkSport = response.data.docs;
      this.channelUrl =  this.getMarketById[0].matchStatus.channelUrl;

      response.data.docs.map(res => {
          this.getMarketByIds.push(res);
      });
      this.getMarketById = this.getMarketByIds;

      this.matchOddsData = this.getMarketById.filter(function(number) {
        if (number.marketTypeId === '5ebc1code68br4bik5b3035') {
        return number.marketTypeId === '5ebc1code68br4bik5b3035';
        } else if (number.marketTypeId === '5ebc1code68br4bik5b0814') {
          return number.marketTypeId === '5ebc1code68br4bik5b0814';
        }
      });
      if (this.matchOddsData.length > 0) {

        this.marketVolume = this.matchOddsData[0].gameSetting && this.matchOddsData[0].gameSetting.volume ? this.matchOddsData[0].gameSetting.volume : this.matchOddsData[0].cupSetting.volume ;
        this.marketStatus = this.matchOddsData[0].marketStatus.id;
        const marketId = this.matchOddsData[0].marketId;
        this.marketSel = marketId.toString().replace('.', '');
        const lastJoinRoom =  sessionStorage.getItem('lastJoinRoom');
        if (lastJoinRoom) {
          let lastJoinRoomAry = [];
          lastJoinRoomAry = JSON.parse(lastJoinRoom);
          lastJoinRoomAry.map(res => {
            this.socketService.leaveRoom(res);
          });
        }

        // check alow bet
        if (this.matchOddsData[0].allowBat == false) {
        }


        this.socketServiceRedis.joinRoom(marketId);
        totalLineSct.push(marketId);
      }

      this.bookmakerData = this.getMarketById.filter(function(number) {
        return number.marketTypeId === '5ebc1code68br4bik5b0810';
      });
      if (this.bookmakerData.length > 0) {
        const bookId = this.bookmakerData[0].marketId;
        this.marketIdBooKmakerUsed = this.bookmakerData[0].marketId;
         this.bookmakerId = bookId.toString().replace('.', '');
        this.socketServiceRedis.joinRoom(bookId);
          this.getbookMakerLatest(bookId , this.bookmakerData);
      }
      this.bookmakerData.map(res => {
        totalLineSct.push(res.marketId);
      });
      this.fancyData = this.getMarketById.filter(function(number) {
        return number.marketTypeId === '5ebc1code68br4bik5b1808';
      });
      this.fancyData.map(res => {
          if(res.fancyMode === 'Manual'){
            this.socketServiceRedis.joinRoom(res.fancyId);
            appendStatus(res.fancyId, res.marketStatus.name);
          }

          if (res.fancyMode == 'Auto') {
            this.socketServiceRedis.joinRoom(res.fancyId);
          }
        totalLineSct.push(res.fancyId);
      });
      this.lineMarketData = this.getMarketById.filter(function(number) {
        return number.marketTypeId === '5ebc1code68br4bik5b0811';
      });

      this.lineMarketData.map(res => {
        totalLineSct.push(res.marketId);
        res.marketIdDec = res.marketId.toString().replace('.', '');
        this.socketServiceRedis.joinRoom(res.marketId);
        this.socketService.setLineRate(res.marketId);
        if (res.lineMode == 'Manual') {
          res.lineMode = 'Manual';
        } else {
          res.lineMode = 'Auto';
        }
      });

      sessionStorage.setItem('lastJoinRoom', JSON.stringify(totalLineSct));
      this.spinner.hide();
    });
  }

  /*
    Developer: Ravi
    Date: 05-mar-2020
    title: Place rate function for market
    Use: This function is use append rate into place bet window
  */

  placeRateMarket(marketSel, index, marketType, row, event, marketDetail, team) {
    const marketId = marketSel + '_' + index + '_' + marketType + '_' + row + '_';
    const odds = $('#' + marketId + 'odds').html();
    const vol = $('#' + marketId + 'vol').html();
    $('.bet_for_name').html(team.runnerName);
    $('.ite-types').html(marketType);
    $('#oddsInput').val(odds);
    if (marketType === 'back') {
      $('#betting-slip-div').removeClass('betting-slip-lay').addClass('betting-slip-back');
    } else {
      $('#betting-slip-div').removeClass('betting-slip-back').addClass('betting-slip-lay');
    }

    $('#placebet').data('data-game-id', marketDetail.marketId);
    $('#placebet').data('data-volume', vol);
    $('#placebet').data('data-runner-type', marketType);
    $('#placebet').data('data-row', row);
    $('#placebet').data('data-market-type', 'market');
    $('#placebet').data('team', team);
    $('#stackInput').val('');
    this.resetTempExp();
  }

  placeRateMarketBM(marketSel, index, marketType, row, event, marketDetail, team) {
    const marketId = marketSel + '_' + marketType + '_';

    const odds = $('#' + marketId + 'odds').html();
    const vol = $('#' + marketId + 'vol').html();
    $('.bet_for_name').html(team.runnerName);
    $('.ite-types').html(marketType);
    $('#oddsInput').val(odds);
    if(marketType === 'back'){
      $('#betting-slip-div').removeClass('betting-slip-lay').addClass('betting-slip-back');
    }else{
      $('#betting-slip-div').removeClass('betting-slip-back').addClass('betting-slip-lay');
    }

    $('#placebet').data('data-game-id', marketDetail.marketId);
    $('#placebet').data('data-volume', vol);
    $('#placebet').data('data-runner-type', marketType);
    $('#placebet').data('data-row', row);
    $('#placebet').data('data-market-type', 'bookmaker');
    $('#placebet').data('team', team);
    $('#stackInput').val('');
    //this.resetTempExp();
  }

  placeRateMarketBMMob(marketSel, index, marketType, row, event, marketDetail, team) {
    this.placeBetModel.show();
    const marketId = marketSel + '_' + marketType + '_';
    const odds = $('#' + marketId + 'odds').html();
    const vol = $('#' + marketId + 'vol').html();
    $('.bet_for_name').html(team.runnerName);
    $('.ite-types').html(marketType);
    $('#oddsInputMob').val(odds);
    if(marketType === 'back'){
      $('.betting-slip-div-class').removeClass('betting-slip-lay').addClass('betting-slip-back');
    }else{
      $('.betting-slip-div-class').removeClass('betting-slip-back').addClass('betting-slip-lay');
    }

    $('#placebetMob').data('data-game-id', marketDetail.marketId);
    $('#placebetMob').data('data-volume', vol);
    $('#placebetMob').data('data-runner-type', marketType);
    $('#placebetMob').data('data-row', row);
    $('#placebetMob').data('data-market-type', 'bookmaker');
    $('#placebetMob').data('team', team);
    $('#stackInputMob').val('');
    //this.resetTempExp();
  }


  placeRateMarketMob(marketSel, index, marketType, row, event, marketDetail, team) {
    this.placeBetModel.show();
    const marketId = marketSel + '_' + index + '_' + marketType + '_' + row + '_';
    const odds = $('#' + marketId + 'odds').html();
    const vol = $('#' + marketId + 'vol').html();
    $('.bet_for_name').html(team.runnerName);
    $('.ite-types').html(marketType);
    $('#oddsInputMob').val(odds);
    if (marketType === 'back') {
      $('.betting-slip-div-class').removeClass('betting-slip-lay').addClass('betting-slip-back');
    } else {
      $('.betting-slip-div-class').removeClass('betting-slip-back').addClass('betting-slip-lay');
    }
    $('#placebetMob').data('data-game-id', marketDetail.marketId);
    $('#placebetMob').data('data-volume', vol);
    $('#placebetMob').data('data-runner-type', marketType);
    $('#placebetMob').data('data-row', row);
    $('#placebetMob').data('data-market-type', 'market');
    $('#placebetMob').data('team', team);
    $('#stackInputMob').val('');
    this.resetTempExp();
  }

  /*
    Developer: Ravi
    Date: 05-mar-2020
    title: Place rate function for fancy
    Use: This function is use append rate into place bet window
  */

  placeRate(type, runner_type, row, id, event, fancyName, marketId = '') {
    this.currentTranPro = 0;
    if (runner_type === 'lay') {
      $('.ite-types').html('No');
    } else {
      $('.ite-types').html('Yes');
    }
    $('#stackInput').val('');
    if (runner_type === 'back') {
      $('.betting-slip-div-class').removeClass('betting-slip-lay').addClass('betting-slip-back');
    } else {
      $('.betting-slip-div-class').removeClass('betting-slip-back').addClass('betting-slip-lay');
    }

    $('#placebet').data('team', '');
    if (type == 'fancy') {
        // Rate value from html (condition check span is exits or not)
        const rateVal = ($(event.target).closest('td').find( '#' + row + '_' + id ).children().length > 0) ? $(event.target).closest('td').find( '#' + row + '_' + id ).children().html() : $(event.target).closest('td').find( '#' + row + '_' + id ).html() ;
        $('#oddsInput').val(parseInt(rateVal));
        // Rate value from html (condition check span is exits or not)
        const rateVol = ($(event.target).closest('td').find( '#' + row + 'Vol_' + id ).children().length > 0) ? $(event.target).closest('td').find( '#' + row + 'Vol_' + id ).children().html() : $(event.target).closest('td').find( '#' + row + 'Vol_' + id ).html();
      // $('.ite-volume').html('/' + rateVol);
      $('.bet_for_name').html(fancyName + '/' + rateVol);
        $('#placebet').data('data-volume', parseInt(rateVol));
        $('#placebet').data('data-game-id', parseInt(id));
    } else {
      $('.bet_for_name').html(fancyName);
        // Rate value from html (condition check span is exits or not)
        const rateVal = ($(event.target).closest('td').find('#' + id + '_' + runner_type).length > 0) ? $(event.target).closest('td').find('#' + id + '_' + runner_type).html() : $(event.target).closest('td').find('#' + id + '_' + runner_type).html() ;
        $('#oddsInput').val(parseInt(rateVal));
        // Rate value from html (condition check span is exits or not)
        const rateVol = ($(event.target).closest('td').find('#' + id + '_' + runner_type + '_vol').length > 0) ? $(event.target).closest('td').find('#' + id + '_' + runner_type + '_vol').html() : $(event.target).closest('td').find('#' + id + '_' + runner_type + '_vol').html();
        $('#placebet').data('data-volume', parseInt(rateVol));
        $('#placebet').data('data-game-id', marketId);
    }

    $('#placebet').data('data-runner-type', runner_type);
    $('#placebet').data('data-row', row);
    $('#placebet').data('data-market-type', type);
  }


  /*
    Developer: Ravi
    Date: 05-mar-2020
    title: Rate append in place bet
    Use: This function is use rate calculation
  */

 placeRateValue(event) {
   $('button').removeClass('btn-danger5');
   $('#'+ event.target.id).addClass('btn-danger5');
  let rateStack = event.target.getAttribute('data-val');
  const marketType = $('#placebet').data('data-market-type');
  const stackInput = $('#stackInput').val();
  if (stackInput != '') {
      rateStack = Number(rateStack);
  }
  $('#stackInput').val(Number(rateStack));
  $('#placebet').attr('data-amount', Number(rateStack));
  if (marketType == 'market') {
    this.getLatestExposer();
  }
  if (marketType == 'fancy' ||  marketType == 'line') {
    this.getLatestExposerFancy('', marketType);
  }
  if (marketType == 'bookmaker') {
    this.getLatestExposerBm();
  }
}


  /*
    Developer: Ravi
    Date: 05-mar-2020
    title: Place rate function
    Use: This function is use append rate into place bet window
  */

 placeRateMob(type, runner_type, row, id, event, fancyName, marketId = '') {
   this.placeBetModel.show();
  this.currentTranPro = 0;
  if (runner_type === 'lay') {
     $('.ite-types').html('No');
   } else {
     $('.ite-types').html('Yes');
   }
  if (runner_type === 'back') {
     $('.betting-slip-div-class').removeClass('betting-slip-lay').addClass('betting-slip-back');
   } else {
     $('.betting-slip-div-class').removeClass('betting-slip-back').addClass('betting-slip-lay');
   }
  $('#stackInputMob').val('');
  // Rate value from html (condition check span is exits or not)
  if (type == 'fancy') {
    const rateVal = ($(event.target).closest('td').find( '#mob_' + row + '_' + id ).children().length > 0) ? $(event.target).closest('td').find( '#mob_' + row + '_' + id ).children().html() : $(event.target).closest('td').find( '#mob_' + row + '_' + id ).html();
    $('#oddsInputMob').val(parseInt(rateVal));
    // Rate value from html (condition check span is exits or not)
    const rateVol = ($(event.target).closest('td').find( '#mob_' + row + 'Vol_' + id ).children().length > 0) ? $(event.target).closest('td').find( '#mob_' + row + 'Vol_' + id ).children().html() : $(event.target).closest('td').find( '#mob_' + row + 'Vol_' + id ).html();
    $('.bet_for_name').html(fancyName + '/' + rateVol);
    $('#placebetMob').data('data-game-id', parseInt(id));
    $('#placebetMob').data('data-volume', parseInt(rateVol));
  } else {

    $('.bet_for_name').html(fancyName);
    const rateVal = ($(event.target).closest('td').find('#' + id + '_' + runner_type + '_mob').length > 0) ? $(event.target).closest('td').find('#' + id + '_' + runner_type  + '_mob').html() : $(event.target).closest('td').find('#' + id + '_' + runner_type + '_mob').html() ;
    $('#oddsInputMob').val(parseInt(rateVal));

    // Rate value from html (condition check span is exits or not)
    const rateVol = ($(event.target).closest('td').find('#' + id + '_' + runner_type + '_mob_vol').length > 0) ? $(event.target).closest('td').find('#' + id + '_' + runner_type + '_mob_vol').html() : $(event.target).closest('td').find('#' + id + '_' + runner_type + '_mob_vol').html();
    $('#placebetMob').data('data-game-id', marketId);
    $('#placebetMob').data('data-volume', parseInt(rateVol));
  }
  $('#placebetMob').data('data-runner-type', runner_type);
  $('#placebetMob').data('data-row', row);
  $('#placebetMob').data('data-market-type', type);
}


/*
    Developer: Ravi
    Date: 05-mar-2020
    title: Rate append in place bet
    Use: This function is use rate calculation
  */

 placeRateValueMob(event) {
   $('button').removeClass('btn-danger5');
   $('#'+ event.target.id).addClass('btn-danger5');
  let rateStack = event.target.getAttribute('data-val');
  const marketType = $('#placebetMob').data('data-market-type');
  const stackInput = $('#stackInputMob').val();
  if (stackInput != '') {
      rateStack = Number(rateStack) ;
      // rateStack = Number(rateStack) + Number(stackInput);
  }
  $('#stackInputMob').val(parseInt(rateStack));
  $('#placebetMob').attr('data-amount', Number(rateStack));
  if (marketType == 'market') {
    this.getLatestExposer('mobile');
  }
  if (marketType == 'fancy' ||  marketType == 'line') {
    this.getLatestExposerFancy('mobile', marketType);
  }
  if (marketType == 'bookmaker') {
    this.getLatestExposerBm('mobile');
  }
}




  /*
    Developer: Ravi
    Date: 05-mar-2020
    title: Place bet function
    Use: This function is use place bet
  */

 placeBet(event, device) {
   $('button').removeClass('btn-danger5');
  if(this.endSubmit) {
      return;
  }
  this.endSubmit = true;
   let postfix = '';
   if (device == 'mobile') {
    postfix = 'Mob';
   }
   this.spinner.show();
   const odds = $('#oddsInput' + postfix).val();
   const rate = $('#stackInput' + postfix).val();
   const team = $('#placebet' + postfix).data('team');
   const game_id = $('#placebet' + postfix).data('data-game-id');
   const volume = $('#placebet' + postfix).data('data-volume');
   const runner_type = $('#placebet' + postfix).data('data-runner-type');
   const row = $('#placebet' + postfix).data('data-row');
   const market_type = $('#placebet' + postfix).data('data-market-type');

  if (game_id == '' || volume == '' || odds == '' || rate == '' || runner_type == '') { // This function check if any parameter is missing
    this.spinner.hide();
    this.endSubmit = false;
    this.showToster('Error', 'error', 'Invalid rate');
  } else if (Number.isInteger(Number(rate)) == false) {
    this.spinner.hide();
    this.endSubmit = false;
    this.showToster('Error', 'error', 'Invalid stake');
  } else {

    const users = this.commonService.getLocalStorage();
    this.usersPartnership = this.commonService.getLocalStorage();
    this.usersPartnership = JSON.parse(this.usersPartnership.userData);
    let sportId = '';
    if (market_type == 'market') {
        sportId = this.matchOddsData[0].sport.id;
      } else {
        sportId = '5ebc1code68br4bik5b1808';
      }

    this.apiObj = {
        odds,
        rate,
        game_id,
        volume,
        runner_type,
        market_type,
        row,
        marketId: this.marketId,
        team: (typeof team != 'undefined') ? team : '',
      };
    const sharReq = {
        masterIds: this.usersPartnership.masterId,
        sportId : (this.getMarketById[0].sport.id) ? Number(this.getMarketById[0].sport.id) : 0,
        parentId : this.usersPartnership.parentId
      };
    this.resetTempExp();
    this.placebetService.addPlaceBet(this.apiObj).subscribe(resPlacebet => {
      resPlacebet = this.utilityService.gsk(resPlacebet.auth);
      resPlacebet = JSON.parse(resPlacebet);
      this.endSubmit = false;
        this.currentTranPro = 0
        this.cancelBtn();
        this.closeBetModal();
        if (resPlacebet.status == true) {
          $('#oddsInput').val('');
          $('#stackInput').val('');

          this.spinner.hide();
          this.upendPlacebetResponse(resPlacebet.placebet , resPlacebet.placebet.user);
          this.headerComponent.updatePlacebetResponse(resPlacebet.placebet.balance)
          this.showToster('Success', 'success', resPlacebet.message);
          this.playAudio();
        } else {
          $('#oddsInput').val('');
          $('#stackInput').val('');
          this.spinner.hide();
          this.showToster('Failed', 'error', resPlacebet.message);
        }
      });
  }
}


upendPlacebetResponse(res , response){
  if(response){
      if (response.gameType == 'market' || response.gameType == "Winner") {
        if (response.runnerExp) {
          let newExp = {
            amount : response.game_exposer,
            runners : response.runnerExp
          }
          this.matchOddsData.map(function(detail) {
            if(detail.marketId == response.gameId){
              detail.exposer = newExp;
            }
          });

          response.runnerExp.map(res => {
            const amountstr = res.amount;
            const className = (res.amount < 0) ? 'text-danger' : 'text-success';
            if (res.amount < 0) {
              $('#' + res.runners.selectionId + '_exposer').removeClass('text-success').addClass('text-danger');
              $('#' + res.runners.selectionId + '_exposer').html(amountstr);
              $('#' + res.runners.selectionId + '_exposer_mob' ).removeClass('text-success').addClass('text-danger');
              $('#' + res.runners.selectionId + '_exposer_mob').html(amountstr);
            } else {
              $('#' + res.runners.selectionId + '_exposer' ).removeClass('text-danger').addClass('text-success');
              $('#' + res.runners.selectionId + '_exposer').html(amountstr);
              $('#' + res.runners.selectionId + '_exposer_mob' ).removeClass('text-danger').addClass('text-success');
              $('#' + res.runners.selectionId + '_exposer_mob').html(amountstr);
            }
          });
        }
      }else if(response.gameType == 'bookmaker'){
        if (response.runnerExp) {
          let newExp = {
            amount : response.game_exposer,
            runners : response.runnerExp
          }
          this.bookmakerData.map(function(detail) {
            if(detail.marketId == response.gameId){
              detail.exposer = newExp;
            }
          });

          response.runnerExp.map(res => {
            const amountstr = res.amount;
            const className = (res.amount < 0) ? 'text-danger' : 'text-success';
            if (res.amount < 0) {
            $('#' + res.runners.selectionId + '_bm_exposer').removeClass('text-success').addClass('text-danger');
            $('#' + res.runners.selectionId + '_bm_exposer').html(amountstr);
            $('#' + res.runners.selectionId + '_bm_exposer_mob' ).removeClass('text-success').addClass('text-danger');
            $('#' + res.runners.selectionId + '_bm_exposer_mob').html(amountstr);
            } else {
              $('#' + res.runners.selectionId + '_bm_exposer' ).removeClass('text-danger').addClass('text-success');
              $('#' + res.runners.selectionId + '_bm_exposer').html(amountstr);
              $('#' + res.runners.selectionId + '_bm_exposer_mob' ).removeClass('text-danger').addClass('text-success');
              $('#' + res.runners.selectionId + '_bm_exposer_mob').html(amountstr);
            }
          });
        }
      } else if (response.gameType == 'line') {
        const lineDec = response.gameId.toString().replace('.', '');
        $('#' + lineDec + '_exposer').html(String(-1 * Math.abs(response.game_exposer)));
        $('#' + lineDec + '_exposer_mob').html(String(-1 * Math.abs(response.game_exposer)));
      } else {
        $('#' + response.gameId + '_exposer').html(String(-1 * Math.abs(response.game_exposer)));
        $('#' + response.gameId + '_exposer_mob').html(String(-1 * Math.abs(response.game_exposer)));
      }
      response['_id'] = res.lastInsId;
    if(this.allTransactions.length > 0){
      this.allTransactions.unshift(response); // AVAILABLE_BALANCE
    }else {
      this.allTransactions.push(response); // AVAILABLE_BALANCE
    }
  }
}

cancelBtn() {
  $('button').removeClass('btn-danger5');
  this.currentTranPro = 0;
  $('#stackInput').val('');
  $('#stackInputMob').val('');
  this.resetTempExp();
}

closeBetModal() {
  this.cancelBtn();
   this.placeBetModel.hide();
   $('.betting-slip-section-class').removeClass('show');
   $('.betting-slip-section').removeClass('d-block');
}

resetTempExp() {
  if (this.matchOddsData[0]) {
    const oldExpo = this.matchOddsData[0].runners;
    oldExpo.forEach( (obj, index) => {
      $('#' + obj.selectionId).html('');
      $('#' + obj.selectionId + '_mob').html('');
    });
  }
  if(this.bookmakerData){
    this.bookmakerData.forEach( (obj, index) => {
      const runner = obj.runners;
      runner.forEach( (run, index) => {
        $('#' + run.selectionId + '_bm').html('');
        $('#' + run.selectionId + '_bm_mob').html('');
      });
    });
  }
}

  /*
    Developer: Ravi
    Date: 05-mar-2020
    title: Toster message
    Use: This function is use to throgh toster message
  */

 showToster(title, type, message) {
    this.Toast.title = title;
    this.Toast.type = type;
    this.Toast.body = message;
    this.commonService.popToast(type, title, 1500, message);
  }

  getFancyChart(fancyId, marketId, fancyName) {
    this.chartFancyName = fancyName;
    const users = this.commonService.getLocalStorage();
    const fancyObj = {
      gameId : fancyId,
      marketId,
      userId : users.userId
    };
    this.placebetService.getFancyChart(fancyObj).subscribe(resPlacebet => {
      this.chart.show();
      if (resPlacebet.status == true) {
        if (resPlacebet.data.length > 0) {
          const dataAry = resPlacebet.data;
          let firstIndex = 0;
          let lastIndex = 0;
          let minOdds = _.minBy(dataAry, 'odds');
          let maxOdds = _.maxBy(dataAry, 'odds');

          firstIndex =  minOdds.odds - 10;
          lastIndex =  maxOdds.odds + 10;

          firstIndex = (firstIndex<0)?0:firstIndex
          this.chartAry = [];
          for (let i = firstIndex; i <= lastIndex; i++) {
            let plusAmt = 0;
            let minusAmt = 0;
            let finalAmt = 0;
            dataAry.forEach( (obj, index) => {
              if (obj.runner_type == 'lay') { // client says no
                  if (i < obj.odds) {
                    plusAmt = plusAmt + obj.lay;
                  } else {
                    minusAmt = minusAmt + obj.back;
                  }
                } else {
                  if (i >= obj.odds) {
                    plusAmt = plusAmt + obj.back;
                  } else {
                    minusAmt = minusAmt + obj.lay;
                  }
                }
            });
            finalAmt = plusAmt + minusAmt;
            const finalChart = {
                  number : i,
                  amount : finalAmt.toFixed(2)
            };
            this.chartAry.push(finalChart);
          }
          $('.fancy-main-chart-div').toggleClass('active');
          this.spinner.hide();
      } else {
        this.chartAry = [];

        $('.fancy-main-chart-div').toggleClass('active');
        this.spinner.hide();
      }
    } else {
      this.chartAry = [];
      $('.fancy-main-chart-div').toggleClass('active');
      this.spinner.hide();
    }
  });
}


getLineChart(lineId, marketId, lineName) {
  this.chartFancyName = lineName;
  const users = this.commonService.getLocalStorage();
  const fancyObj = {
    gameId : lineId,
    marketId,
    userId : users.userId
  };
  this.placebetService.getFancyChart(fancyObj).subscribe(resPlacebet => {
    this.chart.show();
    if (resPlacebet.status == true) {
      if (resPlacebet.data.length > 0) {
        const dataAry = resPlacebet.data;
        let firstIndex = 0;
        let lastIndex = 0;

        dataAry.forEach( (obj, index) => {
          if (index == 0) {
            firstIndex  = obj.odds - 5;
            lastIndex = obj.odds + 5;
          } else {
            if (firstIndex > obj.odds) {
              firstIndex = obj.odds - 5;
            }
            if (lastIndex < obj.odds) {
              lastIndex = obj.odds + 5;
            }
          }
        });
        this.chartAry = [];
        for (let i = firstIndex; i <= lastIndex; i++) {
          let plusAmt = 0;
          let minusAmt = 0;
          let finalAmt = 0;
          dataAry.forEach( (obj, index) => {
            if (obj.runner_type == 'lay') { // client says no
                if (i < obj.odds) {
                  plusAmt = plusAmt + obj.lay;
                } else {
                  minusAmt = minusAmt + obj.back;
                }
              } else {
                if (i >= obj.odds) {
                  plusAmt = plusAmt + obj.back;
                } else {
                  minusAmt = minusAmt + obj.lay;
                }
              }
          });
          finalAmt = plusAmt + minusAmt;
          const finalChart = {
                number : i,
                amount : finalAmt.toFixed(2)
          };
          this.chartAry.push(finalChart);
        }
        $('.fancy-main-chart-div').toggleClass('active');
        this.spinner.hide();
    } else {
      this.chartAry = [];
      $('.fancy-main-chart-div').toggleClass('active');
      this.spinner.hide();
    }
  } else {
    this.chartAry = [];
    $('.fancy-main-chart-div').toggleClass('active');
    this.spinner.hide();
  }
});
}

  /*
    Developer: RK
    Date: 26-04-2020
    title: get latest exposure
    Use: This function is use to get latest exposure
  */
 getLatestExposer(device= '') {
  let odds = $('#oddsInput').val();
  let rate = $('#stackInput').val();
  let team = $('#placebet').data('team');
  let runner_type = $('#placebet').data('data-runner-type');

  if (device) {
    odds = $('#oddsInputMob').val();
    rate = $('#stackInputMob').val();
    team = $('#placebetMob').data('team');
    runner_type = $('#placebetMob').data('data-runner-type');
  }
  const oldExpo = this.matchOddsData[0].exposer;
  let layVal = 0;
  let backVal = 0;
  let calExp = 0;
  if (runner_type == 'lay') {
      calExp =  (Number(rate) * (Number(odds) - 1));
      layVal =  Number(rate) * 1;
      backVal = calExp * -1;
  } else {
      calExp =  (Number(rate) * (Number(odds) - 1));
      layVal = Number(rate) * -1;
      backVal = calExp;
  }
  const  minProfit = (runner_type == 'lay') ? Math.round(backVal) : Math.round(layVal);
  const  maxProfit = (runner_type == 'lay') ? Math.round(layVal) : Math.round(backVal);
  this.currentTranPro = maxProfit;
  if (oldExpo) {
    if (oldExpo.runners.length > 0) {
    oldExpo.runners.forEach( (obj, index) => {
      let amount = 0;
      if (obj.runners.selectionId == team.selectionId) {
          if (runner_type == 'lay') { // client loss
            amount = obj.amount + minProfit;
          } else { // client win
            amount = obj.amount + maxProfit;
          }
        } else {
          if (runner_type == 'lay') { // client win
            amount = obj.amount + maxProfit;
          } else { // client loss
            amount = obj.amount + minProfit;
          }
        }

      if (amount < 0) {
      $( '#' + obj.runners.selectionId ).removeClass(' text-success float-right').addClass( ' text-danger float-right' );
      $('#' + obj.runners.selectionId).html(String(amount));
      if (device) {
          $( '#' + obj.runners.selectionId + '_mob' ).removeClass(' text-success float-right').addClass( ' text-danger float-right' );
          $('#' + obj.runners.selectionId + '_mob').html(String(amount));
        }
      } else {
        $( '#' + obj.runners.selectionId ).removeClass(' text-danger float-right').addClass( ' text-success float-right' );
        $('#' + obj.runners.selectionId).html(String(amount));
        if (device) {
          $( '#' + obj.runners.selectionId + '_mob' ).removeClass(' text-danger float-right').addClass( ' text-success float-right' );
          $('#' + obj.runners.selectionId + '_mob').html(String(amount));
        }
      }
      });
    } else {
      const gameRunner = this.matchOddsData[0].runners;
      gameRunner.forEach( (obj, index) => {
        let amount = 0;
        const prevClassName = $('#' + obj.selectionId).attr('class').split(' ')[1];
        if (prevClassName) {
          $('#' + obj.selectionId).removeClass('float-right ' + prevClassName);
        }
        if (obj.selectionId == team.selectionId) {
          if (runner_type == 'lay') { // client loss
            amount = minProfit;
          } else { // client win
            amount = maxProfit;
          }
        } else {
          if (runner_type == 'lay') { // client win
            amount =  maxProfit;
          } else { // client loss
            amount = minProfit;
          }
        }
        // const className = (amount < 0) ? 'text-danger' : 'text-success';
        // $('#' + obj.selectionId ).addClass( 'float-right ' + className );
        // $('#' + obj.selectionId).html(String(amount));
        // if (device) {
        //   $( '#' + obj.runners.selectionId + '_mob' ).addClass( 'float-right ' + className );
        //   $('#' + obj.runners.selectionId + '_mob').html(String(amount));
        // }

        if (amount < 0) {
          $( '#' + obj.selectionId ).removeClass(' text-success text-right float-right').addClass( ' text-danger text-right float-right' );
          $('#' + obj.selectionId).html(String(amount));
          if (device) {
            $( '#' + obj.selectionId + '_mob' ).removeClass(' text-success text-right float-right').addClass( ' text-danger text-right float-right' );
            $('#' + obj.selectionId + '_mob').html(String(amount));
          }
        } else {
          $( '#' + obj.selectionId ).removeClass(' text-danger text-right float-right').addClass( ' text-success text-right float-right' );
          $('#' + obj.selectionId).html(String(amount));
          if (device) {
            $( '#' + obj.selectionId + '_mob' ).removeClass(' text-danger text-right float-right').addClass( ' text-success text-right float-right' );
            $('#' + obj.selectionId + '_mob').html(String(amount));
          }
        }

      });
    }
  }
 }

  /*
  Developer: RK
  Date: 26-04-2020
  title: get latest exposure fancy
  Use: This function is use to get latest exposure fancy
 */

 getLatestExposerFancy(device= '', marketType) {
  let odds = $('#oddsInput').val();
  let rate = Number($('#stackInput').val());
  let runner_type = $('#placebet').data('data-runner-type');
  let volume = Number($('#placebet').data('data-volume'));
  if (device) {
    odds = $('#oddsInputMob').val();
    rate = Number($('#stackInputMob').val());
    runner_type = $('#placebetMob').data('data-runner-type');
    volume = Number($('#placebetMob').data('data-volume'));
   }
  let backVal = 0;
  let layVal = 0;
  let calExp = 0;
  if (marketType == 'line') {
    volume = 100;
  }

  if (runner_type == 'lay') {
        calExp =  (rate * volume) / 100;
        backVal = calExp * -1;
        layVal = rate;
    } else {
        const calExp =  (rate * volume) / 100;
        layVal = rate * -1;
        backVal = calExp;
    }
  const tranMin = (runner_type == 'lay') ? backVal : layVal;
  const tranMax = (runner_type == 'lay') ? layVal : backVal;
  this.currentTranPro = tranMax;
 }

  /*
    Developer: RK
    Date: 26-04-2020
    title: get latest exposure
    Use: This function is use to get latest exposure
  */
 getLatestExposerBm(device= '') {
  let odds = $('#oddsInput').val();
  let rate = $('#stackInput').val();
  let team = $('#placebet').data('team');
  let gameId = $('#placebet').data("data-game-id")
  let runner_type = $('#placebet').data('data-runner-type');

  if (device) {
    odds = $('#oddsInputMob').val();
    rate = $('#stackInputMob').val();
    team = $('#placebetMob').data('team');
    runner_type = $('#placebetMob').data('data-runner-type');
    gameId = $('#placebetMob').data("data-game-id")
  }

  let bookMakerDetail = this.bookmakerData.find(o => o.marketId == gameId);
  const oldExpo = bookMakerDetail.exposer;

  let layVal = 0;
  let backVal = 0;
  let calExp = 0;
  if (runner_type == 'lay') {
      calExp =  (Number(rate) * (Number(odds)/100));
      layVal =  Number(rate) * 1;
      backVal = calExp * -1;
  } else {
      calExp =  (Number(rate) * (Number(odds)/100));
      layVal = Number(rate) * -1;
      backVal = calExp;
  }

  const  minProfit = (runner_type == 'lay') ? Math.round(backVal) : Math.round(layVal);
  const  maxProfit = (runner_type == 'lay') ? Math.round(layVal) : Math.round(backVal);
  this.currentTranPro = maxProfit;
  if (oldExpo) {
    if (oldExpo.runners.length > 0) {
    oldExpo.runners.forEach( (obj, index) => {
      let amount = 0;
      if (obj.runners.selectionId == team.selectionId) {
          if (runner_type == 'lay') { // client loss
            amount = obj.amount + minProfit;
          } else { // client win
            amount = obj.amount + maxProfit;
          }
        } else {
          if (runner_type == 'lay') { // client win
            amount = obj.amount + maxProfit;
          } else { // client loss
            amount = obj.amount + minProfit;
          }
        }

      if (amount < 0) {
      $( '#' + obj.runners.selectionId + "_bm" ).removeClass(' text-success float-right').addClass( ' text-danger float-right' );
      $('#' + obj.runners.selectionId + "_bm").html(String(amount));
      if (device) {
          $( '#' + obj.runners.selectionId +  "_bm" + '_mob' ).removeClass(' text-success float-right').addClass( ' text-danger float-right' );
          $('#' + obj.runners.selectionId  +  "_bm" + '_mob').html(String(amount));
        }
      } else {
        $( '#' + obj.runners.selectionId + "_bm"  ).removeClass(' text-danger float-right').addClass( ' text-success float-right' );
        $('#' + obj.runners.selectionId  + "_bm").html(String(amount));
        if (device) {
          $( '#' + obj.runners.selectionId + "_bm" + '_mob' ).removeClass(' text-danger float-right').addClass( ' text-success float-right' );
          $('#' + obj.runners.selectionId +  "_bm" + '_mob').html(String(amount));
        }
      }
      });
    } else {
      const gameRunner = bookMakerDetail.runners;
      gameRunner.forEach( (obj, index) => {
        let amount = 0;
        const prevClassName = $('#' + obj.selectionId).attr('class').split(' ')[1];
        if (prevClassName) {
          $('#' + obj.selectionId).removeClass('float-right ' + prevClassName);
        }
        if (obj.selectionId == team.selectionId) {
          if (runner_type == 'lay') { // client loss
            amount = minProfit;
          } else { // client win
            amount = maxProfit;
          }
        } else {
          if (runner_type == 'lay') { // client win
            amount =  maxProfit;
          } else { // client loss
            amount = minProfit;
          }
        }

        if (amount < 0) {
          $( '#' + obj.selectionId + "_bm" ).removeClass(' text-success text-right float-right').addClass( ' text-danger text-right float-right' );
          $('#' + obj.selectionId + "_bm").html(String(amount));
          if (device) {
            $( '#' + obj.selectionId + "_bm" +  '_mob' ).removeClass(' text-success text-right float-right').addClass( ' text-danger text-right float-right' );
            $('#' + obj.selectionId + "_bm" + '_mob').html(String(amount));
          }
        } else {
          $( '#' + obj.selectionId + "_bm" ).removeClass(' text-danger text-right float-right').addClass( ' text-success text-right float-right' );
          $('#' + obj.selectionId + "_bm").html(String(amount));
          if (device) {
            $( '#' + obj.selectionId + "_bm" + '_mob' ).removeClass(' text-danger text-right float-right').addClass( ' text-success text-right float-right' );
            $('#' + obj.selectionId + "_bm" + '_mob').html(String(amount));
          }
        }

      });
    }
  }
 }

   /*
  Developer: RK
  Date: 26-04-2020
  title: get latest exposure on key
  Use: This function is use to get latest exposure on key up
 */

calculateExposerOnkey(value, device = '') {
  const marketType = $('#placebet').data('data-market-type');
  if (marketType == 'market') {
    this.getLatestExposer(device);
  }
  if (marketType == 'fancy' ||  marketType == 'line') {
    this.getLatestExposerFancy(device, marketType);
  }
  if (marketType == 'bookmaker') {
    this.getLatestExposerBm(device);
  }
}



  /*
    Developer: RT
    Date: 02-04-2020
    title: Lock Game Status
    Use: This function is use to Disable lock game
  */

  checkLockGame(data) {
    this.lockGameService.findRecordExist(data)
      .subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        if (response && (response.data)) {
          this.lockGame = true;
        } else {
          this.lockGame = false;
        }
      }, error => {
        console.error('error in check lock game record');
      });
  }

  /**
   * @author TR
   * @date : 04-06-2020
   * get Currency
   */
  getUserCurrency() {
    const data = {
      userId : this.utilityService.returnLocalStorageData('userId')
    };
    this.currencyService.getUserCurrency(data).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.currencyAll = response.data[0];
    });
  }

  minus() {
    this.stack--;
  }
  plus() {
    this.stack++;
  }

  openViewbestFancy(fancyId, name) {
    this.fancyName = name;
    this.betview.show();
    const userId = this.utilityService.returnLocalStorageData('userId');

    const Obj = {
        marketId: this.marketId,
        userId,
        fancyId,
        gameType: 'fancy'
      };
    this.getAllTransactionAsMactch(Obj);
  }

  openViewbestLine(lineId, name) {
    this.lineName = name;
    this.betviewLine.show();
    const userId = this.utilityService.returnLocalStorageData('userId');

    const Obj = {
        marketId: this.marketId,
        userId,
        lineId,
        gameType: 'Line'
      };
    this.getAllTransactionAsLine(Obj);
  }


  closeModal() {
    this.betview.hide();
    this.betviewLine.hide();
    this.chart.hide();
    this.betviewMatchOdds.hide();
    this.betviewall.hide();
  }
  playAudio() {
    const audio = new Audio();
    audio.src = '../../../assets/audio/notification-1.ogg';
    audio.load();
    audio.play();
  }

  allBet() {
    this.betviewall.show();
    const transactionObjData = {
      marketId: this.marketId,
      userId: this.userId,
      gameId: this.marketId,
      dataLimit: 'Allbet',
    };

    this.marketService.getAllTransactions(transactionObjData).subscribe(response => {
        response = this.utilityService.gsk(response.auth);
        response = JSON.parse(response);
        if (response.status == true) {
          this.allTransactions = response.data;
        }
      });
  }

  allMatchOdds() {
    this.betviewMatchOdds.show();

    const Obj = {
      marketId: this.marketId,
      userId: this.userId,
      gameType: 'market'
    };
    this.marketService.getAllTransactionsAsMatchOdds(Obj).subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      if (response.status) {
        this.allTransactionsAsMatchOdds = response.data;
      }
    });
  }

  appendFancyRateAuto(response) {
    const fancyId = response.srno;
    if (response.status == '1') {
      appendStatus(response.srno, 'ballstart');
    } else if (response.status == '2') {
      appendStatus(response.srno, 'suspend');
    } else {
      appendStatus(response.srno, 'active');
      if (response.rates) {
            $('#' + fancyId + '_third').hide(), $('#mob_' + fancyId + '_third').hide();
            $('#' + fancyId + '_first').hide(), $('#mob_' + fancyId + '_first').hide();
            $('#' + fancyId + '_forth').hide(), $('#mob_' + fancyId + '_forth').hide();


            for (const [key, value] of Object.entries(response.rates)) {
          if (key == '0') {
            $('#no2_' + fancyId).html(value['rate_1']), $('#mob_no2_' + fancyId).html(value['rate_1']);
            $('#no2Vol_' + fancyId).html(value['value_1']), $('#mob_no2Vol_' + fancyId).html(value['value_1']);
            $('#yes2_' + fancyId).html(value['rate_2']), $('#mob_yes2_' + fancyId).html(value['rate_2']);
            $('#yes2Vol_' + fancyId).html(value['value_2']), $('#mob_yes2Vol_' + fancyId).html(value['value_2']);
            $('#' + fancyId + '_second').show(), $('#mob_' + fancyId + '_second').show();
          }
          if (key == '1') {
            $('#no1_' + fancyId).html(value['rate_1']), $('#mob_no1_' + fancyId).html(value['rate_1']);
            $('#no1Vol_' + fancyId).html(value['value_1']), $('#mob_no1Vol_' + fancyId).html(value['value_1']);
            $('#yes1_' + fancyId).html(value['rate_2']), $('#mob_yes1_' + fancyId).html(value['rate_2']);
            $('#yes1Vol_' + fancyId).html(value['value_2']), $('#mob_yes1Vol_' + fancyId).html(value['value_2']);
            $('#' + fancyId + '_first').show(), $('#mob_' + fancyId + '_first').show();
          }
          if (key == '2') {
            $('#no3_' + fancyId).html(value['rate_1']), $('#mob_no3_' + fancyId).html(value['rate_1']);
            $('#no3Vol_' + fancyId).html(value['value_1']), $('#mob_no3Vol_' + fancyId).html(value['value_1']);
            $('#yes3_' + fancyId).html(value['rate_2']), $('#mob_yes3_' + fancyId).html(value['rate_2']);
            $('#yes3Vol_' + fancyId).html(value['value_2']), $('#mob_yes3Vol_' + fancyId).html(value['value_2']);
            $('#' + fancyId + '_third').show(), $('#mob_' + fancyId + '_third').show();
          }
          if (key == '3') {
            $('#no4_' + fancyId).html(value['rate_1']), $('#mob_no4_' + fancyId).html(value['rate_1']);
            $('#no4Vol_' + fancyId).html(value['value_1']), $('#mob_no4Vol_' + fancyId).html(value['value_1']);
            $('#yes4_' + fancyId).html(value['rate_2']), $('#mob_yes4_' + fancyId).html(value['rate_2']);
            $('#yes4Vol_' + fancyId).html(value['value_2']), $('#mob_yes4Vol_' + fancyId).html(value['value_2']);
            $('#' + fancyId + '_forth').show(), $('#mob_' + fancyId + '_forth').show();
          }
        }
      } else {
        appendStatus(response.srno, 'suspend');
      }
    }
  }


  appendBMRateAuto(bookmakerObj,response) {
    const bookmakerId = response.srno;
      bookmakerObj.runners.map(res => {
        if (response.status == '1') {
          appendStatusBM(res.selectionId, 'ballstart');
        } else if (response.status == '2') {
          appendStatusBM(res.selectionId, 'suspend');
          $("#" + res.selectionId + "_back_odds").html(''),$("#" + res.selectionId + "_back_odds_mob").html('');              ;
          $("#" + res.selectionId + "_lay_odds").html(''),$("#" + res.selectionId + "_lay_odds_mob").html('');
          $("#" + res.selectionId + "_back_vol").html(''),$("#" + res.selectionId + "_back_vol_mob").html('');
          $("#" + res.selectionId + "_lay_vol").html(''),$("#" + res.selectionId + "_lay_vol_mob").html('');
        } else {
          appendStatusBM(res.selectionId, 'active');
          if(response['team'] == "D"){
              appendStatusBM(res.selectionId, 'suspend');
                let splitAry = response['selectid'].split(',');
                splitAry.map(selId => {
                  appendStatusBM(selId, 'active');
                    if(response['rates']){
                        $("#" + selId + "_back_odds").html(response['rates']['0']['rate_1']),$("#" + selId + "_back_odds_mob").html(response['rates']['0']['rate_1']);
                         $("#" + selId + "_lay_odds").html(''),$("#" + selId + "_lay_odds_mob").html('');
                        $("#" + selId + "_back_vol").html(bookmakerObj['bookmakerSetting']['maxStack']),$("#" + selId + "_back_vol_mob").html(bookmakerObj['bookmakerSetting']['maxStack']);
                        $("#" + selId + "_lay_vol").html(''),$("#" + selId + "_lay_vol_mob").html('');
                    }
                  })
          }else{
            if(res.selectionId == response['selectid']){
              if(response['rates']){
                $("#" + res.selectionId + "_back_odds").html(response['rates']['0']['rate_1']),$("#" + res.selectionId + "_back_odds_mob").html(response['rates']['0']['rate_1']);              ;
                $("#" + res.selectionId + "_lay_odds").html(response['rates']['0']['rate_2']),$("#" + res.selectionId + "_lay_odds_mob").html(response['rates']['0']['rate_2']);
                $("#" + res.selectionId + "_back_vol").html(bookmakerObj['bookmakerSetting']['maxStack']),$("#" + res.selectionId + "_back_vol_mob").html(bookmakerObj['bookmakerSetting']['maxStack']);
                $("#" + res.selectionId + "_lay_vol").html(bookmakerObj['bookmakerSetting']['maxStack']),$("#" + res.selectionId + "_lay_vol_mob").html(bookmakerObj['bookmakerSetting']['maxStack']);
              }
            }else{
              $("#" + res.selectionId + "_back_odds").html(''),$("#" + res.selectionId + "_back_odds_mob").html('');              ;
              $("#" + res.selectionId + "_lay_odds").html(''),$("#" + res.selectionId + "_lay_odds_mob").html('');
              $("#" + res.selectionId + "_back_vol").html(''),$("#" + res.selectionId + "_back_vol_mob").html('');
              $("#" + res.selectionId + "_lay_vol").html(''),$("#" + res.selectionId + "_lay_vol_mob").html('');
            // $("#" + res.selectionId + "_bookmaker").addClass('market_suspend');
              appendStatusBM(res.selectionId, 'suspend');
            }
          }
        }
      });
  }

  /**
   * @author TR
   * @date : 19-02-2021
   * getbookMaker Latest Rate
   */

  getbookMakerLatest(id ,data) {
    this.marketService.getBookmakerRateRedis(id).subscribe(response => {
      if (response.status == true) {
        response.data.runners.map(res => {
          if (res && res.selectionId) {
             $('#' + res.selectionId + '_bookmaker').removeClass('market_suspend');
            $('#' + res.selectionId + '_back_odds').html(res.back);
            $('#' + res.selectionId + '_lay_odds').html(res.lay);
          }else {
             // $('#' + res.selectionId + '_bookmaker').addClass('market_suspend');
          }
          if(data[0].marketStatus.name === 'ballstart') {
            appendStatusBM(res.selectionId, 'ballstart');
          }
        });
      }
    });

  }

  /**
   * @author TR
   * @date : 19-02-2021
   * close placebet model
   */

  closePlacebetModel(){
    this.resetTempExp();
    this.placeBetModel.hide();
  }

  /**
   * @author TR
   * @date : 12-03-2021
   * open live tv
   */

  liveTvClick(){
    this.tvFeet = (this.tvFeet == true) ? false : true;
    if(this.tvFeet == true){
      let liveTv_feed = (typeof this.channelUrl === "undefined" || this.channelUrl.substring(0, this.channelUrl.indexOf('//'))) ? this.channelUrl :  _.isNumber(Number(this.channelUrl));

      if(liveTv_feed && !isUndefined(liveTv_feed)){
        this.marketService.liveTvFeed(this.channelUrl).subscribe(response => {
          if(response){
            this.channelFeed = response.data;
            $('.LiveTvFeed').html( this.channelFeed);
          }
        });
      }else {
        if (this.channelUrl !== '' && !isUndefined(this.channelUrl)) {
          this.safeSrcimg = 'not';
          this.safeSrc =  this.sanitizer.bypassSecurityTrustResourceUrl(this.channelUrl);
        } else {
          this.safeSrc = 'not';
          this.safeSrcimg = 'http://img.youtube.com/vi/YOURVIDEOID/maxresdefault.jpg';
        }
      }
    }else{
      let liveTv_feed = 5000000;

      if(liveTv_feed && !isUndefined(liveTv_feed)){
        this.marketService.liveTvFeed(liveTv_feed).subscribe(response => {
          if(response){
            this.channelFeed = response.data;
            $('.LiveTvFeed').html( this.channelFeed);
          }
        });
      }else {
        if (this.channelUrl !== '' && !isUndefined(this.channelUrl)) {
          this.safeSrcimg = 'not';
          this.safeSrc =  this.sanitizer.bypassSecurityTrustResourceUrl(this.channelUrl);
        } else {
          this.safeSrc = 'not';
          this.safeSrcimg = 'http://img.youtube.com/vi/YOURVIDEOID/maxresdefault.jpg';
        }
      }
    }
  }
}

/**
 * @author TR
 * @date : 19-02-2021
 * append status for fancy manual and auto
 */

function appendStatus(fancyId, status) {
  if (status == 'ballstart') {
    $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId +  ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
    $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

    //$('#' + fancyId +  '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId +  '_first,#mob_' + fancyId + '_third,#mob_' + fancyId + '_forth').hide();
    $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');
    $('#' + fancyId + '_second').addClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').addClass('fancy_ballstart');
  }
  if (status && status.name === 'Close') {
    $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId + ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
    $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId  + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

   // $('#' + fancyId +  '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId +  '_first,#mob_' + fancyId + '_third,#mob_' + fancyId + '_forth').hide();
    $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');
    $('#' + fancyId + '_second').addClass('fancy_close'), $('#mob_' + fancyId + '_second').addClass('fancy_close');
  }
  if (status == 'suspend') {
    $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId + ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
    $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId  + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

    //$('#' + fancyId +  '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId +  '_first,#mob_' + fancyId + '_third,#mob_' + fancyId + '_forth').hide();        $('#' + fancyId + '_second').removeClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').removeClass('fancy_ballstart');
    $('#' + fancyId + '_second').addClass('fancy_suspend'), $('#mob_' + fancyId + '_second').addClass('fancy_suspend');
  }
  if (status == 'settled') {
    $('#no1_' + fancyId + ',#no1Vol_' + fancyId + ',#yes1_' + fancyId + ',#yes1Vol_' + fancyId + ',#no2_' + fancyId + ',#no2Vol_' + fancyId + ',#yes2_' + fancyId + ',#yes2Vol_' + fancyId + ',#no3_' + fancyId + ',#no3Vol_' + fancyId + ',#yes3_' + fancyId + ',#yes3Vol_' + fancyId + ',#no4_' + fancyId + ',#no4Vol_' + fancyId + ',#yes4_' + fancyId + ',#yes4Vol_' + fancyId + '').html('');
    $('#mob_no1_' + fancyId + ',#mob_no1Vol_' + fancyId + ',#mob_yes1_' + fancyId + ',#mob_yes1Vol_' + fancyId + ',#mob_no2_' + fancyId + ',#mob_no2Vol_' + fancyId + ',#mob_yes2_' + fancyId + ',#mob_yes2Vol_' + fancyId + ',#mob_no3_' + fancyId + ',#mob_no3Vol_' + fancyId + ',#mob_yes3_' + fancyId + ',#mob_yes3Vol_' + fancyId  + ',#mob_no4_' + fancyId + ',#mob_no4Vol_' + fancyId + ',#mob_yes4_' + fancyId + ',#mob_yes4Vol_' + fancyId + '').html('');

    //$('#' + fancyId +  '_first,#' + fancyId + '_third,#' + fancyId + '_forth').hide(), $('#mob_' + fancyId +  '_first,#mob_' + fancyId + '_third,#mob_' + fancyId + '_forth').hide();        $('#' + fancyId + '_second').removeClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').removeClass('fancy_ballstart');
    $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');

    $('#' + fancyId + '_second').addClass('fancy_settled'), $('#mob_' + fancyId + '_second').addClass('fancy_settled');
  }
  if (status == 'active') {
    $('#' + fancyId + '_second').removeClass('fancy_ballstart'), $('#mob_' + fancyId + '_second').removeClass('fancy_ballstart');
    $('#' + fancyId + '_second').removeClass('fancy_suspend'), $('#mob_' + fancyId + '_second').removeClass('fancy_suspend');
  }
}

/**
 * @author TR
 * @date : 19-02-2021
 * append Rate for fancy manual and auto
 */

function appendRate(response) {
  if (response && response.type == 'line') {
    const lineId = response.lineId.toString().replace('.', '');
    if (response.no2 != '' && response.yes2 != '' && response.lineId ) {
      // Line market append live rate for manual
      $('#' + lineId + '_lay').html(response.no2), $('#mob_' + lineId + '_lay').html(response.no2);
      $('#' + lineId + '_back').html(response.yes2Vol), $('#mob_' + lineId + '_back').html(response.yes2Vol);
      $('#' + lineId + '_lay_vol').html(response.no2Vol), $('#mob_' + lineId + '_lay_vol').html(response.no2Vol);
      $('#' + lineId + '_back_vol').html(response.yes2), $('#mob_' + lineId + '_back_vol').html(response.yes2);
    }
  }
  const fancyId =  response && response.fancyId;
  $('#' + fancyId + '_third').hide(), $('#mob_' + fancyId + '_third').hide();
  $('#' + fancyId + '_first').hide(), $('#mob_' + fancyId + '_first').hide();
  $('#' + fancyId + '_forth').hide(), $('#mob_' + fancyId + '_forth').hide();

  if (response.no1 != '' && response.yes1 != '' ) {
    $('#' + fancyId + '_first').show(), $('#mob_' + fancyId + '_first').show();
    $('#no1_' + fancyId).html(response.no1), $('#mob_no1_' + fancyId).html(response.no1);
    $('#no1Vol_' + fancyId).html(response.no1Vol), $('#mob_no1Vol_' + fancyId).html(response.no1Vol);
    $('#yes1_' + fancyId).html(response.yes1), $('#mob_yes1_' + fancyId).html(response.yes1);
    $('#yes1Vol_' + fancyId).html(response.yes1Vol), $('#mob_yes1Vol_' + fancyId).html(response.yes1Vol);
  }
  if (response.no2 != '' && response.yes2 != '' ) {
    // Fancy market append live rate for manual
    $('#no2_' + fancyId).html(response.no2), $('#mob_no2_' + fancyId).html(response.no2);
    $('#no2Vol_' + fancyId).html(response.no2Vol), $('#mob_no2Vol_' + fancyId).html(response.no2Vol);
    $('#yes2_' + fancyId).html(response.yes2), $('#mob_yes2_' + fancyId).html(response.yes2);
    $('#yes2Vol_' + fancyId).html(response.yes2Vol), $('#mob_yes2Vol_' + fancyId).html(response.yes2Vol);
    $('#' + fancyId + '_second').show(), $('#mob_' + fancyId + '_second').show();
  }
  if (response.no3 != '' && response.yes3 != '' ) {
    $('#' + fancyId + '_third').show(), $('#mob_' + fancyId + '_third').show();
    $('#no3_' + fancyId).html(response.no3), $('#mob_no3_' + fancyId).html(response.no3);
    $('#no3Vol_' + fancyId).html(response.no3Vol), $('#mob_no3Vol_' + fancyId).html(response.no3Vol);
    $('#yes3_' + fancyId).html(response.yes3), $('#mob_yes3_' + fancyId).html(response.yes3);
    $('#yes3Vol_' + fancyId).html(response.yes3Vol), $('#mob_yes3Vol_' + fancyId).html(response.yes3Vol);
  }
}

/**
 * @author TR
 * @date : 19-02-2021
 * appendStatusLine manual and auto
 */

 function appendStatusLine(marketId, status) {

  if (status == 'ballstart') {
    $('#' + marketId + '_lay' + ',#' + marketId + '_back' + ',#' + marketId + '_lay_mob' + ',#' + marketId + '_back_mob').html('');
    $('#' + marketId + '_lay_vol' + ',#' + marketId + '_back_vol' + ',#' + marketId + '_lay_mob_vol' + ',#' + marketId + '_back_mob_vol' ).html('');
    $('#' + marketId + '_line').removeClass('fancy_suspend'), $('#' + marketId + '_mob_line').removeClass('fancy_suspend');
    $('#' + marketId + '_line').addClass('fancy_ballstart'), $('#' + marketId + '_mob_line').addClass('fancy_ballstart');
  }
  if (status == 'suspend') {
    // $('#' + marketId + '_lay' + ',#' + marketId + '_back' + ',#' + marketId + '_lay_mob' + ',#' + marketId + '_back_mob').html('');
    // $('#' + marketId + '_lay_vol' + ',#' + marketId + '_back_vol' + ',#' + marketId + '_lay_mob_vol' + ',#' + marketId + '_back_mob_vol' ).html('');
    $('#' + marketId + '_line').removeClass('fancy_ballstart'), $('#' + marketId + '_mob_line').removeClass('fancy_ballstart');
    $('#' + marketId + '_line').addClass('fancy_suspend'), $('#' + marketId + '_mob_line').addClass('fancy_suspend');
  }
  if (status == 'settled') {
    $('#' + marketId + '_lay' + ',#' + marketId + '_back' + ',#' + marketId + '_lay_mob' + ',#' + marketId + '_back_mob').html('');
    $('#' + marketId + '_lay_vol' + ',#' + marketId + '_back_vol' + ',#' + marketId + '_lay_mob_vol' + ',#' + marketId + '_back_mob_vol' ).html('');
    $('#' + marketId + '_line').addClass('fancy_settled'), $('#' + marketId + '_mob_line').addClass('fancy_settled');
  }
  if (status == 'active') {
    $('#' + marketId + '_line').removeClass('fancy_ballstart'), $('#' + marketId + '_line').removeClass('fancy_suspend');
    $('#' + marketId + '_mob_line').removeClass('fancy_ballstart'), $('#' + marketId + '_mob_line').removeClass('fancy_suspend');
  }
  if (status == 'Open') {
    $('#' + marketId + '_line').removeClass('fancy_ballstart'), $('#' + marketId + '_line').removeClass('fancy_suspend');
    $('#' + marketId + '_mob_line').removeClass('fancy_ballstart'), $('#' + marketId + '_mob_line').removeClass('fancy_suspend');
  }
}

/**
 * @author TR
 * @date : 19-02-2021
 * appendStatusBM manual and auto
 */

 function appendStatusBM(teamID,status){
  $("#" + teamID + "_bookmaker").removeClass('bookmaker_ballstart'),$("#" + teamID + "_bookmaker_mob").removeClass('bookmaker_ballstart');
  $("#" + teamID + "_bookmaker").removeClass('market_suspend'),$("#" + teamID + "_bookmaker_mob").removeClass('market_suspend');

  if (status == 'ballstart') {
    $("#" + teamID + "_bookmaker").addClass('bookmaker_ballstart'),$("#" + teamID + "_bookmaker_mob").addClass('bookmaker_ballstart');
  }
  if (status == 'suspend') {
    $("#" + teamID + "_bookmaker").addClass('market_suspend'),$("#" + teamID + "_bookmaker_mob").addClass('market_suspend');
  }
}


