import { Component, OnInit } from '@angular/core';
import {NgxSpinnerService} from 'ngx-spinner';
import {SocketServiceRedis} from '../../globals/socketServiceRedis';
import {SocketServiceClient} from '../../globals/socketServiceClient';
import {UtilityService} from '../../globals/utilityService';
import {MarketService} from '../../services/market.service';
import {SocketService} from '../../globals/socketService';
declare  let _: any;

@Component({
  selector: 'app-inplay-view',
  templateUrl: './inplay-view.component.html',
  styleUrls: ['./inplay-view.component.scss']
})
export class InplayViewComponent implements OnInit {

  getAllMarkets = [];
  getAllMatches = [];
  getAllSports = [];
  selectedUniqIndx: any;
  constructor(private marketService: MarketService , private spinner: NgxSpinnerService, private utilityService: UtilityService , private socketService: SocketService, private socketServiceClient: SocketServiceClient, private socketServiceRedis: SocketServiceRedis) { }

  ngOnInit() {
    this.selectedUniqIndx = 0;
    this.getAllMatchData();
    this.socketService
      .changeFlag()
      .subscribe((response) => {
        if(response){
          setTimeout(res =>{
            this.getAllMatchData();
          },2000)
        }
      });

    this.socketServiceClient
      .marketCreate()
      .subscribe((response) => {
        if(response){
          this.getAllMatchData();
        }
      });

    this.socketServiceClient
      .updateSport()
      .subscribe((response) => {
        if(response){
          this.getAllMatchData();
        }
      });

    this.socketServiceClient
      .updateTournament()
      .subscribe((response) => {
        if(response){
          this.getAllMatchData();
        }
      });

    this.socketServiceClient
      .updateMatch()
      .subscribe((response) => {
        if(response){
          this.getAllMatchData();
        }
      });

    this.socketServiceRedis
      .oddsRate()
      .subscribe((response) => {
        if (response) {
          if (response.status == 'OPEN') {
            const linerMarId = response.marketId;
            let marketId = response.marketId.toString().replace('.', '');
            let runtypes = response.runners;
            $("#" + marketId + "_back_1_odds").html((runtypes[0].ex.availableToBack[0].price) ? runtypes[0].ex.availableToBack[0].price : '-');
            $("#" + marketId + "_lay_1_odds").html((runtypes[0].ex.availableToLay[0].price) ? runtypes[0].ex.availableToLay[0].price : '-');
            if (response.numberOfActiveRunners == 3) {
              $("#" + marketId + "_back_3_odds").html((runtypes[1].ex.availableToBack[0].price) ? runtypes[1].ex.availableToBack[0].price : '-');
              $("#" + marketId + "_lay_3_odds").html((runtypes[1].ex.availableToLay[0].price) ? runtypes[1].ex.availableToLay[0].price : '-');
              $("#" + marketId + "_back_2_odds").html((runtypes[2].ex.availableToBack[0].price) ? runtypes[2].ex.availableToBack[0].price : '-');
              $("#" + marketId + "_lay_2_odds").html((runtypes[2].ex.availableToLay[0].price) ? runtypes[2].ex.availableToLay[0].price : '-');
            } else {
              if(runtypes[1] && runtypes[1].ex){
                $("#" + marketId + "_back_3_odds").html((runtypes[1].ex.availableToBack[0].price) ? runtypes[1].ex.availableToBack[0].price : '-');
                $("#" + marketId + "_lay_3_odds").html((runtypes[1].ex.availableToLay[0].price) ? runtypes[1].ex.availableToLay[0].price : '-');
              }
            }
          }
        }
      });
  }
  getAllMatchData() {
    this.marketService.getAllMatchInMarket().subscribe(response => {
      response = this.utilityService.gsk(response.auth);
      response = JSON.parse(response);
      this.getAllMarkets = response.data;
      console.log(this.getAllMarkets)
      this.getAllMarkets.map(marketLoop =>{
        marketLoop.doc = marketLoop.doc.map(firstLoop =>{
          firstLoop.data.map(secondLoop =>{
            console.log(secondLoop.marketId)
            if(secondLoop.marketId && secondLoop.marketId.length > 0) {
              secondLoop.marketIdDec = secondLoop.marketId[0].toString().replace('.', '');
              this.socketServiceRedis.joinRoom(secondLoop.marketId[0]);
            }
          });
          return firstLoop;
        });
        return marketLoop;
      });
    });
  }
}
