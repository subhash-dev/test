import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InplayViewComponent } from './inplay-view.component';

describe('InplayViewComponent', () => {
  let component: InplayViewComponent;
  let fixture: ComponentFixture<InplayViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InplayViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InplayViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
