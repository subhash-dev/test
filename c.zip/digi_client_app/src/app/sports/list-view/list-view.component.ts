import {Component, OnInit} from '@angular/core';
import {MarketService} from "../../services/market.service";
import {SocketService} from "../../globals/socketService";
import {NgxSpinnerService} from "ngx-spinner";
import {SocketServiceRedis} from '../../globals/socketServiceRedis';
import {UtilityService} from '../../globals/utilityService';
import {SocketServiceClient} from '../../globals/socketServiceClient';
declare  let _: any;
@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.scss']
})
export class ListViewComponent implements OnInit {

  constructor(private marketService: MarketService , private spinner: NgxSpinnerService, private utilityService: UtilityService , private socketService: SocketService, private socketServiceClient: SocketServiceClient, private socketServiceRedis: SocketServiceRedis) {
  }

  marketFilter = {
    page: 1,
    limit: 10,
    search: null,
    data: null
  };
  getAllMarkets = [];
  getAllMarket = [];
  getAllSports = [];
  selectedUniqIndx: any;

  ngOnInit() {
    // this.socketServiceRedis.disconnect();
    // this.socketServiceRedis.connect();
    this.selectedUniqIndx = 0;
    this.getAllSportsData();
    this.socketService
      .changeFlag()
      .subscribe((response) => {
        if(response){
          setTimeout(res =>{
            this.getAllSportsData();
          },2000)
        }
      });

    this.socketServiceClient
      .marketCreate()
      .subscribe((response) => {
        if(response){
          this.getAllSportsData();
        }
      });

    this.socketServiceClient
      .updateSport()
      .subscribe((response) => {
        if(response){
           this.getAllSportsData();
        }
      });

    this.socketServiceClient
      .updateTournament()
      .subscribe((response) => {
        if(response){
           this.getAllSportsData();
        }
      });

    this.socketServiceClient
      .updateMatch()
      .subscribe((response) => {
        if(response){
           this.getAllSportsData();
        }
      });

      this.socketServiceRedis
      .oddsRate()
      .subscribe((response) => {
        if (response) {
          if (response.status == 'OPEN') {
            const linerMarId = response.marketId;
            let marketId = response.marketId.toString().replace('.', '');
              let runtypes = response.runners;
              $("#" + marketId + "_back_1_odds").html((runtypes[0].ex.availableToBack[0].price) ? runtypes[0].ex.availableToBack[0].price : '-');
              $("#" + marketId + "_lay_1_odds").html((runtypes[0].ex.availableToLay[0].price) ? runtypes[0].ex.availableToLay[0].price : '-');
              if (runtypes.length  > 2) {
                $("#" + marketId + "_back_3_odds").html((runtypes[1].ex.availableToBack[0].price) ? runtypes[1].ex.availableToBack[0].price : '-');
                $("#" + marketId + "_lay_3_odds").html((runtypes[1].ex.availableToLay[0].price) ? runtypes[1].ex.availableToLay[0].price : '-');
                $("#" + marketId + "_back_2_odds").html((runtypes[2].ex.availableToBack[0].price) ? runtypes[2].ex.availableToBack[0].price : '-');
                $("#" + marketId + "_lay_2_odds").html((runtypes[2].ex.availableToLay[0].price) ? runtypes[2].ex.availableToLay[0].price : '-');
              } else {
                if(runtypes[1] && runtypes[1].ex){
                $("#" + marketId + "_back_3_odds").html((runtypes[1].ex.availableToBack[0].price) ? runtypes[1].ex.availableToBack[0].price : '-');
                $("#" + marketId + "_lay_3_odds").html((runtypes[1].ex.availableToLay[0].price) ? runtypes[1].ex.availableToLay[0].price : '-');
              }
              }
          }
        }
      });

  }


  /**
   * @author kc
   * @date : 25-02-2020
   * get all market
   */
  getMarketOdds(data, index) {
    this.spinner.show();
    this.selectedUniqIndx = index;
    this.marketFilter.data = data;
    let userId = this.utilityService.returnLocalStorageData('userId');
    this.marketService.getAllMarket(this.marketFilter , userId).subscribe(response => {
      this.spinner.hide();
      this.getAllMarkets = response.data ;
      this.spinner.hide();
      this.getAllMarkets.map(marketLoop =>{
        marketLoop.doc = marketLoop.doc.map(firstLoop =>{
             firstLoop.data.map(secondLoop =>{
               // firstLoop.data = _.sortBy(firstLoop.data, o => o.matchStatusDetails.displayOrder);
               secondLoop.marketIdDec = secondLoop.marketId.toString().replace('.', '');
              if (secondLoop.marketType == 'Match Odds') {
                let marketId = secondLoop.marketId;
                this.socketServiceRedis.joinRoom(marketId);
              }
            });

          return firstLoop;
        });

        return marketLoop;
      });
      console.log(this.getAllMarkets);
    });
  }

  getAllSportsData() {
    this.marketService.getAllSport().subscribe(response => {
      this.getAllSports = response.data;
      if(this.getAllSports.length > 0){
      this.getMarketOdds(this.getAllSports[0].id, 0);
      }else {
        this.getAllMarkets = [];
      }
    });
  }
}
